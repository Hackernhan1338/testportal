<?php
require_once __DIR__.'/includes/bootstrap.php';
$user=bfCurrentUser($pdo);
if(!$user){header('Location: /login.php');exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
    bfCheckUserCsrf();
    $choice=(string)($_POST['choice']??'skip');
    try{$pdo->prepare("UPDATE bf_users SET onboarding_seen_at=COALESCE(onboarding_seen_at,NOW()) WHERE id=?")->execute([$user['id']]);}catch(Throwable $e){}
    if($choice==='test'){header('Location: /assessment.php?new=1');exit;}
    if($choice==='guide'){header('Location: /onboarding.php');exit;}
    header('Location: /index.php');exit;
}
$pageTitle='Bắt đầu với Brain Focus';$activePage='welcome';include __DIR__.'/includes/layout_top.php';
?>
<section class="max-w-3xl mx-auto">
  <div class="glass-card rounded-3xl border border-slate-200 p-6 sm:p-8 text-center">
    <div class="text-5xl">🧠</div>
    <h1 class="text-2xl font-black mt-3">Chào mừng bạn đến với Brain Focus</h1>
    <p class="text-sm text-slate-500 mt-2">Bạn có thể kiểm tra BFS ngay để nhận đánh giá ban đầu, xem hướng dẫn dành cho người mới hoặc bỏ qua để tự khám phá.</p>
    <div class="grid sm:grid-cols-3 gap-3 mt-7 text-left">
      <form method="post" class="rounded-2xl border p-4 bg-blue-50 border-blue-200">
        <input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfUserCsrf())?>">
        <input type="hidden" name="choice" value="test">
        <div class="text-2xl">🧪</div><b class="block mt-2">Test BFS</b>
        <p class="text-xs text-slate-600 mt-1">Làm bài đánh giá thói quen tập trung. Nếu đủ điều kiện, hệ thống sẽ ghi nhận điểm theo chính sách hiện tại.</p>
        <button class="mt-4 w-full py-2.5 rounded-xl bg-blue-600 text-white text-xs font-bold">Tôi muốn test</button>
      </form>
      <form method="post" class="rounded-2xl border p-4 bg-emerald-50 border-emerald-200">
        <input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfUserCsrf())?>">
        <input type="hidden" name="choice" value="guide">
        <div class="text-2xl">🧭</div><b class="block mt-2">Trang bắt đầu</b>
        <p class="text-xs text-slate-600 mt-1">Phù hợp với người mới: hoàn thiện hồ sơ, khảo sát BFS, phiên học đầu tiên và Gym não.</p>
        <button class="mt-4 w-full py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-bold">Xem hướng dẫn</button>
      </form>
      <form method="post" class="rounded-2xl border p-4 bg-slate-50 border-slate-200">
        <input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfUserCsrf())?>">
        <input type="hidden" name="choice" value="skip">
        <div class="text-2xl">⏭️</div><b class="block mt-2">Bỏ qua</b>
        <p class="text-xs text-slate-600 mt-1">Bạn vẫn có thể mở Test BFS, Trang bắt đầu và các hướng dẫn bất kỳ lúc nào sau đó.</p>
        <button class="mt-4 w-full py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold">Vào Brain Focus</button>
      </form>
    </div>
  </div>
</section>
<?php include __DIR__.'/includes/layout_bottom.php';?>