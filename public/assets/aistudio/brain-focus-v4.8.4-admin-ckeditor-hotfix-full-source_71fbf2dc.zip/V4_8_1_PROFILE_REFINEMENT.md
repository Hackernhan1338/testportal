# Brain Focus v4.8.1 – Profile & Tasks Refinement

- Profile: điểm BFS/XH/điểm phiên/tổng BXH trở lại mục Thông tin cá nhân.
- Khôi phục giao diện thống kê Hiệu suất & Liêm chính học tập đầy đủ như bản trước: Integrity, Deep Focus, tỷ lệ hoàn thành, khung giờ hiệu quả và biểu đồ học/Gym theo thời gian.
- Khôi phục 4 nút thao tác bên phải: Đổi tên/Avatar, Test lại BFS (10 câu), Khóa màn hình, Đổi mật khẩu.
- Nhiệm vụ trong hồ sơ chia 3 tab nhỏ: Ngày / Tuần / Tháng, vẫn dùng period_key và thưởng đủ bộ theo từng chu kỳ.
- Huy hiệu ảnh đã đạt được đặt quanh avatar; chỉ lấy các huy hiệu có image_path hợp lệ.
- Đăng ký mới bắt buộc chọn Có/Không nhận email sự kiện & cập nhật. OTP, đổi mật khẩu và cảnh báo bảo mật không phụ thuộc lựa chọn này.
- Tài khoản Google mới chọn tùy chọn email ở onboarding.
- Hồ sơ cá nhân cho phép đổi lại lựa chọn email bất kỳ lúc nào.
- Email broadcast dạng sự kiện/thông báo chung/sinh nhật chỉ gửi tới người đã opt-in; email Điều khoản/Bảo mật vẫn được phép gửi như thông báo vận hành.
