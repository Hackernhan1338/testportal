# Brain Focus v4.8.4 Hotfix

- Fix fatal `bfSetting()` missing in Admin bootstrap, affecting Tasks, Focus Audio and Module Control.
- Fix CSP blocking `https://cdn.ckeditor.com`.
- Add CKEditor fallback helper: textarea remains usable if CDN is unavailable.
- Tasks uses page-specific schema guard instead of failing because unrelated modules are missing.
- No user data deletion.
