<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/includes/terms.php';
$terms=bfCurrentTerms($pdo);
$title=$terms['title']??'Điều khoản sử dụng & Chính sách bảo vệ dữ liệu';
$version=$terms['version']??'1.0';
$content=$terms['content_html']??bfDefaultTermsHtml();
?>
<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=htmlspecialchars($title)?> · Brain Focus</title><script src="https://cdn.tailwindcss.com"></script><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><style>body{font-family:Inter,sans-serif}</style></head><body class="bg-slate-50 text-slate-900"><div class="max-w-4xl mx-auto p-4 sm:p-8"><div class="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden"><div class="p-6 sm:p-8 border-b border-slate-100 bg-slate-900 text-white"><div class="text-sm text-slate-300">Brain Focus · Phiên bản điều khoản <?=htmlspecialchars($version)?></div><h1 class="text-2xl sm:text-3xl font-black mt-2"><?=htmlspecialchars($title)?></h1><p class="text-sm text-slate-300 mt-2">Vui lòng đọc kỹ trước khi sử dụng hoặc tiếp tục sử dụng nền tảng.</p></div><div class="p-6 sm:p-8"><?=$content?></div></div><div class="text-center text-xs text-slate-500 mt-5"><a class="text-blue-700 font-semibold" href="/login.php">Đăng nhập</a> · <a class="text-blue-700 font-semibold" href="/">Trang chủ</a></div></div></body></html>
