<?php
require_once __DIR__.'/includes/bootstrap.php';
$user=bfRequireUser($pdo);$id=(int)($_GET['id']??0);$next='/profile.php';
try{
    $st=$pdo->prepare("SELECT link_url,metric_key FROM bf_tasks WHERE id=? AND status='ACTIVE'");
    $st->execute([$id]);$t=$st->fetch();
    if($t && !empty($t['link_url']) && strpos($t['link_url'],'/')===0)$next=$t['link_url'];
    if($id>0){
        if($t && !empty($t['metric_key'])){
            if(function_exists('bfSyncAutomaticTasks'))bfSyncAutomaticTasks($pdo,$user);
        }else{
            bfCompleteTask($pdo,$user,$id);
        }
    }
}catch(Throwable $e){}
header('Location: '.$next);exit;
