# BRAIN FOCUS v3 — KẾT NỐI PHP / MYSQL

## Kiến trúc dữ liệu

```text
Frontend người dùng
  ├─ assets/js/app.js
  ├─ assets/js/database.js
  └─ assets/js/deep-focus.js
          ↓
       PHP API
          ↓
       MySQL
          ↑
 Admin Center /admin/
```

## API chính

### `api/users.php`
- `GET ?action=leaderboard`: bảng xếp hạng công khai theo dữ liệu active.
- `POST action=sync_user`: đăng ký hoặc đồng bộ hồ sơ; tài khoản đã tồn tại phải xác thực đúng mật khẩu.
- `POST action=save_session`: lưu phiên học; yêu cầu mật khẩu học viên.
- `POST action=change_email`: đổi email sau khi xác thực mật khẩu hiện tại.
- `POST action=change_password`: đổi mật khẩu sau khi xác thực mật khẩu hiện tại.

`get_user` công khai bị tắt mặc định để tránh đọc hồ sơ/lịch sử chỉ bằng email.

### `api/events.php`
- `focus_event`: ghi timeline Deep Focus; yêu cầu xác thực học viên.
- `analytics_event`: ghi sự kiện phân tích sản phẩm.

### `api/feedback.php`
- tạo góp ý/báo lỗi;
- tra cứu một phản hồi cần cả mã phản hồi + email;
- cập nhật trạng thái từ phía admin phải qua Admin Session + CSRF + permission.

### `api/admin_auth.php`
- đăng nhập/đăng xuất;
- đọc phiên admin hiện tại;
- đổi mật khẩu admin;
- tự nâng hash SHA-256 legacy sang `PASSWORD_DEFAULT` sau lần đăng nhập hợp lệ.

### `api/admin.php`
Admin-only API cho dashboard, users, sessions, session detail, CMS, feedback, analytics, audit, admins và settings. Mọi POST đều kiểm tra CSRF; từng action kiểm tra permission.

## Database v3

Các bảng lõi cũ vẫn được giữ:
- `bf_users`
- `bf_admins`
- `bf_study_sessions`
- `bf_feedback`
- `bf_audit_logs`
- `bf_analytics_events`
- `bf_content`
- `bf_settings`

Các bảng/mô-đun bổ sung:
- `bf_admin_sessions`
- `bf_admin_permissions`
- `bf_focus_events`
- `bf_bfs_assessments`
- `bf_gym_sessions`
- `bf_notifications`
- `bf_announcements`
- `bf_user_devices`
- `bf_login_history`
- `bf_content_categories`
- `bf_system_health`

## Cấu hình database

`api/db.php` đọc các biến môi trường sau nếu có:

```text
DB_HOST
DB_PORT
DB_NAME
DB_USER
DB_PASS
BF_ALLOWED_ORIGIN
BF_ALLOW_PUBLIC_USER_LOOKUP
```

Nếu Hostinger plan của bạn không tiện cấu hình environment variable, có thể sửa giá trị fallback trong `api/db.php`.

## Cài mới / nâng cấp

- Cài mới: import `sql/schema.sql`, sau đó tạo Super Admin đầu tiên tại `/admin/setup.php`.
- Database cũ: import `sql/migration_2026_09_admin_center.sql` trước khi upload code v3.

Migration không xóa bảng hay dữ liệu cũ.
