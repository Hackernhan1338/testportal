# Brain Focus v4.7.0 – Giai đoạn 2 + 3

## Giai đoạn 2
- Trung tâm thông báo mở rộng theo nhóm: ADMIN, EVENT, TERMS, PROGRESS, REMINDER, FEEDBACK, ACHIEVEMENT, SECURITY, BIRTHDAY.
- Trang chi tiết thông báo, đánh dấu từng thông báo và tất cả đã đọc.
- Tạo thông báo tiến độ ngày/tuần; nhắc lịch học khi người dùng đang hoạt động trên web; chúc mừng sinh nhật; cảnh báo đăng nhập thiết bị mới.
- Phản hồi góp ý được gửi đồng thời vào Trung tâm thông báo và email SMTP khi Admin trả lời.
- Onboarding cho tài khoản mới, hiển thị tiến độ 5 bước và huy hiệu Tân binh Brain Focus khi hoàn thành 100%.
- Trang nhiệm vụ khám phá; mỗi nhiệm vụ chỉ thưởng XP một lần.

## Giai đoạn 3
- Hồ sơ mở rộng: ngày sinh, giới tính, tỉnh/thành, mục tiêu trường, đơn vị đang học, câu nói/tác giả, trạng thái công khai/riêng tư.
- Huy hiệu cạnh avatar, danh hiệu dưới tên, nhiệm vụ hôm nay.
- Hồ sơ công khai khi bấm tên trên BXH; hồ sơ PRIVATE không hiển thị cho người khác.
- Huỷ liên kết Google chỉ khi tài khoản đã có mật khẩu Brain Focus.
- Thư viện danh hiệu/huy hiệu; huy hiệu có phẩm chất Ruby > Lục bảo > Kim cương > Vàng > Bạc > Đồng.
- Admin quản lý thêm/sửa/xoá nhiệm vụ, danh hiệu và huy hiệu.
- Admin email có nhóm sinh nhật hôm nay và loại thông báo bảo mật/sinh nhật.
- SEO: meta description, keywords, canonical, Open Graph, Twitter Card, JSON-LD WebSite, favicon cấu hình, robots.txt, sitemap.php.
- Footer và phiên bản cập nhật v4.7.0-phase2-3.

## Lưu ý triển khai
1. Phải chạy migration GĐ1 trước nếu database đang ở v4.5.4.
2. Sau đó chạy `migration_v4_6_phase2_phase3_social_onboarding_badges.sql`.
3. Upload source mới.
4. Kiểm tra Google OAuth/SMTP từ GĐ1 vẫn giữ nguyên cấu hình.
5. Tài khoản cũ được đánh dấu đã xem onboarding để không bị ép đi qua màn hình bắt đầu; tài khoản mới sẽ thấy onboarding lần đầu.
