# Brain Focus v4.6.0 Phase 1 — Terms, Google OAuth, Mail, Footer

Implemented on top of v4.5.4 without changing focus/gym/BFS/leaderboard/reflection logic.

## New routes
- `/terms.php`
- `/terms-accept.php`
- `/notifications.php`
- `/google-login.php`
- `/google-callback.php`
- `/admin/terms.php`
- `/admin/mail-broadcast.php`

## Updated
- `login.php`: registration terms scroll gate + Google Login.
- `includes/user_auth.php`: current terms enforcement.
- `includes/layout_top.php`: notification bell + unread badge.
- `includes/layout_bottom.php`: footer.
- `admin/includes/layout_top.php`: admin links.
- `admin/settings.php`: social/contact settings.
- `api/db.php`: Google OAuth configuration placeholders.
- `sql/schema.sql`: fresh-install tables/columns.

## Migration
`sql/migration_v4_6_phase1_terms_google_footer_mail.sql`
