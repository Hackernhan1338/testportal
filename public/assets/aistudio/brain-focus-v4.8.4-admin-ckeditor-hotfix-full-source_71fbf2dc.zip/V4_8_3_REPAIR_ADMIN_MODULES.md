# Brain Focus v4.8.3 Repair

Bản sửa lỗi dành cho các trang Admin:
- Nhiệm vụ học viên
- Kho âm thanh tập trung
- Module Control

## Thay đổi
1. Thêm schema guard để trang Admin không còn chết trắng/HTTP 500 khi thiếu bảng hoặc cột.
2. Thêm SUPER_ADMIN > Repair Schema.
3. Health Check hiển thị chính xác bảng/cột còn thiếu và liên kết sửa nhanh.
4. Migration repair độc lập tự tạo/bù bf_tasks, bf_focus_sounds, bf_settings, bf_gym_purchase_events và các cột notification thường bị thiếu.
5. Seed lại bộ nhiệm vụ ngày/tuần theo cấu hình v4.8.2 mà không xóa dữ liệu cũ.

## Triển khai
- Backup DB.
- Import sql/migration_v4_8_3_admin_repair.sql.
- Upload full source v4.8.3.
- Vào Admin > Health & Integration > Repair Schema nếu Health còn báo thiếu.
