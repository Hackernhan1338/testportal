<?php
require_once __DIR__.'/includes/bootstrap.php';bfEnforceModule($pdo,'focus','Phiên học tập trung');
// Trang chủ luôn render giao diện cũ. Các hành động ghi dữ liệu vẫn được API bảo vệ bằng PHP Session.
$default=90;$todayCount=0;$maxDaily=3;
try{$st=$pdo->prepare("SELECT setting_value FROM bf_settings WHERE setting_key='default_focus_duration'");$st->execute();$default=max(1,min(180,(int)($st->fetchColumn()?:90)));}catch(Throwable $e){}
try{$st=$pdo->prepare("SELECT setting_value FROM bf_settings WHERE setting_key='max_daily_sessions'");$st->execute();$maxDaily=max(1,(int)($st->fetchColumn()?:3));}catch(Throwable $e){}
if($user){try{$st=$pdo->prepare("SELECT COUNT(*) FROM bf_study_sessions WHERE user_email=? AND DATE(created_at)=CURDATE()");$st->execute([$user['email']]);$todayCount=(int)$st->fetchColumn();}catch(Throwable $e){}}
$pageTitle='Brain Focus';$activePage='focus';include __DIR__.'/includes/layout_top.php';include __DIR__.'/includes/focus_exact.php';
if(!$user){$authNext='/';$authError='';include __DIR__.'/includes/auth_overlay.php';}
include __DIR__.'/includes/layout_bottom.php';
