SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `bf_password_resets` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(191) NOT NULL,
  `otp_code` VARCHAR(64) NOT NULL,
  `request_ip` VARCHAR(45) DEFAULT NULL,
  `attempts` INT NOT NULL DEFAULT 0,
  `expires_at` DATETIME NOT NULL,
  `used_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_reset_lookup` (`email`,`expires_at`,`used_at`),
  INDEX `idx_reset_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `bf_password_resets`
  MODIFY COLUMN `otp_code` VARCHAR(64) NOT NULL;

ALTER TABLE `bf_password_resets`
  ADD COLUMN IF NOT EXISTS `attempts` INT NOT NULL DEFAULT 0 AFTER `request_ip`;

SET FOREIGN_KEY_CHECKS=1;
