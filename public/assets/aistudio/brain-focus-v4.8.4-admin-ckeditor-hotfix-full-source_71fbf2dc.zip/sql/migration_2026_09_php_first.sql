SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS bf_role_permissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role ENUM('ANALYST','MODERATOR','ADMIN','SUPER_ADMIN') NOT NULL,
  permission_key VARCHAR(120) NOT NULL,
  is_allowed TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_role_permission(role,permission_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_user_sessions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  session_hash CHAR(64) NOT NULL UNIQUE,
  device_hash CHAR(64) NOT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(500) DEFAULT NULL,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_session_user(user_id),
  INDEX idx_user_session_exp(expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_access_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  admin_id INT DEFAULT NULL,
  email VARCHAR(191) DEFAULT NULL,
  device_hash CHAR(64) DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(500) DEFAULT NULL,
  browser_info VARCHAR(255) DEFAULT NULL,
  request_path VARCHAR(500) DEFAULT NULL,
  event_type VARCHAR(50) NOT NULL DEFAULT 'PAGE_VIEW',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_access_ip(ip_address,created_at),
  INDEX idx_access_device(device_hash,created_at),
  INDEX idx_access_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_block_rules (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  rule_type ENUM('IP','DEVICE','EMAIL','USER_AGENT') NOT NULL,
  rule_value VARCHAR(500) NOT NULL,
  reason VARCHAR(500) DEFAULT NULL,
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  expires_at DATETIME DEFAULT NULL,
  created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_block_lookup(rule_type,status),
  INDEX idx_block_exp(expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_forbidden_words (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  word VARCHAR(191) NOT NULL,
  match_type ENUM('CONTAINS','EXACT') NOT NULL DEFAULT 'CONTAINS',
  replacement VARCHAR(50) DEFAULT '***',
  scope ENUM('ALL','PROFILE','FEEDBACK','FOCUS','COMMUNITY') NOT NULL DEFAULT 'ALL',
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_forbidden_word(word,scope)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_point_transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  points INT NOT NULL,
  point_type ENUM('RANK','BFS','HONOR') NOT NULL DEFAULT 'RANK',
  reason_code VARCHAR(80) NOT NULL,
  reason_text VARCHAR(500) DEFAULT NULL,
  ref_type VARCHAR(80) DEFAULT NULL,
  ref_id VARCHAR(100) DEFAULT NULL,
  created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_points_user(user_id,created_at),
  INDEX idx_points_reason(reason_code,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_honors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  honor_code VARCHAR(80) NOT NULL UNIQUE,
  title VARCHAR(191) NOT NULL,
  description VARCHAR(500) NOT NULL,
  icon VARCHAR(20) NOT NULL DEFAULT '🏅',
  metric ENUM('SESSIONS','HOURS','STREAK','INTEGRITY','POINTS','MANUAL') NOT NULL DEFAULT 'MANUAL',
  threshold_value DECIMAL(10,2) NOT NULL DEFAULT 0,
  reward_points INT NOT NULL DEFAULT 0,
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_user_honors (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  honor_id INT NOT NULL,
  awarded_by_admin_id INT DEFAULT NULL,
  awarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  note VARCHAR(500) DEFAULT NULL,
  UNIQUE KEY uq_user_honor(user_id,honor_id),
  INDEX idx_user_honors_user(user_id,awarded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_focus_audio_usage (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  audio_type VARCHAR(50) NOT NULL,
  seconds_played INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audio_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO bf_honors(honor_code,title,description,icon,metric,threshold_value,reward_points,sort_order) VALUES
('FIRST_FOCUS','Khởi đầu tập trung','Hoàn thành phiên học tập trung đầu tiên','🌱','SESSIONS',1,20,10),
('FOCUS_10','Bền bỉ 10 phiên','Hoàn thành ít nhất 10 phiên học','🎯','SESSIONS',10,50,20),
('FOCUS_50','Kỷ luật 50 phiên','Hoàn thành ít nhất 50 phiên học','🏅','SESSIONS',50,120,30),
('HOURS_100','100 giờ chuyên tâm','Tích lũy 100 giờ học tập trung','⏳','HOURS',100,200,40),
('STREAK_7','Chuỗi 7 ngày','Duy trì tập trung 7 ngày liên tục','🔥','STREAK',7,70,50),
('STREAK_30','Chuỗi 30 ngày','Duy trì tập trung 30 ngày liên tục','💎','STREAK',30,250,60),
('INTEGRITY_95','Tập trung chuẩn mực','Đạt trung bình Focus Integrity từ 95','🛡️','INTEGRITY',95,100,70),
('POINTS_5000','Mốc 5.000 điểm','Đạt tổng điểm xếp hạng từ 5.000','⭐','POINTS',5000,150,80);

INSERT IGNORE INTO bf_role_permissions(role,permission_key,is_allowed) VALUES
('ANALYST','security.view',1),
('ADMIN','security.view',1),('ADMIN','security.block',1),('ADMIN','forbidden.view',1),('ADMIN','forbidden.manage',1),('ADMIN','honors.view',1),('ADMIN','honors.manage',1),('ADMIN','points.manage',1),
('MODERATOR','forbidden.view',1),('MODERATOR','honors.view',1);

SET FOREIGN_KEY_CHECKS=1;

-- Nội dung khởi tạo cho kho kiến thức/mẹo. INSERT IGNORE để không ghi đè nội dung quản trị đã có.
INSERT IGNORE INTO bf_content(content_code,type,title,category,author,status,excerpt,content) VALUES
('BF_KNOW_FOCUS_CYCLE','article','Chu kỳ tập trung: làm việc sâu rồi phục hồi','Nền tảng tập trung','Brain Focus','published','Khả năng tập trung không tăng tuyến tính vô hạn. Hãy chia công việc thành phiên rõ mục tiêu và có khoảng phục hồi.','Một phiên tập trung hiệu quả nên bắt đầu bằng một mục tiêu cụ thể, loại bỏ các tác nhân gây nhiễu và kết thúc bằng vài phút tự đánh giá. Với nhiệm vụ khó, có thể dùng các khối 25–90 phút tùy sức bền chú ý. Sau phiên, đứng dậy, uống nước, vận động nhẹ hoặc nhìn xa trước khi bắt đầu khối tiếp theo.'),
('BF_KNOW_ENVIRONMENT','article','Thiết kế môi trường để giảm tải ý chí','Môi trường học tập','Brain Focus','published','Đừng bắt ý chí phải chiến đấu với mọi thông báo và vật gây xao nhãng.','Tắt thông báo không cần thiết, đặt điện thoại ngoài tầm tay, chỉ mở các tab phục vụ nhiệm vụ và chuẩn bị tài liệu trước khi bấm bắt đầu. Môi trường càng ít quyết định thừa, não càng dành được nhiều nguồn lực cho nhiệm vụ chính.'),
('BF_KNOW_REFLECTION','article','Tự phản tư sau phiên học','Kỹ năng tự học','Brain Focus','published','Ghi ngắn điều đã làm được, điểm nghẽn và bước tiếp theo để giảm thời gian khởi động phiên sau.','Sau mỗi phiên, trả lời ba câu: Tôi đã hoàn thành điều gì? Điều gì làm tôi mất tập trung? Bước cụ thể tiếp theo là gì? Câu trả lời nên ngắn, quan sát được và dùng để điều chỉnh phiên tiếp theo.'),
('BF_TIP_10SEC','tip','Quy tắc 10 giây khi muốn mở mạng xã hội','Trị xao nhãng','Brain Focus','published','Không phản ứng ngay với thôi thúc chuyển ứng dụng.','Khi xuất hiện thôi thúc mở mạng xã hội hoặc kiểm tra tin nhắn, đếm chậm 10 giây. Ghi ra một dòng về điều đang muốn kiểm tra. Nếu việc đó không liên quan mục tiêu hiện tại, để lại cho giờ nghỉ và quay lại nhiệm vụ.'),
('BF_TIP_PHONE','tip','Đưa điện thoại ra khỏi đường nhìn','Môi trường','Brain Focus','published','Giảm tín hiệu thị giác có thể giúp giảm số lần tự động kiểm tra điện thoại.','Đặt điện thoại vào balô, ngăn kéo hoặc cách bàn học vài bước. Nếu cần dùng làm đồng hồ, bật chế độ Không làm phiền và úp màn hình.'),
('BF_TIP_RESTART','tip','Nghi thức quay lại trong 60 giây','Khôi phục tập trung','Brain Focus','published','Một lần xao nhãng không cần biến thành cả buổi mất tập trung.','Khi nhận ra mình vừa xao nhãng: đóng nội dung không liên quan, hít thở chậm vài nhịp, đọc lại mục tiêu phiên học và làm một hành động nhỏ trong 60 giây đầu tiên. Mục tiêu là khởi động lại, không tự trách hay cố bù quá mức.');
