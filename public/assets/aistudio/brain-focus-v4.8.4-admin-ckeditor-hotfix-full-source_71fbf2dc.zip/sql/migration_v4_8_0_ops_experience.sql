SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- =========================================================
-- Brain Focus v4.8.0 – Operations & Experience
-- Có thể chạy sau v4.6/v4.7; tự bù các cột GĐ2/GĐ3 thường bị thiếu.
-- =========================================================

ALTER TABLE `bf_users`
  ADD COLUMN IF NOT EXISTS `birthday` DATE DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `gender` VARCHAR(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `province` VARCHAR(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `target_school` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `study_unit` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quote_text` VARCHAR(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quote_author` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `profile_visibility` ENUM('PUBLIC','PRIVATE') NOT NULL DEFAULT 'PUBLIC',
  ADD COLUMN IF NOT EXISTS `onboarding_seen_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `onboarding_completed_at` DATETIME DEFAULT NULL;

-- Không dùng AFTER để tránh lỗi khi schema GĐ1/GĐ2 chưa đồng nhất.
ALTER TABLE `bf_notifications`
  ADD COLUMN IF NOT EXISTS `link_url` VARCHAR(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `read_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `category` VARCHAR(40) NOT NULL DEFAULT 'GENERAL',
  ADD COLUMN IF NOT EXISTS `detail_html` LONGTEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ref_key` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `priority` ENUM('LOW','NORMAL','HIGH') NOT NULL DEFAULT 'NORMAL',
  ADD COLUMN IF NOT EXISTS `expires_at` DATETIME DEFAULT NULL;
CREATE INDEX IF NOT EXISTS `idx_notifications_ref` ON `bf_notifications` (`user_email`,`ref_key`);
CREATE INDEX IF NOT EXISTS `idx_notifications_category` ON `bf_notifications` (`user_email`,`category`,`is_read`,`created_at`);

CREATE TABLE IF NOT EXISTS `bf_badges` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `badge_code` VARCHAR(80) NOT NULL UNIQUE,
  `name` VARCHAR(191) NOT NULL,
  `description` VARCHAR(700) NOT NULL,
  `icon` VARCHAR(30) NOT NULL DEFAULT '',
  `image_path` VARCHAR(500) DEFAULT NULL,
  `tier` ENUM('RUBY','EMERALD','DIAMOND','GOLD','SILVER','BRONZE') NOT NULL DEFAULT 'BRONZE',
  `reward_xp` INT NOT NULL DEFAULT 0,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `bf_badges` ADD COLUMN IF NOT EXISTS `image_path` VARCHAR(500) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `bf_user_badges` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `badge_id` INT NOT NULL,
  `awarded_by_admin_id` INT DEFAULT NULL,
  `note` VARCHAR(500) DEFAULT NULL,
  `awarded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_user_badge` (`user_id`,`badge_id`),
  INDEX `idx_user_badges_user` (`user_id`,`awarded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_tasks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `task_code` VARCHAR(80) NOT NULL UNIQUE,
  `title` VARCHAR(191) NOT NULL,
  `description` VARCHAR(700) NOT NULL,
  `icon` VARCHAR(30) NOT NULL DEFAULT '🎯',
  `task_scope` ENUM('DISCOVERY','DAILY','WEEKLY','MONTHLY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',
  `link_url` VARCHAR(500) DEFAULT NULL,
  `reward_xp` INT NOT NULL DEFAULT 10,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `starts_at` DATETIME DEFAULT NULL,
  `ends_at` DATETIME DEFAULT NULL,
  `required_for_bonus` TINYINT(1) NOT NULL DEFAULT 1,
  `max_completions_per_period` INT NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `bf_tasks`
  MODIFY COLUMN `task_scope` ENUM('DISCOVERY','DAILY','WEEKLY','MONTHLY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',
  ADD COLUMN IF NOT EXISTS `required_for_bonus` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `max_completions_per_period` INT NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS `bf_user_task_completions` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `task_id` INT NOT NULL,
  `reward_xp` INT NOT NULL DEFAULT 0,
  `period_key` VARCHAR(40) NOT NULL DEFAULT 'ONCE',
  `completed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_task_user` (`user_id`,`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `bf_user_task_completions` ADD COLUMN IF NOT EXISTS `period_key` VARCHAR(40) NOT NULL DEFAULT 'ONCE';
ALTER TABLE `bf_user_task_completions` DROP INDEX IF EXISTS `uq_user_task`;
CREATE UNIQUE INDEX IF NOT EXISTS `uq_user_task_period` ON `bf_user_task_completions` (`user_id`,`task_id`,`period_key`);
CREATE INDEX IF NOT EXISTS `idx_user_task_period` ON `bf_user_task_completions` (`user_id`,`period_key`,`completed_at`);

CREATE TABLE IF NOT EXISTS `bf_task_period_rewards` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `scope` ENUM('DAILY','WEEKLY','MONTHLY') NOT NULL,
  `period_key` VARCHAR(40) NOT NULL,
  `reward_xp` INT NOT NULL DEFAULT 100,
  `awarded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_task_period_reward` (`user_id`,`scope`,`period_key`),
  INDEX `idx_task_period_reward_user` (`user_id`,`awarded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_focus_sounds` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sound_code` VARCHAR(80) NOT NULL UNIQUE,
  `name` VARCHAR(191) NOT NULL,
  `description` VARCHAR(500) DEFAULT NULL,
  `file_path` VARCHAR(500) NOT NULL,
  `mime_type` VARCHAR(100) DEFAULT NULL,
  `default_volume` INT NOT NULL DEFAULT 40,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_by_admin_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('app_version','4.8.0-ops-experience'),
('task_set_bonus_xp','100'),
('module_focus','true'),
('module_gym','true'),
('module_knowledge','true'),
('module_tips','true'),
('module_leaderboard','true'),
('module_achievements','true'),
('module_feedback','true'),
('module_notifications','true'),
('module_audio','true'),
('seo_index_title','Brain Focus – Không gian học tập và rèn luyện tập trung'),
('seo_index_description','Brain Focus hỗ trợ Deep Focus, Pomodoro, Gym não, BFS, thống kê tiến độ và xây dựng thói quen học tập tập trung.'),
('seo_knowledge_title','Kiến thức tập trung – Brain Focus'),
('seo_knowledge_description','Thư viện kiến thức, phương pháp học tập trung, quản lý xao nhãng và xây dựng thói quen học hiệu quả.'),
('seo_leaderboard_title','Bảng xếp hạng học tập – Brain Focus'),
('seo_leaderboard_description','Bảng xếp hạng thi đua học tập Brain Focus theo từng đợt, dựa trên điểm và hoạt động học tập hợp lệ.'),
('seo_gym_title','Gym não – Brain Focus'),
('seo_gym_description','Rèn luyện phản xạ, ghi nhớ và chú ý với các bài tập Gym não có giới hạn thời gian trên Brain Focus.')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`),`updated_at`=NOW();

SET FOREIGN_KEY_CHECKS=1;
