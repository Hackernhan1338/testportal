-- Brain Focus v4.8.3 REPAIR
-- Sửa schema phục vụ Admin Tasks / Focus Audio / Module Control.
-- MariaDB 10.5+/11.x. Không DROP bảng, không xóa dữ liệu người dùng.
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `bf_settings` (
  `setting_key` varchar(191) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_code` varchar(80) NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` varchar(700) NOT NULL,
  `icon` varchar(30) NOT NULL DEFAULT '🎯',
  `task_scope` enum('DISCOVERY','DAILY','WEEKLY','MONTHLY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',
  `link_url` varchar(500) DEFAULT NULL,
  `reward_xp` int NOT NULL DEFAULT 10,
  `status` enum('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` int NOT NULL DEFAULT 0,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `required_for_bonus` tinyint(1) NOT NULL DEFAULT 1,
  `max_completions_per_period` int NOT NULL DEFAULT 1,
  `metric_key` varchar(50) DEFAULT NULL,
  `target_value` int NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_task_code` (`task_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `bf_tasks`
  MODIFY COLUMN `task_scope` ENUM('DISCOVERY','DAILY','WEEKLY','MONTHLY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',
  ADD COLUMN IF NOT EXISTS `starts_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ends_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `required_for_bonus` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `max_completions_per_period` INT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `metric_key` VARCHAR(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `target_value` INT NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS `bf_user_task_completions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `task_id` int NOT NULL,
  `reward_xp` int NOT NULL DEFAULT 0,
  `period_key` varchar(40) NOT NULL DEFAULT 'ONCE',
  `completed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_task_user` (`user_id`,`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `bf_user_task_completions`
  ADD COLUMN IF NOT EXISTS `period_key` VARCHAR(40) NOT NULL DEFAULT 'ONCE';
CREATE INDEX IF NOT EXISTS `idx_user_task_period` ON `bf_user_task_completions` (`user_id`,`period_key`,`completed_at`);

CREATE TABLE IF NOT EXISTS `bf_task_period_rewards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `scope` enum('DAILY','WEEKLY','MONTHLY') NOT NULL,
  `period_key` varchar(40) NOT NULL,
  `reward_xp` int NOT NULL DEFAULT 100,
  `awarded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_task_period_reward` (`user_id`,`scope`,`period_key`),
  KEY `idx_task_period_reward_user` (`user_id`,`awarded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_focus_sounds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sound_code` varchar(80) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `file_path` varchar(500) NOT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `default_volume` int NOT NULL DEFAULT 40,
  `status` enum('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` int NOT NULL DEFAULT 0,
  `created_by_admin_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_focus_sound_code` (`sound_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_gym_purchase_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT 1,
  `currency` varchar(20) NOT NULL DEFAULT 'RANK',
  `cost_points` int NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_gym_purchase_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tự bù notification schema nếu GĐ2/GĐ3 trước đó từng import dở.
ALTER TABLE `bf_notifications`
  ADD COLUMN IF NOT EXISTS `link_url` VARCHAR(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `read_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `category` VARCHAR(40) NOT NULL DEFAULT 'GENERAL',
  ADD COLUMN IF NOT EXISTS `detail_html` LONGTEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ref_key` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `priority` ENUM('LOW','NORMAL','HIGH') NOT NULL DEFAULT 'NORMAL',
  ADD COLUMN IF NOT EXISTS `expires_at` DATETIME DEFAULT NULL;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('module_focus','true'),('module_gym','true'),('module_knowledge','true'),('module_tips','true'),
('module_leaderboard','true'),('module_achievements','true'),('module_feedback','true'),
('module_notifications','true'),('module_audio','true'),('task_set_bonus_xp','100'),
('ckeditor_enabled','true'),('app_version','4.8.3-repair')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

INSERT INTO `bf_tasks`
(`task_code`,`title`,`description`,`icon`,`task_scope`,`link_url`,`reward_xp`,`status`,`sort_order`,`required_for_bonus`,`metric_key`,`target_value`)
VALUES
('DAILY_FOCUS_2','Chạy 2 phiên học bất kỳ','Hoàn thành 2 phiên học trong ngày.','⏱️','DAILY','/index.php',15,'ACTIVE',10,1,'FOCUS_ANY',2),
('DAILY_GYM_PLAY_5','Chơi 5 lượt Gym não','Hoàn thành 5 lượt Gym não trong ngày.','🎮','DAILY','/gym.php',15,'ACTIVE',20,1,'GYM_PLAY',5),
('DAILY_GYM_BUY_5','Mua 5 lượt Gym não','Mua tổng cộng 5 lượt Gym não trong ngày.','🛒','DAILY','/gym.php',15,'ACTIVE',30,1,'GYM_PURCHASE',5),
('DAILY_REFLECTION_1','Làm ít nhất 1 bài đánh giá sau phiên học','Lưu ít nhất 1 đúc kết/đánh giá sau phiên học trong ngày.','📝','DAILY','/profile.php#reflections',15,'ACTIVE',40,1,'REFLECTION',1),
('DAILY_FOCUS_90_1','Chạy 1 phiên học 90 phút','Hoàn thành ít nhất 1 phiên học đặt 90 phút trong ngày.','🧘','DAILY','/index.php?duration=90&deep=1',20,'ACTIVE',50,1,'FOCUS_90',1),
('WEEKLY_FOCUS_15','Chạy 15 phiên học bất kỳ','Hoàn thành 15 phiên học trong tuần.','⏱️','WEEKLY','/index.php',30,'ACTIVE',10,1,'FOCUS_ANY',15),
('WEEKLY_GYM_PLAY_200','Chơi 200 lượt Gym não','Hoàn thành 200 lượt Gym não trong tuần.','🎮','WEEKLY','/gym.php',40,'ACTIVE',20,1,'GYM_PLAY',200),
('WEEKLY_GYM_BUY_150','Mua 150 lượt Gym não','Mua tổng cộng 150 lượt Gym não trong tuần.','🛒','WEEKLY','/gym.php',40,'ACTIVE',30,1,'GYM_PURCHASE',150),
('WEEKLY_REFLECTION_10','Làm ít nhất 10 bài đánh giá sau phiên học','Lưu ít nhất 10 đúc kết/đánh giá sau phiên học trong tuần.','📝','WEEKLY','/profile.php#reflections',35,'ACTIVE',40,1,'REFLECTION',10),
('WEEKLY_FOCUS_90_5','Chạy 5 phiên học 90 phút','Hoàn thành ít nhất 5 phiên học đặt 90 phút trong tuần.','🧘','WEEKLY','/index.php?duration=90&deep=1',40,'ACTIVE',50,1,'FOCUS_90',5)
ON DUPLICATE KEY UPDATE
  `title`=VALUES(`title`),`description`=VALUES(`description`),`icon`=VALUES(`icon`),
  `task_scope`=VALUES(`task_scope`),`link_url`=VALUES(`link_url`),`reward_xp`=VALUES(`reward_xp`),
  `status`='ACTIVE',`sort_order`=VALUES(`sort_order`),`required_for_bonus`=1,
  `metric_key`=VALUES(`metric_key`),`target_value`=VALUES(`target_value`);

SET FOREIGN_KEY_CHECKS=1;
