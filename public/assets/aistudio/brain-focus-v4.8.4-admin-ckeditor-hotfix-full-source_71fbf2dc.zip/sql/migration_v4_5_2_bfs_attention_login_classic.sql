-- Brain Focus v4.5.2
-- BFS attention checks + retake bonus ledger + classic login UI
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `bf_bfs_test_attempts` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `user_email` VARCHAR(191) NOT NULL,
  `attempt_no` INT NOT NULL DEFAULT 1,
  `raw_bfs_score` INT NOT NULL DEFAULT 0,
  `bonus_points` INT NOT NULL DEFAULT 0,
  `trap_total` INT NOT NULL DEFAULT 0,
  `trap_passed` INT NOT NULL DEFAULT 0,
  `status` ENUM('VALID','RETAKE_REQUIRED') NOT NULL DEFAULT 'VALID',
  `penalty_level` INT NOT NULL DEFAULT 0,
  `is_retake` TINYINT(1) NOT NULL DEFAULT 0,
  `answers_json` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_bfs_attempt_user` (`user_id`,`created_at`),
  INDEX `idx_bfs_attempt_email` (`user_email`,`created_at`),
  INDEX `idx_bfs_attempt_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('bfs_retake_bonus','30'),
('bfs_attention_retry_bonus_1','15'),
('bfs_attention_retry_bonus_2','5'),
('bfs_attention_check_count','2')
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

SET FOREIGN_KEY_CHECKS=1;
