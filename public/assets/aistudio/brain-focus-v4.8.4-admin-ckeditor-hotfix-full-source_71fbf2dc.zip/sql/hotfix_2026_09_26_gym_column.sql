-- Brain Focus v4.4.1 - Hotfix Rèn luyện phản xạ
-- Sửa lỗi SQLSTATE[42S22] / MariaDB 1054 do DB cũ dùng game_code,
-- trong khi API v4.4 ghi vào game_type.
SET NAMES utf8mb4;

DROP PROCEDURE IF EXISTS bf_hotfix_add_column;
DELIMITER $$
CREATE PROCEDURE bf_hotfix_add_column(IN tbl VARCHAR(64), IN col VARCHAR(64), IN defn TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = tbl AND COLUMN_NAME = col
  ) THEN
    SET @q = CONCAT('ALTER TABLE `', tbl, '` ADD COLUMN `', col, '` ', defn);
    PREPARE s FROM @q;
    EXECUTE s;
    DEALLOCATE PREPARE s;
  END IF;
END$$
DELIMITER ;

CALL bf_hotfix_add_column('bf_gym_sessions','game_type','VARCHAR(80) DEFAULT NULL AFTER `user_email`');

-- Chép loại trò chơi từ cột legacy sang cột mới nếu cột game_code tồn tại.
DROP PROCEDURE IF EXISTS bf_hotfix_copy_game_code;
DELIMITER $$
CREATE PROCEDURE bf_hotfix_copy_game_code()
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='bf_gym_sessions' AND COLUMN_NAME='game_code'
  ) THEN
    UPDATE bf_gym_sessions
    SET game_type = game_code
    WHERE (game_type IS NULL OR game_type='') AND game_code IS NOT NULL;
  END IF;
END$$
DELIMITER ;
CALL bf_hotfix_copy_game_code();

DROP PROCEDURE IF EXISTS bf_hotfix_copy_game_code;
DROP PROCEDURE IF EXISTS bf_hotfix_add_column;

-- Kiểm tra sau hotfix
SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA=DATABASE()
  AND TABLE_NAME='bf_gym_sessions'
  AND COLUMN_NAME IN ('game_code','game_type')
ORDER BY ORDINAL_POSITION;
