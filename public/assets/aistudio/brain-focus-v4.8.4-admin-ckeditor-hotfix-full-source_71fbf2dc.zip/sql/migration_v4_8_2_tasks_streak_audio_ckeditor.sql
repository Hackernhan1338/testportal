-- Brain Focus v4.8.2 - Tasks, streak, audio module, birthday helper, CKEditor toggle
SET NAMES utf8mb4;

ALTER TABLE `bf_tasks`
  ADD COLUMN IF NOT EXISTS `metric_key` VARCHAR(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `target_value` INT NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS `bf_gym_purchase_events` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `currency` VARCHAR(20) NOT NULL DEFAULT 'RANK',
  `cost_points` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_gym_purchase_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('module_audio','true'),
('task_set_bonus_xp','100'),
('ckeditor_enabled','true')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

-- Nhiệm vụ hằng ngày
INSERT INTO `bf_tasks`
(`task_code`,`title`,`description`,`icon`,`task_scope`,`link_url`,`reward_xp`,`status`,`sort_order`,`required_for_bonus`,`metric_key`,`target_value`)
VALUES
('DAILY_FOCUS_2','Chạy 2 phiên học bất kỳ','Hoàn thành 2 phiên học trong ngày.','⏱️','DAILY','/index.php',15,'ACTIVE',10,1,'FOCUS_ANY',2),
('DAILY_GYM_PLAY_5','Chơi 5 lượt Gym não','Hoàn thành 5 lượt Gym não trong ngày.','🎮','DAILY','/gym.php',15,'ACTIVE',20,1,'GYM_PLAY',5),
('DAILY_GYM_BUY_5','Mua 5 lượt Gym não','Mua tổng cộng 5 lượt Gym não trong ngày.','🛒','DAILY','/gym.php',15,'ACTIVE',30,1,'GYM_PURCHASE',5),
('DAILY_REFLECTION_1','Làm ít nhất 1 bài đánh giá sau phiên học','Lưu ít nhất 1 đúc kết/đánh giá sau phiên học trong ngày.','📝','DAILY','/profile.php#reflections',15,'ACTIVE',40,1,'REFLECTION',1),
('DAILY_FOCUS_90_1','Chạy 1 phiên học 90 phút','Hoàn thành ít nhất 1 phiên học đặt 90 phút trong ngày.','🧘','DAILY','/index.php?duration=90&deep=1',20,'ACTIVE',50,1,'FOCUS_90',1)
ON DUPLICATE KEY UPDATE
title=VALUES(title),description=VALUES(description),icon=VALUES(icon),task_scope=VALUES(task_scope),
link_url=VALUES(link_url),reward_xp=VALUES(reward_xp),status='ACTIVE',sort_order=VALUES(sort_order),
required_for_bonus=VALUES(required_for_bonus),metric_key=VALUES(metric_key),target_value=VALUES(target_value);

-- Nhiệm vụ hằng tuần
INSERT INTO `bf_tasks`
(`task_code`,`title`,`description`,`icon`,`task_scope`,`link_url`,`reward_xp`,`status`,`sort_order`,`required_for_bonus`,`metric_key`,`target_value`)
VALUES
('WEEKLY_FOCUS_15','Chạy 15 phiên học bất kỳ','Hoàn thành 15 phiên học trong tuần.','⏱️','WEEKLY','/index.php',30,'ACTIVE',10,1,'FOCUS_ANY',15),
('WEEKLY_GYM_PLAY_200','Chơi 200 lượt Gym não','Hoàn thành 200 lượt Gym não trong tuần.','🎮','WEEKLY','/gym.php',40,'ACTIVE',20,1,'GYM_PLAY',200),
('WEEKLY_GYM_BUY_150','Mua 150 lượt Gym não','Mua tổng cộng 150 lượt Gym não trong tuần.','🛒','WEEKLY','/gym.php',40,'ACTIVE',30,1,'GYM_PURCHASE',150),
('WEEKLY_REFLECTION_10','Làm ít nhất 10 bài đánh giá sau phiên học','Lưu ít nhất 10 đúc kết/đánh giá sau phiên học trong tuần.','📝','WEEKLY','/profile.php#reflections',35,'ACTIVE',40,1,'REFLECTION',10),
('WEEKLY_FOCUS_90_5','Chạy 5 phiên học 90 phút','Hoàn thành ít nhất 5 phiên học đặt 90 phút trong tuần.','🧘','WEEKLY','/index.php?duration=90&deep=1',40,'ACTIVE',50,1,'FOCUS_90',5)
ON DUPLICATE KEY UPDATE
title=VALUES(title),description=VALUES(description),icon=VALUES(icon),task_scope=VALUES(task_scope),
link_url=VALUES(link_url),reward_xp=VALUES(reward_xp),status='ACTIVE',sort_order=VALUES(sort_order),
required_for_bonus=VALUES(required_for_bonus),metric_key=VALUES(metric_key),target_value=VALUES(target_value);

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('app_version','4.8.2')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);
