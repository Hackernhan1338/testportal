SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `bf_users`
  ADD COLUMN IF NOT EXISTS `google_sub` VARCHAR(191) DEFAULT NULL AFTER `password_hash`,
  ADD COLUMN IF NOT EXISTS `google_linked_at` DATETIME DEFAULT NULL AFTER `google_sub`;
CREATE UNIQUE INDEX IF NOT EXISTS `uq_users_google_sub` ON `bf_users` (`google_sub`);

CREATE TABLE IF NOT EXISTS `bf_terms_versions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `version` VARCHAR(40) NOT NULL UNIQUE,
  `title` VARCHAR(255) NOT NULL,
  `content_html` LONGTEXT NOT NULL,
  `reward_xp` INT NOT NULL DEFAULT 50,
  `status` ENUM('DRAFT','PUBLISHED','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
  `published_at` DATETIME DEFAULT NULL,
  `created_by_admin_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_terms_status` (`status`,`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_terms_acceptances` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `terms_id` INT NOT NULL,
  `accepted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted_ip` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(500) DEFAULT NULL,
  `reward_xp` INT NOT NULL DEFAULT 0,
  UNIQUE KEY `uq_terms_user_version` (`user_id`,`terms_id`),
  INDEX `idx_terms_accept_terms` (`terms_id`,`accepted_at`),
  INDEX `idx_terms_accept_user` (`user_id`,`accepted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `bf_notifications`
  ADD COLUMN IF NOT EXISTS `link_url` VARCHAR(500) DEFAULT NULL AFTER `type`,
  ADD COLUMN IF NOT EXISTS `read_at` DATETIME DEFAULT NULL AFTER `is_read`;

CREATE TABLE IF NOT EXISTS `bf_mail_campaigns` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `created_by_admin_id` INT DEFAULT NULL,
  `category` VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
  `recipient_scope` VARCHAR(50) NOT NULL DEFAULT 'ALL_ACTIVE',
  `subject` VARCHAR(255) NOT NULL,
  `content_html` LONGTEXT NOT NULL,
  `create_notification` TINYINT(1) NOT NULL DEFAULT 1,
  `status` ENUM('QUEUED','SENDING','COMPLETED','CANCELLED') NOT NULL DEFAULT 'QUEUED',
  `total_count` INT NOT NULL DEFAULT 0,
  `sent_count` INT NOT NULL DEFAULT 0,
  `failed_count` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_mail_queue` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `campaign_id` BIGINT NOT NULL,
  `user_id` INT NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `status` ENUM('PENDING','SENT','FAILED') NOT NULL DEFAULT 'PENDING',
  `error_message` VARCHAR(1000) DEFAULT NULL,
  `sent_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_campaign_user` (`campaign_id`,`user_id`),
  INDEX `idx_mail_queue_status` (`campaign_id`,`status`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('app_version','4.6.0-phase1'),
('social_facebook_url',''),
('social_youtube_url',''),
('social_tiktok_url',''),
('site_contact_email','thiennhan1338@gmail.com')
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

SET FOREIGN_KEY_CHECKS=1;
