SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `bf_users`
  ADD COLUMN IF NOT EXISTS `birthday` DATE DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `gender` VARCHAR(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `province` VARCHAR(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `target_school` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `study_unit` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quote_text` VARCHAR(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quote_author` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `profile_visibility` ENUM('PUBLIC','PRIVATE') NOT NULL DEFAULT 'PUBLIC',
  ADD COLUMN IF NOT EXISTS `onboarding_seen_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `onboarding_completed_at` DATETIME DEFAULT NULL;

-- Tài khoản cũ không bị ép onboarding lần đầu; tài khoản tạo sau migration vẫn NULL.
UPDATE `bf_users` SET `onboarding_seen_at`=NOW() WHERE `onboarding_seen_at` IS NULL;

ALTER TABLE `bf_notifications`
  ADD COLUMN IF NOT EXISTS `category` VARCHAR(40) NOT NULL DEFAULT 'GENERAL' AFTER `type`,
  ADD COLUMN IF NOT EXISTS `detail_html` LONGTEXT DEFAULT NULL AFTER `content`,
  ADD COLUMN IF NOT EXISTS `ref_key` VARCHAR(191) DEFAULT NULL AFTER `link_url`,
  ADD COLUMN IF NOT EXISTS `priority` ENUM('LOW','NORMAL','HIGH') NOT NULL DEFAULT 'NORMAL' AFTER `ref_key`,
  ADD COLUMN IF NOT EXISTS `expires_at` DATETIME DEFAULT NULL AFTER `read_at`;
CREATE INDEX IF NOT EXISTS `idx_notifications_ref` ON `bf_notifications` (`user_email`,`ref_key`);
CREATE INDEX IF NOT EXISTS `idx_notifications_category` ON `bf_notifications` (`user_email`,`category`,`is_read`,`created_at`);

CREATE TABLE IF NOT EXISTS `bf_badges` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `badge_code` VARCHAR(80) NOT NULL UNIQUE,
  `name` VARCHAR(191) NOT NULL,
  `description` VARCHAR(700) NOT NULL,
  `icon` VARCHAR(30) NOT NULL DEFAULT '🏅',
  `tier` ENUM('RUBY','EMERALD','DIAMOND','GOLD','SILVER','BRONZE') NOT NULL DEFAULT 'BRONZE',
  `reward_xp` INT NOT NULL DEFAULT 0,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_user_badges` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `badge_id` INT NOT NULL,
  `awarded_by_admin_id` INT DEFAULT NULL,
  `note` VARCHAR(500) DEFAULT NULL,
  `awarded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_user_badge` (`user_id`,`badge_id`),
  INDEX `idx_user_badges_user` (`user_id`,`awarded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_tasks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `task_code` VARCHAR(80) NOT NULL UNIQUE,
  `title` VARCHAR(191) NOT NULL,
  `description` VARCHAR(700) NOT NULL,
  `icon` VARCHAR(30) NOT NULL DEFAULT '🎯',
  `task_scope` ENUM('DISCOVERY','DAILY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',
  `link_url` VARCHAR(500) DEFAULT NULL,
  `reward_xp` INT NOT NULL DEFAULT 10,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `starts_at` DATETIME DEFAULT NULL,
  `ends_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_user_task_completions` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `task_id` INT NOT NULL,
  `reward_xp` INT NOT NULL DEFAULT 0,
  `completed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_user_task` (`user_id`,`task_id`),
  INDEX `idx_user_task_user` (`user_id`,`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_badges` (`badge_code`,`name`,`description`,`icon`,`tier`,`reward_xp`,`sort_order`) VALUES
('ROOKIE_BRAIN_FOCUS','Tân binh Brain Focus','Hoàn thành 100% hồ sơ khởi động và các bước làm quen Brain Focus.','🧠','BRONZE',50,10),
('PROFILE_READY','Hồ sơ chỉn chu','Hoàn thiện đầy đủ hồ sơ cá nhân.','✨','SILVER',30,20),
('FOCUS_EXPLORER','Nhà thám hiểm tập trung','Khám phá các khu vực quan trọng của Brain Focus.','🧭','GOLD',50,30)
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

INSERT INTO `bf_tasks` (`task_code`,`title`,`description`,`icon`,`task_scope`,`link_url`,`reward_xp`,`sort_order`) VALUES
('DISCOVER_NOTIFICATIONS','Khám phá Trung tâm thông báo','Mở Trung tâm thông báo để theo dõi lịch học, tiến độ, bảo mật và thông báo từ BQT.','🔔','DISCOVERY','/notifications.php',10,10),
('DISCOVER_PROFILE','Hoàn thiện hồ sơ cá nhân','Bổ sung ngày sinh, câu nói, tỉnh/thành, mục tiêu trường và đơn vị đang học.','👤','DISCOVERY','/profile.php',20,20),
('DISCOVER_ACHIEVEMENTS','Khám phá thư viện thành tích','Xem danh hiệu và huy hiệu đã đạt cùng kho thành tích của Brain Focus.','🏅','DISCOVERY','/achievements.php',10,30),
('DISCOVER_LEADERBOARD','Xem bảng xếp hạng','Kiểm tra thứ hạng và các đợt thi đua đang diễn ra.','🏆','DISCOVERY','/leaderboard.php',10,40),
('DISCOVER_GYM','Thử Gym não','Mở khu vực rèn luyện phản xạ và ghi nhớ.','🎮','DISCOVERY','/gym.php',10,50),
('DISCOVER_KNOWLEDGE','Mở thư viện kiến thức','Khám phá nội dung khoa học tập trung và mẹo trị xao nhãng.','📚','DISCOVERY','/knowledge.php',10,60)
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('app_version','4.7.0-phase2-3'),
('seo_site_name','Brain Focus'),
('seo_site_description','Brain Focus hỗ trợ học tập tập trung, Deep Focus, Gym não, BFS, thống kê tiến độ và thi đua học tập.'),
('seo_keywords','brain focus,tập trung,học tập,pomodoro,deep focus,gym não,BFS'),
('seo_og_image',''),
('site_favicon_url','')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`),`updated_at`=NOW();

SET FOREIGN_KEY_CHECKS=1;
