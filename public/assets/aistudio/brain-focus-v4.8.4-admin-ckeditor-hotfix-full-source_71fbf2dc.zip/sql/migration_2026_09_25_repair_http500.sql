-- ============================================================================
-- Brain Focus v4 - REPAIR HTTP 500 + PASSWORD MIGRATION + SECURITY PROFILE
-- Target: current u977589364_brainfocus dump (MariaDB/MySQL compatible)
-- Date: 2026-09-25
--
-- Temporary password ONLY for users whose password_hash is NULL/empty:
--   BrainFocus@2026!
-- All pre-existing users are marked must_change_password=1.
-- Existing non-NULL password hashes are NOT overwritten.
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

DROP PROCEDURE IF EXISTS bf_add_column_if_missing;
DELIMITER $$
CREATE PROCEDURE bf_add_column_if_missing(IN tbl VARCHAR(64), IN col VARCHAR(64), IN ddl TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=tbl AND COLUMN_NAME=col
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', tbl, '` ADD COLUMN ', ddl);
    PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS bf_add_index_if_missing;
DELIMITER $$
CREATE PROCEDURE bf_add_index_if_missing(IN tbl VARCHAR(64), IN idx VARCHAR(64), IN ddl TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=tbl AND INDEX_NAME=idx
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', tbl, '` ADD ', ddl);
    PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

-- --------------------------------------------------------------------------
-- 1) USER SECURITY COLUMNS
-- --------------------------------------------------------------------------
CALL bf_add_column_if_missing('bf_users','must_change_password','`must_change_password` TINYINT(1) NOT NULL DEFAULT 0 AFTER `password_hash`');
CALL bf_add_column_if_missing('bf_users','password_changed_at','`password_changed_at` DATETIME DEFAULT NULL AFTER `must_change_password`');
CALL bf_add_column_if_missing('bf_users','last_login_at','`last_login_at` DATETIME DEFAULT NULL AFTER `password_changed_at`');
CALL bf_add_column_if_missing('bf_users','last_ip','`last_ip` VARCHAR(45) DEFAULT NULL AFTER `last_login_at`');
CALL bf_add_column_if_missing('bf_users','last_user_agent','`last_user_agent` VARCHAR(500) DEFAULT NULL AFTER `last_ip`');
CALL bf_add_column_if_missing('bf_users','last_device_hash','`last_device_hash` CHAR(64) DEFAULT NULL AFTER `last_user_agent`');
CALL bf_add_index_if_missing('bf_users','idx_users_last_ip','INDEX `idx_users_last_ip` (`last_ip`)');

-- Keep current hashes. Only NULL/empty accounts receive the temporary password.
UPDATE `bf_users`
SET `password_hash`='$2y$12$oy8RSrMD3LQs/KtkWHaFj.fne.yrfa116/yyhkiP8O.MosQjVwB.i'
WHERE `password_hash` IS NULL OR `password_hash`='';

-- Every account present at migration time must choose a private password.
UPDATE `bf_users` SET `must_change_password`=1;

-- --------------------------------------------------------------------------
-- 2) SERVER-SIDE USER SESSIONS / ACCESS LOG / BLOCKLIST
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bf_user_devices` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_email` VARCHAR(191) NOT NULL,
  `device_hash` CHAR(64) NOT NULL,
  `device_name` VARCHAR(191) DEFAULT NULL,
  `last_ip` VARCHAR(45) DEFAULT NULL,
  `last_seen_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_user_device` (`user_email`,`device_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_login_history` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_email` VARCHAR(191) DEFAULT NULL,
  `actor_type` ENUM('USER','ADMIN') NOT NULL,
  `success` TINYINT(1) NOT NULL DEFAULT 1,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_login_actor_created` (`actor_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_user_sessions` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `session_hash` CHAR(64) NOT NULL UNIQUE,
  `device_hash` CHAR(64) NOT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(500) DEFAULT NULL,
  `last_seen_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_session_user` (`user_id`),
  INDEX `idx_user_session_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_access_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `admin_id` INT DEFAULT NULL,
  `email` VARCHAR(191) DEFAULT NULL,
  `device_hash` CHAR(64) DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(500) DEFAULT NULL,
  `browser_info` VARCHAR(255) DEFAULT NULL,
  `request_path` VARCHAR(500) DEFAULT NULL,
  `event_type` VARCHAR(50) NOT NULL DEFAULT 'PAGE_VIEW',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_access_ip` (`ip_address`,`created_at`),
  INDEX `idx_access_device` (`device_hash`,`created_at`),
  INDEX `idx_access_user` (`user_id`,`created_at`),
  INDEX `idx_access_email` (`email`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_block_rules` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `rule_type` ENUM('IP','DEVICE','EMAIL','USER_AGENT') NOT NULL,
  `rule_value` VARCHAR(500) NOT NULL,
  `reason` VARCHAR(500) DEFAULT NULL,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `expires_at` DATETIME DEFAULT NULL,
  `created_by_admin_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_block_lookup` (`rule_type`,`status`),
  INDEX `idx_block_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_forbidden_words` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `word` VARCHAR(191) NOT NULL,
  `match_type` ENUM('CONTAINS','EXACT') NOT NULL DEFAULT 'CONTAINS',
  `replacement` VARCHAR(50) DEFAULT '***',
  `scope` ENUM('ALL','PROFILE','FEEDBACK','FOCUS','COMMUNITY') NOT NULL DEFAULT 'ALL',
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `created_by_admin_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_forbidden_word` (`word`,`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------------
-- 3) ROLE PERMISSIONS - SEPARATE FROM LEGACY bf_admin_permissions(admin_id,...)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bf_role_permissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role` ENUM('ANALYST','MODERATOR','ADMIN','SUPER_ADMIN') NOT NULL,
  `permission_key` VARCHAR(120) NOT NULL,
  `is_allowed` TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY `uq_role_permission` (`role`,`permission_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_role_permissions` (`role`,`permission_key`,`is_allowed`) VALUES
('ANALYST','dashboard.view',1),('ANALYST','analytics.view',1),('ANALYST','sessions.view',1),('ANALYST','security.view',1),
('MODERATOR','dashboard.view',1),('MODERATOR','analytics.view',1),('MODERATOR','sessions.view',1),('MODERATOR','content.view',1),('MODERATOR','content.create',1),('MODERATOR','content.edit',1),('MODERATOR','content.publish',1),('MODERATOR','feedback.view',1),('MODERATOR','feedback.reply',1),('MODERATOR','forbidden.view',1),('MODERATOR','honors.view',1),
('ADMIN','dashboard.view',1),('ADMIN','analytics.view',1),('ADMIN','analytics.export',1),('ADMIN','users.view',1),('ADMIN','users.edit',1),('ADMIN','users.lock',1),('ADMIN','sessions.view',1),('ADMIN','sessions.export',1),('ADMIN','content.view',1),('ADMIN','content.create',1),('ADMIN','content.edit',1),('ADMIN','content.delete',1),('ADMIN','content.publish',1),('ADMIN','feedback.view',1),('ADMIN','feedback.reply',1),('ADMIN','feedback.delete',1),('ADMIN','settings.view',1),('ADMIN','settings.update',1),('ADMIN','audit.view',1),('ADMIN','security.view',1),('ADMIN','security.block',1),('ADMIN','forbidden.view',1),('ADMIN','forbidden.manage',1),('ADMIN','honors.view',1),('ADMIN','honors.manage',1),('ADMIN','points.manage',1)
ON DUPLICATE KEY UPDATE `is_allowed`=VALUES(`is_allowed`);

-- --------------------------------------------------------------------------
-- 4) POINT LEDGER / HONORS / AUDIO
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bf_point_transactions` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `points` INT NOT NULL,
  `point_type` ENUM('RANK','BFS','HONOR') NOT NULL DEFAULT 'RANK',
  `reason_code` VARCHAR(80) NOT NULL,
  `reason_text` VARCHAR(500) DEFAULT NULL,
  `ref_type` VARCHAR(80) DEFAULT NULL,
  `ref_id` VARCHAR(100) DEFAULT NULL,
  `created_by_admin_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_points_user` (`user_id`,`created_at`),
  INDEX `idx_points_reason` (`reason_code`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_honors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `honor_code` VARCHAR(80) NOT NULL UNIQUE,
  `title` VARCHAR(191) NOT NULL,
  `description` VARCHAR(500) NOT NULL,
  `icon` VARCHAR(20) NOT NULL DEFAULT '🏅',
  `metric` ENUM('SESSIONS','HOURS','STREAK','INTEGRITY','POINTS','MANUAL') NOT NULL DEFAULT 'MANUAL',
  `threshold_value` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `reward_points` INT NOT NULL DEFAULT 0,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_user_honors` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `honor_id` INT NOT NULL,
  `awarded_by_admin_id` INT DEFAULT NULL,
  `awarded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` VARCHAR(500) DEFAULT NULL,
  UNIQUE KEY `uq_user_honor` (`user_id`,`honor_id`),
  INDEX `idx_user_honors_user` (`user_id`,`awarded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_focus_audio_usage` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `audio_type` VARCHAR(50) NOT NULL,
  `seconds_played` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_audio_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `bf_honors` (`honor_code`,`title`,`description`,`icon`,`metric`,`threshold_value`,`reward_points`,`sort_order`) VALUES
('FIRST_FOCUS','Khởi đầu tập trung','Hoàn thành phiên học tập trung đầu tiên','🌱','SESSIONS',1,20,10),
('FOCUS_10','Bền bỉ 10 phiên','Hoàn thành ít nhất 10 phiên học','🎯','SESSIONS',10,50,20),
('FOCUS_50','Kỷ luật 50 phiên','Hoàn thành ít nhất 50 phiên học','🏅','SESSIONS',50,120,30),
('HOURS_100','100 giờ chuyên tâm','Tích lũy 100 giờ học tập trung','⏳','HOURS',100,200,40),
('STREAK_7','Chuỗi 7 ngày','Duy trì tập trung 7 ngày liên tục','🔥','STREAK',7,70,50),
('STREAK_30','Chuỗi 30 ngày','Duy trì tập trung 30 ngày liên tục','💎','STREAK',30,250,60),
('INTEGRITY_95','Tập trung chuẩn mực','Đạt trung bình Focus Integrity từ 95','🛡️','INTEGRITY',95,100,70),
('POINTS_5000','Mốc 5.000 điểm','Đạt tổng điểm xếp hạng từ 5.000','⭐','POINTS',5000,150,80);

-- --------------------------------------------------------------------------
-- 5) ALIGN OLD FOCUS EVENT TABLE TO V4
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bf_focus_events` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `study_session_id` INT DEFAULT NULL,
  `user_email` VARCHAR(191) NOT NULL,
  `client_session_id` VARCHAR(100) DEFAULT NULL,
  `event_type` VARCHAR(80) NOT NULL,
  `event_value` VARCHAR(255) DEFAULT NULL,
  `metadata_json` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL bf_add_column_if_missing('bf_study_sessions','client_session_id','`client_session_id` VARCHAR(100) DEFAULT NULL AFTER `user_email`');
CALL bf_add_column_if_missing('bf_focus_events','study_session_id','`study_session_id` INT DEFAULT NULL AFTER `id`');
CALL bf_add_column_if_missing('bf_focus_events','client_session_id','`client_session_id` VARCHAR(100) DEFAULT NULL AFTER `user_email`');
CALL bf_add_column_if_missing('bf_focus_events','event_value','`event_value` VARCHAR(255) DEFAULT NULL AFTER `event_type`');

-- Old dump uses ENUM and cannot accept AUDIO_START/AUDIO_STOP. V4 uses VARCHAR.
ALTER TABLE `bf_focus_events` MODIFY COLUMN `event_type` VARCHAR(80) NOT NULL;

DROP PROCEDURE IF EXISTS bf_copy_legacy_focus_session_id;
DELIMITER $$
CREATE PROCEDURE bf_copy_legacy_focus_session_id()
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bf_focus_events' AND COLUMN_NAME='session_id'
  ) THEN
    UPDATE `bf_focus_events` SET `study_session_id`=`session_id`
    WHERE `study_session_id` IS NULL AND `session_id` IS NOT NULL;
  END IF;
END$$
DELIMITER ;
CALL bf_copy_legacy_focus_session_id();
DROP PROCEDURE IF EXISTS bf_copy_legacy_focus_session_id;

CALL bf_add_index_if_missing('bf_focus_events','idx_focus_event_study_session','INDEX `idx_focus_event_study_session` (`study_session_id`)');
CALL bf_add_index_if_missing('bf_focus_events','idx_focus_event_client','INDEX `idx_focus_event_client` (`user_email`,`client_session_id`,`created_at`)');
CALL bf_add_index_if_missing('bf_study_sessions','idx_session_client','INDEX `idx_session_client` (`client_session_id`)');

-- Old logged-in user sessions should not survive a forced password migration.
DELETE FROM `bf_user_sessions`;

DROP PROCEDURE IF EXISTS bf_add_column_if_missing;
DROP PROCEDURE IF EXISTS bf_add_index_if_missing;

SET FOREIGN_KEY_CHECKS=1;

-- Verification queries. These SELECTs are safe to leave in phpMyAdmin output.
SELECT COUNT(*) AS total_users FROM bf_users;
SELECT COUNT(*) AS users_requiring_password_change FROM bf_users WHERE must_change_password=1;
SELECT COUNT(*) AS users_without_password_hash FROM bf_users WHERE password_hash IS NULL OR password_hash='';
SELECT COUNT(*) AS role_permissions FROM bf_role_permissions;
