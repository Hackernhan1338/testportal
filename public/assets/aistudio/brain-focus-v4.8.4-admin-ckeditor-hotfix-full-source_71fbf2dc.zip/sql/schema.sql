-- =========================================================================
-- BRAIN FOCUS - DATABASE SCHEMA (MySQL 5.7+ / MySQL 8.0+ / MariaDB)
-- Bộ mã SQL tạo cơ sở dữ liệu và bảng lưu trữ toàn bộ dữ liệu Brain Focus
-- =========================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. BẢNG NGƯỜI DÙNG & HỌC VIÊN (users)
CREATE TABLE IF NOT EXISTS `bf_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(191) NOT NULL UNIQUE,
  `name` VARCHAR(191) NOT NULL,
  `school` VARCHAR(255) DEFAULT 'Người học tập trung',
  `password_hash` VARCHAR(255) DEFAULT NULL,
  `google_sub` VARCHAR(191) DEFAULT NULL UNIQUE,
  `google_linked_at` DATETIME DEFAULT NULL,
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 0,
  `password_changed_at` DATETIME DEFAULT NULL,
  `last_login_at` DATETIME DEFAULT NULL,
  `last_ip` VARCHAR(45) DEFAULT NULL,
  `last_user_agent` VARCHAR(500) DEFAULT NULL,
  `last_device_hash` CHAR(64) DEFAULT NULL,
  `avatar` LONGTEXT DEFAULT NULL,
  `role` ENUM('STUDENT', 'MODERATOR', 'ADMIN', 'SUPER_ADMIN') NOT NULL DEFAULT 'STUDENT',
  `status` ENUM('ACTIVE', 'LOCKED') NOT NULL DEFAULT 'ACTIVE',
  `rank_points` INT NOT NULL DEFAULT 1000,
  `bfs_score` INT NOT NULL DEFAULT 0,
  `bfs_assessment_score` INT NOT NULL DEFAULT 0,
  `purchased_gym_plays` INT NOT NULL DEFAULT 0,
  `total_hours` DECIMAL(8, 2) NOT NULL DEFAULT 0.00,
  `streak_days` INT NOT NULL DEFAULT 1,
  `sessions_count` INT NOT NULL DEFAULT 0,
  `gym_count` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_users_role` (`role`),
  INDEX `idx_users_points` (`rank_points`, `bfs_score`),
  INDEX `idx_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. BẢNG QUẢN TRỊ VIÊN HỆ THỐNG (admin_users)
CREATE TABLE IF NOT EXISTS `bf_admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `email` VARCHAR(191) NOT NULL UNIQUE,
  `full_name` VARCHAR(191) NOT NULL,
  `role` ENUM('ANALYST', 'MODERATOR', 'ADMIN', 'SUPER_ADMIN') NOT NULL DEFAULT 'ADMIN',
  `password_hash` VARCHAR(255) NOT NULL,
  `status` ENUM('ACTIVE', 'LOCKED') NOT NULL DEFAULT 'ACTIVE',
  `last_login` DATETIME DEFAULT NULL,
  `must_change_password` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. BẢNG LỊCH SỬ PHIÊN HỌC (study_sessions)
CREATE TABLE IF NOT EXISTS `bf_study_sessions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_email` VARCHAR(191) NOT NULL,
  `client_session_id` VARCHAR(100) DEFAULT NULL,
  `mode` VARCHAR(50) NOT NULL DEFAULT 'ultradian',
  `duration_minutes` INT NOT NULL DEFAULT 90,
  `actual_seconds` INT NOT NULL DEFAULT 0,
  `fullscreen_seconds` INT NOT NULL DEFAULT 0,
  `completion_percent` DECIMAL(5,2) NOT NULL DEFAULT 0,
  `started_at` DATETIME DEFAULT NULL,
  `ended_at` DATETIME DEFAULT NULL,
  `distractions` INT NOT NULL DEFAULT 0,
  `is_deep_focus` TINYINT(1) NOT NULL DEFAULT 0,
  `focus_integrity` INT NOT NULL DEFAULT 100,
  `goal` TEXT DEFAULT NULL,
  `emotion` VARCHAR(100) DEFAULT 'Tập trung cao 🚀',
  `reflection` TEXT DEFAULT NULL,
  `learned_insight` TEXT DEFAULT NULL,
  `bfs_earned` INT NOT NULL DEFAULT 0,
  `rank_earned` INT NOT NULL DEFAULT 0,
  `session_timestamp` BIGINT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_session_email` (`user_email`),
  INDEX `idx_session_client` (`client_session_id`),
  INDEX `idx_session_timestamp` (`session_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. BẢNG GÓP Ý & BÁO LỖI (feedback)
CREATE TABLE IF NOT EXISTS `bf_feedback` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `feedback_code` VARCHAR(50) NOT NULL UNIQUE,
  `type` VARCHAR(50) NOT NULL DEFAULT 'feature',
  `severity` VARCHAR(50) NOT NULL DEFAULT 'normal',
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `user_email` VARCHAR(191) DEFAULT NULL,
  `response_email` VARCHAR(191) DEFAULT NULL,
  `user_name` VARCHAR(191) DEFAULT NULL,
  `screenshot` LONGTEXT DEFAULT NULL,
  `status` ENUM('NEW', 'REVIEWING', 'IN_PROGRESS', 'RESOLVED', 'REJECTED') NOT NULL DEFAULT 'NEW',
  `admin_reply` TEXT DEFAULT NULL,
  `admin_note` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_fb_status` (`status`),
  INDEX `idx_fb_email` (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. BẢNG NHẬT KÝ KIỂM TOÁN QUẢN TRỊ (audit_logs)
CREATE TABLE IF NOT EXISTS `bf_audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` VARCHAR(100) NOT NULL,
  `admin_email` VARCHAR(191) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `target` VARCHAR(255) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_audit_admin` (`admin_email`),
  INDEX `idx_audit_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. BẢNG SỰ KIỆN PHÂN TÍCH (analytics_events)
CREATE TABLE IF NOT EXISTS `bf_analytics_events` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `event_name` VARCHAR(100) NOT NULL,
  `user_email` VARCHAR(191) DEFAULT NULL,
  `metadata_json` JSON DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ev_name` (`event_name`),
  INDEX `idx_ev_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. BẢNG NỘI DUNG CMS ĐỘNG (content_articles)
CREATE TABLE IF NOT EXISTS `bf_content` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `content_code` VARCHAR(50) NOT NULL UNIQUE,
  `type` ENUM('article', 'tip', 'faq') NOT NULL DEFAULT 'article',
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `author` VARCHAR(100) NOT NULL DEFAULT 'Admin',
  `status` ENUM('draft', 'published', 'archived') NOT NULL DEFAULT 'published',
  `excerpt` TEXT DEFAULT NULL,
  `cover_image` VARCHAR(1000) DEFAULT NULL,
  `featured` TINYINT(1) NOT NULL DEFAULT 0,
  `content` LONGTEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_content_type` (`type`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. BẢNG CẤU HÌNH HỆ THỐNG (system_settings)
CREATE TABLE IF NOT EXISTS `bf_settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. PHIÊN ĐĂNG NHẬP QUẢN TRỊ
CREATE TABLE IF NOT EXISTS `bf_admin_sessions` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY, `admin_id` INT NOT NULL, `session_hash` CHAR(64) NOT NULL UNIQUE,
  `ip_address` VARCHAR(45) DEFAULT NULL, `user_agent` VARCHAR(255) DEFAULT NULL, `last_seen_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` DATETIME NOT NULL, `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX `idx_admin_session_admin` (`admin_id`), INDEX `idx_admin_session_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. RBAC PERMISSIONS
CREATE TABLE IF NOT EXISTS `bf_role_permissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY, `role` ENUM('ANALYST','MODERATOR','ADMIN','SUPER_ADMIN') NOT NULL, `permission_key` VARCHAR(120) NOT NULL, `is_allowed` TINYINT(1) NOT NULL DEFAULT 1, UNIQUE KEY `uq_role_permission` (`role`,`permission_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. DEEP FOCUS EVENT TIMELINE
CREATE TABLE IF NOT EXISTS `bf_focus_events` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY, `study_session_id` INT DEFAULT NULL, `user_email` VARCHAR(191) NOT NULL, `client_session_id` VARCHAR(100) DEFAULT NULL, `event_type` VARCHAR(80) NOT NULL, `event_value` VARCHAR(255) DEFAULT NULL, `metadata_json` JSON DEFAULT NULL, `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_focus_event_session` (`study_session_id`), INDEX `idx_focus_event_user` (`user_email`,`created_at`), INDEX `idx_focus_event_type` (`event_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_bfs_assessments` (`id` BIGINT AUTO_INCREMENT PRIMARY KEY,`user_email` VARCHAR(191) NOT NULL,`score` INT NOT NULL,`answers_json` JSON DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX `idx_bfs_user` (`user_email`,`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_gym_sessions` (`id` BIGINT AUTO_INCREMENT PRIMARY KEY,`user_email` VARCHAR(191) NOT NULL,`game_type` VARCHAR(80) NOT NULL,`score` INT NOT NULL DEFAULT 0,`duration_seconds` INT NOT NULL DEFAULT 0,`metadata_json` JSON DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX `idx_gym_user` (`user_email`,`created_at`),INDEX `idx_gym_type` (`game_type`,`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_notifications` (`id` BIGINT AUTO_INCREMENT PRIMARY KEY,`user_email` VARCHAR(191) DEFAULT NULL,`title` VARCHAR(255) NOT NULL,`content` TEXT NOT NULL,`type` VARCHAR(50) NOT NULL DEFAULT 'info',`link_url` VARCHAR(500) DEFAULT NULL,`is_read` TINYINT(1) NOT NULL DEFAULT 0,`read_at` DATETIME DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX `idx_notification_user` (`user_email`,`is_read`,`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_announcements` (`id` INT AUTO_INCREMENT PRIMARY KEY,`title` VARCHAR(255) NOT NULL,`content` TEXT NOT NULL,`status` ENUM('draft','published','archived') NOT NULL DEFAULT 'draft',`starts_at` DATETIME DEFAULT NULL,`ends_at` DATETIME DEFAULT NULL,`created_by` INT DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,INDEX `idx_announcement_status` (`status`,`starts_at`,`ends_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_user_devices` (`id` BIGINT AUTO_INCREMENT PRIMARY KEY,`user_email` VARCHAR(191) NOT NULL,`device_hash` CHAR(64) NOT NULL,`device_name` VARCHAR(191) DEFAULT NULL,`last_ip` VARCHAR(45) DEFAULT NULL,`last_seen_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY `uq_user_device` (`user_email`,`device_hash`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_login_history` (`id` BIGINT AUTO_INCREMENT PRIMARY KEY,`user_email` VARCHAR(191) DEFAULT NULL,`actor_type` ENUM('USER','ADMIN') NOT NULL,`success` TINYINT(1) NOT NULL DEFAULT 1,`ip_address` VARCHAR(45) DEFAULT NULL,`user_agent` VARCHAR(255) DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX `idx_login_actor_created` (`actor_type`,`created_at`),INDEX `idx_login_user` (`user_email`,`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_content_categories` (`id` INT AUTO_INCREMENT PRIMARY KEY,`name` VARCHAR(100) NOT NULL UNIQUE,`slug` VARCHAR(120) NOT NULL UNIQUE,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_system_health` (`id` BIGINT AUTO_INCREMENT PRIMARY KEY,`metric_key` VARCHAR(100) NOT NULL,`metric_value` VARCHAR(255) NOT NULL,`metadata_json` JSON DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX `idx_health_metric` (`metric_key`,`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================================
-- KHỞI TẠO DỮ LIỆU BAN ĐẦU (SEED DATA)
-- =========================================================================

-- Super Admin đầu tiên được tạo an toàn qua /admin/setup.php khi bảng bf_admins còn trống.

-- Khởi tạo Cấu hình hệ thống mặc định
INSERT INTO `bf_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'Brain Focus'),
('site_tagline', 'Nền Tảng Quản Lý Tập Trung & Rèn Luyện Não Bộ'),
('default_focus_duration', '90'),
('max_daily_sessions', '3'),
('max_daily_gym_plays', '5'),
('maintenance_mode', 'false'),
('system_announcement', ''),
('show_announcement', 'false'),
('social_facebook_url', ''),
('social_youtube_url', ''),
('social_tiktok_url', ''),
('site_contact_email', 'thiennhan1338@gmail.com'),
('app_version', '4.6.0-phase1')
ON DUPLICATE KEY UPDATE `updated_at` = NOW();

-- Khởi tạo Bài viết khoa học & Mẹo mẫu
INSERT INTO `bf_content` (`content_code`, `type`, `title`, `category`, `author`, `status`, `excerpt`, `content`) VALUES
('art_1', 'article', 'Hội chứng Não Bỏng Ngô (Popcorn Brain): Cơ Chế & Cách Chữa Trị', 'Khoa Học Não Bộ', 'Ban Học Thuật Brain Focus', 'published', 'Tìm hiểu cơ chế não bộ bị quen với kích thích liên tục từ mạng xã hội ngắn và giải pháp phục hồi.', 'Não Bỏng Ngô xuất hiện khi dopamine được kích thích quá nhanh bởi video ngắn (TikTok, Reels, Shorts). Để điều trị, chu kỳ Ultradian 90 phút và thời gian tĩnh lặng là bài tập tối thượng.'),
('tip_1', 'tip', 'Quy tắc 5 Phút Vượt Qua Trì Hoãn', 'Mẹo Tập Trung', 'Admin', 'published', 'Cam kết chỉ ngồi vào bàn 5 phút. Vỏ não trước sẽ vượt qua rào cản ma sát ban đầu.', 'Hầu hết sự trì hoãn đến từ sự sợ hãi năng lượng bắt đầu. Hãy tự nhủ chỉ học đúng 5 phút, nếu chán thì nghỉ. 85% người dùng sẽ tiếp tục học sau 5 phút đầu.')
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);


INSERT INTO `bf_role_permissions` (`role`,`permission_key`,`is_allowed`) VALUES
('ANALYST','dashboard.view',1),('ANALYST','analytics.view',1),('ANALYST','sessions.view',1),
('MODERATOR','dashboard.view',1),('MODERATOR','analytics.view',1),('MODERATOR','sessions.view',1),('MODERATOR','content.view',1),('MODERATOR','content.create',1),('MODERATOR','content.edit',1),('MODERATOR','content.publish',1),('MODERATOR','feedback.view',1),('MODERATOR','feedback.reply',1),
('ADMIN','dashboard.view',1),('ADMIN','analytics.view',1),('ADMIN','analytics.export',1),('ADMIN','users.view',1),('ADMIN','users.edit',1),('ADMIN','users.lock',1),('ADMIN','sessions.view',1),('ADMIN','sessions.export',1),('ADMIN','content.view',1),('ADMIN','content.create',1),('ADMIN','content.edit',1),('ADMIN','content.delete',1),('ADMIN','content.publish',1),('ADMIN','feedback.view',1),('ADMIN','feedback.reply',1),('ADMIN','feedback.delete',1),('ADMIN','settings.view',1),('ADMIN','settings.update',1),('ADMIN','audit.view',1),('ADMIN','security.view',1),('ADMIN','security.block',1),('ADMIN','forbidden.view',1),('ADMIN','forbidden.manage',1),('ADMIN','honors.view',1),('ADMIN','honors.manage',1),('ADMIN','points.manage',1),('MODERATOR','forbidden.view',1),('MODERATOR','honors.view',1),('ANALYST','security.view',1)
ON DUPLICATE KEY UPDATE `is_allowed`=VALUES(`is_allowed`);

SET FOREIGN_KEY_CHECKS = 1;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS bf_user_sessions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  session_hash CHAR(64) NOT NULL UNIQUE,
  device_hash CHAR(64) NOT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(500) DEFAULT NULL,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_session_user(user_id),
  INDEX idx_user_session_exp(expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_access_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  admin_id INT DEFAULT NULL,
  email VARCHAR(191) DEFAULT NULL,
  device_hash CHAR(64) DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(500) DEFAULT NULL,
  browser_info VARCHAR(255) DEFAULT NULL,
  request_path VARCHAR(500) DEFAULT NULL,
  event_type VARCHAR(50) NOT NULL DEFAULT 'PAGE_VIEW',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_access_ip(ip_address,created_at),
  INDEX idx_access_device(device_hash,created_at),
  INDEX idx_access_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_block_rules (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  rule_type ENUM('IP','DEVICE','EMAIL','USER_AGENT') NOT NULL,
  rule_value VARCHAR(500) NOT NULL,
  reason VARCHAR(500) DEFAULT NULL,
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  expires_at DATETIME DEFAULT NULL,
  created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_block_lookup(rule_type,status),
  INDEX idx_block_exp(expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_forbidden_words (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  word VARCHAR(191) NOT NULL,
  match_type ENUM('CONTAINS','EXACT') NOT NULL DEFAULT 'CONTAINS',
  replacement VARCHAR(50) DEFAULT '***',
  scope ENUM('ALL','PROFILE','FEEDBACK','FOCUS','COMMUNITY') NOT NULL DEFAULT 'ALL',
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_forbidden_word(word,scope)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_point_transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  points INT NOT NULL,
  point_type ENUM('RANK','BFS','HONOR') NOT NULL DEFAULT 'RANK',
  reason_code VARCHAR(80) NOT NULL,
  reason_text VARCHAR(500) DEFAULT NULL,
  ref_type VARCHAR(80) DEFAULT NULL,
  ref_id VARCHAR(100) DEFAULT NULL,
  created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_points_user(user_id,created_at),
  INDEX idx_points_reason(reason_code,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_honors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  honor_code VARCHAR(80) NOT NULL UNIQUE,
  title VARCHAR(191) NOT NULL,
  description VARCHAR(500) NOT NULL,
  icon VARCHAR(20) NOT NULL DEFAULT '🏅',
  metric ENUM('SESSIONS','HOURS','STREAK','INTEGRITY','POINTS','MANUAL') NOT NULL DEFAULT 'MANUAL',
  threshold_value DECIMAL(10,2) NOT NULL DEFAULT 0,
  reward_points INT NOT NULL DEFAULT 0,
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_user_honors (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  honor_id INT NOT NULL,
  awarded_by_admin_id INT DEFAULT NULL,
  awarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  note VARCHAR(500) DEFAULT NULL,
  UNIQUE KEY uq_user_honor(user_id,honor_id),
  INDEX idx_user_honors_user(user_id,awarded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_focus_audio_usage (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  audio_type VARCHAR(50) NOT NULL,
  seconds_played INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audio_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO bf_honors(honor_code,title,description,icon,metric,threshold_value,reward_points,sort_order) VALUES
('FIRST_FOCUS','Khởi đầu tập trung','Hoàn thành phiên học tập trung đầu tiên','🌱','SESSIONS',1,20,10),
('FOCUS_10','Bền bỉ 10 phiên','Hoàn thành ít nhất 10 phiên học','🎯','SESSIONS',10,50,20),
('FOCUS_50','Kỷ luật 50 phiên','Hoàn thành ít nhất 50 phiên học','🏅','SESSIONS',50,120,30),
('HOURS_100','100 giờ chuyên tâm','Tích lũy 100 giờ học tập trung','⏳','HOURS',100,200,40),
('STREAK_7','Chuỗi 7 ngày','Duy trì tập trung 7 ngày liên tục','🔥','STREAK',7,70,50),
('STREAK_30','Chuỗi 30 ngày','Duy trì tập trung 30 ngày liên tục','💎','STREAK',30,250,60),
('INTEGRITY_95','Tập trung chuẩn mực','Đạt trung bình Focus Integrity từ 95','🛡️','INTEGRITY',95,100,70),
('POINTS_5000','Mốc 5.000 điểm','Đạt tổng điểm xếp hạng từ 5.000','⭐','POINTS',5000,150,80);

INSERT IGNORE INTO bf_role_permissions(role,permission_key,is_allowed) VALUES
('ANALYST','security.view',1),
('ADMIN','security.view',1),('ADMIN','security.block',1),('ADMIN','forbidden.view',1),('ADMIN','forbidden.manage',1),('ADMIN','honors.view',1),('ADMIN','honors.manage',1),('ADMIN','points.manage',1),
('MODERATOR','forbidden.view',1),('MODERATOR','honors.view',1);

SET FOREIGN_KEY_CHECKS=1;

-- Nội dung khởi tạo cho kho kiến thức/mẹo. INSERT IGNORE để không ghi đè nội dung quản trị đã có.
INSERT IGNORE INTO bf_content(content_code,type,title,category,author,status,excerpt,content) VALUES
('BF_KNOW_FOCUS_CYCLE','article','Chu kỳ tập trung: làm việc sâu rồi phục hồi','Nền tảng tập trung','Brain Focus','published','Khả năng tập trung không tăng tuyến tính vô hạn. Hãy chia công việc thành phiên rõ mục tiêu và có khoảng phục hồi.','Một phiên tập trung hiệu quả nên bắt đầu bằng một mục tiêu cụ thể, loại bỏ các tác nhân gây nhiễu và kết thúc bằng vài phút tự đánh giá. Với nhiệm vụ khó, có thể dùng các khối 25–90 phút tùy sức bền chú ý. Sau phiên, đứng dậy, uống nước, vận động nhẹ hoặc nhìn xa trước khi bắt đầu khối tiếp theo.'),
('BF_KNOW_ENVIRONMENT','article','Thiết kế môi trường để giảm tải ý chí','Môi trường học tập','Brain Focus','published','Đừng bắt ý chí phải chiến đấu với mọi thông báo và vật gây xao nhãng.','Tắt thông báo không cần thiết, đặt điện thoại ngoài tầm tay, chỉ mở các tab phục vụ nhiệm vụ và chuẩn bị tài liệu trước khi bấm bắt đầu. Môi trường càng ít quyết định thừa, não càng dành được nhiều nguồn lực cho nhiệm vụ chính.'),
('BF_KNOW_REFLECTION','article','Tự phản tư sau phiên học','Kỹ năng tự học','Brain Focus','published','Ghi ngắn điều đã làm được, điểm nghẽn và bước tiếp theo để giảm thời gian khởi động phiên sau.','Sau mỗi phiên, trả lời ba câu: Tôi đã hoàn thành điều gì? Điều gì làm tôi mất tập trung? Bước cụ thể tiếp theo là gì? Câu trả lời nên ngắn, quan sát được và dùng để điều chỉnh phiên tiếp theo.'),
('BF_TIP_10SEC','tip','Quy tắc 10 giây khi muốn mở mạng xã hội','Trị xao nhãng','Brain Focus','published','Không phản ứng ngay với thôi thúc chuyển ứng dụng.','Khi xuất hiện thôi thúc mở mạng xã hội hoặc kiểm tra tin nhắn, đếm chậm 10 giây. Ghi ra một dòng về điều đang muốn kiểm tra. Nếu việc đó không liên quan mục tiêu hiện tại, để lại cho giờ nghỉ và quay lại nhiệm vụ.'),
('BF_TIP_PHONE','tip','Đưa điện thoại ra khỏi đường nhìn','Môi trường','Brain Focus','published','Giảm tín hiệu thị giác có thể giúp giảm số lần tự động kiểm tra điện thoại.','Đặt điện thoại vào balô, ngăn kéo hoặc cách bàn học vài bước. Nếu cần dùng làm đồng hồ, bật chế độ Không làm phiền và úp màn hình.'),
('BF_TIP_RESTART','tip','Nghi thức quay lại trong 60 giây','Khôi phục tập trung','Brain Focus','published','Một lần xao nhãng không cần biến thành cả buổi mất tập trung.','Khi nhận ra mình vừa xao nhãng: đóng nội dung không liên quan, hít thở chậm vài nhịp, đọc lại mục tiêu phiên học và làm một hành động nhỏ trong 60 giây đầu tiên. Mục tiêu là khởi động lại, không tự trách hay cố bù quá mức.');


-- v4.4: secure gym attempts, dynamic surveys and score audit
CREATE TABLE IF NOT EXISTS bf_gym_attempts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, attempt_token CHAR(64) NOT NULL UNIQUE,
  user_id INT NOT NULL, user_email VARCHAR(191) NOT NULL, game_type ENUM('stroop','grid','math') NOT NULL,
  challenge_json LONGTEXT NOT NULL, used_paid_play TINYINT(1) NOT NULL DEFAULT 0,
  paid_currency ENUM('FREE','RANK','BFS') NOT NULL DEFAULT 'FREE', score INT NOT NULL DEFAULT 0,
  max_score INT NOT NULL DEFAULT 0, duration_seconds INT NOT NULL DEFAULT 0, rank_awarded INT NOT NULL DEFAULT 0,
  bfs_awarded INT NOT NULL DEFAULT 0, status ENUM('STARTED','COMPLETED','ABORTED','EXPIRED') NOT NULL DEFAULT 'STARTED',
  ip_address VARCHAR(45) DEFAULT NULL, user_agent VARCHAR(500) DEFAULT NULL,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, completed_at DATETIME DEFAULT NULL,
  INDEX idx_gym_attempt_user(user_id,started_at), INDEX idx_gym_attempt_email(user_email,started_at), INDEX idx_gym_attempt_status(status,started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_survey_questions (
  id INT AUTO_INCREMENT PRIMARY KEY, question_text VARCHAR(1000) NOT NULL, help_text VARCHAR(1000) DEFAULT NULL,
  question_type ENUM('SCALE','SINGLE','TEXT') NOT NULL DEFAULT 'SCALE', options_json LONGTEXT DEFAULT NULL,
  is_bfs_scored TINYINT(1) NOT NULL DEFAULT 1, status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  sort_order INT NOT NULL DEFAULT 0, created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_survey_question_status(status,sort_order), UNIQUE KEY uq_survey_question_text(question_text(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bf_survey_submissions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, user_email VARCHAR(191) NOT NULL, bfs_score INT DEFAULT NULL,
  question_count INT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_survey_submission_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bf_survey_responses (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, submission_id BIGINT NOT NULL, question_id INT NOT NULL, user_id INT NOT NULL,
  answer_value VARCHAR(500) DEFAULT NULL, answer_score DECIMAL(10,2) DEFAULT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_survey_response_question(question_id,created_at), INDEX idx_survey_response_submission(submission_id), INDEX idx_survey_response_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bf_score_audit_cases (
  id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, actual_rank_points INT NOT NULL DEFAULT 0,
  expected_rank_points INT NOT NULL DEFAULT 0, displayed_total_score INT NOT NULL DEFAULT 0, discrepancy INT NOT NULL DEFAULT 0,
  risk_score INT NOT NULL DEFAULT 0, reasons_json LONGTEXT DEFAULT NULL,
  status ENUM('OPEN','REVIEWING','CLEARED','CONFIRMED') NOT NULL DEFAULT 'OPEN', assigned_admin_id INT DEFAULT NULL,
  admin_note TEXT DEFAULT NULL, detected_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_score_audit_user_status(user_id,status), INDEX idx_score_audit_risk(status,risk_score,detected_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO bf_survey_questions(question_text,question_type,options_json,is_bfs_scored,status,sort_order) VALUES
('Tôi vô thức mở mạng xã hội hoặc ứng dụng khác khi đang học.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',10),
('Tôi khó duy trì chú ý vào một nhiệm vụ liên tục.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',20),
('Thông báo điện thoại làm tôi lập tức muốn kiểm tra.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',30),
('Tôi thường mở nhiều tab hoặc nhiều nhiệm vụ và chuyển qua lại.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',40),
('Tôi thấy bồn chồn khi phải học mà không có kích thích nhanh.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',50),
('Tôi thường bỏ dở một phần việc để bắt đầu việc khác.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',60),
('Sau khi bị gián đoạn, tôi mất nhiều thời gian để quay lại nhiệm vụ.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',70),
('Tôi có xu hướng vừa học vừa kiểm tra tin nhắn hoặc video ngắn.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',80),
('Tôi trì hoãn nhiệm vụ khó bằng các hoạt động số dễ chịu hơn.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',90),
('Tôi kết thúc một phiên học mà không nhớ rõ mục tiêu ban đầu.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',100);
INSERT INTO bf_role_permissions(role,permission_key,is_allowed) VALUES
('ANALYST','surveys.view',1),('ANALYST','score_audit.view',1),('MODERATOR','surveys.view',1),('MODERATOR','surveys.manage',1),
('ADMIN','surveys.view',1),('ADMIN','surveys.manage',1),('ADMIN','score_audit.view',1),('ADMIN','score_audit.manage',1)
ON DUPLICATE KEY UPDATE is_allowed=VALUES(is_allowed);

-- =========================================================================
-- V4.5.1 - QUÊN MẬT KHẨU QUA GMAIL SMTP
-- OTP chỉ lưu SHA-256 trong otp_code, không lưu mã 6 số dạng rõ.
-- =========================================================================
CREATE TABLE IF NOT EXISTS `bf_password_resets` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(191) NOT NULL,
  `otp_code` VARCHAR(64) NOT NULL,
  `request_ip` VARCHAR(45) DEFAULT NULL,
  `attempts` INT NOT NULL DEFAULT 0,
  `expires_at` DATETIME NOT NULL,
  `used_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_reset_lookup` (`email`,`expires_at`,`used_at`),
  INDEX `idx_reset_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_study_reminders` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `reminder_time` TIME NOT NULL,
  `reminder_text` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_reminder_user_time` (`user_id`,`reminder_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- V4.5.2 - BFS attention checks and retake audit
CREATE TABLE IF NOT EXISTS `bf_bfs_test_attempts` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `user_email` VARCHAR(191) NOT NULL,
  `attempt_no` INT NOT NULL DEFAULT 1,
  `raw_bfs_score` INT NOT NULL DEFAULT 0,
  `bonus_points` INT NOT NULL DEFAULT 0,
  `trap_total` INT NOT NULL DEFAULT 0,
  `trap_passed` INT NOT NULL DEFAULT 0,
  `status` ENUM('VALID','RETAKE_REQUIRED') NOT NULL DEFAULT 'VALID',
  `penalty_level` INT NOT NULL DEFAULT 0,
  `is_retake` TINYINT(1) NOT NULL DEFAULT 0,
  `answers_json` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_bfs_attempt_user` (`user_id`,`created_at`),
  INDEX `idx_bfs_attempt_email` (`user_email`,`created_at`),
  INDEX `idx_bfs_attempt_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('bfs_retake_bonus','30'),
('bfs_attention_retry_bonus_1','15'),
('bfs_attention_retry_bonus_2','5'),
('bfs_attention_check_count','2')
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

-- =========================================================================
-- V4.5.3 - ADMIN-CONTROLLED BFS RETAKE POLICY + REQUIRED RETAKE CAMPAIGNS
-- =========================================================================
CREATE TABLE IF NOT EXISTS `bf_bfs_retake_campaigns` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `reward_bfs` INT NOT NULL DEFAULT 500,
  `status` ENUM('ACTIVE','CLOSED') NOT NULL DEFAULT 'ACTIVE',
  `created_by_admin_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `closed_at` DATETIME DEFAULT NULL,
  INDEX `idx_bfs_campaign_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_bfs_retake_campaign_targets` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `campaign_id` BIGINT NOT NULL,
  `user_id` INT NOT NULL,
  `user_email` VARCHAR(191) NOT NULL,
  `status` ENUM('PENDING','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `penalty_level` INT NOT NULL DEFAULT 0,
  `reward_bfs_awarded` INT NOT NULL DEFAULT 0,
  `completed_attempt_id` BIGINT DEFAULT NULL,
  `completed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_bfs_campaign_target` (`campaign_id`,`user_id`),
  INDEX `idx_bfs_target_user_status` (`user_id`,`status`),
  INDEX `idx_bfs_target_campaign_status` (`campaign_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `bf_bfs_test_attempts`
  ADD COLUMN IF NOT EXISTS `campaign_id` BIGINT DEFAULT NULL AFTER `is_retake`,
  ADD COLUMN IF NOT EXISTS `bonus_type` VARCHAR(40) NOT NULL DEFAULT 'NONE' AFTER `campaign_id`;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('bfs_first_retake_adjustment_bfs','500'),
('bfs_repeat_retake_adjustment_bfs','0'),
('bfs_attention_retry_adjustment_1_bfs','250'),
('bfs_attention_retry_adjustment_2_bfs','100'),
('bfs_global_retake_default_adjustment_bfs','500'),
('bfs_attention_check_count','2')
ON DUPLICATE KEY UPDATE `updated_at`=NOW();
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- ================================================================
-- BRAIN FOCUS v4.5.4
-- Mobile UI support, BFS level card, Excel exports, web visits,
-- leaderboard rounds/share links, default reminders, reflection +25 XP.
-- ================================================================

ALTER TABLE `bf_study_sessions`
  ADD COLUMN IF NOT EXISTS `reflection_xp_awarded` TINYINT(1) NOT NULL DEFAULT 0 AFTER `reflection`;

CREATE TABLE IF NOT EXISTS `bf_page_visits` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `user_email` VARCHAR(191) DEFAULT NULL,
  `request_path` VARCHAR(500) NOT NULL,
  `referrer` VARCHAR(1000) DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(500) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_visit_created` (`created_at`),
  INDEX `idx_visit_path_created` (`request_path`(191),`created_at`),
  INDEX `idx_visit_user_created` (`user_id`,`created_at`),
  INDEX `idx_visit_ip_created` (`ip_address`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_leaderboard_rounds` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `status` ENUM('ACTIVE','CLOSED') NOT NULL DEFAULT 'ACTIVE',
  `created_by_admin_id` INT DEFAULT NULL,
  `started_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_lb_round_status` (`status`,`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_leaderboard_round_members` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `round_id` BIGINT NOT NULL,
  `user_id` INT NOT NULL,
  `baseline_score` INT NOT NULL DEFAULT 0,
  `final_score` INT DEFAULT NULL,
  `final_round_points` INT DEFAULT NULL,
  `final_rank` INT DEFAULT NULL,
  `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_lb_round_user` (`round_id`,`user_id`),
  INDEX `idx_lb_member_round_rank` (`round_id`,`final_rank`),
  INDEX `idx_lb_member_user` (`user_id`,`round_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_rank_share_links` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `share_token` CHAR(40) NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `round_id` BIGINT DEFAULT NULL,
  `snapshot_rank` INT NOT NULL DEFAULT 0,
  `snapshot_score` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_opened_at` DATETIME DEFAULT NULL,
  `open_count` INT NOT NULL DEFAULT 0,
  INDEX `idx_rank_share_user` (`user_id`,`created_at`),
  INDEX `idx_rank_share_round` (`round_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('reflection_xp_bonus','25')
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

INSERT INTO `bf_role_permissions` (`role`,`permission_key`,`is_allowed`) VALUES
('ANALYST','visits.view',1),('ANALYST','exports.view',1),
('MODERATOR','visits.view',1),('MODERATOR','exports.view',1),
('ADMIN','visits.view',1),('ADMIN','exports.view',1),('ADMIN','leaderboard.manage',1),
('SUPER_ADMIN','visits.view',1),('SUPER_ADMIN','exports.view',1),('SUPER_ADMIN','leaderboard.manage',1)
ON DUPLICATE KEY UPDATE `is_allowed`=VALUES(`is_allowed`);

-- Tạo đợt BXH đầu tiên nếu hệ thống chưa có đợt nào. Baseline 0 để giữ cách xếp hạng hiện tại.
INSERT INTO `bf_leaderboard_rounds` (`title`,`status`,`started_at`)
SELECT 'Đợt 1','ACTIVE',NOW()
WHERE NOT EXISTS (SELECT 1 FROM `bf_leaderboard_rounds` LIMIT 1);

INSERT IGNORE INTO `bf_leaderboard_round_members` (`round_id`,`user_id`,`baseline_score`)
SELECT (SELECT id FROM `bf_leaderboard_rounds` WHERE status='ACTIVE' ORDER BY id DESC LIMIT 1),u.id,0
FROM `bf_users` u
WHERE u.status='ACTIVE' AND (SELECT id FROM `bf_leaderboard_rounds` WHERE status='ACTIVE' ORDER BY id DESC LIMIT 1) IS NOT NULL;

-- Ba lịch nhắc mặc định giống giao diện mẫu.
INSERT INTO `bf_study_reminders` (`user_id`,`reminder_time`,`reminder_text`,`is_active`)
SELECT u.id,'08:30:00','Học sâu buổi sáng (Lock In)',1 FROM bf_users u
WHERE u.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM bf_study_reminders r WHERE r.user_id=u.id AND r.reminder_time='08:30:00');
INSERT INTO `bf_study_reminders` (`user_id`,`reminder_time`,`reminder_text`,`is_active`)
SELECT u.id,'14:00:00','Gym não giải toả (3 Game)',1 FROM bf_users u
WHERE u.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM bf_study_reminders r WHERE r.user_id=u.id AND r.reminder_time='14:00:00');
INSERT INTO `bf_study_reminders` (`user_id`,`reminder_time`,`reminder_text`,`is_active`)
SELECT u.id,'20:00:00','Chu kỳ Ultradian tối (90p)',1 FROM bf_users u
WHERE u.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM bf_study_reminders r WHERE r.user_id=u.id AND r.reminder_time='20:00:00');

-- Bộ 10 câu BFS mới: chỉ cập nhật dữ liệu câu hỏi, giữ nguyên ID/trạng thái/thứ tự.
UPDATE bf_survey_questions SET question_text='Khi bắt đầu ngồi vào bàn học hoặc làm bài tập, bạn thường mở điện thoại sau bao lâu?',help_text='Kiểm soát xung động',options_json='[{"label":"Ngay lập tức hoặc dưới 5 phút","score":10},{"label":"Khoảng 10 - 15 phút","score":40},{"label":"Khoảng 30 - 45 phút","score":75},{"label":"Giữ vững trên 60 - 90 phút mà không chạm vào điện thoại","score":100}]' WHERE id=1;
UPDATE bf_survey_questions SET question_text='Bạn có thói quen vừa học vừa nghe nhạc có lời hoặc liên tục đổi bài hát không?',help_text='Độ tập trung',options_json='[{"label":"Thường xuyên, nếu không có tiếng nhạc/clip thì không ngồi yên được","score":15},{"label":"Thỉnh thoảng đổi bài hoặc lướt chọn playlist","score":45},{"label":"Chỉ nghe nhạc không lời/lofi/tiếng ồn trắng cố định","score":85},{"label":"Học trong không gian yên tĩnh tuyệt đối hoặc không bị phụ thuộc","score":100}]' WHERE id=2;
UPDATE bf_survey_questions SET question_text='Khi gặp một bài toán khó hoặc đoạn văn dài, cảm giác đầu tiên của bạn là gì?',help_text='Sức bền nhận thức',options_json='[{"label":"Cực kỳ bồn chồn, muốn bỏ qua hoặc mở app khác ngay lập tức","score":10},{"label":"Đọc lướt nhanh, dễ mất kiên nhẫn sau 2-3 phút","score":35},{"label":"Cố gắng đọc lại 1-2 lần để tìm hướng giải","score":70},{"label":"Bình tĩnh phân tích từng bước, duy trì chú ý cho đến khi giải xong","score":100}]' WHERE id=3;
UPDATE bf_survey_questions SET question_text='Thời gian bạn lướt các video ngắn (TikTok, Reels, Shorts) mỗi ngày là bao nhiêu?',help_text='Thói quen số',options_json='[{"label":"Trên 3 - 4 tiếng mỗi ngày","score":10},{"label":"Từ 1.5 - 3 tiếng","score":40},{"label":"Dưới 1 tiếng mỗi ngày","score":75},{"label":"Rất hiếm khi hoặc dưới 20 phút mỗi ngày","score":100}]' WHERE id=4;
UPDATE bf_survey_questions SET question_text='Bạn có thường cảm thấy ''rung chuông ảo'' (nghĩ điện thoại có thông báo dù không có) không?',help_text='Xung động vô thức',options_json='[{"label":"Liên tục trong ngày, luôn vô thức mở màn hình kiểm tra","score":15},{"label":"Thỉnh thoảng, đặc biệt khi cảm thấy chán bài học","score":40},{"label":"Hiếm khi","score":80},{"label":"Hoàn toàn không","score":100}]' WHERE id=5;
UPDATE bf_survey_questions SET question_text='Khả năng duy trì đọc một cuốn sách giáo khoa/tài liệu giấy liên tục 30 phút của bạn thế nào?',help_text='Độ sâu chú ý',options_json='[{"label":"Gần như không thể, mắt đọc nhưng đầu nghĩ việc khác","score":15},{"label":"Đọc được 10-15 phút là muốn với tay lấy điện thoại","score":45},{"label":"Đọc tốt khoảng 25-30 phút với độ hiểu bài khá","score":80},{"label":"Đọc say mê 45-60 phút mà không hề bị phân tâm","score":100}]' WHERE id=6;
UPDATE bf_survey_questions SET question_text='Khi có thông báo tin nhắn mới khi đang học, phản xạ của bạn là gì?',help_text='Kiểm soát kích thích',options_json='[{"label":"Mở xem và trả lời ngay lập tức, sau đó bị cuốn vào lướt mạng xã hội","score":10},{"label":"Mở xem tin nhắn rồi cố gắng quay lại học tiếp","score":40},{"label":"Liếc nhìn preview, nếu không khẩn cấp sẽ đợi hết phiên học","score":75},{"label":"Tắt toàn bộ thông báo hoặc để điện thoại ở chế độ Không làm phiền","score":100}]' WHERE id=7;
UPDATE bf_survey_questions SET question_text='Sau một phiên học dài 60-90 phút, bạn cảm thấy thế nào?',help_text='Năng lượng não bộ',options_json='[{"label":"Rất hiếm khi học được 60 phút, thường bỏ dở giữa chừng","score":15},{"label":"Căng thẳng, mệt mỏi và thèm kích thích từ điện thoại","score":45},{"label":"Khá thoải mái nếu có quãng nghỉ ngắn giữa chừng","score":80},{"label":"Cảm giác sảng khoái và tự hào vì đạt trạng thái tập trung sâu","score":100}]' WHERE id=8;
UPDATE bf_survey_questions SET question_text='Bạn có thực hiện đa nhiệm (vừa học vừa nhắn tin, xem video phụ) không?',help_text='Tập trung đơn nhiệm',options_json='[{"label":"Thường xuyên làm nhiều việc một lúc","score":10},{"label":"Thỉnh thoảng mở tab phụ để trò chuyện","score":40},{"label":"Chủ yếu chỉ tập trung vào tài liệu môn học","score":80},{"label":"Luôn thực hiện đơn nhiệm tuyệt đối (Monotasking)","score":100}]' WHERE id=9;
UPDATE bf_survey_questions SET question_text='Buổi tối trước khi đi ngủ, bạn thường sử dụng điện thoại đến khi nào?',help_text='Nhịp sinh học',options_json='[{"label":"Dùng đến tận lúc ngủ thiếp đi, để điện thoại ngay đầu giường","score":10},{"label":"Dùng đến trước khi ngủ 10-15 phút","score":40},{"label":"Cất điện thoại trước khi ngủ 30-45 phút","score":75},{"label":"Ngừng dùng thiết bị điện tử trước khi ngủ 60 phút và để ngoài tầm với","score":100}]' WHERE id=10;

SET FOREIGN_KEY_CHECKS=1;


-- PHASE 1 v4.6: TERMS / GOOGLE / MAIL CAMPAIGN
CREATE TABLE IF NOT EXISTS `bf_terms_versions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,`version` VARCHAR(40) NOT NULL UNIQUE,`title` VARCHAR(255) NOT NULL,`content_html` LONGTEXT NOT NULL,`reward_xp` INT NOT NULL DEFAULT 50,`status` ENUM('DRAFT','PUBLISHED','ARCHIVED') NOT NULL DEFAULT 'DRAFT',`published_at` DATETIME DEFAULT NULL,`created_by_admin_id` INT DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,INDEX `idx_terms_status` (`status`,`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_terms_acceptances` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,`user_id` INT NOT NULL,`terms_id` INT NOT NULL,`accepted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`accepted_ip` VARCHAR(45) DEFAULT NULL,`user_agent` VARCHAR(500) DEFAULT NULL,`reward_xp` INT NOT NULL DEFAULT 0,UNIQUE KEY `uq_terms_user_version` (`user_id`,`terms_id`),INDEX `idx_terms_accept_terms` (`terms_id`,`accepted_at`),INDEX `idx_terms_accept_user` (`user_id`,`accepted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_mail_campaigns` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,`created_by_admin_id` INT DEFAULT NULL,`category` VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',`recipient_scope` VARCHAR(50) NOT NULL DEFAULT 'ALL_ACTIVE',`subject` VARCHAR(255) NOT NULL,`content_html` LONGTEXT NOT NULL,`create_notification` TINYINT(1) NOT NULL DEFAULT 1,`status` ENUM('QUEUED','SENDING','COMPLETED','CANCELLED') NOT NULL DEFAULT 'QUEUED',`total_count` INT NOT NULL DEFAULT 0,`sent_count` INT NOT NULL DEFAULT 0,`failed_count` INT NOT NULL DEFAULT 0,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`completed_at` DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_mail_queue` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,`campaign_id` BIGINT NOT NULL,`user_id` INT NOT NULL,`email` VARCHAR(191) NOT NULL,`status` ENUM('PENDING','SENT','FAILED') NOT NULL DEFAULT 'PENDING',`error_message` VARCHAR(1000) DEFAULT NULL,`sent_at` DATETIME DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY `uq_campaign_user` (`campaign_id`,`user_id`),INDEX `idx_mail_queue_status` (`campaign_id`,`status`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `bf_users`
  ADD COLUMN IF NOT EXISTS `birthday` DATE DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `gender` VARCHAR(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `province` VARCHAR(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `target_school` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `study_unit` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quote_text` VARCHAR(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `quote_author` VARCHAR(191) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `profile_visibility` ENUM('PUBLIC','PRIVATE') NOT NULL DEFAULT 'PUBLIC',
  ADD COLUMN IF NOT EXISTS `onboarding_seen_at` DATETIME DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `onboarding_completed_at` DATETIME DEFAULT NULL;

-- Tài khoản cũ không bị ép onboarding lần đầu; tài khoản tạo sau migration vẫn NULL.
UPDATE `bf_users` SET `onboarding_seen_at`=NOW() WHERE `onboarding_seen_at` IS NULL;

ALTER TABLE `bf_notifications`
  ADD COLUMN IF NOT EXISTS `category` VARCHAR(40) NOT NULL DEFAULT 'GENERAL' AFTER `type`,
  ADD COLUMN IF NOT EXISTS `detail_html` LONGTEXT DEFAULT NULL AFTER `content`,
  ADD COLUMN IF NOT EXISTS `ref_key` VARCHAR(191) DEFAULT NULL AFTER `link_url`,
  ADD COLUMN IF NOT EXISTS `priority` ENUM('LOW','NORMAL','HIGH') NOT NULL DEFAULT 'NORMAL' AFTER `ref_key`,
  ADD COLUMN IF NOT EXISTS `expires_at` DATETIME DEFAULT NULL AFTER `read_at`;
CREATE INDEX IF NOT EXISTS `idx_notifications_ref` ON `bf_notifications` (`user_email`,`ref_key`);
CREATE INDEX IF NOT EXISTS `idx_notifications_category` ON `bf_notifications` (`user_email`,`category`,`is_read`,`created_at`);

CREATE TABLE IF NOT EXISTS `bf_badges` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `badge_code` VARCHAR(80) NOT NULL UNIQUE,
  `name` VARCHAR(191) NOT NULL,
  `description` VARCHAR(700) NOT NULL,
  `icon` VARCHAR(30) NOT NULL DEFAULT '🏅',
  `tier` ENUM('RUBY','EMERALD','DIAMOND','GOLD','SILVER','BRONZE') NOT NULL DEFAULT 'BRONZE',
  `reward_xp` INT NOT NULL DEFAULT 0,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_user_badges` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `badge_id` INT NOT NULL,
  `awarded_by_admin_id` INT DEFAULT NULL,
  `note` VARCHAR(500) DEFAULT NULL,
  `awarded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_user_badge` (`user_id`,`badge_id`),
  INDEX `idx_user_badges_user` (`user_id`,`awarded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_tasks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `task_code` VARCHAR(80) NOT NULL UNIQUE,
  `title` VARCHAR(191) NOT NULL,
  `description` VARCHAR(700) NOT NULL,
  `icon` VARCHAR(30) NOT NULL DEFAULT '🎯',
  `task_scope` ENUM('DISCOVERY','DAILY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',
  `link_url` VARCHAR(500) DEFAULT NULL,
  `reward_xp` INT NOT NULL DEFAULT 10,
  `status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  `sort_order` INT NOT NULL DEFAULT 0,
  `starts_at` DATETIME DEFAULT NULL,
  `ends_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_user_task_completions` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `task_id` INT NOT NULL,
  `reward_xp` INT NOT NULL DEFAULT 0,
  `completed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_user_task` (`user_id`,`task_id`),
  INDEX `idx_user_task_user` (`user_id`,`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_badges` (`badge_code`,`name`,`description`,`icon`,`tier`,`reward_xp`,`sort_order`) VALUES
('ROOKIE_BRAIN_FOCUS','Tân binh Brain Focus','Hoàn thành 100% hồ sơ khởi động và các bước làm quen Brain Focus.','🧠','BRONZE',50,10),
('PROFILE_READY','Hồ sơ chỉn chu','Hoàn thiện đầy đủ hồ sơ cá nhân.','✨','SILVER',30,20),
('FOCUS_EXPLORER','Nhà thám hiểm tập trung','Khám phá các khu vực quan trọng của Brain Focus.','🧭','GOLD',50,30)
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

INSERT INTO `bf_tasks` (`task_code`,`title`,`description`,`icon`,`task_scope`,`link_url`,`reward_xp`,`sort_order`) VALUES
('DISCOVER_NOTIFICATIONS','Khám phá Trung tâm thông báo','Mở Trung tâm thông báo để theo dõi lịch học, tiến độ, bảo mật và thông báo từ BQT.','🔔','DISCOVERY','/notifications.php',10,10),
('DISCOVER_PROFILE','Hoàn thiện hồ sơ cá nhân','Bổ sung ngày sinh, câu nói, tỉnh/thành, mục tiêu trường và đơn vị đang học.','👤','DISCOVERY','/profile.php',20,20),
('DISCOVER_ACHIEVEMENTS','Khám phá thư viện thành tích','Xem danh hiệu và huy hiệu đã đạt cùng kho thành tích của Brain Focus.','🏅','DISCOVERY','/achievements.php',10,30),
('DISCOVER_LEADERBOARD','Xem bảng xếp hạng','Kiểm tra thứ hạng và các đợt thi đua đang diễn ra.','🏆','DISCOVERY','/leaderboard.php',10,40),
('DISCOVER_GYM','Thử Gym não','Mở khu vực rèn luyện phản xạ và ghi nhớ.','🎮','DISCOVERY','/gym.php',10,50),
('DISCOVER_KNOWLEDGE','Mở thư viện kiến thức','Khám phá nội dung khoa học tập trung và mẹo trị xao nhãng.','📚','DISCOVERY','/knowledge.php',10,60)
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('app_version','4.7.0-phase2-3'),
('seo_site_name','Brain Focus'),
('seo_site_description','Brain Focus hỗ trợ học tập tập trung, Deep Focus, Gym não, BFS, thống kê tiến độ và thi đua học tập.'),
('seo_keywords','brain focus,tập trung,học tập,pomodoro,deep focus,gym não,BFS'),
('seo_og_image',''),
('site_favicon_url','')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`),`updated_at`=NOW();

SET FOREIGN_KEY_CHECKS=1;

-- =========================================================
-- v4.8.0 Operations & Experience
-- =========================================================
ALTER TABLE `bf_badges` ADD COLUMN IF NOT EXISTS `image_path` VARCHAR(500) DEFAULT NULL;
ALTER TABLE `bf_tasks`
  MODIFY COLUMN `task_scope` ENUM('DISCOVERY','DAILY','WEEKLY','MONTHLY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',
  ADD COLUMN IF NOT EXISTS `required_for_bonus` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `max_completions_per_period` INT NOT NULL DEFAULT 1;
ALTER TABLE `bf_user_task_completions` ADD COLUMN IF NOT EXISTS `period_key` VARCHAR(40) NOT NULL DEFAULT 'ONCE';
ALTER TABLE `bf_user_task_completions` DROP INDEX IF EXISTS `uq_user_task`;
CREATE UNIQUE INDEX IF NOT EXISTS `uq_user_task_period` ON `bf_user_task_completions` (`user_id`,`task_id`,`period_key`);
CREATE TABLE IF NOT EXISTS `bf_task_period_rewards` (`id` BIGINT AUTO_INCREMENT PRIMARY KEY,`user_id` INT NOT NULL,`scope` ENUM('DAILY','WEEKLY','MONTHLY') NOT NULL,`period_key` VARCHAR(40) NOT NULL,`reward_xp` INT NOT NULL DEFAULT 100,`awarded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY `uq_task_period_reward` (`user_id`,`scope`,`period_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `bf_focus_sounds` (`id` INT AUTO_INCREMENT PRIMARY KEY,`sound_code` VARCHAR(80) NOT NULL UNIQUE,`name` VARCHAR(191) NOT NULL,`description` VARCHAR(500) DEFAULT NULL,`file_path` VARCHAR(500) NOT NULL,`mime_type` VARCHAR(100) DEFAULT NULL,`default_volume` INT NOT NULL DEFAULT 40,`status` ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',`sort_order` INT NOT NULL DEFAULT 0,`created_by_admin_id` INT DEFAULT NULL,`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- v4.8.1 Profile/tasks/email preference
-- =========================================================
ALTER TABLE `bf_users`
  ADD COLUMN IF NOT EXISTS `email_updates_opt_in` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `email_updates_decided_at` DATETIME DEFAULT NULL;
INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES ('app_version','4.8.1')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`),`updated_at`=NOW();


-- ===== v4.8.2 =====
-- Brain Focus v4.8.2 - Tasks, streak, audio module, birthday helper, CKEditor toggle
SET NAMES utf8mb4;

ALTER TABLE `bf_tasks`
  ADD COLUMN IF NOT EXISTS `metric_key` VARCHAR(50) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `target_value` INT NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS `bf_gym_purchase_events` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `currency` VARCHAR(20) NOT NULL DEFAULT 'RANK',
  `cost_points` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_gym_purchase_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('module_audio','true'),
('task_set_bonus_xp','100'),
('ckeditor_enabled','true')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

-- Nhiệm vụ hằng ngày
INSERT INTO `bf_tasks`
(`task_code`,`title`,`description`,`icon`,`task_scope`,`link_url`,`reward_xp`,`status`,`sort_order`,`required_for_bonus`,`metric_key`,`target_value`)
VALUES
('DAILY_FOCUS_2','Chạy 2 phiên học bất kỳ','Hoàn thành 2 phiên học trong ngày.','⏱️','DAILY','/index.php',15,'ACTIVE',10,1,'FOCUS_ANY',2),
('DAILY_GYM_PLAY_5','Chơi 5 lượt Gym não','Hoàn thành 5 lượt Gym não trong ngày.','🎮','DAILY','/gym.php',15,'ACTIVE',20,1,'GYM_PLAY',5),
('DAILY_GYM_BUY_5','Mua 5 lượt Gym não','Mua tổng cộng 5 lượt Gym não trong ngày.','🛒','DAILY','/gym.php',15,'ACTIVE',30,1,'GYM_PURCHASE',5),
('DAILY_REFLECTION_1','Làm ít nhất 1 bài đánh giá sau phiên học','Lưu ít nhất 1 đúc kết/đánh giá sau phiên học trong ngày.','📝','DAILY','/profile.php#reflections',15,'ACTIVE',40,1,'REFLECTION',1),
('DAILY_FOCUS_90_1','Chạy 1 phiên học 90 phút','Hoàn thành ít nhất 1 phiên học đặt 90 phút trong ngày.','🧘','DAILY','/index.php?duration=90&deep=1',20,'ACTIVE',50,1,'FOCUS_90',1)
ON DUPLICATE KEY UPDATE
title=VALUES(title),description=VALUES(description),icon=VALUES(icon),task_scope=VALUES(task_scope),
link_url=VALUES(link_url),reward_xp=VALUES(reward_xp),status='ACTIVE',sort_order=VALUES(sort_order),
required_for_bonus=VALUES(required_for_bonus),metric_key=VALUES(metric_key),target_value=VALUES(target_value);

-- Nhiệm vụ hằng tuần
INSERT INTO `bf_tasks`
(`task_code`,`title`,`description`,`icon`,`task_scope`,`link_url`,`reward_xp`,`status`,`sort_order`,`required_for_bonus`,`metric_key`,`target_value`)
VALUES
('WEEKLY_FOCUS_15','Chạy 15 phiên học bất kỳ','Hoàn thành 15 phiên học trong tuần.','⏱️','WEEKLY','/index.php',30,'ACTIVE',10,1,'FOCUS_ANY',15),
('WEEKLY_GYM_PLAY_200','Chơi 200 lượt Gym não','Hoàn thành 200 lượt Gym não trong tuần.','🎮','WEEKLY','/gym.php',40,'ACTIVE',20,1,'GYM_PLAY',200),
('WEEKLY_GYM_BUY_150','Mua 150 lượt Gym não','Mua tổng cộng 150 lượt Gym não trong tuần.','🛒','WEEKLY','/gym.php',40,'ACTIVE',30,1,'GYM_PURCHASE',150),
('WEEKLY_REFLECTION_10','Làm ít nhất 10 bài đánh giá sau phiên học','Lưu ít nhất 10 đúc kết/đánh giá sau phiên học trong tuần.','📝','WEEKLY','/profile.php#reflections',35,'ACTIVE',40,1,'REFLECTION',10),
('WEEKLY_FOCUS_90_5','Chạy 5 phiên học 90 phút','Hoàn thành ít nhất 5 phiên học đặt 90 phút trong tuần.','🧘','WEEKLY','/index.php?duration=90&deep=1',40,'ACTIVE',50,1,'FOCUS_90',5)
ON DUPLICATE KEY UPDATE
title=VALUES(title),description=VALUES(description),icon=VALUES(icon),task_scope=VALUES(task_scope),
link_url=VALUES(link_url),reward_xp=VALUES(reward_xp),status='ACTIVE',sort_order=VALUES(sort_order),
required_for_bonus=VALUES(required_for_bonus),metric_key=VALUES(metric_key),target_value=VALUES(target_value);

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('app_version','4.8.2')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

