-- Brain Focus v4.4 - Gym, leaderboard, integrity statistics, surveys and score audit
SET NAMES utf8mb4;

DROP PROCEDURE IF EXISTS bf44_add_column;
DELIMITER $$
CREATE PROCEDURE bf44_add_column(IN tbl VARCHAR(64), IN col VARCHAR(64), IN defn TEXT)
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=tbl AND COLUMN_NAME=col) THEN
    SET @q = CONCAT('ALTER TABLE `',tbl,'` ADD COLUMN `',col,'` ',defn);
    PREPARE s FROM @q; EXECUTE s; DEALLOCATE PREPARE s;
  END IF;
END$$
DELIMITER ;

CALL bf44_add_column('bf_study_sessions','actual_seconds','INT NOT NULL DEFAULT 0 AFTER `duration_minutes`');
CALL bf44_add_column('bf_study_sessions','fullscreen_seconds','INT NOT NULL DEFAULT 0 AFTER `actual_seconds`');
CALL bf44_add_column('bf_study_sessions','completion_percent','DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER `fullscreen_seconds`');
CALL bf44_add_column('bf_study_sessions','started_at','DATETIME DEFAULT NULL AFTER `completion_percent`');
CALL bf44_add_column('bf_study_sessions','ended_at','DATETIME DEFAULT NULL AFTER `started_at`');
CALL bf44_add_column('bf_feedback','response_email','VARCHAR(191) DEFAULT NULL AFTER `user_email`');
CALL bf44_add_column('bf_content','cover_image','VARCHAR(1000) DEFAULT NULL AFTER `excerpt`');
CALL bf44_add_column('bf_content','featured','TINYINT(1) NOT NULL DEFAULT 0 AFTER `cover_image`');
CALL bf44_add_column('bf_users','bfs_assessment_score','INT NOT NULL DEFAULT 0 AFTER `bfs_score`');
-- Tương thích bf_gym_sessions legacy: DB cũ dùng game_code, v4.4 dùng game_type.
CALL bf44_add_column('bf_gym_sessions','game_type','VARCHAR(80) DEFAULT NULL AFTER `user_email`');
UPDATE bf_gym_sessions SET game_type=game_code WHERE (game_type IS NULL OR game_type='') AND game_code IS NOT NULL;
UPDATE bf_users u
LEFT JOIN (
  SELECT a.user_email,a.score FROM bf_bfs_assessments a
  INNER JOIN (SELECT user_email,MAX(id) max_id FROM bf_bfs_assessments GROUP BY user_email) x ON x.max_id=a.id
) last_bfs ON last_bfs.user_email=u.email
SET u.bfs_assessment_score=COALESCE(last_bfs.score,LEAST(u.bfs_score,1000))
WHERE u.bfs_assessment_score=0 AND u.bfs_score>0;
DROP PROCEDURE IF EXISTS bf44_add_column;

CREATE TABLE IF NOT EXISTS bf_gym_attempts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  attempt_token CHAR(64) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  user_email VARCHAR(191) NOT NULL,
  game_type ENUM('stroop','grid','math') NOT NULL,
  challenge_json LONGTEXT NOT NULL,
  used_paid_play TINYINT(1) NOT NULL DEFAULT 0,
  paid_currency ENUM('FREE','RANK','BFS') NOT NULL DEFAULT 'FREE',
  score INT NOT NULL DEFAULT 0,
  max_score INT NOT NULL DEFAULT 0,
  duration_seconds INT NOT NULL DEFAULT 0,
  rank_awarded INT NOT NULL DEFAULT 0,
  bfs_awarded INT NOT NULL DEFAULT 0,
  status ENUM('STARTED','COMPLETED','ABORTED','EXPIRED') NOT NULL DEFAULT 'STARTED',
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(500) DEFAULT NULL,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME DEFAULT NULL,
  INDEX idx_gym_attempt_user(user_id,started_at),
  INDEX idx_gym_attempt_email(user_email,started_at),
  INDEX idx_gym_attempt_status(status,started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_survey_questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  question_text VARCHAR(1000) NOT NULL,
  help_text VARCHAR(1000) DEFAULT NULL,
  question_type ENUM('SCALE','SINGLE','TEXT') NOT NULL DEFAULT 'SCALE',
  options_json LONGTEXT DEFAULT NULL,
  is_bfs_scored TINYINT(1) NOT NULL DEFAULT 1,
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  sort_order INT NOT NULL DEFAULT 0,
  created_by_admin_id INT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_survey_question_status(status,sort_order), UNIQUE KEY uq_survey_question_text(question_text(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_survey_submissions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  user_email VARCHAR(191) NOT NULL,
  bfs_score INT DEFAULT NULL,
  question_count INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_survey_submission_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_survey_responses (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  submission_id BIGINT NOT NULL,
  question_id INT NOT NULL,
  user_id INT NOT NULL,
  answer_value VARCHAR(500) DEFAULT NULL,
  answer_score DECIMAL(10,2) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_survey_response_question(question_id,created_at),
  INDEX idx_survey_response_submission(submission_id),
  INDEX idx_survey_response_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bf_score_audit_cases (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  actual_rank_points INT NOT NULL DEFAULT 0,
  expected_rank_points INT NOT NULL DEFAULT 0,
  displayed_total_score INT NOT NULL DEFAULT 0,
  discrepancy INT NOT NULL DEFAULT 0,
  risk_score INT NOT NULL DEFAULT 0,
  reasons_json LONGTEXT DEFAULT NULL,
  status ENUM('OPEN','REVIEWING','CLEARED','CONFIRMED') NOT NULL DEFAULT 'OPEN',
  assigned_admin_id INT DEFAULT NULL,
  admin_note TEXT DEFAULT NULL,
  detected_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_score_audit_user_open(user_id,status),
  INDEX idx_score_audit_risk(status,risk_score,detected_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cho phép lưu lịch sử nhiều hồ sơ giám sát cho cùng một user; không khóa theo trạng thái.
DROP PROCEDURE IF EXISTS bf44_drop_score_audit_unique;
DELIMITER $$
CREATE PROCEDURE bf44_drop_score_audit_unique()
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bf_score_audit_cases' AND INDEX_NAME='uq_score_audit_user_open') THEN
    ALTER TABLE bf_score_audit_cases DROP INDEX uq_score_audit_user_open;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bf_score_audit_cases' AND INDEX_NAME='idx_score_audit_user_status') THEN
    ALTER TABLE bf_score_audit_cases ADD INDEX idx_score_audit_user_status(user_id,status);
  END IF;
END$$
DELIMITER ;
CALL bf44_drop_score_audit_unique();
DROP PROCEDURE IF EXISTS bf44_drop_score_audit_unique;


INSERT IGNORE INTO bf_survey_questions(question_text,question_type,options_json,is_bfs_scored,status,sort_order) VALUES
('Tôi vô thức mở mạng xã hội hoặc ứng dụng khác khi đang học.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',10),
('Tôi khó duy trì chú ý vào một nhiệm vụ liên tục.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',20),
('Thông báo điện thoại làm tôi lập tức muốn kiểm tra.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',30),
('Tôi thường mở nhiều tab hoặc nhiều nhiệm vụ và chuyển qua lại.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',40),
('Tôi thấy bồn chồn khi phải học mà không có kích thích nhanh.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',50),
('Tôi thường bỏ dở một phần việc để bắt đầu việc khác.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',60),
('Sau khi bị gián đoạn, tôi mất nhiều thời gian để quay lại nhiệm vụ.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',70),
('Tôi có xu hướng vừa học vừa kiểm tra tin nhắn hoặc video ngắn.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',80),
('Tôi trì hoãn nhiệm vụ khó bằng các hoạt động số dễ chịu hơn.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',90),
('Tôi kết thúc một phiên học mà không nhớ rõ mục tiêu ban đầu.','SCALE','[{"label":"Không bao giờ","score":0},{"label":"Hiếm khi","score":1},{"label":"Đôi khi","score":2},{"label":"Thường xuyên","score":3},{"label":"Rất thường xuyên","score":4}]',1,'ACTIVE',100);

INSERT INTO bf_role_permissions(role,permission_key,is_allowed) VALUES
('ANALYST','surveys.view',1),('ANALYST','score_audit.view',1),
('MODERATOR','surveys.view',1),('MODERATOR','surveys.manage',1),
('ADMIN','surveys.view',1),('ADMIN','surveys.manage',1),('ADMIN','score_audit.view',1),('ADMIN','score_audit.manage',1)
ON DUPLICATE KEY UPDATE is_allowed=VALUES(is_allowed);
