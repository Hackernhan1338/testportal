-- Brain Focus v4.8.4 HOTFIX
-- Không thay đổi dữ liệu người dùng. Chỉ bảo đảm setting phiên bản/CKEditor tồn tại.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS `bf_settings` (
  `setting_key` varchar(191) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('ckeditor_enabled','true'),
('app_version','4.8.4-hotfix')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`);
