-- Brain Focus v4.8.1 - Profile/tasks/email preference hotfix
SET NAMES utf8mb4;

ALTER TABLE `bf_users`
  ADD COLUMN IF NOT EXISTS `email_updates_opt_in` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `email_updates_decided_at` DATETIME DEFAULT NULL;

-- Existing accounts are not forced through the new signup preference prompt.
-- They default to no promotional/event email until they change the setting in Profile.
UPDATE `bf_users`
SET `email_updates_opt_in` = COALESCE(`email_updates_opt_in`,0),
    `email_updates_decided_at` = COALESCE(`email_updates_decided_at`, NOW());

INSERT INTO `bf_settings` (`setting_key`,`setting_value`)
VALUES ('app_version','4.8.1')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`), `updated_at`=NOW();
