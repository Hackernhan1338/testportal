-- ============================================================================
-- Brain Focus v4.5.3
-- Admin-configurable BFS retake adjustments + mandatory retake campaigns
-- Positive values add BFS; negative values subtract BFS (never below 0).
-- ============================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `bf_bfs_retake_campaigns` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `reward_bfs` INT NOT NULL DEFAULT 500,
  `status` ENUM('ACTIVE','CLOSED') NOT NULL DEFAULT 'ACTIVE',
  `created_by_admin_id` INT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `closed_at` DATETIME DEFAULT NULL,
  INDEX `idx_bfs_campaign_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_bfs_retake_campaign_targets` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `campaign_id` BIGINT NOT NULL,
  `user_id` INT NOT NULL,
  `user_email` VARCHAR(191) NOT NULL,
  `status` ENUM('PENDING','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `penalty_level` INT NOT NULL DEFAULT 0,
  `reward_bfs_awarded` INT NOT NULL DEFAULT 0,
  `completed_attempt_id` BIGINT DEFAULT NULL,
  `completed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_bfs_campaign_target` (`campaign_id`,`user_id`),
  INDEX `idx_bfs_target_user_status` (`user_id`,`status`),
  INDEX `idx_bfs_target_campaign_status` (`campaign_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `bf_bfs_test_attempts`
  ADD COLUMN IF NOT EXISTS `campaign_id` BIGINT DEFAULT NULL AFTER `is_retake`,
  ADD COLUMN IF NOT EXISTS `bonus_type` VARCHAR(40) NOT NULL DEFAULT 'NONE' AFTER `campaign_id`;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('bfs_first_retake_adjustment_bfs','500'),
('bfs_repeat_retake_adjustment_bfs','0'),
('bfs_attention_retry_adjustment_1_bfs','250'),
('bfs_attention_retry_adjustment_2_bfs','100'),
('bfs_global_retake_default_adjustment_bfs','500'),
('bfs_attention_check_count','2')
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

SET FOREIGN_KEY_CHECKS=1;
