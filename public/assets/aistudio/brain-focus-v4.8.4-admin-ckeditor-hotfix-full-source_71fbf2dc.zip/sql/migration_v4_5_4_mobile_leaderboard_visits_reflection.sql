SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- ================================================================
-- BRAIN FOCUS v4.5.4
-- Mobile UI support, BFS level card, Excel exports, web visits,
-- leaderboard rounds/share links, default reminders, reflection +25 XP.
-- ================================================================

ALTER TABLE `bf_study_sessions`
  ADD COLUMN IF NOT EXISTS `reflection_xp_awarded` TINYINT(1) NOT NULL DEFAULT 0 AFTER `reflection`;

CREATE TABLE IF NOT EXISTS `bf_page_visits` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `user_email` VARCHAR(191) DEFAULT NULL,
  `request_path` VARCHAR(500) NOT NULL,
  `referrer` VARCHAR(1000) DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(500) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_visit_created` (`created_at`),
  INDEX `idx_visit_path_created` (`request_path`(191),`created_at`),
  INDEX `idx_visit_user_created` (`user_id`,`created_at`),
  INDEX `idx_visit_ip_created` (`ip_address`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_leaderboard_rounds` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `status` ENUM('ACTIVE','CLOSED') NOT NULL DEFAULT 'ACTIVE',
  `created_by_admin_id` INT DEFAULT NULL,
  `started_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_lb_round_status` (`status`,`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_leaderboard_round_members` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `round_id` BIGINT NOT NULL,
  `user_id` INT NOT NULL,
  `baseline_score` INT NOT NULL DEFAULT 0,
  `final_score` INT DEFAULT NULL,
  `final_round_points` INT DEFAULT NULL,
  `final_rank` INT DEFAULT NULL,
  `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_lb_round_user` (`round_id`,`user_id`),
  INDEX `idx_lb_member_round_rank` (`round_id`,`final_rank`),
  INDEX `idx_lb_member_user` (`user_id`,`round_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bf_rank_share_links` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `share_token` CHAR(40) NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `round_id` BIGINT DEFAULT NULL,
  `snapshot_rank` INT NOT NULL DEFAULT 0,
  `snapshot_score` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_opened_at` DATETIME DEFAULT NULL,
  `open_count` INT NOT NULL DEFAULT 0,
  INDEX `idx_rank_share_user` (`user_id`,`created_at`),
  INDEX `idx_rank_share_round` (`round_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bf_settings` (`setting_key`,`setting_value`) VALUES
('reflection_xp_bonus','25')
ON DUPLICATE KEY UPDATE `updated_at`=NOW();

INSERT INTO `bf_role_permissions` (`role`,`permission_key`,`is_allowed`) VALUES
('ANALYST','visits.view',1),('ANALYST','exports.view',1),
('MODERATOR','visits.view',1),('MODERATOR','exports.view',1),
('ADMIN','visits.view',1),('ADMIN','exports.view',1),('ADMIN','leaderboard.manage',1),
('SUPER_ADMIN','visits.view',1),('SUPER_ADMIN','exports.view',1),('SUPER_ADMIN','leaderboard.manage',1)
ON DUPLICATE KEY UPDATE `is_allowed`=VALUES(`is_allowed`);

-- Tạo đợt BXH đầu tiên nếu hệ thống chưa có đợt nào. Baseline 0 để giữ cách xếp hạng hiện tại.
INSERT INTO `bf_leaderboard_rounds` (`title`,`status`,`started_at`)
SELECT 'Đợt 1','ACTIVE',NOW()
WHERE NOT EXISTS (SELECT 1 FROM `bf_leaderboard_rounds` LIMIT 1);

INSERT IGNORE INTO `bf_leaderboard_round_members` (`round_id`,`user_id`,`baseline_score`)
SELECT (SELECT id FROM `bf_leaderboard_rounds` WHERE status='ACTIVE' ORDER BY id DESC LIMIT 1),u.id,0
FROM `bf_users` u
WHERE u.status='ACTIVE' AND (SELECT id FROM `bf_leaderboard_rounds` WHERE status='ACTIVE' ORDER BY id DESC LIMIT 1) IS NOT NULL;

-- Ba lịch nhắc mặc định giống giao diện mẫu.
INSERT INTO `bf_study_reminders` (`user_id`,`reminder_time`,`reminder_text`,`is_active`)
SELECT u.id,'08:30:00','Học sâu buổi sáng (Lock In)',1 FROM bf_users u
WHERE u.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM bf_study_reminders r WHERE r.user_id=u.id AND r.reminder_time='08:30:00');
INSERT INTO `bf_study_reminders` (`user_id`,`reminder_time`,`reminder_text`,`is_active`)
SELECT u.id,'14:00:00','Gym não giải toả (3 Game)',1 FROM bf_users u
WHERE u.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM bf_study_reminders r WHERE r.user_id=u.id AND r.reminder_time='14:00:00');
INSERT INTO `bf_study_reminders` (`user_id`,`reminder_time`,`reminder_text`,`is_active`)
SELECT u.id,'20:00:00','Chu kỳ Ultradian tối (90p)',1 FROM bf_users u
WHERE u.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM bf_study_reminders r WHERE r.user_id=u.id AND r.reminder_time='20:00:00');

-- Bộ 10 câu BFS mới: chỉ cập nhật dữ liệu câu hỏi, giữ nguyên ID/trạng thái/thứ tự.
UPDATE bf_survey_questions SET question_text='Khi bắt đầu ngồi vào bàn học hoặc làm bài tập, bạn thường mở điện thoại sau bao lâu?',help_text='Kiểm soát xung động',options_json='[{"label":"Ngay lập tức hoặc dưới 5 phút","score":10},{"label":"Khoảng 10 - 15 phút","score":40},{"label":"Khoảng 30 - 45 phút","score":75},{"label":"Giữ vững trên 60 - 90 phút mà không chạm vào điện thoại","score":100}]' WHERE id=1;
UPDATE bf_survey_questions SET question_text='Bạn có thói quen vừa học vừa nghe nhạc có lời hoặc liên tục đổi bài hát không?',help_text='Độ tập trung',options_json='[{"label":"Thường xuyên, nếu không có tiếng nhạc/clip thì không ngồi yên được","score":15},{"label":"Thỉnh thoảng đổi bài hoặc lướt chọn playlist","score":45},{"label":"Chỉ nghe nhạc không lời/lofi/tiếng ồn trắng cố định","score":85},{"label":"Học trong không gian yên tĩnh tuyệt đối hoặc không bị phụ thuộc","score":100}]' WHERE id=2;
UPDATE bf_survey_questions SET question_text='Khi gặp một bài toán khó hoặc đoạn văn dài, cảm giác đầu tiên của bạn là gì?',help_text='Sức bền nhận thức',options_json='[{"label":"Cực kỳ bồn chồn, muốn bỏ qua hoặc mở app khác ngay lập tức","score":10},{"label":"Đọc lướt nhanh, dễ mất kiên nhẫn sau 2-3 phút","score":35},{"label":"Cố gắng đọc lại 1-2 lần để tìm hướng giải","score":70},{"label":"Bình tĩnh phân tích từng bước, duy trì chú ý cho đến khi giải xong","score":100}]' WHERE id=3;
UPDATE bf_survey_questions SET question_text='Thời gian bạn lướt các video ngắn (TikTok, Reels, Shorts) mỗi ngày là bao nhiêu?',help_text='Thói quen số',options_json='[{"label":"Trên 3 - 4 tiếng mỗi ngày","score":10},{"label":"Từ 1.5 - 3 tiếng","score":40},{"label":"Dưới 1 tiếng mỗi ngày","score":75},{"label":"Rất hiếm khi hoặc dưới 20 phút mỗi ngày","score":100}]' WHERE id=4;
UPDATE bf_survey_questions SET question_text='Bạn có thường cảm thấy ''rung chuông ảo'' (nghĩ điện thoại có thông báo dù không có) không?',help_text='Xung động vô thức',options_json='[{"label":"Liên tục trong ngày, luôn vô thức mở màn hình kiểm tra","score":15},{"label":"Thỉnh thoảng, đặc biệt khi cảm thấy chán bài học","score":40},{"label":"Hiếm khi","score":80},{"label":"Hoàn toàn không","score":100}]' WHERE id=5;
UPDATE bf_survey_questions SET question_text='Khả năng duy trì đọc một cuốn sách giáo khoa/tài liệu giấy liên tục 30 phút của bạn thế nào?',help_text='Độ sâu chú ý',options_json='[{"label":"Gần như không thể, mắt đọc nhưng đầu nghĩ việc khác","score":15},{"label":"Đọc được 10-15 phút là muốn với tay lấy điện thoại","score":45},{"label":"Đọc tốt khoảng 25-30 phút với độ hiểu bài khá","score":80},{"label":"Đọc say mê 45-60 phút mà không hề bị phân tâm","score":100}]' WHERE id=6;
UPDATE bf_survey_questions SET question_text='Khi có thông báo tin nhắn mới khi đang học, phản xạ của bạn là gì?',help_text='Kiểm soát kích thích',options_json='[{"label":"Mở xem và trả lời ngay lập tức, sau đó bị cuốn vào lướt mạng xã hội","score":10},{"label":"Mở xem tin nhắn rồi cố gắng quay lại học tiếp","score":40},{"label":"Liếc nhìn preview, nếu không khẩn cấp sẽ đợi hết phiên học","score":75},{"label":"Tắt toàn bộ thông báo hoặc để điện thoại ở chế độ Không làm phiền","score":100}]' WHERE id=7;
UPDATE bf_survey_questions SET question_text='Sau một phiên học dài 60-90 phút, bạn cảm thấy thế nào?',help_text='Năng lượng não bộ',options_json='[{"label":"Rất hiếm khi học được 60 phút, thường bỏ dở giữa chừng","score":15},{"label":"Căng thẳng, mệt mỏi và thèm kích thích từ điện thoại","score":45},{"label":"Khá thoải mái nếu có quãng nghỉ ngắn giữa chừng","score":80},{"label":"Cảm giác sảng khoái và tự hào vì đạt trạng thái tập trung sâu","score":100}]' WHERE id=8;
UPDATE bf_survey_questions SET question_text='Bạn có thực hiện đa nhiệm (vừa học vừa nhắn tin, xem video phụ) không?',help_text='Tập trung đơn nhiệm',options_json='[{"label":"Thường xuyên làm nhiều việc một lúc","score":10},{"label":"Thỉnh thoảng mở tab phụ để trò chuyện","score":40},{"label":"Chủ yếu chỉ tập trung vào tài liệu môn học","score":80},{"label":"Luôn thực hiện đơn nhiệm tuyệt đối (Monotasking)","score":100}]' WHERE id=9;
UPDATE bf_survey_questions SET question_text='Buổi tối trước khi đi ngủ, bạn thường sử dụng điện thoại đến khi nào?',help_text='Nhịp sinh học',options_json='[{"label":"Dùng đến tận lúc ngủ thiếp đi, để điện thoại ngay đầu giường","score":10},{"label":"Dùng đến trước khi ngủ 10-15 phút","score":40},{"label":"Cất điện thoại trước khi ngủ 30-45 phút","score":75},{"label":"Ngừng dùng thiết bị điện tử trước khi ngủ 60 phút và để ngoài tầm với","score":100}]' WHERE id=10;

SET FOREIGN_KEY_CHECKS=1;
