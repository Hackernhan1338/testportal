# Brain Focus v4.5.4

## Mobile UI
- Tối ưu header, chuỗi tập trung, top navigation cuộn ngang, podium Top 3, tìm kiếm và bottom navigation cho màn hình điện thoại.
- Bảng xếp hạng giữ cấu trúc 3 bục, thanh vị trí cá nhân và danh sách gọn như giao diện tham chiếu.

## BFS level trong hồ sơ
- Level 1: BFS khảo sát >= 700.
- Level 2: BFS khảo sát 400–699.
- Level 3: BFS khảo sát < 400.
- Nội dung tiêu đề, mô tả, khuyến nghị và thông điệp dùng đúng dữ liệu BFS_LEVELS_DATA được yêu cầu.
- Level dùng `bfs_assessment_score`, không dùng BFS thưởng để tránh làm sai đánh giá.

## Admin
- Web visits: `/admin/visits.php`.
- Điều hành BXH theo đợt: `/admin/leaderboard.php`.
- Export Excel: học viên, khảo sát, BXH qua `/admin/export.php`.

## BXH theo đợt
- Dừng = đóng/chốt cứng đợt hiện tại.
- Điểm phát sinh sau khi chốt không thay đổi đợt đã đóng.
- Khi mở đợt mới, baseline của học viên cũ là final score của đợt trước, nên điểm tăng sau mốc chốt được tính vào đợt mới.

## Chia sẻ hạng
- Người dùng tạo link token server-side.
- Link công khai không hiển thị email.
- Hỗ trợ Web Share, copy link, Facebook và X.
- Trang chia sẻ có CTA “Tham gia cùng bạn thân” và lời mời đua top.

## Nhắc học
- Seed 08:30 Học sâu buổi sáng (Lock In).
- Seed 14:00 Gym não giải toả (3 Game).
- Seed 20:00 Chu kỳ Ultradian tối (90p).

## Đúc kết
- Sau khi hoàn thành phiên học, modal hỏi đúc kết.
- Có đúc kết hợp lệ: +25 XP (Rank) một lần/phiên.
- Đúc kết được lưu vào lịch sử phiên học trên hồ sơ.
