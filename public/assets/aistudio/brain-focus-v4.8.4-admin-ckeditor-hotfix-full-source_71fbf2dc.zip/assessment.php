<?php
require_once __DIR__.'/includes/bootstrap.php';
$user=bfRequireUser($pdo);
bfStartUserSession();
$msg='';$error='';$result=null;$mustRetake=false;

function bfBfsLoadQuestions(PDO $pdo){
    try{$rows=$pdo->query("SELECT * FROM bf_survey_questions WHERE status='ACTIVE' ORDER BY sort_order,id")->fetchAll();}catch(Throwable $e){$rows=[];}
    if($rows)return $rows;
    $fallback=['Tôi vô thức mở mạng xã hội hoặc ứng dụng khác khi đang học.','Tôi khó duy trì chú ý vào một nhiệm vụ liên tục.','Thông báo điện thoại làm tôi lập tức muốn kiểm tra.','Tôi thường mở nhiều tab hoặc nhiều nhiệm vụ và chuyển qua lại.','Tôi thấy bồn chồn khi phải học mà không có kích thích nhanh.','Tôi thường bỏ dở một phần việc để bắt đầu việc khác.','Sau khi bị gián đoạn, tôi mất nhiều thời gian để quay lại nhiệm vụ.','Tôi có xu hướng vừa học vừa kiểm tra tin nhắn hoặc video ngắn.','Tôi trì hoãn nhiệm vụ khó bằng các hoạt động số dễ chịu hơn.','Tôi kết thúc một phiên học mà không nhớ rõ mục tiêu ban đầu.'];
    $rows=[];$opts=json_encode([['label'=>'Không bao giờ','score'=>0],['label'=>'Hiếm khi','score'=>1],['label'=>'Đôi khi','score'=>2],['label'=>'Thường xuyên','score'=>3],['label'=>'Rất thường xuyên','score'=>4]],JSON_UNESCAPED_UNICODE);
    foreach($fallback as $i=>$t)$rows[]=['id'=>-($i+1),'question_text'=>$t,'help_text'=>null,'question_type'=>'SCALE','options_json'=>$opts,'is_bfs_scored'=>1];
    return $rows;
}
function bfBfsAttentionTemplates(){
    return [
        ['text'=>'Khi tự đánh giá thói quen học tập, tôi luôn đọc kỹ yêu cầu trước khi chọn. Với câu này, hãy chọn “Hiếm khi”.','expected'=>1],
        ['text'=>'Để bảo đảm câu trả lời phản ánh việc bạn đang đọc nội dung, ở câu này vui lòng chọn “Đôi khi”.','expected'=>2],
        ['text'=>'Tôi đang trả lời từng câu một cách có chủ đích. Riêng câu này, hãy chọn “Thường xuyên”.','expected'=>3],
        ['text'=>'Trong lúc làm khảo sát, tôi chú ý tới chỉ dẫn của từng mục. Với mục này, hãy chọn “Không bao giờ”.','expected'=>0],
        ['text'=>'Tôi kiểm tra nội dung trước khi nộp khảo sát. Đối với câu này, vui lòng chọn “Rất thường xuyên”.','expected'=>4]
    ];
}
function bfBfsBaseOptions(){return [['label'=>'Không bao giờ','score'=>0],['label'=>'Hiếm khi','score'=>1],['label'=>'Đôi khi','score'=>2],['label'=>'Thường xuyên','score'=>3],['label'=>'Rất thường xuyên','score'=>4]];}
function bfSignedPoints($n){$n=(int)$n;return ($n>0?'+':'').number_format($n);}
function bfBfsAttemptState(PDO $pdo,$userId){
    $validCount=0;$last=null;
    try{$st=$pdo->prepare("SELECT COUNT(*) FROM bf_bfs_test_attempts WHERE user_id=? AND status='VALID'");$st->execute([$userId]);$validCount=(int)$st->fetchColumn();$st=$pdo->prepare("SELECT * FROM bf_bfs_test_attempts WHERE user_id=? ORDER BY id DESC LIMIT 1");$st->execute([$userId]);$last=$st->fetch()?:null;}catch(Throwable $e){}
    if($validCount===0){try{$st=$pdo->prepare("SELECT COUNT(*) FROM bf_bfs_assessments a JOIN bf_users u ON u.email=a.user_email WHERE u.id=?");$st->execute([$userId]);$validCount=(int)$st->fetchColumn();}catch(Throwable $ignore){}}
    $campaign=bfPendingBfsCampaign($pdo,(int)$userId);
    $forcedByAttention=$last && ($last['status']??'')==='RETAKE_REQUIRED';
    $penalty=0;
    if($campaign)$penalty=max($penalty,(int)($campaign['penalty_level']??0));
    if($forcedByAttention)$penalty=max($penalty,max(1,(int)($last['penalty_level']??1)));
    return ['validCount'=>$validCount,'last'=>$last,'forcedByAttention'=>$forcedByAttention,'penalty'=>$penalty,'campaign'=>$campaign];
}
function bfBfsAdjustmentForState(PDO $pdo,array $state){
    $campaign=$state['campaign'];$penalty=(int)$state['penalty'];
    if($penalty>=2)return (int)bfSetting($pdo,'bfs_attention_retry_adjustment_2_bfs','100');
    if($penalty===1)return (int)bfSetting($pdo,'bfs_attention_retry_adjustment_1_bfs','250');
    if($campaign)return (int)$campaign['reward_bfs'];
    if((int)$state['validCount']===0)return 0;
    if((int)$state['validCount']===1)return (int)bfSetting($pdo,'bfs_first_retake_adjustment_bfs','500');
    return (int)bfSetting($pdo,'bfs_repeat_retake_adjustment_bfs','0');
}
function bfBfsBuildChallenge(PDO $pdo,array $user){
    $questions=bfBfsLoadQuestions($pdo);shuffle($questions);$state=bfBfsAttemptState($pdo,(int)$user['id']);
    $templates=bfBfsAttentionTemplates();shuffle($templates);$trapCount=max(1,min(3,(int)bfSetting($pdo,'bfs_attention_check_count','2')));
    $items=[];
    foreach($questions as $q){$opts=json_decode((string)($q['options_json']??''),true);if(!is_array($opts)||!$opts)$opts=bfBfsBaseOptions();shuffle($opts);$items[]=['kind'=>'question','id'=>(int)$q['id'],'text'=>(string)$q['question_text'],'help'=>(string)($q['help_text']??''),'type'=>(string)($q['question_type']??'SCALE'),'options'=>$opts,'isScored'=>(int)($q['is_bfs_scored']??1)===1];}
    for($i=0;$i<$trapCount;$i++){$t=$templates[$i];$opts=bfBfsBaseOptions();shuffle($opts);$pos=random_int(1,max(1,count($items)-1));array_splice($items,$pos,0,[['kind'=>'attention','id'=>'att_'.$i.'_'.bin2hex(random_bytes(3)),'text'=>$t['text'],'help'=>'','type'=>'SCALE','options'=>$opts,'expected'=>(int)$t['expected'],'isScored'=>false]]);}
    $nonce=bin2hex(random_bytes(16));$adjustment=bfBfsAdjustmentForState($pdo,$state);
    $challenge=['nonce'=>$nonce,'userId'=>(int)$user['id'],'items'=>$items,'createdAt'=>time(),'validCount'=>(int)$state['validCount'],'penalty'=>(int)$state['penalty'],'adjustment'=>$adjustment,'campaignId'=>$state['campaign']?(int)$state['campaign']['campaign_id']:0,'campaignTitle'=>$state['campaign']?(string)$state['campaign']['title']:'','required'=>(bool)$state['campaign'],'forcedByAttention'=>(bool)$state['forcedByAttention']];
    if(!isset($_SESSION['bf_bfs_challenges'])||!is_array($_SESSION['bf_bfs_challenges']))$_SESSION['bf_bfs_challenges']=[];
    $_SESSION['bf_bfs_challenges']=[$nonce=>$challenge];
    return $challenge;
}
function bfBfsSaveAttempt(PDO $pdo,array $user,$status,$rawScore,$bonus,$trapTotal,$trapPassed,$penalty,$answers,$isRetake,$campaignId=0,$bonusType='NONE'){
    try{
        $st=$pdo->prepare("SELECT COUNT(*) FROM bf_bfs_test_attempts WHERE user_id=?");$st->execute([$user['id']]);$no=(int)$st->fetchColumn()+1;
        try{$sql="INSERT INTO bf_bfs_test_attempts(user_id,user_email,attempt_no,raw_bfs_score,bonus_points,trap_total,trap_passed,status,penalty_level,is_retake,campaign_id,bonus_type,answers_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";$pdo->prepare($sql)->execute([$user['id'],$user['email'],$no,$rawScore,$bonus,$trapTotal,$trapPassed,$status,$penalty,$isRetake?1:0,$campaignId?:null,$bonusType,json_encode($answers,JSON_UNESCAPED_UNICODE)]);}
        catch(Throwable $legacy){$pdo->prepare("INSERT INTO bf_bfs_test_attempts(user_id,user_email,attempt_no,raw_bfs_score,bonus_points,trap_total,trap_passed,status,penalty_level,is_retake,answers_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)")->execute([$user['id'],$user['email'],$no,$rawScore,$bonus,$trapTotal,$trapPassed,$status,$penalty,$isRetake?1:0,json_encode($answers,JSON_UNESCAPED_UNICODE)]);}
        return (int)$pdo->lastInsertId();
    }catch(Throwable $e){return 0;}
}
function bfCampaignPenalty(PDO $pdo,$campaignId,$userId,$penalty){
    if(!$campaignId)return;try{$pdo->prepare("UPDATE bf_bfs_retake_campaign_targets SET penalty_level=? WHERE campaign_id=? AND user_id=? AND status='PENDING'")->execute([(int)$penalty,(int)$campaignId,(int)$userId]);}catch(Throwable $e){}
}
function bfCampaignComplete(PDO $pdo,$campaignId,$userId,$attemptId,$awarded){
    if(!$campaignId)return;try{$pdo->prepare("UPDATE bf_bfs_retake_campaign_targets SET status='COMPLETED',reward_bfs_awarded=?,completed_attempt_id=?,completed_at=NOW() WHERE campaign_id=? AND user_id=? AND status='PENDING'")->execute([(int)$awarded,(int)$attemptId,(int)$campaignId,(int)$userId]);}catch(Throwable $e){}
}

$challenge=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    bfCheckUserCsrf();$nonce=preg_replace('/[^a-f0-9]/','',strtolower((string)($_POST['challenge_nonce']??'')));$challenge=$_SESSION['bf_bfs_challenges'][$nonce]??null;
    if(!$challenge || (int)($challenge['userId']??0)!==(int)$user['id'] || time()-(int)($challenge['createdAt']??0)>3600){$error='Phiên kiểm tra đã hết hạn. Vui lòng tải lại trang và làm lại.';$challenge=bfBfsBuildChallenge($pdo,$user);}else{
        $sum=0;$max=0;$answers=[];$valid=true;$trapTotal=0;$trapPassed=0;$realResponses=[];
        foreach($challenge['items'] as $idx=>$item){$key='a_'.$idx;$v=isset($_POST[$key])?(string)$_POST[$key]:'';$opts=$item['options']??[];$found=null;foreach($opts as $o){if((string)($o['score']??'')===$v){$found=$o;break;}}if($found===null){$valid=false;break;}$sc=(float)($found['score']??0);$answers[]=['kind'=>$item['kind'],'question_id'=>$item['id'],'value'=>$found['label']??$v,'score'=>$sc];
            if($item['kind']==='attention'){$trapTotal++;if((int)$sc===(int)$item['expected'])$trapPassed++;continue;}
            $realResponses[]=['question_id'=>$item['id'],'value'=>$found['label']??$v,'score'=>$sc];
            if(!empty($item['isScored'])){$sum+=$sc;$localMax=0;foreach($opts as $o)$localMax=max($localMax,(float)($o['score']??0));$max+=$localMax;}
        }
        if(!$valid){$error='Vui lòng trả lời đầy đủ tất cả các câu hỏi.';}
        else{
            $raw=$max>0?(int)round(max(0,min(1000,($max>100?($sum/$max)*1000:1000-($sum/$max)*1000)))):(int)($user['bfs_assessment_score']??0);$campaignId=(int)($challenge['campaignId']??0);
            if($trapPassed<$trapTotal){
                $nextPenalty=min(2,max(1,(int)$challenge['penalty']+1));bfCampaignPenalty($pdo,$campaignId,(int)$user['id'],$nextPenalty);bfBfsSaveAttempt($pdo,$user,'RETAKE_REQUIRED',$raw,0,$trapTotal,$trapPassed,$nextPenalty,$answers,true,$campaignId,'ATTENTION_RETRY');$mustRetake=true;
                $nextState=bfBfsAttemptState($pdo,(int)$user['id']);$nextAdjustment=bfBfsAdjustmentForState($pdo,$nextState);$result=['valid'=>false,'raw'=>$raw,'adjustment'=>0,'trapPassed'=>$trapPassed,'trapTotal'=>$trapTotal,'nextAdjustment'=>$nextAdjustment];$msg='Hệ thống phát hiện bạn có thể đã bỏ qua chỉ dẫn. Kết quả này chưa được công nhận; vui lòng đọc kỹ và làm lại.';unset($_SESSION['bf_bfs_challenges'][$nonce]);$challenge=bfBfsBuildChallenge($pdo,$user);
            }else{
                $requestedAdjustment=(int)$challenge['adjustment'];$pdo->beginTransaction();try{
                    $pdo->prepare("INSERT INTO bf_bfs_assessments(user_email,score,answers_json) VALUES(?,?,?)")->execute([$user['email'],$raw,json_encode($realResponses,JSON_UNESCAPED_UNICODE)]);
                    $submissionId=0;try{$pdo->prepare("INSERT INTO bf_survey_submissions(user_id,user_email,bfs_score,question_count) VALUES(?,?,?,?)")->execute([$user['id'],$user['email'],$raw,count($realResponses)]);$submissionId=(int)$pdo->lastInsertId();$rs=$pdo->prepare("INSERT INTO bf_survey_responses(submission_id,question_id,user_id,answer_value,answer_score) VALUES(?,?,?,?,?)");foreach($realResponses as $a)if((int)$a['question_id']>0)$rs->execute([$submissionId,$a['question_id'],$user['id'],$a['value'],$a['score']]);}catch(Throwable $ignore){}
                    $oldAssessment=(int)($user['bfs_assessment_score']??0);$currentBfs=(int)($user['bfs_score']??0);$baseAfterAssessment=max(0,$currentBfs-$oldAssessment+$raw);$newBfs=max(0,$baseAfterAssessment+$requestedAdjustment);$actualAdjustment=$newBfs-$baseAfterAssessment;
                    $pdo->prepare("UPDATE bf_users SET bfs_score=?,bfs_assessment_score=? WHERE id=?")->execute([$newBfs,$raw,$user['id']]);
                    if($actualAdjustment!==0){$reason=$campaignId?'Điều chỉnh BFS khi hoàn thành khảo sát bắt buộc':'Điều chỉnh BFS khi làm lại khảo sát';$pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'BFS','BFS_RETAKE_ADJUSTMENT',?,'BFS_TEST',?)")->execute([$user['id'],$actualAdjustment,$reason,(string)time()]);}
                    $bonusType=$campaignId?'CAMPAIGN':(((int)$challenge['validCount']===1)?'FIRST_RETAKE':'REPEAT_RETAKE');$attemptId=bfBfsSaveAttempt($pdo,$user,'VALID',$raw,$actualAdjustment,$trapTotal,$trapPassed,0,$answers,true,$campaignId,$bonusType);bfCampaignComplete($pdo,$campaignId,(int)$user['id'],$attemptId,$actualAdjustment);
                    $pdo->commit();$user=bfCurrentUser($pdo);$result=['valid'=>true,'raw'=>$raw,'adjustment'=>$actualAdjustment,'requestedAdjustment'=>$requestedAdjustment,'trapPassed'=>$trapPassed,'trapTotal'=>$trapTotal,'attemptId'=>$attemptId,'campaignId'=>$campaignId];$msg='Đã ghi nhận kết quả BFS hợp lệ.';unset($_SESSION['bf_bfs_challenges'][$nonce]);
                }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error='Không thể lưu kết quả kiểm tra BFS.';error_log('[BrainFocus BFS] '.$e->getMessage());}
            }
        }
    }
}
if(!$challenge && !$result)$challenge=bfBfsBuildChallenge($pdo,$user);
$state=bfBfsAttemptState($pdo,(int)$user['id']);$pendingCampaign=$state['campaign'];
$pageTitle='Kiểm tra BFS';$activePage='assessment';include __DIR__.'/includes/layout_top.php';
?>
<section class="max-w-3xl mx-auto space-y-4">
  <div class="bg-slate-900 p-5 rounded-2xl text-white"><div class="flex items-start justify-between gap-4"><div><h2 class="font-bold text-lg">🧪 KIỂM TRA KHẢ NĂNG TẬP TRUNG (BFS)</h2><p class="text-xs text-slate-300 mt-1">BFS thật được tính từ các câu đánh giá chính. Các câu kiểm tra chú ý được trộn ngẫu nhiên và không tính vào BFS thật.</p></div><div class="text-right shrink-0"><div class="text-[10px] text-slate-400 uppercase">BFS thật hiện tại</div><div class="font-mono font-black text-2xl text-blue-300"><?=number_format((int)($user['bfs_assessment_score']??0))?></div></div></div></div>
  <?php if($pendingCampaign):?><div class="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-900"><b>📣 Khảo sát bắt buộc: <?=htmlspecialchars($pendingCampaign['title'])?></b><p class="text-xs mt-1">Admin đang yêu cầu học viên hoàn thành lại khảo sát. Khi hoàn thành hợp lệ, tài khoản sẽ được điều chỉnh <b><?=bfSignedPoints((int)$pendingCampaign['reward_bfs'])?> BFS</b> trước khi tiếp tục sử dụng các chức năng khác.</p></div><?php endif;?>
  <?php if($error):?><div class="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-sm text-rose-800">⚠️ <?=htmlspecialchars($error)?></div><?php endif;?>
  <?php if($msg):?><div class="p-4 rounded-2xl <?=$mustRetake?'bg-amber-50 border-amber-200 text-amber-900':'bg-emerald-50 border-emerald-200 text-emerald-900'?> border text-sm"><?=htmlspecialchars($msg)?></div><?php endif;?>

  <?php if($result):?>
    <div class="glass-card rounded-3xl p-6 border-slate-200 shadow-xs text-center">
      <?php if($result['valid']):?>
        <div class="text-4xl">✨</div><h3 class="font-black text-xl text-slate-900 mt-2">KẾT QUẢ ĐÃ ĐƯỢC CÔNG NHẬN</h3>
        <div class="grid sm:grid-cols-3 gap-3 mt-5"><div class="p-4 rounded-2xl bg-blue-50 border border-blue-200"><div class="text-[10px] text-blue-600 uppercase font-semibold">BFS thật</div><div class="text-3xl font-black font-mono text-blue-800"><?=number_format((int)$result['raw'])?></div></div><div class="p-4 rounded-2xl <?=((int)$result['adjustment']>=0)?'bg-emerald-50 border-emerald-200':'bg-rose-50 border-rose-200'?> border"><div class="text-[10px] uppercase font-semibold <?=((int)$result['adjustment']>=0)?'text-emerald-700':'text-rose-700'?>">Điều chỉnh BFS</div><div class="text-3xl font-black font-mono <?=((int)$result['adjustment']>=0)?'text-emerald-800':'text-rose-800'?>"><?=bfSignedPoints((int)$result['adjustment'])?> BFS</div></div><div class="p-4 rounded-2xl bg-emerald-50 border border-emerald-200"><div class="text-[10px] text-emerald-700 uppercase font-semibold">Kiểm tra chú ý</div><div class="text-3xl font-black font-mono text-emerald-800"><?=$result['trapPassed']?>/<?=$result['trapTotal']?></div></div></div>
        <p class="text-xs text-slate-500 mt-4">BFS thật và phần điều chỉnh được lưu tách biệt trong lịch sử giao dịch để có thể kiểm toán.</p>
        <div class="mt-5 flex justify-center gap-2 flex-wrap"><a href="/profile.php" class="px-4 py-2.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold">Về hồ sơ</a><a href="/assessment.php?retake=1" class="px-4 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold">Làm lại kiểm tra BFS</a></div>
      <?php else:?>
        <div class="text-4xl">⚠️</div><h3 class="font-black text-xl text-slate-900 mt-2">CẦN LÀM LẠI VÀ ĐỌC KỸ CÂU HỎI</h3><p class="text-sm text-slate-600 mt-3">Bạn chỉ vượt qua <?=$result['trapPassed']?>/<?=$result['trapTotal']?> câu kiểm tra chú ý. Kết quả BFS vừa rồi <b>không được ghi nhận</b>.</p><div class="mt-4 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-sm text-amber-900">Mức điều chỉnh ở lượt làm lại tiếp theo là <b><?=bfSignedPoints((int)$result['nextAdjustment'])?> BFS</b>. Giá trị âm nghĩa là trừ BFS; hệ thống không để tổng BFS xuống dưới 0.</div>
      <?php endif;?>
    </div>
  <?php endif;?>

  <?php if(!$result || !$result['valid']):?>
    <div class="glass-card rounded-2xl p-4 border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"><div><div class="text-sm font-bold text-slate-900"><?=!empty($challenge['required'])?'Lượt khảo sát bắt buộc':(!empty($challenge['forcedByAttention'])?'Lượt làm lại bắt buộc':'Lượt kiểm tra hiện tại')?></div><p class="text-xs text-slate-500 mt-1">Hãy đọc từng câu. Các câu kiểm tra chú ý có hình thức giống câu bình thường và xuất hiện ngẫu nhiên.</p></div><div class="px-4 py-2 rounded-xl <?=((int)($challenge['adjustment']??0)>=0)?'bg-emerald-50 border-emerald-200 text-emerald-800':'bg-rose-50 border-rose-200 text-rose-800'?> border text-xs font-bold">Điều chỉnh khi hợp lệ: <?=bfSignedPoints((int)($challenge['adjustment']??0))?> BFS</div></div>
    <form method="post" class="space-y-3" id="bfs-test-form"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfUserCsrf())?>"><input type="hidden" name="challenge_nonce" value="<?=htmlspecialchars($challenge['nonce'])?>">
      <?php foreach($challenge['items'] as $i=>$item):?>
      <article class="glass-card rounded-2xl p-4 border-slate-200"><div class="text-[10px] text-slate-400 font-semibold uppercase">Câu <?=($i+1)?></div><b class="text-sm text-slate-900 block mt-1"><?=htmlspecialchars($item['text'])?></b><?php if(!empty($item['help'])):?><p class="text-[11px] text-slate-500 mt-1"><?=htmlspecialchars($item['help'])?></p><?php endif;?><div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 mt-3"><?php foreach($item['options'] as $o):?><label class="cursor-pointer p-2.5 rounded-xl border border-slate-200 hover:bg-blue-50 text-[11px] has-[:checked]:bg-blue-50 has-[:checked]:border-blue-300"><input type="radio" name="a_<?=$i?>" value="<?=htmlspecialchars((string)$o['score'])?>" required> <?=htmlspecialchars($o['label'])?></label><?php endforeach;?></div></article>
      <?php endforeach;?>
      <div class="glass-card rounded-2xl p-4 border-slate-200 flex flex-col sm:flex-row gap-3 sm:items-center justify-between"><p class="text-xs text-slate-500">Khi nộp, hệ thống chấm BFS thật và kiểm tra tính chú ý. Câu kiểm tra chú ý không trực tiếp cộng/trừ BFS thật.</p><button class="px-5 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-bold shrink-0">NỘP VÀ CHẤM BFS</button></div>
    </form>
  <?php endif;?>
</section>
<?php include __DIR__.'/includes/layout_bottom.php';?>
