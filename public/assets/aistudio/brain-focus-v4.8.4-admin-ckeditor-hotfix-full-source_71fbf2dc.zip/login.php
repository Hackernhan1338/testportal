<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/api/mail.php';
bfStartUserSession();
if(empty($_SESSION['bf_login_csrf'])) $_SESSION['bf_login_csrf']=bin2hex(random_bytes(32));
$mode=(string)($_GET['mode']??'login');
$next=(string)($_GET['next']??'/');
if($next==='' || substr($next,0,1)!=='/' || substr($next,0,2)==='//') $next='/';
$msg='';$err='';$resetEmail='';
$currentTerms=bfCurrentTerms($pdo);

function bfLoginStrongPassword($pw){
    return strlen($pw)>=8 && preg_match('/[A-Z]/',$pw) && preg_match('/[a-z]/',$pw) && preg_match('/\d/',$pw) && preg_match('/[^A-Za-z0-9]/',$pw);
}
function bfResetRateLimit(PDO $pdo,$email){
    try{
        $st=$pdo->prepare("SELECT created_at FROM bf_password_resets WHERE email=? ORDER BY id DESC LIMIT 1");$st->execute([$email]);$last=$st->fetchColumn();
        if($last && time()-strtotime($last)<60) return 'Vui lòng chờ ít nhất 60 giây trước khi yêu cầu mã mới.';
        $st=$pdo->prepare("SELECT COUNT(*) FROM bf_password_resets WHERE email=? AND created_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR)");$st->execute([$email]);
        if((int)$st->fetchColumn()>=5) return 'Đã gửi quá nhiều mã trong 1 giờ. Vui lòng thử lại sau.';
    }catch(Throwable $e){}
    return '';
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    $csrf=(string)($_POST['_csrf']??'');
    if(!$csrf || !hash_equals((string)($_SESSION['bf_login_csrf']??''),$csrf)){http_response_code(419);exit('CSRF token không hợp lệ');}
    $mode=(string)($_POST['mode']??$mode);

    if($mode==='login'){
        $email=strtolower(trim((string)($_POST['email']??'')));$password=(string)($_POST['password']??'');
        bfSecurityGate($pdo,$email);
        $st=$pdo->prepare("SELECT * FROM bf_users WHERE email=? LIMIT 1");$st->execute([$email]);$u=$st->fetch();
        if(!$u || (string)($u['status']??'')!=='ACTIVE' || empty($u['password_hash']) || !password_verify($password,(string)$u['password_hash'])){
            $err='Email hoặc mật khẩu không đúng.';bfRecordLoginHistory($pdo,$email,false);bfLogAccess($pdo,['email'=>$email,'event_type'=>'USER_LOGIN_FAILED']);
        }else{
            bfRecordLoginHistory($pdo,$email,true);bfLoginUser($pdo,$u);bfLogAccess($pdo,['user_id'=>$u['id'],'email'=>$email,'event_type'=>'LOGIN_SUCCESS']);
            if(!empty($u['must_change_password'])){header('Location: /change-password.php?required=1');exit;}
            header('Location: '.$next);exit;
        }
    }
    elseif($mode==='register'){
        $email=strtolower(trim((string)($_POST['email']??'')));$name=trim((string)($_POST['name']??''));$school=trim((string)($_POST['school']??''));$password=(string)($_POST['password']??'');$emailUpdates=(string)($_POST['email_updates_opt_in']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)) $err='Email không hợp lệ.';
        elseif((function_exists('mb_strlen')?mb_strlen($name):strlen($name))<2) $err='Tên phải từ 2 ký tự.';
        elseif(!bfLoginStrongPassword($password)) $err='Mật khẩu phải từ 8 ký tự, gồm chữ hoa, chữ thường, số và ký tự đặc biệt.';
        elseif(!$currentTerms) $err='Điều khoản hệ thống chưa sẵn sàng. Vui lòng thử lại sau.';
        elseif((string)($_POST['terms_scrolled']??'0')!=='1' || empty($_POST['accept_terms'])) $err='Bạn phải đọc đến cuối và đồng ý với điều khoản trước khi đăng ký.';
        elseif(!in_array($emailUpdates,['0','1'],true)) $err='Vui lòng chọn có hoặc không nhận email thông tin sự kiện.';
        else{
            $ck=$pdo->prepare("SELECT id FROM bf_users WHERE email=? LIMIT 1");$ck->execute([$email]);
            if($ck->fetch()) $err='Email này đã được đăng ký.';
            else{
                $pdo->prepare("INSERT INTO bf_users(email,name,school,password_hash,rank_points,bfs_score,streak_days,sessions_count,gym_count,purchased_gym_plays,email_updates_opt_in,email_updates_decided_at) VALUES(?,?,?,?,1000,0,1,0,0,0,?,NOW())")->execute([$email,$name,$school?:'Người học tập trung',password_hash($password,PASSWORD_DEFAULT),(int)$emailUpdates]);
                $newId=(int)$pdo->lastInsertId();
                try{$rem=$pdo->prepare("INSERT INTO bf_study_reminders(user_id,reminder_time,reminder_text,is_active) VALUES(?,?,?,1)");foreach([['08:30:00','Học sâu buổi sáng (Lock In)'],['14:00:00','Gym não giải toả (3 Game)'],['20:00:00','Chu kỳ Ultradian tối (90p)']] as $r)$rem->execute([$newId,$r[0],$r[1]]);}catch(Throwable $ignore){}
                try{$pdo->prepare("INSERT INTO bf_terms_acceptances(user_id,terms_id,accepted_ip,user_agent,reward_xp) VALUES(?,?,?,?,0)")->execute([$newId,(int)$currentTerms['id'],bfRequestIp(),substr(bfUserAgent(),0,500)]);}catch(Throwable $ignore){}
                $st=$pdo->prepare("SELECT * FROM bf_users WHERE email=? LIMIT 1");$st->execute([$email]);$u=$st->fetch();bfLoginUser($pdo,$u);bfLogAccess($pdo,['user_id'=>$u['id'],'email'=>$email,'event_type'=>'REGISTER_SUCCESS']);header('Location: /welcome.php');exit;
            }
        }
    }
    elseif($mode==='forgot'){
        $email=strtolower(trim((string)($_POST['email']??'')));$resetEmail=$email;
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)) $err='Email không hợp lệ.';
        else{
            bfSecurityGate($pdo,$email);
            $st=$pdo->prepare("SELECT id,status FROM bf_users WHERE email=? LIMIT 1");$st->execute([$email]);$account=$st->fetch();
            if(!$account || (string)$account['status']!=='ACTIVE') $err='Không tìm thấy tài khoản đang hoạt động với email này.';
            else{
                $limit=bfResetRateLimit($pdo,$email);
                if($limit!=='') $err=$limit;
                elseif(!bfSmtpConfigured()) $err='SMTP chưa được cấu hình. Hãy nhập App Password 16 ký tự trong api/db.php.';
                else{
                    $code=(string)random_int(100000,999999);$hash=hash('sha256',$code);
                    try{
                        $pdo->prepare("UPDATE bf_password_resets SET used_at=NOW() WHERE email=? AND used_at IS NULL")->execute([$email]);
                        $pdo->prepare("INSERT INTO bf_password_resets(email,otp_code,expires_at,request_ip,attempts) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE),?,0)")->execute([$email,$hash,bfRequestIp()]);
                        $resetId=(int)$pdo->lastInsertId();
                        $sent=bfSendPasswordResetOtp($email,$code);
                        if(!$sent['success']){
                            $pdo->prepare("UPDATE bf_password_resets SET used_at=NOW() WHERE id=?")->execute([$resetId]);
                            $err='Không gửi được email: '.$sent['message'];
                            bfLogAccess($pdo,['user_id'=>$account['id'],'email'=>$email,'event_type'=>'PASSWORD_RESET_MAIL_FAILED']);
                        }else{
                            $_SESSION['bf_reset_email']=$email;
                            $msg='Mã xác nhận 6 số đã được gửi tới '.$email.'. Mã có hiệu lực 10 phút.';
                            $mode='reset';
                            bfLogAccess($pdo,['user_id'=>$account['id'],'email'=>$email,'event_type'=>'PASSWORD_RESET_OTP_SENT']);
                        }
                    }catch(Throwable $e){$err='Không thể khởi tạo yêu cầu đặt lại mật khẩu. Hãy chạy migration v4.5.1.';error_log('[BrainFocus Reset] '.$e->getMessage());}
                }
            }
        }
    }
    elseif($mode==='reset'){
        $email=strtolower(trim((string)($_POST['email']??($_SESSION['bf_reset_email']??''))));$resetEmail=$email;$code=trim((string)($_POST['otp_code']??''));$new=(string)($_POST['new_password']??'');$confirm=(string)($_POST['confirm_password']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)) $err='Email không hợp lệ.';
        elseif(!preg_match('/^\d{6}$/',$code)) $err='Mã xác nhận phải gồm 6 chữ số.';
        elseif($new!==$confirm) $err='Xác nhận mật khẩu chưa khớp.';
        elseif(!bfLoginStrongPassword($new)) $err='Mật khẩu mới phải từ 8 ký tự, gồm chữ hoa, chữ thường, số và ký tự đặc biệt.';
        else{
            try{
                $st=$pdo->prepare("SELECT * FROM bf_password_resets WHERE email=? AND used_at IS NULL AND expires_at>=NOW() ORDER BY id DESC LIMIT 1");$st->execute([$email]);$reset=$st->fetch();
                if(!$reset) $err='Mã xác nhận đã hết hạn. Hãy yêu cầu mã mới.';
                elseif((int)($reset['attempts']??0)>=5) $err='Mã này đã bị khóa sau 5 lần nhập sai. Hãy yêu cầu mã mới.';
                elseif(!hash_equals((string)$reset['otp_code'],hash('sha256',$code))){
                    $pdo->prepare("UPDATE bf_password_resets SET attempts=attempts+1 WHERE id=?")->execute([$reset['id']]);
                    $remaining=max(0,4-(int)($reset['attempts']??0));$err='Mã xác nhận không đúng. Còn '.$remaining.' lần thử.';
                }else{
                    $st=$pdo->prepare("SELECT id FROM bf_users WHERE email=? AND status='ACTIVE' LIMIT 1");$st->execute([$email]);$uid=(int)$st->fetchColumn();
                    if(!$uid) $err='Tài khoản không còn hoạt động.';
                    else{
                        $pdo->beginTransaction();
                        try{
                            $pdo->prepare("UPDATE bf_users SET password_hash=?,must_change_password=0,password_changed_at=NOW() WHERE id=?")->execute([password_hash($new,PASSWORD_DEFAULT),$uid]);
                            $pdo->prepare("UPDATE bf_password_resets SET used_at=NOW() WHERE id=?")->execute([$reset['id']]);
                            try{$pdo->prepare("DELETE FROM bf_user_sessions WHERE user_id=?")->execute([$uid]);}catch(Throwable $ignore){}
                            $pdo->commit();unset($_SESSION['bf_reset_email']);$msg='Đổi mật khẩu thành công. Tất cả phiên đăng nhập cũ đã được thu hồi.';$mode='login';
                            bfLogAccess($pdo,['user_id'=>$uid,'email'=>$email,'event_type'=>'PASSWORD_RESET_SUCCESS']);
                        }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
                    }
                }
            }catch(Throwable $e){$err='Không thể xác minh mã. Hãy kiểm tra migration v4.5.1.';error_log('[BrainFocus Reset] '.$e->getMessage());}
        }
    }
}
?>
<!doctype html>
<html lang="vi" class="h-full">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Đăng nhập · Brain Focus</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:Inter,sans-serif;background:linear-gradient(180deg,#101722 0,#2f343c 25%,#30353d 100%)}
.auth-card{width:min(92vw,390px);box-shadow:0 28px 65px rgba(0,0,0,.28)}
.auth-input{height:42px;background:#f8fafc;border:1px solid #d8e0ea;border-radius:10px;width:100%;padding:0 12px;font-size:12px;outline:none}.auth-input:focus{background:#fff;border-color:#93c5fd;box-shadow:0 0 0 3px rgba(59,130,246,.10)}
.auth-btn{height:42px;border-radius:10px;font-size:12px;font-weight:700}.small-link{font-size:11px;font-weight:650}
</style>
</head>
<body class="min-h-full flex items-center justify-center p-4 text-slate-900">
<div class="auth-card rounded-[22px] bg-white border border-slate-200 overflow-hidden">
  <div class="p-6 pb-5">
    <div class="flex items-start gap-3">
      <div class="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-lg shrink-0">🔐</div>
      <div class="min-w-0">
        <h1 class="text-[14px] font-extrabold text-slate-900 leading-tight"><?php if($mode==='forgot'):?>QUÊN MẬT KHẨU<?php elseif($mode==='reset'):?>XÁC NHẬN MÃ OTP<?php elseif($mode==='register'):?>TẠO TÀI KHOẢN BRAIN FOCUS<?php else:?>MỞ KHÓA BRAIN FOCUS<?php endif;?></h1>
        <p class="text-[10px] text-slate-400 mt-1"><?php if($mode==='forgot'):?>Nhập email để nhận mã xác nhận qua Gmail<?php elseif($mode==='reset'):?>Nhập mã 6 số rồi đặt mật khẩu mới<?php elseif($mode==='register'):?>Tạo hồ sơ học viên mới và đồng bộ dữ liệu<?php else:?>Nhập email và mật khẩu để vào ứng dụng<?php endif;?></p>
      </div>
    </div>

    <?php if($msg):?><div class="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-800 leading-5"><?=htmlspecialchars($msg)?></div><?php endif;?>
    <?php if($err):?><div class="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-[11px] text-rose-700 leading-5">⚠️ <?=htmlspecialchars($err)?></div><?php endif;?>

    <?php if($mode==='register'):?>
      <form method="post" class="mt-5 space-y-3"><input type="hidden" name="_csrf" value="<?=htmlspecialchars($_SESSION['bf_login_csrf'])?>"><input type="hidden" name="mode" value="register"><input type="hidden" name="next" value="<?=htmlspecialchars($next)?>">
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Họ và tên:</label><input required name="name" class="auth-input" placeholder="Nhập họ và tên..."></div>
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Email tài khoản:</label><input type="email" required name="email" class="auth-input" placeholder="Nhập email..."></div>
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Trường / đơn vị:</label><input name="school" class="auth-input" placeholder="Nhập trường hoặc đơn vị..."></div>
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Mật khẩu mạnh:</label><input type="password" required name="password" class="auth-input" placeholder="Hoa + thường + số + ký tự đặc biệt"></div>
        <?php if($currentTerms):?><div><div class="flex items-center justify-between mb-1.5"><label class="text-[11px] font-semibold text-slate-600">Điều khoản Brain Focus · <?=htmlspecialchars($currentTerms['version'])?></label><a href="/terms.php" target="_blank" class="text-[10px] text-blue-600 font-semibold">Mở trang đầy đủ ↗</a></div><div id="reg-terms-scroll" class="h-40 overflow-y-auto rounded-xl border border-slate-200 bg-slate-50 p-3 text-[10px] leading-5"><?=$currentTerms['content_html']?></div><input type="hidden" id="reg-terms-scrolled" name="terms_scrolled" value="0"><label id="reg-terms-wrap" class="mt-2 flex items-start gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3 opacity-50 cursor-not-allowed"><input id="reg-terms-check" type="checkbox" name="accept_terms" disabled class="mt-0.5"><span class="text-[10px] text-slate-600"><b>Tôi đã đọc hết và đồng ý với Điều khoản sử dụng & Chính sách bảo vệ dữ liệu.</b><span id="reg-terms-hint" class="block mt-1 text-slate-400">Cuộn xuống cuối điều khoản để mở khóa ô xác nhận.</span></span></label></div><?php endif;?>
        <fieldset class="rounded-xl border border-slate-200 bg-slate-50 p-3"><legend class="px-1 text-[11px] font-semibold text-slate-700">Email thông tin Brain Focus</legend><p class="text-[10px] leading-5 text-slate-500">Bạn có muốn chúng tôi gửi email về sự kiện, hoạt động và cập nhật của Brain Focus không? Lựa chọn này <b>không áp dụng</b> cho email mã xác nhận đổi mật khẩu, OTP hoặc cảnh báo bảo mật cần thiết.</p><div class="mt-2 grid grid-cols-2 gap-2"><label class="flex items-center gap-2 rounded-lg border bg-white p-2 text-[10px]"><input type="radio" name="email_updates_opt_in" value="1" required> Có, tôi đồng ý</label><label class="flex items-center gap-2 rounded-lg border bg-white p-2 text-[10px]"><input type="radio" name="email_updates_opt_in" value="0" required> Không, cảm ơn</label></div></fieldset>
        <button id="register-submit" class="auth-btn w-full bg-slate-900 hover:bg-slate-800 text-white" <?= $currentTerms?'disabled':'' ?>>Tạo tài khoản</button>
      </form>
      <div class="mt-4 pt-4 border-t border-slate-100 space-y-3"><a href="/google-login.php?next=<?=urlencode($next)?>" class="auth-btn w-full border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 flex items-center justify-center gap-2"><span class="text-base">G</span><span>Tiếp tục bằng Google</span></a><div class="text-center"><a href="/login.php?next=<?=urlencode($next)?>" class="small-link text-blue-600 hover:underline">← Quay về mở khóa</a></div></div>

    <?php elseif($mode==='forgot'):?>
      <form method="post" class="mt-5 space-y-3"><input type="hidden" name="_csrf" value="<?=htmlspecialchars($_SESSION['bf_login_csrf'])?>"><input type="hidden" name="mode" value="forgot">
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Email tài khoản:</label><input type="email" required name="email" value="<?=htmlspecialchars($resetEmail)?>" class="auth-input" placeholder="Nhập lại email của học viên..."></div>
        <div class="rounded-xl border border-blue-100 bg-blue-50 p-3 text-[10px] text-blue-700 leading-5">Mã xác nhận gồm 6 số, có hiệu lực 10 phút. Website không tự chọn tài khoản theo IP hoặc thiết bị.</div>
        <button class="auth-btn w-full bg-slate-900 hover:bg-slate-800 text-white">Gửi mã xác nhận</button>
      </form>
      <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between"><a href="/login.php?next=<?=urlencode($next)?>" class="small-link text-blue-600">← Quay về</a><a href="/login.php?mode=register&next=<?=urlencode($next)?>" class="small-link text-slate-600">✚ Tạo tài khoản mới</a></div>

    <?php elseif($mode==='reset'):?>
      <form method="post" class="mt-5 space-y-3"><input type="hidden" name="_csrf" value="<?=htmlspecialchars($_SESSION['bf_login_csrf'])?>"><input type="hidden" name="mode" value="reset">
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Email tài khoản:</label><input type="email" required name="email" value="<?=htmlspecialchars($resetEmail?:($_SESSION['bf_reset_email']??''))?>" class="auth-input" placeholder="Nhập email..."></div>
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Mã xác nhận 6 số:</label><input required inputmode="numeric" pattern="[0-9]{6}" name="otp_code" maxlength="6" class="auth-input text-center tracking-[.32em] font-bold text-base" placeholder="000000"></div>
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Mật khẩu mới:</label><input type="password" required name="new_password" class="auth-input" placeholder="Hoa + thường + số + ký tự đặc biệt"></div>
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Xác nhận mật khẩu:</label><input type="password" required name="confirm_password" class="auth-input" placeholder="Nhập lại mật khẩu mới..."></div>
        <button class="auth-btn w-full bg-slate-900 hover:bg-slate-800 text-white">Xác nhận & đổi mật khẩu</button>
      </form>
      <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between"><a href="/login.php?mode=forgot&next=<?=urlencode($next)?>" class="small-link text-blue-600">↻ Gửi lại mã</a><a href="/login.php?next=<?=urlencode($next)?>" class="small-link text-slate-600">Quay về đăng nhập</a></div>

    <?php else:?>
      <form method="post" class="mt-5 space-y-3"><input type="hidden" name="_csrf" value="<?=htmlspecialchars($_SESSION['bf_login_csrf'])?>"><input type="hidden" name="mode" value="login">
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Email tài khoản:</label><input type="email" name="email" required class="auth-input" placeholder="Nhập email tài khoản..."></div>
        <div><label class="text-[11px] font-semibold text-slate-600 block mb-1.5">Mật khẩu tài khoản:</label><div class="relative"><input id="login-password" type="password" name="password" required class="auth-input pr-10" placeholder="Nhập mật khẩu tài khoản..."><button type="button" onclick="const p=document.getElementById('login-password');p.type=p.type==='password'?'text':'password'" class="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-500">👁️</button></div></div>
        <div class="grid grid-cols-2 gap-2 pt-1"><a href="/login.php?mode=forgot&next=<?=urlencode($next)?>" class="auth-btn border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 flex items-center justify-center">Quên mật khẩu</a><button class="auth-btn bg-slate-900 hover:bg-slate-800 text-white">Mở Khóa 🔐</button></div>
      </form>
      <div class="mt-4 pt-4 border-t border-slate-100 space-y-3"><a href="/google-login.php?next=<?=urlencode($next)?>" class="auth-btn w-full border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 flex items-center justify-center gap-2"><span class="text-base">G</span><span>Đăng nhập bằng Google</span></a><div class="flex items-center justify-end"><a href="/login.php?mode=register&next=<?=urlencode($next)?>" class="small-link text-slate-600 hover:text-slate-900">✚ Tạo tài khoản mới</a></div><p class="text-[9px] text-slate-400 leading-4">Brain Focus không thu hoặc nhìn thấy mật khẩu Google. Google chỉ trả thông tin tài khoản sau khi bạn cấp quyền.</p></div>
    <?php endif;?>
  </div>
</div>
<script>
(function(){const sc=document.getElementById('reg-terms-scroll'),cb=document.getElementById('reg-terms-check'),hid=document.getElementById('reg-terms-scrolled'),wrap=document.getElementById('reg-terms-wrap'),btn=document.getElementById('register-submit'),hint=document.getElementById('reg-terms-hint');if(!sc||!cb)return;function unlock(){if(sc.scrollTop+sc.clientHeight>=sc.scrollHeight-8){cb.disabled=false;hid.value='1';wrap.classList.remove('opacity-50','cursor-not-allowed');hint.textContent='Đã đọc đến cuối. Hãy tích xác nhận để đăng ký.'}}sc.addEventListener('scroll',unlock);unlock();cb.addEventListener('change',()=>btn.disabled=!cb.checked);})();
</script></body></html>
