# Brain Focus – Classic Exact UI

Bản này lấy `legacy/brainfocus-classic.html` và giao diện đang chạy tại focusbrain.online làm chuẩn thị giác.

- `/` và `/focus.php` mở thẳng Phiên học tập trung như bản cũ.
- Header, sub-banner, mobile tabs, sidebar, audio box, daily tracker, Deep Focus hero, mode tabs, circular timer và login modal được phục dựng sát cấu trúc cũ.
- Backend PHP-first, session, CSRF, IP/device tracking, RBAC, security center, forbidden words, point ledger và honors giữ nguyên từ bản secure.
- Không khôi phục cơ chế localStorage làm nguồn xác thực/điểm.
