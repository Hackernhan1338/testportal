<?php
require_once __DIR__.'/api/db.php';
header('Content-Type: application/xml; charset=utf-8');
$pdo=getDbConnection();$scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';$base=$scheme.'://'.($_SERVER['HTTP_HOST']??'localhost');
$pages=[['/index.php','daily','1.0'],['/terms.php','monthly','0.5'],['/knowledge.php','daily','0.8'],['/tips.php','weekly','0.7'],['/leaderboard.php','daily','0.6']];
echo '<?xml version="1.0" encoding="UTF-8"?>';
?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><?php foreach($pages as $x):?><url><loc><?=htmlspecialchars($base.$x[0],ENT_XML1,'UTF-8')?></loc><changefreq><?=$x[1]?></changefreq><priority><?=$x[2]?></priority></url><?php endforeach;?></urlset>
