# Brain Focus v3 — EduWall Architecture Upgrade

## Đã thực hiện

- Tách Admin Center thành `/admin/` độc lập khỏi giao diện học viên.
- Admin dùng PHP Session thay cho localStorage admin.
- Thêm CSRF protection, role/permission RBAC và Audit Log.
- Thêm trình tạo Super Admin lần đầu `/admin/setup.php`; không phát hành mật khẩu admin mặc định.
- Thêm Dashboard KPI: users, sessions, hours, Deep Focus, integrity, DAU/WAU/MAU, BFS, feedback.
- Thêm Users Management và bulk lock/unlock.
- Thêm Session Inspector với Deep Focus event timeline.
- Thêm CMS quản trị article/tip/FAQ.
- Thêm Feedback workflow và admin reply/note.
- Thêm Analytics dashboard.
- Thêm Admin Accounts cho Super Admin.
- Thêm Settings Center.
- Tách `index.html` khỏi JS/CSS khổng lồ thành `assets/js/*` và `assets/css/*`.
- Thêm API `events.php` cho Deep Focus + analytics event.
- Khóa thao tác ghi hồ sơ/phiên học theo mật khẩu học viên.
- Tắt public `get_user` mặc định.
- Đổi email/mật khẩu học viên có xác thực server.
- Hỗ trợ nâng SHA-256 admin legacy sang `password_hash()`.
- Thêm migration không xóa dữ liệu cũ.
- Thêm `.htaccess` production hardening và chặn tải file SQL.
- Đồng bộ bản web nhúng Android với frontend module hóa; Admin Center chỉ dùng trên phiên bản web máy chủ.

## Ghi chú kiến trúc

Frontend học viên vẫn giữ cơ chế local-first/offline của Brain Focus cũ để không phá trải nghiệm hiện có. Xác thực học viên chưa chuyển hoàn toàn thành server-side login session; v3 đã khóa các API ghi quan trọng bằng password verification. Một phiên bản sau có thể chuyển toàn bộ user authentication sang PHP session/token để loại bỏ phần auth legacy trên client.
