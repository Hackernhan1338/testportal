<?php
require_once __DIR__.'/includes/bootstrap.php';require_once __DIR__.'/../api/mail.php';
$admin=adminRequire($pdo,'dashboard.view');if(($admin['role']??'')!=='SUPER_ADMIN'){http_response_code(403);die('Chỉ SUPER_ADMIN được truy cập Health Check.');}
$adminPage='health';$pageTitle='Health Check & Tích hợp';
$checks=[];
function hc($name,$ok,$detail,$level='critical'){global $checks;$checks[]=['name'=>$name,'ok'=>$ok,'detail'=>$detail,'level'=>$level];}
hc('PHP >= 7.2',version_compare(PHP_VERSION,'7.2.0','>='),'PHP '.PHP_VERSION);
try{$v=$pdo->query('SELECT VERSION()')->fetchColumn();hc('Kết nối MariaDB/MySQL',true,(string)$v);}catch(Throwable $e){hc('Kết nối MariaDB/MySQL',false,'Không truy vấn được database');}
$need=['bf_users','bf_study_sessions','bf_notifications','bf_tasks','bf_badges','bf_settings'];foreach($need as $t){try{$st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");$st->execute([$t]);$found=((int)$st->fetchColumn())>0;hc('Bảng '.$t,$found,$found?'OK':'Thiếu bảng');}catch(Throwable $e){hc('Bảng '.$t,false,'Lỗi kiểm tra');}}
hc('PDO MySQL',extension_loaded('pdo_mysql'),'pdo_mysql '.(extension_loaded('pdo_mysql')?'đã bật':'chưa bật'));
hc('OpenSSL',extension_loaded('openssl'),'Cần cho Gmail SMTP/HTTPS');
hc('PHP cURL',extension_loaded('curl'),'Cần cho Google OAuth 2.0');
hc('Gmail SMTP',function_exists('bfSmtpConfigured')&&bfSmtpConfigured(),function_exists('bfSmtpConfigured')&&bfSmtpConfigured()?'Đã cấu hình':'Chưa cấu hình App Password/SMTP','integration');
$googleOk=defined('BF_GOOGLE_CLIENT_ID')&&strpos(BF_GOOGLE_CLIENT_ID,'DAN_')===false&&trim(BF_GOOGLE_CLIENT_ID)!=='';hc('Google OAuth',$googleOk,$googleOk?'Client ID đã cấu hình':'Chưa cấu hình Client ID','integration');
$dirs=[__DIR__.'/../uploads',__DIR__.'/../uploads/badges',__DIR__.'/../uploads/focus-audio',__DIR__.'/../backups'];foreach($dirs as $d){if(!is_dir($d))@mkdir($d,0755,true);hc('Ghi thư mục '.basename($d),is_dir($d)&&is_writable($d),$d,'storage');}
try{$terms=$pdo->query("SELECT version,status FROM bf_terms_versions WHERE status='PUBLISHED' ORDER BY id DESC LIMIT 1")->fetch();hc('Điều khoản hiện hành',(bool)$terms,$terms?'Phiên bản '.$terms['version']:'Chưa có bản PUBLISHED','integration');}catch(Throwable $e){hc('Điều khoản hiện hành',false,'Không kiểm tra được','integration');}
$schemaStatus=bfAdminSchemaStatus($pdo);hc('Schema vận hành v4.8.x',$schemaStatus['ok'],$schemaStatus['ok']?'Đủ bảng/cột':'Thiếu: '.implode(', ',$schemaStatus['missing']));
$passed=count(array_filter($checks,function($x){return $x['ok'];}));$total=count($checks);
include __DIR__.'/includes/layout_top.php';?>
<div class="page-head"><div><h1>Health Check & Integration Check</h1><p>Dành riêng cho SUPER_ADMIN. Không hiển thị mật khẩu DB, App Password Gmail hay Google Client Secret.</p></div><div><span class="badge green"><?=$passed?>/<?=$total?> OK</span></div></div>
<div class="grid grid-3"><?php foreach($checks as $c):?><div class="card card-pad"><div style="display:flex;gap:10px;align-items:center"><span style="font-size:24px"><?=$c['ok']?'✅':'❌'?></span><div><b><?=htmlspecialchars($c['name'])?></b><div class="mini muted" style="margin-top:4px"><?=htmlspecialchars($c['detail'])?></div></div></div></div><?php endforeach;?></div>
<section class="card card-pad" style="margin-top:14px"><h2 class="section-title">Kiểm tra tích hợp nhanh</h2><p class="muted">SMTP có thể kiểm tra gửi thực tế tại <a href="/admin/mail-test.php">Email SMTP</a>. Google OAuth cần Redirect URI trùng chính xác với cấu hình Google Cloud. Backup DB có trang riêng và chỉ SUPER_ADMIN được tải.</p><div class="row-actions" style="margin-top:10px"><a class="btn" href="/admin/mail-test.php">Kiểm tra SMTP</a><a class="btn" href="/admin/backup.php">Backup Database</a><a class="btn" href="/admin/modules.php">Module Control</a><a class="btn" href="/admin/focus-audio.php">Kho âm thanh</a><a class="btn primary" href="/admin/repair-schema.php">Repair schema</a></div></section>
<?php include __DIR__.'/includes/layout_bottom.php';?>
