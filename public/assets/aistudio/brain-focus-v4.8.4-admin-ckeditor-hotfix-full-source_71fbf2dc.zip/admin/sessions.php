<?php
require_once __DIR__.'/includes/bootstrap.php';
$admin=adminRequire($pdo,'sessions.view');$adminPage='sessions';$pageTitle='Phiên học';
$id=(int)($_GET['id']??0);$detail=null;$events=[];
if($id){
  $st=$pdo->prepare("SELECT s.*,u.name user_name,u.school FROM bf_study_sessions s LEFT JOIN bf_users u ON u.email=s.user_email WHERE s.id=?");$st->execute([$id]);$detail=$st->fetch();
  if($detail){
    $ev=$pdo->prepare("SELECT event_type,event_value,created_at FROM bf_focus_events WHERE study_session_id=? ORDER BY id");$ev->execute([$id]);$events=$ev->fetchAll();
    $detailActual=(int)($detail['actual_seconds']??0);if($detailActual<=0)$detailActual=(int)$detail['duration_minutes']*60;
    $detailFull=(int)($detail['fullscreen_seconds']??0);if($detailFull<=0&&!empty($detail['is_deep_focus'])&&empty($detail['actual_seconds']))$detailFull=$detailActual;
    $detailCompletion=(float)($detail['completion_percent']??0);if($detailCompletion<=0)$detailCompletion=min(100,round($detailActual/max(60,(int)$detail['duration_minutes']*60)*100,1));
  }
}
$q=trim($_GET['q']??'');$p=[];$where='1=1';if($q!==''){$where='(s.user_email LIKE ? OR u.name LIKE ?)';$x='%'.$q.'%';$p=[$x,$x];}
$st=$pdo->prepare("SELECT s.id,s.user_email,s.duration_minutes,s.actual_seconds,s.fullscreen_seconds,s.completion_percent,s.focus_integrity,s.distractions,s.rank_earned,s.bfs_earned,s.goal,s.created_at,u.name user_name FROM bf_study_sessions s LEFT JOIN bf_users u ON u.email=s.user_email WHERE $where ORDER BY s.id DESC LIMIT 250");$st->execute($p);$rows=$st->fetchAll();
include __DIR__.'/includes/layout_top.php';
?>
<div class="page-head"><div><h1>Phiên học</h1><p>Session Inspector: thời gian thực, F11, độ hoàn thành, Integrity và timeline hành vi.</p></div></div>
<?php if($detail):?>
<section class="card card-pad" style="margin-bottom:14px">
 <h2 class="section-title">Session #<?=$detail['id']?> · <?=htmlspecialchars($detail['user_name']?:$detail['user_email'])?></h2>
 <div class="grid grid-4">
  <div class="stat"><span>Thực tế / mục tiêu</span><strong><?=number_format($detailActual/60,1)?>p / <?=$detail['duration_minutes']?>p</strong></div>
  <div class="stat"><span>F11 / Fullscreen</span><strong><?=number_format($detailFull/60,1)?>p</strong></div>
  <div class="stat"><span>Hoàn thành</span><strong><?=number_format($detailCompletion,1)?>%</strong></div>
  <div class="stat"><span>Integrity</span><strong><?=$detail['focus_integrity']?>/100</strong></div>
 </div>
 <div class="grid grid-4" style="margin-top:10px">
  <div class="stat"><span>Xao nhãng</span><strong><?=$detail['distractions']?></strong></div>
  <div class="stat"><span>Điểm XH</span><strong>+<?=$detail['rank_earned']?></strong></div>
  <div class="stat"><span>BFS</span><strong>+<?=$detail['bfs_earned']?></strong></div>
  <div class="stat"><span>Chế độ</span><strong><?=htmlspecialchars($detail['mode']?:'—')?></strong></div>
 </div>
 <h3 class="section-title" style="margin-top:18px">Timeline</h3>
 <div class="list"><?php foreach($events as $e):?><div class="list-row"><span class="code"><?=htmlspecialchars($e['event_type'])?> <?=htmlspecialchars($e['event_value']?:'')?></span><span class="muted mini"><?=htmlspecialchars($e['created_at'])?></span></div><?php endforeach;?></div>
</section>
<?php endif;?>
<form method="get" class="filterbar"><div class="field"><label>Tìm người học</label><input class="input" name="q" value="<?=htmlspecialchars($q)?>"></div><button class="btn ghost">Tìm</button></form>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Học viên</th><th>Mục tiêu</th><th>Thực tế</th><th>F11</th><th>Hoàn thành</th><th>Integrity</th><th>Điểm</th><th>Thời gian</th><th></th></tr></thead><tbody>
<?php foreach($rows as $s):$actual=(int)($s['actual_seconds']??0);if($actual<=0)$actual=(int)$s['duration_minutes']*60;$full=(int)($s['fullscreen_seconds']??0);if($full<=0&&empty($s['actual_seconds']))$full=0;$comp=(float)($s['completion_percent']??0);if($comp<=0)$comp=min(100,round($actual/max(60,(int)$s['duration_minutes']*60)*100,1));?>
<tr><td>#<?=$s['id']?></td><td><b><?=htmlspecialchars($s['user_name']?:'—')?></b><div class="mini muted"><?=htmlspecialchars($s['user_email'])?></div></td><td><?=htmlspecialchars(mb_substr($s['goal']?:'—',0,80))?></td><td><?=number_format($actual/60,1)?>p</td><td><?=number_format($full/60,1)?>p</td><td><?=number_format($comp,0)?>%</td><td><?=$s['focus_integrity']?>/100</td><td>+<?=$s['rank_earned']?> / +<?=$s['bfs_earned']?> BFS</td><td><?=htmlspecialchars($s['created_at'])?></td><td><a class="btn ghost" href="?id=<?=$s['id']?>">Xem</a></td></tr>
<?php endforeach;?></tbody></table></div>
<?php include __DIR__.'/includes/layout_bottom.php';?>
