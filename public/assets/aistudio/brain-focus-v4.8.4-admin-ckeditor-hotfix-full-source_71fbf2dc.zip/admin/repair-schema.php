<?php
require_once __DIR__.'/includes/bootstrap.php';
$admin=adminRequire($pdo,'dashboard.view');
if(($admin['role']??'')!=='SUPER_ADMIN'){http_response_code(403);die('Chỉ SUPER_ADMIN được sửa schema.');}
$adminPage='health';$pageTitle='Repair Database Schema';$result=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    adminPostCsrf();
    $result=bfAdminSchemaRepair($pdo);
    if(function_exists('bfAudit')) bfAudit($pdo,$admin,'SCHEMA_REPAIR','SYSTEM','Repair schema v4.8.3');
}
$status=bfAdminSchemaStatus($pdo);
include __DIR__.'/includes/layout_top.php';
?>
<div class="page-head"><div><h1>Repair Database Schema</h1><p>Sửa các bảng/cột cần cho Nhiệm vụ, Kho âm thanh và Module Control. Không DROP bảng và không xoá dữ liệu học viên.</p></div></div>
<?php if($result):?>
<div class="notice <?=$result['ok']?'':'error'?>"><b><?=$result['ok']?'Repair hoàn tất.':'Repair còn lỗi.'?></b><?php if($result['errors']):?><div class="mini" style="margin-top:8px"><?=htmlspecialchars(implode(' | ',$result['errors']))?></div><?php endif;?></div>
<?php endif;?>
<section class="card card-pad"><h2 class="section-title">Trạng thái schema</h2><?php if($status['ok']):?><div class="notice">✅ Database đã đủ schema cho các module vận hành.</div><?php else:?><div class="notice error">⚠️ Thiếu: <?=htmlspecialchars(implode(', ',$status['missing']))?></div><?php endif;?><form method="post" style="margin-top:14px" onsubmit="return confirm('Chạy repair schema? Hệ thống chỉ CREATE/ALTER bổ sung, không DROP dữ liệu.')"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><button class="btn primary">🛠️ Repair schema ngay</button> <a class="btn" href="/admin/health.php">Quay lại Health Check</a></form></section>
<?php include __DIR__.'/includes/layout_bottom.php';?>
