    </main>
  </section>
</div>
<nav class="admin-mobile-nav">
  <a class="<?=$adminPage==='dashboard'?'active':''?>" href="/admin/index.php">▦<span>Dashboard</span></a>
  <?php if(bfHasPermission($admin,'users.view')):?><a class="<?=$adminPage==='users'?'active':''?>" href="/admin/users.php">👥<span>Users</span></a><?php endif;?>
  <?php if(bfHasPermission($admin,'sessions.view')):?><a class="<?=$adminPage==='sessions'?'active':''?>" href="/admin/sessions.php">⏱<span>Sessions</span></a><?php endif;?>
  <?php if(bfHasPermission($admin,'security.view')):?><a class="<?=$adminPage==='security'?'active':''?>" href="/admin/security.php">🛡<span>Security</span></a><?php endif;?>
  <a href="/admin/account.php">👤<span>Account</span></a>
</nav>
</body></html>
