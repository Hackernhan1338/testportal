<?php
require_once __DIR__.'/../../api/admin_security.php';
require_once __DIR__.'/../../includes/metrics.php';
require_once __DIR__.'/schema_guard.php';

// Shared settings helper for Admin pages.
// Admin bootstrap does not load the public includes/bootstrap.php, therefore
// pages such as tasks.php, focus-audio.php and modules.php must have bfSetting()
// available here as well.
if(!function_exists('bfSetting')){
    function bfSetting(PDO $pdo,string $key,$default=null){
        try{
            $st=$pdo->prepare("SELECT setting_value FROM bf_settings WHERE setting_key=? LIMIT 1");
            $st->execute([$key]);
            $v=$st->fetchColumn();
            if($v===false||$v===null||$v==='') return $default;
            return $v;
        }catch(Throwable $e){
            return $default;
        }
    }
}

if(!function_exists('bfAdminSettingWrite')){
    function bfAdminSettingWrite(PDO $pdo,string $key,$value): void {
        $st=$pdo->prepare("INSERT INTO bf_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
        $st->execute([$key,(string)$value]);
    }
}
$pdo=getDbConnection();bfStartAdminSession();bfSecurityGate($pdo,null);$admin=bfCurrentAdmin($pdo);
function adminRequire(PDO $pdo, ?string $perm=null): array {global $admin;if(!$admin){header('Location: /admin/login.php');exit;}if(!empty($admin['must_change_password'])&&substr((string)($_SERVER['SCRIPT_NAME']??''),-12)!=='/account.php'){header('Location: /admin/account.php');exit;}if($perm&&!bfHasPermission($admin,$perm)){http_response_code(403);die('Bạn không có quyền truy cập chức năng này.');}bfLogAccess($pdo,['admin_id'=>$admin['id'],'email'=>$admin['email'],'event_type'=>'ADMIN_PAGE_VIEW']);return $admin;}
function adminPostCsrf(): void {bfStartAdminSession();$p=(string)($_POST['_csrf']??'');$e=(string)($_SESSION['bf_csrf']??'');if(!$p||!$e||!hash_equals($e,$p)){http_response_code(419);die('CSRF token không hợp lệ');}}
