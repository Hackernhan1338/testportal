<?php
if(!isset($adminPage))$adminPage='dashboard';
if(!isset($pageTitle))$pageTitle='Quản trị';
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#12213f">
  <title><?=htmlspecialchars($pageTitle)?> · Brain Focus Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/site.css?v=4.1.0">
  <link rel="stylesheet" href="/admin/assets/admin.css?v=3.0.0">
  <link rel="stylesheet" href="/admin/assets/admin-v4.css?v=4.1.0">
</head>
<body class="admin-classic-body">
<div class="adminpagentn-shell">
  <aside id="admin-sidebar" class="adminpagentn-sidebar">
    <a class="adminpagentn-brand" href="/admin/index.php">
      <span class="adminpagentn-brand-mark">🧠</span>
      <span><strong>Brain Focus</strong><span>ADMINISTRATION</span></span>
    </a>
    <nav class="adminpagentn-nav">
      <div class="adminpagentn-nav-label">TỔNG QUAN</div>
      <a class="<?=$adminPage==='dashboard'?'active':''?>" href="/admin/index.php"><span class="adminpagentn-nav-icon">▦</span>Dashboard</a>
      <?php if(bfHasPermission($admin,'users.view')):?>
      <div class="adminpagentn-nav-label">TÀI KHOẢN</div>
      <a class="<?=$adminPage==='users'?'active':''?>" href="/admin/users.php"><span class="adminpagentn-nav-icon">👥</span>Học viên</a>
      <?php endif;?>
      <?php if(bfHasPermission($admin,'admins.view')):?><a class="<?=$adminPage==='admins'?'active':''?>" href="/admin/admins.php"><span class="adminpagentn-nav-icon">♜</span>Quản trị viên</a><?php endif;?>
      <?php if(bfHasPermission($admin,'sessions.view')):?>
      <div class="adminpagentn-nav-label">HỌC TẬP</div>
      <a class="<?=$adminPage==='sessions'?'active':''?>" href="/admin/sessions.php"><span class="adminpagentn-nav-icon">⏱</span>Phiên học</a>
      <?php endif;?>
      <?php if(bfHasPermission($admin,'content.view')):?>
      <div class="adminpagentn-nav-label">NỘI DUNG</div>
      <a class="<?=$adminPage==='content'?'active':''?>" href="/admin/content.php"><span class="adminpagentn-nav-icon">▤</span>CMS</a>
      <?php endif;?>
      <?php if(bfHasPermission($admin,'surveys.view')):?><a class="<?=$adminPage==='surveys'?'active':''?>" href="/admin/surveys.php"><span class="adminpagentn-nav-icon">▥</span>Khảo sát học viên</a><?php endif;?>
      <?php if(bfHasPermission($admin,'feedback.view')):?><a class="<?=$adminPage==='feedback'?'active':''?>" href="/admin/feedback.php"><span class="adminpagentn-nav-icon">✉</span>Góp ý</a><?php endif;?>
      <?php if(bfHasPermission($admin,'honors.view')):?>
      <div class="adminpagentn-nav-label">VINH DANH</div>
      <a class="<?=$adminPage==='honors'?'active':''?>" href="/admin/honors.php"><span class="adminpagentn-nav-icon">🏅</span>Điểm & cấp vinh danh</a>
      <a class="<?=$adminPage==='achievements'?'active':''?>" href="/admin/achievements.php"><span class="adminpagentn-nav-icon">💎</span>Kho danh hiệu & huy hiệu</a>
      <?php endif;?>
      <?php if(bfHasPermission($admin,'score_audit.view')):?><a class="<?=$adminPage==='score-audit'?'active':''?>" href="/admin/score-audit.php"><span class="adminpagentn-nav-icon">⚖</span>Viện giám sát điểm</a><?php endif;?>
      <?php if(bfHasPermission($admin,'security.view')):?>
      <div class="adminpagentn-nav-label">BẢO MẬT</div>
      <a class="<?=$adminPage==='security'?'active':''?>" href="/admin/security.php"><span class="adminpagentn-nav-icon">🛡</span>Truy cập & chặn</a>
      <?php endif;?>
      <?php if(bfHasPermission($admin,'forbidden.view')):?><a class="<?=$adminPage==='forbidden'?'active':''?>" href="/admin/forbidden-words.php"><span class="adminpagentn-nav-icon">⊘</span>Từ cấm</a><?php endif;?>
      <?php if(bfHasPermission($admin,'analytics.view')):?>
      <div class="adminpagentn-nav-label">VẬN HÀNH</div>
      <a class="<?=$adminPage==='analytics'?'active':''?>" href="/admin/analytics.php"><span class="adminpagentn-nav-icon">◫</span>Analytics</a>
      <?php endif;?>
      <?php if(bfHasPermission($admin,'visits.view')):?><a class="<?=$adminPage==='visits'?'active':''?>" href="/admin/visits.php"><span class="adminpagentn-nav-icon">◉</span>Web visits</a><?php endif;?>
      <?php if(bfHasPermission($admin,'leaderboard.manage')):?><a class="<?=$adminPage==='leaderboard'?'active':''?>" href="/admin/leaderboard.php"><span class="adminpagentn-nav-icon">🏆</span>Điều hành BXH</a><?php endif;?>
      <?php if(bfHasPermission($admin,'audit.view')):?><a class="<?=$adminPage==='audit'?'active':''?>" href="/admin/audit.php"><span class="adminpagentn-nav-icon">⌕</span>Audit logs</a><?php endif;?>
      <?php if(bfHasPermission($admin,'settings.view')):?><a class="<?=$adminPage==='tasks'?'active':''?>" href="/admin/tasks.php"><span class="adminpagentn-nav-icon">🎯</span>Nhiệm vụ học viên</a><a class="<?=$adminPage==='focus-audio'?'active':''?>" href="/admin/focus-audio.php"><span class="adminpagentn-nav-icon">🎧</span>Kho âm thanh</a><a class="<?=$adminPage==='modules'?'active':''?>" href="/admin/modules.php"><span class="adminpagentn-nav-icon">◫</span>Module Control</a><a class="<?=$adminPage==='settings'?'active':''?>" href="/admin/settings.php"><span class="adminpagentn-nav-icon">⚙</span>Cấu hình</a><?php endif;?>
      <?php if(bfHasPermission($admin,'settings.view')):?><a class="<?=$adminPage==='mail-test'?'active':''?>" href="/admin/mail-test.php"><span class="adminpagentn-nav-icon">✉</span>Email SMTP</a><?php endif;?>
      <?php if(bfHasPermission($admin,'settings.view')):?><a class="<?=$adminPage==='terms'?'active':''?>" href="/admin/terms.php"><span class="adminpagentn-nav-icon">📜</span>Điều khoản</a><a class="<?=$adminPage==='mail-broadcast'?'active':''?>" href="/admin/mail-broadcast.php"><span class="adminpagentn-nav-icon">📣</span>Gửi email học viên</a><?php endif;?><?php if(($admin['role']??'')==='SUPER_ADMIN'):?><div class="adminpagentn-nav-label">SUPER ADMIN</div><a class="<?=$adminPage==='health'?'active':''?>" href="/admin/health.php"><span class="adminpagentn-nav-icon">🩺</span>Health & Integration</a><a class="<?=$adminPage==='backup'?'active':''?>" href="/admin/backup.php"><span class="adminpagentn-nav-icon">💾</span>Backup Database</a><a href="/admin/repair-schema.php"><span class="adminpagentn-nav-icon">🛠️</span>Repair Schema</a><?php endif;?>
    </nav>
    <div class="adminpagentn-sidebar-footer">
      <div><span class="admin-online-dot"></span> Secure PHP session</div>
      <div style="margin-top:5px">Brain Focus Admin · v4.8.3</div>
    </div>
  </aside>
  <section class="adminpagentn-workspace">
    <header class="adminpagentn-topbar">
      <div class="adminpagentn-topbar-left">
        <button type="button" class="adminpagentn-menu-btn adminpagentn-btn adminpagentn-btn-secondary adminpagentn-btn-sm" onclick="document.getElementById('admin-sidebar').classList.toggle('open')">☰</button>
        <div><h2><?=htmlspecialchars($pageTitle)?></h2><small>Trung tâm quản trị Brain Focus</small></div>
      </div>
      <div class="adminpagentn-admin-chip">
        <span class="adminpagentn-status-dot"></span>
        <div class="adminpagentn-admin-meta"><strong><?=htmlspecialchars($admin['full_name'])?></strong><span><?=htmlspecialchars($admin['role'])?></span></div>
        <a class="adminpagentn-btn adminpagentn-btn-secondary adminpagentn-btn-sm" href="/admin/account.php">Tài khoản</a>
        <a class="adminpagentn-btn adminpagentn-btn-secondary adminpagentn-btn-sm" href="/index.php">Trang user</a>
        <a class="adminpagentn-btn adminpagentn-btn-secondary adminpagentn-btn-sm" href="/admin/logout.php">Đăng xuất</a>
      </div>
    </header>
    <main class="adminpagentn-main">
