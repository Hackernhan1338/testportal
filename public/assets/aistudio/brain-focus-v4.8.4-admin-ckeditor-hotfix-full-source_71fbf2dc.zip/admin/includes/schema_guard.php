<?php
if (!function_exists('bfAdminTableExists')) {
    function bfAdminTableExists(PDO $pdo, string $table): bool {
        try {
            $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
            $st->execute([$table]);
            return ((int)$st->fetchColumn())>0;
        } catch (Throwable $e) { return false; }
    }
}
if (!function_exists('bfAdminColumnExists')) {
    function bfAdminColumnExists(PDO $pdo, string $table, string $column): bool {
        try {
            $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");
            $st->execute([$table,$column]);
            return ((int)$st->fetchColumn())>0;
        } catch (Throwable $e) { return false; }
    }
}
if (!function_exists('bfAdminIndexExists')) {
    function bfAdminIndexExists(PDO $pdo, string $table, string $index): bool {
        try {
            $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name=? AND index_name=?");
            $st->execute([$table,$index]);
            return ((int)$st->fetchColumn())>0;
        } catch (Throwable $e) { return false; }
    }
}
if (!function_exists('bfAdminSchemaStatus')) {
    function bfAdminSchemaStatus(PDO $pdo): array {
        $requiredTables=[
            'bf_settings','bf_tasks','bf_user_task_completions','bf_task_period_rewards',
            'bf_focus_sounds','bf_gym_purchase_events'
        ];
        $requiredColumns=[
            'bf_tasks'=>['task_code','title','description','icon','task_scope','link_url','reward_xp','status','sort_order','starts_at','ends_at','required_for_bonus','max_completions_per_period','metric_key','target_value','created_at','updated_at'],
            'bf_user_task_completions'=>['user_id','task_id','reward_xp','period_key','completed_at'],
            'bf_focus_sounds'=>['sound_code','name','description','file_path','mime_type','default_volume','status','sort_order','created_by_admin_id','created_at','updated_at']
        ];
        $missing=[];
        foreach($requiredTables as $t) if(!bfAdminTableExists($pdo,$t)) $missing[]='table:'.$t;
        foreach($requiredColumns as $t=>$cols){
            if(!bfAdminTableExists($pdo,$t)) continue;
            foreach($cols as $c) if(!bfAdminColumnExists($pdo,$t,$c)) $missing[]='column:'.$t.'.'.$c;
        }
        return ['ok'=>count($missing)===0,'missing'=>$missing];
    }
}
if (!function_exists('bfAdminSchemaRepair')) {
    function bfAdminSchemaRepair(PDO $pdo): array {
        $done=[];$errors=[];
        $run=function(string $sql,string $label) use($pdo,&$done,&$errors){
            try{$pdo->exec($sql);$done[]=$label;}catch(Throwable $e){$errors[]=$label.': '.$e->getMessage();}
        };

        $run("CREATE TABLE IF NOT EXISTS `bf_settings` (`setting_key` varchar(191) NOT NULL,`setting_value` longtext DEFAULT NULL,`updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),PRIMARY KEY (`setting_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",'bf_settings');
        $run("CREATE TABLE IF NOT EXISTS `bf_tasks` (`id` int NOT NULL AUTO_INCREMENT,`task_code` varchar(80) NOT NULL,`title` varchar(191) NOT NULL,`description` varchar(700) NOT NULL,`icon` varchar(30) NOT NULL DEFAULT '🎯',`task_scope` enum('DISCOVERY','DAILY','WEEKLY','MONTHLY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY',`link_url` varchar(500) DEFAULT NULL,`reward_xp` int NOT NULL DEFAULT 10,`status` enum('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',`sort_order` int NOT NULL DEFAULT 0,`starts_at` datetime DEFAULT NULL,`ends_at` datetime DEFAULT NULL,`required_for_bonus` tinyint(1) NOT NULL DEFAULT 1,`max_completions_per_period` int NOT NULL DEFAULT 1,`metric_key` varchar(50) DEFAULT NULL,`target_value` int NOT NULL DEFAULT 1,`created_at` datetime NOT NULL DEFAULT current_timestamp(),`updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),PRIMARY KEY (`id`),UNIQUE KEY `uq_task_code` (`task_code`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",'bf_tasks');

        if(bfAdminTableExists($pdo,'bf_tasks')){
            $taskCols=[
                'starts_at'=>"ALTER TABLE `bf_tasks` ADD COLUMN `starts_at` DATETIME DEFAULT NULL",
                'ends_at'=>"ALTER TABLE `bf_tasks` ADD COLUMN `ends_at` DATETIME DEFAULT NULL",
                'required_for_bonus'=>"ALTER TABLE `bf_tasks` ADD COLUMN `required_for_bonus` TINYINT(1) NOT NULL DEFAULT 1",
                'max_completions_per_period'=>"ALTER TABLE `bf_tasks` ADD COLUMN `max_completions_per_period` INT NOT NULL DEFAULT 1",
                'metric_key'=>"ALTER TABLE `bf_tasks` ADD COLUMN `metric_key` VARCHAR(50) DEFAULT NULL",
                'target_value'=>"ALTER TABLE `bf_tasks` ADD COLUMN `target_value` INT NOT NULL DEFAULT 1"
            ];
            foreach($taskCols as $c=>$sql) if(!bfAdminColumnExists($pdo,'bf_tasks',$c)) $run($sql,'bf_tasks.'.$c);
            $run("ALTER TABLE `bf_tasks` MODIFY COLUMN `task_scope` ENUM('DISCOVERY','DAILY','WEEKLY','MONTHLY','SYSTEM') NOT NULL DEFAULT 'DISCOVERY'",'bf_tasks.task_scope enum');
        }

        $run("CREATE TABLE IF NOT EXISTS `bf_user_task_completions` (`id` bigint NOT NULL AUTO_INCREMENT,`user_id` int NOT NULL,`task_id` int NOT NULL,`reward_xp` int NOT NULL DEFAULT 0,`period_key` varchar(40) NOT NULL DEFAULT 'ONCE',`completed_at` datetime NOT NULL DEFAULT current_timestamp(),PRIMARY KEY (`id`),KEY `idx_user_task_user` (`user_id`,`completed_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",'bf_user_task_completions');
        if(bfAdminTableExists($pdo,'bf_user_task_completions')&&!bfAdminColumnExists($pdo,'bf_user_task_completions','period_key')) $run("ALTER TABLE `bf_user_task_completions` ADD COLUMN `period_key` VARCHAR(40) NOT NULL DEFAULT 'ONCE'",'bf_user_task_completions.period_key');
        if(bfAdminTableExists($pdo,'bf_user_task_completions')&&!bfAdminIndexExists($pdo,'bf_user_task_completions','uq_user_task_period')) $run("CREATE UNIQUE INDEX `uq_user_task_period` ON `bf_user_task_completions` (`user_id`,`task_id`,`period_key`)",'uq_user_task_period');

        $run("CREATE TABLE IF NOT EXISTS `bf_task_period_rewards` (`id` bigint NOT NULL AUTO_INCREMENT,`user_id` int NOT NULL,`scope` enum('DAILY','WEEKLY','MONTHLY') NOT NULL,`period_key` varchar(40) NOT NULL,`reward_xp` int NOT NULL DEFAULT 100,`awarded_at` datetime NOT NULL DEFAULT current_timestamp(),PRIMARY KEY (`id`),UNIQUE KEY `uq_task_period_reward` (`user_id`,`scope`,`period_key`),KEY `idx_task_period_reward_user` (`user_id`,`awarded_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",'bf_task_period_rewards');
        $run("CREATE TABLE IF NOT EXISTS `bf_focus_sounds` (`id` int NOT NULL AUTO_INCREMENT,`sound_code` varchar(80) NOT NULL,`name` varchar(191) NOT NULL,`description` varchar(500) DEFAULT NULL,`file_path` varchar(500) NOT NULL,`mime_type` varchar(100) DEFAULT NULL,`default_volume` int NOT NULL DEFAULT 40,`status` enum('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',`sort_order` int NOT NULL DEFAULT 0,`created_by_admin_id` int DEFAULT NULL,`created_at` datetime NOT NULL DEFAULT current_timestamp(),`updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),PRIMARY KEY (`id`),UNIQUE KEY `uq_focus_sound_code` (`sound_code`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",'bf_focus_sounds');
        $run("CREATE TABLE IF NOT EXISTS `bf_gym_purchase_events` (`id` bigint NOT NULL AUTO_INCREMENT,`user_id` int NOT NULL,`quantity` int NOT NULL DEFAULT 1,`currency` varchar(20) NOT NULL DEFAULT 'RANK',`cost_points` int NOT NULL DEFAULT 0,`created_at` datetime NOT NULL DEFAULT current_timestamp(),PRIMARY KEY (`id`),KEY `idx_gym_purchase_user_created` (`user_id`,`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",'bf_gym_purchase_events');

        $settings=['module_focus'=>'true','module_gym'=>'true','module_knowledge'=>'true','module_tips'=>'true','module_leaderboard'=>'true','module_achievements'=>'true','module_feedback'=>'true','module_notifications'=>'true','module_audio'=>'true','task_set_bonus_xp'=>'100','ckeditor_enabled'=>'true','app_version'=>'4.8.3-repair'];
        try{$st=$pdo->prepare("INSERT INTO bf_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=setting_value");foreach($settings as $k=>$v)$st->execute([$k,$v]);$done[]='settings defaults';}catch(Throwable $e){$errors[]='settings defaults: '.$e->getMessage();}

        $tasks=[
            ['DAILY_FOCUS_2','Chạy 2 phiên học bất kỳ','Hoàn thành 2 phiên học trong ngày.','⏱️','DAILY','/index.php',15,10,'FOCUS_ANY',2],
            ['DAILY_GYM_PLAY_5','Chơi 5 lượt Gym não','Hoàn thành 5 lượt Gym não trong ngày.','🎮','DAILY','/gym.php',15,20,'GYM_PLAY',5],
            ['DAILY_GYM_BUY_5','Mua 5 lượt Gym não','Mua tổng cộng 5 lượt Gym não trong ngày.','🛒','DAILY','/gym.php',15,30,'GYM_PURCHASE',5],
            ['DAILY_REFLECTION_1','Làm ít nhất 1 bài đánh giá sau phiên học','Lưu ít nhất 1 đúc kết/đánh giá sau phiên học trong ngày.','📝','DAILY','/profile.php#reflections',15,40,'REFLECTION',1],
            ['DAILY_FOCUS_90_1','Chạy 1 phiên học 90 phút','Hoàn thành ít nhất 1 phiên học đặt 90 phút trong ngày.','🧘','DAILY','/index.php?duration=90&deep=1',20,50,'FOCUS_90',1],
            ['WEEKLY_FOCUS_15','Chạy 15 phiên học bất kỳ','Hoàn thành 15 phiên học trong tuần.','⏱️','WEEKLY','/index.php',30,10,'FOCUS_ANY',15],
            ['WEEKLY_GYM_PLAY_200','Chơi 200 lượt Gym não','Hoàn thành 200 lượt Gym não trong tuần.','🎮','WEEKLY','/gym.php',40,20,'GYM_PLAY',200],
            ['WEEKLY_GYM_BUY_150','Mua 150 lượt Gym não','Mua tổng cộng 150 lượt Gym não trong tuần.','🛒','WEEKLY','/gym.php',40,30,'GYM_PURCHASE',150],
            ['WEEKLY_REFLECTION_10','Làm ít nhất 10 bài đánh giá sau phiên học','Lưu ít nhất 10 đúc kết/đánh giá sau phiên học trong tuần.','📝','WEEKLY','/profile.php#reflections',35,40,'REFLECTION',10],
            ['WEEKLY_FOCUS_90_5','Chạy 5 phiên học 90 phút','Hoàn thành ít nhất 5 phiên học đặt 90 phút trong tuần.','🧘','WEEKLY','/index.php?duration=90&deep=1',40,50,'FOCUS_90',5]
        ];
        try{
            $st=$pdo->prepare("INSERT INTO bf_tasks(task_code,title,description,icon,task_scope,link_url,reward_xp,status,sort_order,required_for_bonus,metric_key,target_value) VALUES(?,?,?,?,?,?,?,'ACTIVE',?,1,?,?) ON DUPLICATE KEY UPDATE title=VALUES(title),description=VALUES(description),icon=VALUES(icon),task_scope=VALUES(task_scope),link_url=VALUES(link_url),reward_xp=VALUES(reward_xp),sort_order=VALUES(sort_order),required_for_bonus=1,metric_key=VALUES(metric_key),target_value=VALUES(target_value)");
            foreach($tasks as $t)$st->execute($t);
            $done[]='seed nhiệm vụ ngày/tuần';
        }catch(Throwable $e){$errors[]='seed nhiệm vụ: '.$e->getMessage();}
        return ['ok'=>count($errors)===0,'done'=>$done,'errors'=>$errors,'status'=>bfAdminSchemaStatus($pdo)];
    }
}
