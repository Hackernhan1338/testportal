<?php
require_once __DIR__.'/includes/bootstrap.php';
$admin=adminRequire($pdo,'users.view');
$adminPage='users';$pageTitle='Quản lý học viên';$msg='';$err='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    adminPostCsrf();
    $action=(string)($_POST['action']??'status');
    $id=(int)($_POST['id']??0);
    if($action==='status'){
        bfRequirePermission($admin,'users.lock');
        $status=(string)($_POST['status']??'');
        if($id&&in_array($status,['ACTIVE','LOCKED'],true)){
            $pdo->prepare("UPDATE bf_users SET status=? WHERE id=?")->execute([$status,$id]);
            if($status==='LOCKED'){try{$pdo->prepare("DELETE FROM bf_user_sessions WHERE user_id=?")->execute([$id]);}catch(Throwable $e){}}
            bfAudit($pdo,$admin,'USER_STATUS','USER:'.$id,'Status='.$status);$msg='Đã cập nhật trạng thái.';
        }
    }elseif($action==='force_password_change'){
        bfRequirePermission($admin,'users.edit');
        if($id){
            $pdo->prepare("UPDATE bf_users SET must_change_password=1 WHERE id=?")->execute([$id]);
            try{$pdo->prepare("DELETE FROM bf_user_sessions WHERE user_id=?")->execute([$id]);}catch(Throwable $e){}
            bfAudit($pdo,$admin,'FORCE_PASSWORD_CHANGE','USER:'.$id,'Yêu cầu học viên đổi mật khẩu ở lần đăng nhập kế tiếp');
            $msg='Đã yêu cầu tài khoản đổi mật khẩu ở lần đăng nhập kế tiếp.';
        }
    }
}

$q=trim((string)($_GET['q']??''));$params=[];$where='1=1';
if($q!==''){$where='(name LIKE ? OR email LIKE ? OR school LIKE ?)';$like='%'.$q.'%';$params=[$like,$like,$like];}
$st=$pdo->prepare("SELECT id,name,email,school,birthday,province,status,rank_points,bfs_score,total_hours,sessions_count,must_change_password,password_changed_at,last_login_at,last_ip,created_at FROM bf_users WHERE $where ORDER BY id DESC LIMIT 300");
$st->execute($params);$rows=$st->fetchAll();

$detail=null;$devices=[];$logins=[];$points=[];$honors=[];$detailId=(int)($_GET['id']??0);
if($detailId){
    $du=$pdo->prepare("SELECT * FROM bf_users WHERE id=?");$du->execute([$detailId]);$detail=$du->fetch();
    if($detail){
        $d=$pdo->prepare("SELECT * FROM bf_user_devices WHERE user_email=? ORDER BY last_seen_at DESC LIMIT 30");$d->execute([$detail['email']]);$devices=$d->fetchAll();
        try{$l=$pdo->prepare("SELECT success,actor_type,ip_address,user_agent,created_at FROM bf_login_history WHERE user_email=? ORDER BY id DESC LIMIT 30");$l->execute([$detail['email']]);$logins=$l->fetchAll();}
        catch(Throwable $e){try{$l=$pdo->prepare("SELECT (status='SUCCESS') success,'USER' actor_type,ip_address,user_agent,created_at FROM bf_login_history WHERE user_email=? ORDER BY id DESC LIMIT 30");$l->execute([$detail['email']]);$logins=$l->fetchAll();}catch(Throwable $ignored){$logins=[];}}
        $pt=$pdo->prepare("SELECT points,point_type,reason_text,created_at FROM bf_point_transactions WHERE user_id=? ORDER BY id DESC LIMIT 30");$pt->execute([$detailId]);$points=$pt->fetchAll();
        $hh=$pdo->prepare("SELECT h.icon,h.title,uh.awarded_at FROM bf_user_honors uh JOIN bf_honors h ON h.id=uh.honor_id WHERE uh.user_id=? ORDER BY uh.awarded_at DESC");$hh->execute([$detailId]);$honors=$hh->fetchAll();
    }
}
include __DIR__.'/includes/layout_top.php';
?>
<div class="page-head"><div><h1>Học viên</h1><p>Quản lý trạng thái, mật khẩu bắt buộc, thiết bị, IP, điểm và lịch sử sử dụng.</p></div><a class="btn ghost" href="/admin/export.php?type=students">Xuất Excel học viên</a></div>
<?php if($msg):?><div class="notice"><?=htmlspecialchars($msg)?></div><?php endif;?>
<?php if($err):?><div class="notice error"><?=htmlspecialchars($err)?></div><?php endif;?>

<?php if($detail):?>
<section class="card card-pad" style="margin:14px 0">
  <div class="page-head" style="margin-bottom:12px"><div><h2 style="margin:0"><?=htmlspecialchars($detail['name'])?></h2><p><?=htmlspecialchars($detail['email'])?> · <?=htmlspecialchars($detail['school'])?></p><p class="mini muted">Sinh nhật: <?=htmlspecialchars($detail['birthday']?:'—')?> · Tỉnh/thành: <?=htmlspecialchars($detail['province']?:'—')?> · Hồ sơ: <?=htmlspecialchars($detail['profile_visibility']??'PUBLIC')?></p></div><a class="btn ghost" href="/admin/users.php">Đóng chi tiết</a></div>
  <div class="grid grid-4">
    <div class="stat"><span>XH</span><strong><?=number_format((int)$detail['rank_points'])?></strong></div>
    <div class="stat"><span>BFS</span><strong><?=number_format((int)$detail['bfs_score'])?></strong></div>
    <div class="stat"><span>Phiên</span><strong><?=$detail['sessions_count']?></strong></div>
    <div class="stat"><span>Giờ</span><strong><?=number_format((float)$detail['total_hours'],1)?></strong></div>
  </div>
  <div class="notice" style="margin-top:14px"><b>Bảo mật:</b> IP gần nhất <span class="code"><?=htmlspecialchars($detail['last_ip']?:'—')?></span> · đăng nhập <?=htmlspecialchars($detail['last_login_at']?:'—')?> · đổi mật khẩu <?=htmlspecialchars($detail['password_changed_at']?:'chưa ghi nhận')?> · yêu cầu đổi mật khẩu: <b><?=!empty($detail['must_change_password'])?'CÓ':'KHÔNG'?></b></div>
  <?php if(bfHasPermission($admin,'users.edit')):?><form method="post" style="margin-top:10px"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="force_password_change"><input type="hidden" name="id" value="<?=$detail['id']?>"><button class="btn ghost">Buộc đổi mật khẩu lần kế tiếp</button></form><?php endif;?>
  <div class="grid grid-2" style="margin-top:16px">
    <div><h3 class="section-title">Thiết bị</h3><?php if(!$devices):?><p class="muted">Chưa ghi nhận thiết bị.</p><?php endif;?><?php foreach($devices as $d):?><div class="list-row"><div class="mini"><?=htmlspecialchars(mb_substr($d['device_name']?:'Thiết bị',0,80))?><div class="code"><?=htmlspecialchars(substr($d['device_hash'],0,18))?>…</div></div><span class="code"><?=htmlspecialchars($d['last_ip']?:'—')?></span></div><?php endforeach;?></div>
    <div><h3 class="section-title">Đăng nhập gần đây</h3><?php if(!$logins):?><p class="muted">Chưa có lịch sử.</p><?php endif;?><?php foreach($logins as $l):?><div class="list-row"><span class="badge <?=!empty($l['success'])?'green':'red'?>"><?=!empty($l['success'])?'SUCCESS':'FAILED'?></span><div class="mini"><?=htmlspecialchars($l['ip_address']?:'—')?> · <?=htmlspecialchars($l['created_at'])?></div></div><?php endforeach;?></div>
    <div><h3 class="section-title">Điểm gần đây</h3><?php foreach($points as $x):?><div class="list-row"><span><?=htmlspecialchars($x['reason_text']?:$x['point_type'])?></span><span class="badge <?=$x['points']<0?'red':'green'?>"><?=$x['points']>0?'+':''?><?=$x['points']?></span></div><?php endforeach;?></div>
    <div><h3 class="section-title">Vinh danh</h3><?php foreach($honors as $h):?><div class="list-row"><span><?=$h['icon']?> <?=htmlspecialchars($h['title'])?></span><span class="mini muted"><?=htmlspecialchars($h['awarded_at'])?></span></div><?php endforeach;?></div>
  </div>
</section>
<?php endif;?>

<form class="filterbar" method="get"><div class="field"><label>Tìm tài khoản</label><input class="input" name="q" value="<?=htmlspecialchars($q)?>" placeholder="Tên, email, trường"></div><button class="btn ghost">Tìm</button></form>
<div class="table-wrap"><table><thead><tr><th>Học viên</th><th>Trường</th><th>Điểm</th><th>Phiên/Giờ</th><th>IP gần nhất</th><th>Mật khẩu</th><th>Trạng thái</th><th>Thao tác</th></tr></thead><tbody>
<?php foreach($rows as $u):?><tr>
<td><b><?=htmlspecialchars($u['name'])?></b><div class="muted mini"><?=htmlspecialchars($u['email'])?></div></td><td><?=htmlspecialchars($u['school'])?></td><td>XH <?=number_format((int)$u['rank_points'])?><br>BFS <?=number_format((int)$u['bfs_score'])?></td><td><?=$u['sessions_count']?> / <?=number_format((float)$u['total_hours'],1)?>h</td><td class="code"><?=htmlspecialchars($u['last_ip']?:'—')?></td><td><span class="badge <?=!empty($u['must_change_password'])?'red':'green'?>"><?=!empty($u['must_change_password'])?'PHẢI ĐỔI':'OK'?></span></td><td><span class="badge <?=$u['status']==='ACTIVE'?'green':'red'?>"><?=$u['status']?></span></td><td><div class="row-actions"><a class="btn ghost" href="?id=<?=$u['id']?>">Chi tiết</a><?php if(bfHasPermission($admin,'users.lock')):?><form method="post" class="row-actions"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?=$u['id']?>"><input type="hidden" name="status" value="<?=$u['status']==='ACTIVE'?'LOCKED':'ACTIVE'?>"><button class="btn <?=$u['status']==='ACTIVE'?'danger':'ghost'?>"><?=$u['status']==='ACTIVE'?'Khóa':'Mở khóa'?></button></form><?php endif;?></div></td></tr><?php endforeach;?>
</tbody></table></div>
<?php include __DIR__.'/includes/layout_bottom.php';?>
