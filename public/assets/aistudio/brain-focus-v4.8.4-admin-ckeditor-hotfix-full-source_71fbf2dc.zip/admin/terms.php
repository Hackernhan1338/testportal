<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/../includes/terms.php';
$admin=adminRequire($pdo,'settings.view');$adminPage='terms';$pageTitle='Điều khoản & đồng ý';$msg='';$err='';
bfEnsureDefaultTerms($pdo);
if($_SERVER['REQUEST_METHOD']==='POST'){
    adminPostCsrf();bfRequirePermission($admin,'settings.update');$action=(string)($_POST['action']??'');
    if($action==='publish'){
        $version=trim((string)($_POST['version']??''));$title=trim((string)($_POST['title']??''));$content=trim((string)($_POST['content_html']??''));$reward=(int)($_POST['reward_xp']??50);
        if($version===''||$title===''||$content==='')$err='Phiên bản, tiêu đề và nội dung không được để trống.';
        else{
            $pdo->beginTransaction();
            try{
                $pdo->exec("UPDATE bf_terms_versions SET status='ARCHIVED' WHERE status='PUBLISHED'");
                $st=$pdo->prepare("INSERT INTO bf_terms_versions(version,title,content_html,reward_xp,status,published_at,created_by_admin_id) VALUES(?,?,?,?, 'PUBLISHED',NOW(),?)");$st->execute([$version,$title,$content,$reward,$admin['id']]);$termsId=(int)$pdo->lastInsertId();
                $note=$pdo->prepare("INSERT INTO bf_notifications(user_email,title,content,type,link_url) SELECT email,?,?, 'TERMS','/terms-accept.php' FROM bf_users WHERE status='ACTIVE'");$note->execute(['Điều khoản Brain Focus đã được cập nhật','Phiên bản '.$version.' đã được công bố. Vui lòng đọc và xác nhận để tiếp tục sử dụng Brain Focus.']);
                $pdo->commit();bfAudit($pdo,$admin,'TERMS_PUBLISH','TERMS#'.$termsId,'Công bố điều khoản '.$version);$msg='Đã công bố điều khoản mới và tạo thông báo cho học viên.';
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$err='Không thể công bố: '.$e->getMessage();}
        }
    }
}
$current=bfCurrentTerms($pdo);$versions=$pdo->query("SELECT * FROM bf_terms_versions ORDER BY id DESC LIMIT 30")->fetchAll();
$total=(int)$pdo->query("SELECT COUNT(*) FROM bf_users WHERE status='ACTIVE'")->fetchColumn();$accepted=0;if($current){$st=$pdo->prepare("SELECT COUNT(DISTINCT a.user_id) FROM bf_terms_acceptances a JOIN bf_users u ON u.id=a.user_id WHERE a.terms_id=? AND u.status='ACTIVE'");$st->execute([$current['id']]);$accepted=(int)$st->fetchColumn();}$rate=$total?round($accepted/$total*100,1):0;
include __DIR__.'/includes/layout_top.php';?>
<div class="page-head"><div><h1>Điều khoản & Chính sách dữ liệu</h1><p>Quản lý phiên bản điều khoản, mức thưởng xác nhận và tỷ lệ học viên đã đồng ý.</p></div></div><?php if($msg):?><div class="notice"><?=$msg?></div><?php endif;?><?php if($err):?><div class="notice" style="border-color:#fecaca;background:#fff1f2;color:#be123c"><?=htmlspecialchars($err)?></div><?php endif;?>
<div class="stats-grid" style="margin-top:14px"><div class="stat-card"><span>Phiên bản hiện tại</span><strong><?=htmlspecialchars($current['version']??'—')?></strong></div><div class="stat-card"><span>Đã đồng ý</span><strong><?=number_format($accepted)?> / <?=number_format($total)?></strong></div><div class="stat-card"><span>Tỷ lệ đồng ý</span><strong><?=$rate?>%</strong></div><div class="stat-card"><span>Thưởng xác nhận</span><strong>+<?=number_format((int)($current['reward_xp']??0))?> XP</strong></div></div>
<section class="card card-pad" style="margin-top:14px"><h2>Công bố phiên bản điều khoản mới</h2><p style="color:#64748b;font-size:13px">Khi công bố, phiên bản hiện tại được lưu trữ và toàn bộ học viên ACTIVE sẽ nhận thông báo yêu cầu xác nhận phiên bản mới.</p><form method="post" class="form-grid"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="publish"><div class="field"><label>Phiên bản</label><input class="input" name="version" placeholder="Ví dụ 1.1" required></div><div class="field"><label>Thưởng XP khi học viên cũ xác nhận</label><input class="input" type="number" name="reward_xp" value="50"></div><div class="field full"><label>Tiêu đề</label><input class="input" name="title" value="Điều khoản sử dụng & Chính sách bảo vệ dữ liệu Brain Focus" required></div><div class="field full"><label>Nội dung HTML</label><textarea id="ckeditor-terms" class="textarea" name="content_html" rows="24" required><?=htmlspecialchars($current['content_html']??bfDefaultTermsHtml())?></textarea></div><div class="field full"><button class="btn primary" onclick="return confirm('Công bố phiên bản mới và yêu cầu toàn bộ học viên xác nhận lại?')">Công bố điều khoản mới</button></div></form></section>
<section class="card card-pad" style="margin-top:14px"><h2>Lịch sử phiên bản</h2><div class="table-wrap"><table><thead><tr><th>Phiên bản</th><th>Trạng thái</th><th>Thưởng XP</th><th>Ngày công bố</th></tr></thead><tbody><?php foreach($versions as $v):?><tr><td><b><?=htmlspecialchars($v['version'])?></b></td><td><?=htmlspecialchars($v['status'])?></td><td><?=number_format((int)$v['reward_xp'])?></td><td><?=htmlspecialchars((string)$v['published_at'])?></td></tr><?php endforeach;?></tbody></table></div></section>
<?php if(defined('BF_CKEDITOR_ENABLED') && BF_CKEDITOR_ENABLED):?><script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script><script src="/assets/js/ckeditor-init.js"></script><script>if(window.BFCKEditor){BFCKEditor.create('#ckeditor-terms',{toolbar:['heading','|','bold','italic','link','bulletedList','numberedList','blockQuote','insertTable','undo','redo']});}</script><?php endif;?><?php include __DIR__.'/includes/layout_bottom.php';?>
