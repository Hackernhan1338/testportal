<?php
require_once __DIR__.'/includes/bootstrap.php';
$admin=adminRequire($pdo,'settings.view');$adminPage='settings';$pageTitle='Cấu hình';$msg='';
$allowed=['site_name','site_tagline','default_focus_duration','max_daily_sessions','max_daily_gym_plays','gym_play_cost','maintenance_mode','maintenance_title','maintenance_message','system_announcement','show_announcement','social_facebook_url','social_youtube_url','social_tiktok_url','site_contact_email','seo_site_name','seo_site_description','seo_keywords','seo_og_image','site_favicon_url','seo_index_title','seo_index_description','seo_knowledge_title','seo_knowledge_description','seo_leaderboard_title','seo_leaderboard_description','seo_gym_title','seo_gym_description'];
if($_SERVER['REQUEST_METHOD']==='POST'){
  adminPostCsrf();bfRequirePermission($admin,'settings.update');$st=$pdo->prepare("INSERT INTO bf_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");foreach($allowed as $k)if(isset($_POST[$k]))$st->execute([$k,(string)$_POST[$k]]);bfAudit($pdo,$admin,'SETTINGS_UPDATE','SYSTEM','Cập nhật cấu hình nâng cao');$msg='Đã lưu cấu hình.';
}
$map=[];foreach($pdo->query("SELECT setting_key,setting_value FROM bf_settings") as $x)$map[$x['setting_key']]=$x['setting_value'];
include __DIR__.'/includes/layout_top.php';
?>
<div class="page-head"><div><h1>Cấu hình hệ thống</h1><p>Thiết lập thông báo bảo trì, giới hạn phiên học và giới hạn gym não.</p></div></div>
<?php if($msg):?><div class="notice"><?=$msg?></div><?php endif;?>
<section class="card card-pad admin-form-card" style="margin-top:14px">
  <form method="post" class="form-grid">
    <input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>">
    <div class="field"><label>Tên hệ thống</label><input class="input" name="site_name" value="<?=htmlspecialchars($map['site_name']??'Brain Focus')?>"></div>
    <div class="field"><label>Khẩu hiệu</label><input class="input" name="site_tagline" value="<?=htmlspecialchars($map['site_tagline']??'')?>"></div>
    <div class="field"><label>Focus mặc định (phút)</label><input class="input" type="number" name="default_focus_duration" value="<?=htmlspecialchars($map['default_focus_duration']??'90')?>"></div>
    <div class="field"><label>Phiên học tối đa / ngày</label><input class="input" type="number" name="max_daily_sessions" value="<?=htmlspecialchars($map['max_daily_sessions']??'3')?>"></div>
    <div class="field"><label>Gym não miễn phí / ngày</label><input class="input" type="number" name="max_daily_gym_plays" value="<?=htmlspecialchars($map['max_daily_gym_plays']??'5')?>"></div>
    <div class="field"><label>Giá mua 1 lượt Gym</label><input class="input" type="number" name="gym_play_cost" value="<?=htmlspecialchars($map['gym_play_cost']??'35')?>"></div>
    <div class="field"><label>Maintenance Mode</label><select class="select" name="maintenance_mode"><option value="false">Tắt</option><option value="true" <?=($map['maintenance_mode']??'')==='true'?'selected':''?>>Bật</option></select></div>
    <div class="field"><label>Tiêu đề bảo trì</label><input class="input" name="maintenance_title" value="<?=htmlspecialchars($map['maintenance_title']??'Hệ thống đang bảo trì')?>"></div>
    <div class="field full"><label>Nội dung bảo trì</label><textarea class="textarea" name="maintenance_message"><?=htmlspecialchars($map['maintenance_message']??'Brain Focus đang được nâng cấp để phục vụ tốt hơn. Vui lòng quay lại sau.')?></textarea></div>
    <div class="field full"><label>Thông báo hệ thống chung</label><textarea class="textarea" name="system_announcement"><?=htmlspecialchars($map['system_announcement']??'')?></textarea></div>
    <div class="field"><label>Hiện thông báo chung</label><select class="select" name="show_announcement"><option value="false">Không</option><option value="true" <?=($map['show_announcement']??'')==='true'?'selected':''?>>Có</option></select></div>
    <div class="field"><label>Email liên hệ</label><input class="input" type="email" name="site_contact_email" value="<?=htmlspecialchars($map['site_contact_email']??'thiennhan1338@gmail.com')?>"></div>
    <div class="field"><label>Facebook URL</label><input class="input" name="social_facebook_url" value="<?=htmlspecialchars($map['social_facebook_url']??'')?>"></div>
    <div class="field"><label>YouTube URL</label><input class="input" name="social_youtube_url" value="<?=htmlspecialchars($map['social_youtube_url']??'')?>"></div>
    <div class="field"><label>TikTok URL</label><input class="input" name="social_tiktok_url" value="<?=htmlspecialchars($map['social_tiktok_url']??'')?>"></div>
    <div class="field"><label>SEO Site Name</label><input class="input" name="seo_site_name" value="<?=htmlspecialchars($map['seo_site_name']??'Brain Focus')?>"></div>
    <div class="field"><label>Favicon URL</label><input class="input" name="site_favicon_url" value="<?=htmlspecialchars($map['site_favicon_url']??'')?>"></div>
    <div class="field full"><label>SEO Description</label><textarea class="textarea" name="seo_site_description"><?=htmlspecialchars($map['seo_site_description']??'Brain Focus hỗ trợ học tập tập trung, Deep Focus, Gym não, BFS, thống kê tiến độ và thi đua học tập.')?></textarea></div>
    <div class="field full"><label>SEO Keywords</label><input class="input" name="seo_keywords" value="<?=htmlspecialchars($map['seo_keywords']??'brain focus,tập trung,học tập,pomodoro,deep focus,gym não,BFS')?>"></div>
    <div class="field full"><label>Open Graph Image URL</label><input class="input" name="seo_og_image" value="<?=htmlspecialchars($map['seo_og_image']??'')?>"></div>
    <div class="field full"><h3 style="margin:8px 0">SEO trang quan trọng</h3></div>
    <div class="field"><label>Title trang chính</label><input class="input" name="seo_index_title" value="<?=htmlspecialchars($map['seo_index_title']??'Brain Focus – Không gian học tập và rèn luyện tập trung')?>"></div>
    <div class="field"><label>Title Gym não</label><input class="input" name="seo_gym_title" value="<?=htmlspecialchars($map['seo_gym_title']??'Gym não – Brain Focus')?>"></div>
    <div class="field full"><label>Description trang chính</label><textarea class="textarea" name="seo_index_description"><?=htmlspecialchars($map['seo_index_description']??'Brain Focus hỗ trợ Deep Focus, Pomodoro, Gym não, BFS, thống kê tiến độ và xây dựng thói quen học tập tập trung.')?></textarea></div>
    <div class="field full"><label>Description Gym não</label><textarea class="textarea" name="seo_gym_description"><?=htmlspecialchars($map['seo_gym_description']??'Rèn luyện phản xạ, ghi nhớ và chú ý với các bài tập Gym não có giới hạn thời gian trên Brain Focus.')?></textarea></div>
    <div class="field"><label>Title kiến thức</label><input class="input" name="seo_knowledge_title" value="<?=htmlspecialchars($map['seo_knowledge_title']??'Kiến thức tập trung – Brain Focus')?>"></div>
    <div class="field"><label>Title bảng xếp hạng</label><input class="input" name="seo_leaderboard_title" value="<?=htmlspecialchars($map['seo_leaderboard_title']??'Bảng xếp hạng học tập – Brain Focus')?>"></div>
    <div class="field full"><label>Description kiến thức</label><textarea class="textarea" name="seo_knowledge_description"><?=htmlspecialchars($map['seo_knowledge_description']??'Thư viện kiến thức, phương pháp học tập trung, quản lý xao nhãng và xây dựng thói quen học hiệu quả.')?></textarea></div>
    <div class="field full"><label>Description bảng xếp hạng</label><textarea class="textarea" name="seo_leaderboard_description"><?=htmlspecialchars($map['seo_leaderboard_description']??'Bảng xếp hạng thi đua học tập Brain Focus theo từng đợt, dựa trên điểm và hoạt động học tập hợp lệ.')?></textarea></div>
    <?php if(bfHasPermission($admin,'settings.update')):?><div class="field full"><button class="btn primary">Lưu cấu hình</button></div><?php endif;?>
  </form>
</section>
<?php include __DIR__.'/includes/layout_bottom.php';?>
