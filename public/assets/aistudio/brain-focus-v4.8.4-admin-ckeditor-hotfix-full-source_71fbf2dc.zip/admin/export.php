<?php
require_once __DIR__.'/includes/bootstrap.php';
$admin=adminRequire($pdo,'exports.view');
$type=(string)($_GET['type']??'students');
function xlsEsc($s){return htmlspecialchars((string)$s,ENT_XML1|ENT_QUOTES,'UTF-8');}
function xlsCell($v,$number=false){$type=$number?'Number':'String';return '<Cell><Data ss:Type="'.$type.'">'.xlsEsc($v).'</Data></Cell>';}
function xlsRow($cells){return '<Row>'.implode('',$cells).'</Row>';}
function xlsDownload($filename,$headers,$rows){
    header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Cache-Control: no-store');
    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '<?mso-application progid="Excel.Sheet"?>';
    echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Brain Focus"><Table>';
    $hc=[];foreach($headers as $h)$hc[]=xlsCell($h);echo xlsRow($hc);
    foreach($rows as $row){$c=[];foreach($row as $v){$isNum=is_int($v)||is_float($v);$c[]=xlsCell($v,$isNum);}echo xlsRow($c);}echo '</Table></Worksheet></Workbook>';exit;
}
if($type==='students'){
    $rows=[];$st=$pdo->query("SELECT id,name,email,school,status,rank_points,bfs_score,bfs_assessment_score,sessions_count,total_hours,gym_count,streak_days,last_login_at,created_at FROM bf_users ORDER BY id");
    foreach($st->fetchAll() as $u)$rows[]=[(int)$u['id'],$u['name'],$u['email'],$u['school'],$u['status'],(int)$u['rank_points'],(int)$u['bfs_score'],(int)$u['bfs_assessment_score'],(int)$u['sessions_count'],(float)$u['total_hours'],(int)$u['gym_count'],(int)$u['streak_days'],$u['last_login_at'],$u['created_at']];
    bfAudit($pdo,$admin,'EXPORT_EXCEL','STUDENTS','Xuất danh sách học viên');
    xlsDownload('brain-focus-hoc-vien-'.date('Ymd-His').'.xls',['ID','Họ tên','Email','Đơn vị','Trạng thái','Điểm XH','BFS tổng','BFS khảo sát','Số phiên','Tổng giờ','Gym','Streak','Đăng nhập gần nhất','Ngày tạo'],$rows);
}
if($type==='leaderboard'){
    $rows=[];$lb=bfLeaderboardRows($pdo,'',100000,0);$round=bfLatestLeaderboardRound($pdo);foreach($lb as $i=>$u)$rows[]=[!empty($u['final_rank'])?(int)$u['final_rank']:$i+1,$u['name'],$u['email'],$u['school'],(int)$u['round_points'],(int)$u['account_total'],(int)$u['rank_points'],(int)$u['bfs_score'],(int)$u['session_points']];
    bfAudit($pdo,$admin,'EXPORT_EXCEL','LEADERBOARD','Xuất BXH '.($round['title']??''));
    xlsDownload('brain-focus-bxh-'.date('Ymd-His').'.xls',['Hạng','Họ tên','Email','Đơn vị','Điểm đợt','Tổng tài khoản','XH','BFS','Điểm phiên'],$rows);
}
if($type==='surveys'){
    $questions=$pdo->query("SELECT id,question_text FROM bf_survey_questions ORDER BY sort_order,id")->fetchAll();$headers=['Submission','Học viên','Email','BFS','Thời gian'];foreach($questions as $q)$headers[]='Q'.$q['id'].' - '.$q['question_text'];
    $subs=$pdo->query("SELECT s.*,u.name FROM bf_survey_submissions s LEFT JOIN bf_users u ON u.id=s.user_id ORDER BY s.id")->fetchAll();$rows=[];$rs=$pdo->prepare("SELECT question_id,answer_value FROM bf_survey_responses WHERE submission_id=?");
    foreach($subs as $s){$rs->execute([$s['id']]);$map=[];foreach($rs->fetchAll() as $a)$map[(int)$a['question_id']]=$a['answer_value'];$row=[(int)$s['id'],$s['name']?:'',$s['user_email'],(int)$s['bfs_score'],$s['created_at']];foreach($questions as $q)$row[]=$map[(int)$q['id']]??'';$rows[]=$row;}
    bfAudit($pdo,$admin,'EXPORT_EXCEL','SURVEYS','Xuất dữ liệu khảo sát');
    xlsDownload('brain-focus-khao-sat-'.date('Ymd-His').'.xls',$headers,$rows);
}
http_response_code(400);echo 'Loại dữ liệu xuất không hợp lệ.';
