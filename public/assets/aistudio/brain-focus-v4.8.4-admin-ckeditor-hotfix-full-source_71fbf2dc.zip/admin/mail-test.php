<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/../api/mail.php';
$admin=adminRequire($pdo,'settings.view');$adminPage='mail-test';$pageTitle='Kiểm tra Email SMTP';$msg='';$err='';
$recipient=(string)($admin['email']??'');
if($_SERVER['REQUEST_METHOD']==='POST'){
    adminPostCsrf();bfRequirePermission($admin,'settings.update');
    $recipient=strtolower(trim((string)($_POST['recipient']??'')));
    if(!filter_var($recipient,FILTER_VALIDATE_EMAIL)) $err='Email nhận thử không hợp lệ.';
    else{
        $html='<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto"><h2>🧠 Brain Focus SMTP Test</h2><p>Nếu bạn nhận được email này, Gmail SMTP của Brain Focus đã hoạt động.</p><p><b>Thời gian:</b> '.htmlspecialchars(date('d/m/Y H:i:s')).'</p></div>';
        $r=bfSendSmtpMail($recipient,'[Brain Focus] Kiểm tra kết nối Gmail SMTP',$html,'Brain Focus SMTP Test - Kết nối Gmail SMTP hoạt động.');
        if($r['success']){$msg='Gửi email thử thành công tới '.$recipient.'. Hãy kiểm tra Inbox và Spam.';bfAudit($pdo,$admin,'SMTP_TEST','SYSTEM','Gửi SMTP test tới '.$recipient);}else{$err=$r['message'];bfAudit($pdo,$admin,'SMTP_TEST_FAILED','SYSTEM',$r['message']);}
    }
}
include __DIR__.'/includes/layout_top.php';
?>
<div class="page-head"><div><h1>Kiểm tra Gmail SMTP</h1><p>Kiểm tra cấu hình gửi OTP trước khi mở chức năng Quên mật khẩu cho học viên.</p></div></div>
<?php if($msg):?><div class="notice"><?=htmlspecialchars($msg)?></div><?php endif;?>
<?php if($err):?><div class="notice" style="border-color:#fecaca;background:#fff1f2;color:#be123c"><?=htmlspecialchars($err)?></div><?php endif;?>
<section class="card card-pad" style="margin-top:14px">
  <div class="stats-grid" style="margin-bottom:16px">
    <div class="stat-card"><span>SMTP Host</span><strong><?=htmlspecialchars(BF_SMTP_HOST)?>:<?=intval(BF_SMTP_PORT)?></strong></div>
    <div class="stat-card"><span>Tài khoản gửi</span><strong style="font-size:14px"><?=htmlspecialchars(BF_SMTP_USERNAME)?></strong></div>
    <div class="stat-card"><span>STARTTLS</span><strong><?=strtolower(BF_SMTP_ENCRYPTION)==='tls'?'BẬT':'TẮT'?></strong></div>
    <div class="stat-card"><span>App Password</span><strong><?=bfSmtpConfigured()?'ĐÃ CẤU HÌNH':'CHƯA CẤU HÌNH'?></strong></div>
  </div>
  <div class="notice" style="margin-bottom:16px">App Password không được hiển thị tại đây. Hãy dán mã 16 ký tự vào <code>BF_SMTP_APP_PASSWORD</code> trong <code>api/db.php</code>.</div>
  <?php if(bfHasPermission($admin,'settings.update')):?><form method="post" class="form-grid"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><div class="field full"><label>Email nhận thư thử</label><input class="input" type="email" name="recipient" value="<?=htmlspecialchars($recipient)?>" required></div><div class="field full"><button class="btn primary">Gửi email thử qua Gmail SMTP</button></div></form><?php endif;?>
</section>
<?php include __DIR__.'/includes/layout_bottom.php';?>
