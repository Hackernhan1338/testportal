<?php
require_once __DIR__.'/includes/bootstrap.php';$admin=adminRequire($pdo,'visits.view');$adminPage='visits';$pageTitle='Web visits';
$stats=['today'=>0,'week'=>0,'month'=>0,'unique_today'=>0];$daily=[];$pages=[];
try{
 $stats['today']=(int)$pdo->query("SELECT COUNT(*) FROM bf_page_visits WHERE created_at>=CURDATE()")->fetchColumn();
 $stats['week']=(int)$pdo->query("SELECT COUNT(*) FROM bf_page_visits WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)")->fetchColumn();
 $stats['month']=(int)$pdo->query("SELECT COUNT(*) FROM bf_page_visits WHERE created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)")->fetchColumn();
 $stats['unique_today']=(int)$pdo->query("SELECT COUNT(DISTINCT COALESCE(NULLIF(user_email,''),ip_address)) FROM bf_page_visits WHERE created_at>=CURDATE()")->fetchColumn();
 $daily=$pdo->query("SELECT DATE(created_at) d,COUNT(*) c,COUNT(DISTINCT COALESCE(NULLIF(user_email,''),ip_address)) u FROM bf_page_visits WHERE created_at>=DATE_SUB(CURDATE(),INTERVAL 13 DAY) GROUP BY DATE(created_at) ORDER BY d")->fetchAll();
 $pages=$pdo->query("SELECT request_path,COUNT(*) c FROM bf_page_visits WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY request_path ORDER BY c DESC LIMIT 15")->fetchAll();
}catch(Throwable $e){}
$max=1;foreach($daily as $d)$max=max($max,(int)$d['c']);include __DIR__.'/includes/layout_top.php';?>
<div class="page-head"><div><h1>Web visits</h1><p>Lưu lượng truy cập thực tế được ghi nhận từ các trang người dùng.</p></div></div>
<div class="grid grid-4"><div class="card card-pad stat"><span>Hôm nay</span><strong><?=number_format($stats['today'])?></strong></div><div class="card card-pad stat"><span>Khách duy nhất hôm nay</span><strong><?=number_format($stats['unique_today'])?></strong></div><div class="card card-pad stat"><span>7 ngày</span><strong><?=number_format($stats['week'])?></strong></div><div class="card card-pad stat"><span>30 ngày</span><strong><?=number_format($stats['month'])?></strong></div></div>
<div class="grid grid-2" style="margin-top:14px"><section class="card card-pad"><h2 class="section-title">14 ngày gần đây</h2><div style="display:flex;align-items:end;gap:8px;height:190px;margin-top:16px;border-bottom:1px solid #e2e8f0"><?php foreach($daily as $d):$h=max(5,round($d['c']/$max*150));?><div style="flex:1;text-align:center;min-width:18px"><div title="<?=$d['c']?> lượt" style="height:<?=$h?>px;background:#2563eb;border-radius:7px 7px 0 0"></div><div class="mini muted" style="font-size:9px;margin-top:4px"><?=date('d/m',strtotime($d['d']))?></div></div><?php endforeach;?></div></section><section class="card card-pad"><h2 class="section-title">Trang được xem nhiều · 7 ngày</h2><?php foreach($pages as $p):?><div class="list-row"><span class="code" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:75%"><?=htmlspecialchars($p['request_path'])?></span><b><?=number_format((int)$p['c'])?></b></div><?php endforeach;?></section></div>
<?php include __DIR__.'/includes/layout_bottom.php';?>
