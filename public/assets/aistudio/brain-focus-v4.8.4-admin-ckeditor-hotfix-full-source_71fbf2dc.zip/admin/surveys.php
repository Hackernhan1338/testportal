<?php
require_once __DIR__.'/includes/bootstrap.php';
$admin=adminRequire($pdo,'surveys.view');$adminPage='surveys';$pageTitle='Khảo sát học viên';$msg='';$err='';

function adminSurveySetting(PDO $pdo,$key,$default='0'){
    try{$st=$pdo->prepare("SELECT setting_value FROM bf_settings WHERE setting_key=? LIMIT 1");$st->execute([$key]);$v=$st->fetchColumn();return ($v===false||$v===null)?$default:$v;}catch(Throwable $e){return $default;}
}
function adminSaveSurveySetting(PDO $pdo,$key,$value){$st=$pdo->prepare("INSERT INTO bf_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=NOW()");$st->execute([$key,(string)$value]);}
function adminSigned($n){$n=(int)$n;return ($n>0?'+':'').number_format($n);}

if($_SERVER['REQUEST_METHOD']==='POST'){
    adminPostCsrf();bfRequirePermission($admin,'surveys.manage');$action=$_POST['action']??'';
    if($action==='save'){
        $id=(int)($_POST['id']??0);$text=trim($_POST['question_text']??'');$help=trim($_POST['help_text']??'');$status=($_POST['status']??'ACTIVE')==='DISABLED'?'DISABLED':'ACTIVE';$scored=!empty($_POST['is_bfs_scored'])?1:0;$sort=(int)($_POST['sort_order']??0);$labels=[];
        for($i=0;$i<5;$i++){ $label=trim($_POST['opt_'.$i]??''); if($label==='')continue; $labels[]=['label'=>$label,'score'=>(float)($_POST['score_'.$i]??$i)]; }
        if($text===''||count($labels)<2)$err='Cần nội dung câu hỏi và ít nhất 2 phương án.';
        else{$json=json_encode($labels,JSON_UNESCAPED_UNICODE);if($id)$pdo->prepare("UPDATE bf_survey_questions SET question_text=?,help_text=?,options_json=?,is_bfs_scored=?,status=?,sort_order=? WHERE id=?")->execute([$text,$help,$json,$scored,$status,$sort,$id]);else{$pdo->prepare("INSERT INTO bf_survey_questions(question_text,help_text,question_type,options_json,is_bfs_scored,status,sort_order,created_by_admin_id) VALUES(?,?,'SCALE',?,?,?,?,?)")->execute([$text,$help,$json,$scored,$status,$sort,$admin['id']]);}$msg='Đã lưu câu hỏi.';}
    } elseif($action==='status'){
        $pdo->prepare("UPDATE bf_survey_questions SET status=? WHERE id=?")->execute([($_POST['status']??'ACTIVE')==='ACTIVE'?'ACTIVE':'DISABLED',(int)$_POST['id']]);$msg='Đã cập nhật trạng thái.';
    } elseif($action==='save_bfs_policy'){
        $keys=[
            'bfs_first_retake_adjustment_bfs'=>max(-10000,min(10000,(int)($_POST['bfs_first_retake_adjustment_bfs']??500))),
            'bfs_repeat_retake_adjustment_bfs'=>max(-10000,min(10000,(int)($_POST['bfs_repeat_retake_adjustment_bfs']??0))),
            'bfs_attention_retry_adjustment_1_bfs'=>max(-10000,min(10000,(int)($_POST['bfs_attention_retry_adjustment_1_bfs']??250))),
            'bfs_attention_retry_adjustment_2_bfs'=>max(-10000,min(10000,(int)($_POST['bfs_attention_retry_adjustment_2_bfs']??100))),
            'bfs_global_retake_default_adjustment_bfs'=>max(-10000,min(10000,(int)($_POST['bfs_global_retake_default_adjustment_bfs']??500))),
            'bfs_attention_check_count'=>max(1,min(3,(int)($_POST['bfs_attention_check_count']??2)))
        ];
        foreach($keys as $k=>$v)adminSaveSurveySetting($pdo,$k,$v);
        bfAudit($pdo,$admin,'BFS_POLICY_UPDATE','SURVEY','Cập nhật chính sách cộng/trừ BFS khi làm lại');$msg='Đã lưu chính sách điểm BFS và câu kiểm tra chú ý.';
    } elseif($action==='force_all_retake'){
        $title=trim((string)($_POST['campaign_title']??'Khảo sát BFS bắt buộc'));
        $reward=max(-10000,min(10000,(int)($_POST['campaign_reward_bfs']??adminSurveySetting($pdo,'bfs_global_retake_default_adjustment_bfs','500'))));
        if($title==='')$title='Khảo sát BFS bắt buộc';
        $pdo->beginTransaction();
        try{
            $pdo->exec("UPDATE bf_bfs_retake_campaigns SET status='CLOSED',closed_at=NOW() WHERE status='ACTIVE'");
            $st=$pdo->prepare("INSERT INTO bf_bfs_retake_campaigns(title,reward_bfs,status,created_by_admin_id) VALUES(?,?,'ACTIVE',?)");$st->execute([$title,$reward,$admin['id']]);$cid=(int)$pdo->lastInsertId();
            $pdo->prepare("INSERT INTO bf_bfs_retake_campaign_targets(campaign_id,user_id,user_email,status,penalty_level) SELECT ?,id,email,'PENDING',0 FROM bf_users WHERE status='ACTIVE' AND role='STUDENT'")->execute([$cid]);
            $targets=(int)$pdo->query("SELECT COUNT(*) FROM bf_bfs_retake_campaign_targets WHERE campaign_id=".$cid)->fetchColumn();
            try{$n=$pdo->prepare("INSERT INTO bf_notifications(user_email,title,content,type) SELECT email,?,?, 'survey' FROM bf_users WHERE status='ACTIVE' AND role='STUDENT'");$n->execute(['Yêu cầu làm lại khảo sát BFS',$title.' · Hoàn thành hợp lệ sẽ được điều chỉnh '.adminSigned($reward).' BFS.']);}catch(Throwable $ignore){}
            adminSaveSurveySetting($pdo,'bfs_global_retake_default_adjustment_bfs',$reward);
            $pdo->commit();bfAudit($pdo,$admin,'BFS_FORCE_RETAKE_ALL','SURVEY_CAMPAIGN','#'.$cid.' · '.$targets.' học viên · '.adminSigned($reward).' BFS');$msg='Đã tạo đợt khảo sát bắt buộc cho '.number_format($targets).' học viên. Mức điều chỉnh: '.adminSigned($reward).' BFS.';
        }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$err='Không thể tạo đợt khảo sát bắt buộc. Hãy chạy migration v4.5.3 trước.';error_log('[BrainFocus Admin BFS campaign] '.$e->getMessage());}
    } elseif($action==='close_campaign'){
        $cid=(int)($_POST['campaign_id']??0);try{$pdo->prepare("UPDATE bf_bfs_retake_campaigns SET status='CLOSED',closed_at=NOW() WHERE id=?")->execute([$cid]);bfAudit($pdo,$admin,'BFS_CAMPAIGN_CLOSE','SURVEY_CAMPAIGN','#'.$cid);$msg='Đã kết thúc yêu cầu khảo sát bắt buộc.';}catch(Throwable $e){$err='Không thể kết thúc đợt khảo sát.';}
    }
}

$edit=null;if(!empty($_GET['edit'])){$st=$pdo->prepare("SELECT * FROM bf_survey_questions WHERE id=?");$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();}
$questions=$pdo->query("SELECT q.*,COUNT(r.id) response_count FROM bf_survey_questions q LEFT JOIN bf_survey_responses r ON r.question_id=q.id GROUP BY q.id ORDER BY q.sort_order,q.id")->fetchAll();$subs=(int)$pdo->query("SELECT COUNT(*) FROM bf_survey_submissions")->fetchColumn();
$charts=[];foreach($questions as $q){$st=$pdo->prepare("SELECT answer_value,COUNT(*) c FROM bf_survey_responses WHERE question_id=? GROUP BY answer_value ORDER BY c DESC");$st->execute([$q['id']]);$charts[$q['id']]=$st->fetchAll();}
$policy=[
 'first'=>(int)adminSurveySetting($pdo,'bfs_first_retake_adjustment_bfs','500'),
 'repeat'=>(int)adminSurveySetting($pdo,'bfs_repeat_retake_adjustment_bfs','0'),
 'retry1'=>(int)adminSurveySetting($pdo,'bfs_attention_retry_adjustment_1_bfs','250'),
 'retry2'=>(int)adminSurveySetting($pdo,'bfs_attention_retry_adjustment_2_bfs','100'),
 'global'=>(int)adminSurveySetting($pdo,'bfs_global_retake_default_adjustment_bfs','500'),
 'traps'=>(int)adminSurveySetting($pdo,'bfs_attention_check_count','2')
];
$activeCampaign=null;$campaignHistory=[];
try{
 $st=$pdo->query("SELECT c.*,COUNT(t.id) total_targets,SUM(t.status='COMPLETED') completed_targets,SUM(t.status='PENDING') pending_targets FROM bf_bfs_retake_campaigns c LEFT JOIN bf_bfs_retake_campaign_targets t ON t.campaign_id=c.id GROUP BY c.id ORDER BY c.id DESC LIMIT 10");$campaignHistory=$st->fetchAll();foreach($campaignHistory as $c)if($c['status']==='ACTIVE'&&!$activeCampaign)$activeCampaign=$c;
}catch(Throwable $e){}
include __DIR__.'/includes/layout_top.php';$eo=$edit?json_decode($edit['options_json'],true):[];
?>
<div class="page-head"><div><h1>Khảo sát học viên</h1><p>Quản lý câu hỏi, chính sách BFS, yêu cầu khảo sát lại và biểu đồ câu trả lời.</p></div><div class="row-actions"><span class="badge green"><?=number_format($subs)?> lượt nộp</span><a class="btn ghost" href="/admin/export.php?type=surveys">Xuất Excel khảo sát</a></div></div>
<?php if($msg):?><div class="notice"><?=$msg?></div><?php endif;?><?php if($err):?><div class="notice error"><?=$err?></div><?php endif;?>

<?php if(bfHasPermission($admin,'surveys.manage')):?>
<div class="grid grid-2" style="margin-top:14px">
  <section class="card card-pad">
    <span class="kicker">CHÍNH SÁCH BFS</span><h2 class="section-title" style="margin-top:6px">Điểm cộng / trừ khi làm lại</h2><p class="muted mini">Nhập số dương để cộng BFS, số âm để trừ BFS. BFS tổng không bao giờ bị giảm dưới 0.</p>
    <form method="post" class="form-grid" style="margin-top:12px"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="save_bfs_policy">
      <div class="field"><label>Lần làm lại đầu tiên</label><input class="input" type="number" min="-10000" max="10000" name="bfs_first_retake_adjustment_bfs" value="<?=$policy['first']?>"><small class="muted">Mặc định đề xuất: +500 BFS</small></div>
      <div class="field"><label>Các lần làm lại tiếp theo</label><input class="input" type="number" min="-10000" max="10000" name="bfs_repeat_retake_adjustment_bfs" value="<?=$policy['repeat']?>"></div>
      <div class="field"><label>Sau 1 lần sai câu kiểm tra chú ý</label><input class="input" type="number" min="-10000" max="10000" name="bfs_attention_retry_adjustment_1_bfs" value="<?=$policy['retry1']?>"></div>
      <div class="field"><label>Sau từ 2 lần sai câu kiểm tra chú ý</label><input class="input" type="number" min="-10000" max="10000" name="bfs_attention_retry_adjustment_2_bfs" value="<?=$policy['retry2']?>"></div>
      <div class="field"><label>Mức mặc định cho đợt bắt buộc</label><input class="input" type="number" min="-10000" max="10000" name="bfs_global_retake_default_adjustment_bfs" value="<?=$policy['global']?>"></div>
      <div class="field"><label>Số câu kiểm tra chú ý / bài</label><input class="input" type="number" min="1" max="3" name="bfs_attention_check_count" value="<?=$policy['traps']?>"></div>
      <div class="field full"><button class="btn primary">Lưu chính sách BFS</button></div>
    </form>
  </section>
  <section class="card card-pad">
    <span class="kicker">KHẢO SÁT BẮT BUỘC</span><h2 class="section-title" style="margin-top:6px">Yêu cầu tất cả học viên làm lại</h2><p class="muted mini">Khi kích hoạt, hệ thống chụp danh sách học viên ACTIVE hiện tại. Những học viên chưa hoàn thành sẽ được đưa tới trang khảo sát trước khi dùng chức năng khác.</p>
    <?php if($activeCampaign):?>
      <div class="notice" style="margin-top:12px"><b>Đang hoạt động: <?=htmlspecialchars($activeCampaign['title'])?></b><br><span class="mini">Mức: <?=adminSigned((int)$activeCampaign['reward_bfs'])?> BFS · Đã xong <?=number_format((int)$activeCampaign['completed_targets'])?> / <?=number_format((int)$activeCampaign['total_targets'])?> · Còn <?=number_format((int)$activeCampaign['pending_targets'])?></span></div>
      <form method="post" style="margin-top:10px" onsubmit="return confirm('Kết thúc đợt khảo sát bắt buộc hiện tại? Học viên còn thiếu sẽ không còn bị ép làm lại.')"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="close_campaign"><input type="hidden" name="campaign_id" value="<?=$activeCampaign['id']?>"><button class="btn danger">Kết thúc đợt hiện tại</button></form>
    <?php endif;?>
    <form method="post" class="form-grid" style="margin-top:12px" onsubmit="return confirm('Xác nhận tạo đợt khảo sát mới cho TẤT CẢ học viên ACTIVE? Đợt đang hoạt động (nếu có) sẽ được đóng.')"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="force_all_retake">
      <div class="field full"><label>Tên đợt</label><input class="input" name="campaign_title" value="Khảo sát BFS bắt buộc <?=date('d/m/Y')?>" required></div>
      <div class="field full"><label>BFS cộng / trừ khi hoàn thành hợp lệ</label><input class="input" type="number" min="-10000" max="10000" name="campaign_reward_bfs" value="<?=$policy['global']?>"><small class="muted">Ví dụ 500 = +500 BFS; -200 = trừ 200 BFS.</small></div>
      <div class="field full"><button class="btn primary">Yêu cầu tất cả học viên làm khảo sát lại</button></div>
    </form>
  </section>
</div>
<?php endif;?>

<?php if($campaignHistory):?><section class="card card-pad" style="margin-top:14px"><h2 class="section-title">Lịch sử đợt khảo sát bắt buộc</h2><div class="table-wrap" style="margin-top:10px"><table><thead><tr><th>Đợt</th><th>Trạng thái</th><th>Điều chỉnh</th><th>Đã xong</th><th>Còn thiếu</th><th>Tạo lúc</th></tr></thead><tbody><?php foreach($campaignHistory as $c):?><tr><td>#<?=$c['id']?> · <?=htmlspecialchars($c['title'])?></td><td><span class="badge <?=$c['status']==='ACTIVE'?'green':'red'?>"><?=$c['status']?></span></td><td><?=adminSigned((int)$c['reward_bfs'])?> BFS</td><td><?=number_format((int)$c['completed_targets'])?> / <?=number_format((int)$c['total_targets'])?></td><td><?=number_format((int)$c['pending_targets'])?></td><td><?=htmlspecialchars($c['created_at'])?></td></tr><?php endforeach;?></tbody></table></div></section><?php endif;?>

<?php if(bfHasPermission($admin,'surveys.manage')):?><section class="card card-pad" style="margin:14px 0"><h2 class="section-title"><?=$edit?'Sửa câu hỏi':'Thêm câu hỏi mới'?></h2><form method="post" class="form-grid"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=$edit['id']??0?>"><div class="field full"><label>Câu hỏi</label><input class="input" name="question_text" value="<?=htmlspecialchars($edit['question_text']??'')?>" required></div><div class="field full"><label>Gợi ý / giải thích</label><input class="input" name="help_text" value="<?=htmlspecialchars($edit['help_text']??'')?>"></div><?php for($i=0;$i<5;$i++):?><div class="field"><label>Phương án <?=$i+1?></label><input class="input" name="opt_<?=$i?>" value="<?=htmlspecialchars($eo[$i]['label']??'')?>" placeholder="Nội dung phương án"></div><div class="field"><label>Điểm phương án <?=$i+1?></label><input class="input" type="number" step="0.01" name="score_<?=$i?>" value="<?=htmlspecialchars(isset($eo[$i]['score'])?$eo[$i]['score']:$i)?>"></div><?php endfor;?><div class="field"><label>Thứ tự</label><input class="input" type="number" name="sort_order" value="<?=htmlspecialchars($edit['sort_order']??0)?>"></div><div class="field"><label>Trạng thái</label><select class="select" name="status"><option>ACTIVE</option><option <?=$edit&&$edit['status']==='DISABLED'?'selected':''?>>DISABLED</option></select></div><div class="field"><label><input type="checkbox" name="is_bfs_scored" value="1" <?=!$edit||!empty($edit['is_bfs_scored'])?'checked':''?>> Tính vào BFS thật</label></div><div class="field full"><button class="btn primary">Lưu câu hỏi</button></div></form></section><?php endif;?>

<div class="grid grid-2"><?php foreach($questions as $q):$bars=$charts[$q['id']]??[];$max=1;foreach($bars as $b)$max=max($max,(int)$b['c']);?><section class="card card-pad"><div style="display:flex;justify-content:space-between;gap:10px"><div><span class="badge <?=$q['status']==='ACTIVE'?'green':'red'?>"><?=$q['status']?></span><h3 class="section-title" style="margin-top:8px"><?=htmlspecialchars($q['question_text'])?></h3><p class="muted mini"><?=number_format((int)$q['response_count'])?> câu trả lời</p></div><a class="btn ghost" href="?edit=<?=$q['id']?>">Sửa</a></div><div style="margin-top:12px"><?php if(!$bars):?><p class="muted mini">Chưa có dữ liệu.</p><?php endif;?><?php foreach($bars as $b):$w=round($b['c']/$max*100);?><div style="margin:8px 0"><div class="metric-line"><span><?=htmlspecialchars($b['answer_value'])?></span><b><?=$b['c']?></b></div><div style="height:7px;background:#e2e8f0;border-radius:9px;overflow:hidden"><div style="height:100%;width:<?=$w?>%;background:#2563eb"></div></div></div><?php endforeach;?></div></section><?php endforeach;?></div>
<?php include __DIR__.'/includes/layout_bottom.php';?>
