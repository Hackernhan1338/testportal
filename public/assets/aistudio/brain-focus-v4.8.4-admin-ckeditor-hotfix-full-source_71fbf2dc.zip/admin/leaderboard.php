<?php
require_once __DIR__.'/includes/bootstrap.php';
$admin=adminRequire($pdo,'leaderboard.manage');$adminPage='leaderboard';$pageTitle='Điều hành bảng xếp hạng';$msg='';$err='';
function adminLbRound(PDO $pdo){try{return $pdo->query("SELECT * FROM bf_leaderboard_rounds WHERE status='ACTIVE' ORDER BY id DESC LIMIT 1")->fetch()?:null;}catch(Throwable $e){return null;}}
function adminLbAccountRows(PDO $pdo){return bfLeaderboardAccountRows($pdo,'',100000,0);}
if($_SERVER['REQUEST_METHOD']==='POST'){
    adminPostCsrf();$action=(string)($_POST['action']??'');
    if($action==='stop'){
        $round=adminLbRound($pdo);
        if(!$round)$err='Không có đợt bảng xếp hạng đang chạy.';
        else{
            $rows=adminLbAccountRows($pdo);$rid=(int)$round['id'];$base=[];$st=$pdo->prepare("SELECT user_id,baseline_score FROM bf_leaderboard_round_members WHERE round_id=?");$st->execute([$rid]);foreach($st->fetchAll() as $r)$base[(int)$r['user_id']]=(int)$r['baseline_score'];
            foreach($rows as &$r){$r['_baseline']=$base[(int)$r['id']]??(int)$r['account_total'];$r['_round_points']=(int)$r['account_total']-(int)$r['_baseline'];}unset($r);
            usort($rows,function($a,$b){if((int)$a['_round_points']===(int)$b['_round_points'])return (int)$b['account_total']<=>(int)$a['account_total'];return (int)$b['_round_points']<=>(int)$a['_round_points'];});
            $pdo->beginTransaction();try{
                $up=$pdo->prepare("INSERT INTO bf_leaderboard_round_members(round_id,user_id,baseline_score,final_score,final_round_points,final_rank) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE final_score=VALUES(final_score),final_round_points=VALUES(final_round_points),final_rank=VALUES(final_rank)");
                foreach($rows as $i=>$r)$up->execute([$rid,$r['id'],$r['_baseline'],$r['account_total'],$r['_round_points'],$i+1]);
                $pdo->prepare("UPDATE bf_leaderboard_rounds SET status='CLOSED',ended_at=NOW() WHERE id=?")->execute([$rid]);
                $pdo->commit();bfAudit($pdo,$admin,'LEADERBOARD_STOP','ROUND:'.$rid,'Chốt BXH '.$round['title']);$msg='Đã dừng và chốt cứng '.$round['title'].'. Điểm phát sinh sau thời điểm này sẽ được tính cho đợt kế tiếp.';
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$err='Không thể chốt bảng xếp hạng.';}
        }
    }elseif($action==='start'){
        if(adminLbRound($pdo))$err='Đang có một đợt bảng xếp hạng hoạt động.';
        else{
            $last=$pdo->query("SELECT * FROM bf_leaderboard_rounds ORDER BY id DESC LIMIT 1")->fetch();$nextNo=$last?((int)$last['id']+1):1;$title=trim((string)($_POST['title']??('Đợt '.$nextNo)));if($title==='')$title='Đợt '.$nextNo;
            $rows=adminLbAccountRows($pdo);$prevFinal=[];if($last){$st=$pdo->prepare("SELECT user_id,final_score FROM bf_leaderboard_round_members WHERE round_id=?");$st->execute([(int)$last['id']]);foreach($st->fetchAll() as $r)if($r['final_score']!==null)$prevFinal[(int)$r['user_id']]=(int)$r['final_score'];}
            $pdo->beginTransaction();try{
                $pdo->prepare("INSERT INTO bf_leaderboard_rounds(title,status,created_by_admin_id,started_at) VALUES(?,'ACTIVE',?,NOW())")->execute([$title,$admin['id']]);$rid=(int)$pdo->lastInsertId();
                $ins=$pdo->prepare("INSERT INTO bf_leaderboard_round_members(round_id,user_id,baseline_score) VALUES(?,?,?)");foreach($rows as $r){$baseline=array_key_exists((int)$r['id'],$prevFinal)?$prevFinal[(int)$r['id']]:(int)$r['account_total'];$ins->execute([$rid,$r['id'],$baseline]);}
                $pdo->commit();bfAudit($pdo,$admin,'LEADERBOARD_START','ROUND:'.$rid,'Mở BXH '.$title);$msg='Đã mở '.$title.'. Với học viên có mặt ở đợt trước, mọi điểm phát sinh sau lúc chốt đợt trước được tính vào đợt này.';
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$err='Không thể mở đợt bảng xếp hạng mới.';}
        }
    }
}
$active=adminLbRound($pdo);$history=[];try{$history=$pdo->query("SELECT r.*,COUNT(m.id) member_count FROM bf_leaderboard_rounds r LEFT JOIN bf_leaderboard_round_members m ON m.round_id=r.id GROUP BY r.id ORDER BY r.id DESC LIMIT 20")->fetchAll();}catch(Throwable $e){}
$top=bfLeaderboardRows($pdo,'',10,0);
include __DIR__.'/includes/layout_top.php';
?>
<div class="page-head"><div><h1>Điều hành bảng xếp hạng</h1><p>Dừng để chốt thứ hạng hiện tại; tiếp tục bằng một đợt mới để điểm phát sinh sau mốc chốt được tính riêng.</p></div><a class="btn ghost" href="/admin/export.php?type=leaderboard">Xuất Excel BXH</a></div>
<?php if($msg):?><div class="notice"><?=htmlspecialchars($msg)?></div><?php endif;?><?php if($err):?><div class="notice error"><?=htmlspecialchars($err)?></div><?php endif;?>
<div class="grid grid-2" style="margin-top:14px">
<section class="card card-pad"><span class="kicker">TRẠNG THÁI HIỆN TẠI</span><?php if($active):?><h2 class="section-title" style="margin-top:8px"><?=htmlspecialchars($active['title'])?> · ĐANG CHẠY</h2><p class="muted mini">Bắt đầu: <?=htmlspecialchars($active['started_at'])?></p><form method="post" style="margin-top:12px" onsubmit="return confirm('Dừng và chốt bảng xếp hạng hiện tại?')"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="stop"><button class="btn danger">⏸ Dừng & chốt BXH</button></form><?php else:?><h2 class="section-title" style="margin-top:8px">BXH ĐANG TẠM DỪNG</h2><p class="muted mini">Điểm học viên vẫn tiếp tục được ghi nhận. Khi mở đợt mới, phần tăng thêm của học viên từ mốc chốt trước sẽ được đưa vào đợt mới.</p><form method="post" class="form-grid" style="margin-top:12px"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfEnsureCsrfToken())?>"><input type="hidden" name="action" value="start"><div class="field full"><label>Tên đợt mới</label><input class="input" name="title" value="Đợt <?=count($history)+1?>"></div><div class="field full"><button class="btn primary">▶ Tiếp tục / Mở đợt mới</button></div></form><?php endif;?></section>
<section class="card card-pad"><span class="kicker">TOP 10 ĐỢT HIỂN THỊ</span><?php foreach($top as $i=>$r):?><div class="list-row"><span><b>#<?=!empty($r['final_rank'])?$r['final_rank']:$i+1?></b> <?=htmlspecialchars($r['name'])?></span><span class="badge green"><?=number_format((int)$r['total_score'])?>đ</span></div><?php endforeach;?></section>
</div>
<section class="card card-pad" style="margin-top:14px"><h2 class="section-title">Lịch sử các đợt</h2><div class="table-wrap" style="margin-top:10px"><table><thead><tr><th>Đợt</th><th>Trạng thái</th><th>Học viên</th><th>Bắt đầu</th><th>Kết thúc</th></tr></thead><tbody><?php foreach($history as $r):?><tr><td>#<?=$r['id']?> · <?=htmlspecialchars($r['title'])?></td><td><span class="badge <?=$r['status']==='ACTIVE'?'green':'red'?>"><?=$r['status']?></span></td><td><?=number_format((int)$r['member_count'])?></td><td><?=htmlspecialchars($r['started_at'])?></td><td><?=htmlspecialchars($r['ended_at']?:'—')?></td></tr><?php endforeach;?></tbody></table></div></section>
<?php include __DIR__.'/includes/layout_bottom.php';?>
