# Brain Focus v4.8.0 – Operations & Experience

## Nâng cấp chính
- Nhiệm vụ DAILY/WEEKLY/MONTHLY có chu kỳ riêng, có thời gian bắt đầu/kết thúc tùy chọn và reset trạng thái hoàn thành theo chu kỳ.
- Thưởng hoàn thành đủ bộ nhiệm vụ chu kỳ, mặc định +100 XP, chỉnh được trong Admin.
- Huy hiệu chuyển sang ảnh upload PNG/JPG/WebP; hồ sơ và thư viện thành tích hiển thị ảnh huy hiệu.
- Hồ sơ chia tab: Thông tin cá nhân, Level, Hiệu suất & liêm chính, Lịch nhắc, Đúc kết phiên học.
- Menu mobile gom vào drawer ☰ và bottom navigation gọn hơn.
- CKEditor 5 cho CMS bài viết và email broadcast.
- SUPER_ADMIN: Health & Integration Check và Backup Database.
- Quản lý âm thanh tập trung: upload MP3/OGG/WAV/M4A, bật/tắt/xóa và tích hợp vào selector người dùng.
- Module Control: bật/tắt Focus, Gym, Knowledge, Tips, BXH, Achievements, Feedback, Notifications, Audio.
- SEO theo từng trang quan trọng: title/description riêng, canonical, Open Graph, sitemap/robots cập nhật.

## Migration
Chạy `sql/migration_v4_8_0_ops_experience.sql` sau khi đã chạy migration v4.7.x.
