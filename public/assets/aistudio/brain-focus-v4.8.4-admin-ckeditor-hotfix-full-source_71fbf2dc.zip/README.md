# Brain Focus v4.4 — Classic UI + PHP-first Secure Platform

Brain Focus v4 là bản tái cấu trúc web theo hướng EduWall: **nhiều trang PHP nhỏ, MySQL tập trung, user/admin session phía máy chủ, RBAC, audit, security center, CMS, point ledger và vinh danh**.

## Điểm chính

- User: `index.php`, `focus.php`, `gym.php`, `gym-play.php`, `assessment.php`, `knowledge.php`, `article.php`, `tips.php`, `honors.php`, `leaderboard.php`, `profile.php`, `feedback.php`.
- Admin: `/admin/` có dashboard, users, admins, sessions, CMS, feedback, honors, security, forbidden words, analytics, audit, settings, khảo sát học viên và Viện giám sát điểm.
- Self-study có White/Pink/Brown noise phát trực tiếp trong trình duyệt.
- IP, User-Agent, device ID ngẫu nhiên và browser info được ghi nhận phục vụ bảo mật.
- Admin có thể block IP/device/email/User-Agent và chặn nhanh từ Access Log.
- Từ cấm được kiểm tra server-side.
- Điểm do server quản lý; client không được tự đồng bộ/cộng điểm.
- Huy hiệu/vinh danh tự động hoặc cấp bởi admin, mọi thay đổi điểm có ledger.
- Brain Gym tách trang chơi, 5 lượt miễn phí/ngày, cửa hàng 35 điểm/lượt và chấm điểm phía server.
- Leaderboard có podium Top 3, Tổng Điểm, tìm kiếm tên/đơn vị, giới hạn 10/25/50/100/tất cả và tìm hạng bản thân.
- Hồ sơ có Integrity, F11, completion rate, khung giờ vàng và biểu đồ thời gian học/Gym theo 12h–tất cả.
- Kiến thức tập trung dùng CMS bài viết; khảo sát BFS động và biểu đồ câu trả lời trong admin.
- Góp ý hỗ trợ email nhận phản hồi và ảnh sự cố.


## Cài đặt / nâng cấp

- **Cài mới:** import `sql/schema.sql`, sau đó mở `/admin/setup.php`.
- **Nâng từ v4.3:** backup DB, import `sql/migration_2026_09_26_v44_features.sql`, sau đó upload source v4.4.
- **Nâng từ v3:** chạy các migration nền v4 trước, rồi chạy migration v4.4.

Đọc `NANG_CAP_PHP_FIRST_V4.md` và `HUONG_DAN_DEPLOY_HOSTING.md` để triển khai.

> Source Android/Kotlin vẫn được giữ trong repository như một client riêng. Các tính năng quản trị PHP v4 chạy trên web/hosting, không chạy trực tiếp trong WebView offline.
