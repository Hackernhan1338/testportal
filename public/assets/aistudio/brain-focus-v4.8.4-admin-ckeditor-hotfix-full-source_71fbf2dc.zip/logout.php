<?php require_once __DIR__.'/includes/bootstrap.php';bfLogoutUser($pdo);header('Location: /login.php');exit;
