# Brain Focus v4.5.3 — BFS Admin Retake Campaign

## Mới
- Admin chỉnh trực tiếp điểm BFS cộng/trừ cho lần làm lại đầu tiên, các lần làm lại tiếp theo, và các mức sau khi sai câu kiểm tra chú ý.
- Giá trị dương = cộng BFS; giá trị âm = trừ BFS; tổng BFS không giảm dưới 0.
- Nút “Yêu cầu tất cả học viên làm khảo sát lại”.
- Mỗi đợt khảo sát bắt buộc chụp danh sách học viên ACTIVE/STUDENT tại thời điểm tạo.
- Học viên còn PENDING bị điều hướng tới `assessment.php` trước khi sử dụng chức năng khác.
- Mức điểm của đợt được lưu riêng trong `bf_bfs_retake_campaigns`, nên thay đổi cấu hình sau đó không làm đổi mức của đợt đang chạy.
- Theo dõi tổng học viên, đã hoàn thành và còn thiếu.
- BFS thật (`bfs_assessment_score`) được tách khỏi phần điều chỉnh BFS.
- Mọi phần cộng/trừ BFS khi làm lại được ghi vào `bf_point_transactions` với `point_type='BFS'` để kiểm toán.

## Database
Chạy `sql/migration_v4_5_3_bfs_admin_forced_retake.sql` nếu nâng cấp từ v4.5.2.
