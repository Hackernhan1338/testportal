# Tóm tắt triển khai GĐ2 + GĐ3

Phiên bản: `4.7.0-phase2-3`

Các route mới chính:
- `/onboarding.php`
- `/notifications.php`
- `/notification-detail.php`
- `/achievements.php`
- `/public-profile.php?id=USER_ID`
- `/task-go.php?id=TASK_ID`
- `/admin/tasks.php`
- `/admin/achievements.php`
- `/sitemap.php`

Các bảng mới:
- `bf_badges`
- `bf_user_badges`
- `bf_tasks`
- `bf_user_task_completions`

Các cột hồ sơ mới nằm trong `bf_users`; thông báo được mở rộng thêm category, detail_html, ref_key và priority.
