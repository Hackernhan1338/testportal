# Brain Focus v4.8.2

- Audio module can be disabled from Module Control or directly in Focus Audio admin; frontend/API hides audio when disabled.
- Daily and weekly automatic tasks with measurable targets; month remains admin-configurable.
- Daily defaults: 2 focus sessions, 5 gym plays, buy 5 gym plays, 1 reflection, 1 completed 90-minute session.
- Weekly defaults: 15 focus sessions, 200 gym plays, buy 150 gym plays, 10 reflections, 5 completed 90-minute sessions.
- Full-set task bonus remains configurable; default +100 XP per daily/weekly/monthly period.
- Streak is recalculated from consecutive calendar days containing completed study sessions.
- Earned badge images are displayed beside the avatar.
- Upcoming birthdays are surfaced on Admin Dashboard.
- New-account welcome screen offers BFS test, onboarding guide, or skip.
- CKEditor can be toggled from api/db.php with BF_CKEDITOR_ENABLED.
- Mobile footer includes direct Admin access.
