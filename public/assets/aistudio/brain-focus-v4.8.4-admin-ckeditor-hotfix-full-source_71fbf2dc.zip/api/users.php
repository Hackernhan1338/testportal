<?php
/**
 * BRAIN FOCUS - USERS & LEADERBOARD API
 * Endpoint: /api/users.php
 * Hỗ trợ: Lấy Bảng xếp hạng, Đăng ký/Cập nhật học viên, Đồng bộ dữ liệu
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/metrics.php';

$pdo = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];
bfSecurityGate($pdo, null);

function bfLoadUserForAuth(PDO $pdo, string $email): ?array {
    $stmt = $pdo->prepare("SELECT id,email,password_hash,status FROM bf_users WHERE email=? LIMIT 1");
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    return $row ?: null;
}
function bfVerifyUserPasswordOrFail(PDO $pdo, string $email, string $password): array {
    $user = bfLoadUserForAuth($pdo, $email);
    if (!$user) jsonResponse(['success'=>false,'message'=>'Tài khoản học viên không tồn tại'],404);
    if (($user['status'] ?? '') !== 'ACTIVE') jsonResponse(['success'=>false,'message'=>'Tài khoản đã bị khóa'],403);
    $hash = (string)($user['password_hash'] ?? '');
    if ($hash === '' || $password === '' || !password_verify($password,$hash)) jsonResponse(['success'=>false,'message'=>'Mật khẩu học viên không chính xác'],401);
    if (password_needs_rehash($hash,PASSWORD_DEFAULT)) $pdo->prepare("UPDATE bf_users SET password_hash=? WHERE id=?")->execute([password_hash($password,PASSWORD_DEFAULT),$user['id']]);
    return $user;
}

// ================= 1. GET: LẤY DANH SÁCH BẢNG XẾP HẠNG / HỌC VIÊN =================
if ($method === 'GET') {
    $action = $_GET['action'] ?? 'leaderboard';

    if ($action === 'leaderboard') {
        $rows=bfLeaderboardRows($pdo,trim((string)($_GET['q']??'')),200,0);$round=bfLatestLeaderboardRound($pdo);$users=[];
        foreach($rows as $index=>$r){$users[]=['id'=>$r['id'],'name'=>$r['name'],'school'=>$r['school'],'avatar'=>$r['avatar'],'rankPoints'=>(int)$r['rank_points'],'bfs'=>(int)$r['bfs_score'],'sessionPoints'=>(int)$r['session_points'],'totalScore'=>(int)$r['total_score'],'accountTotal'=>(int)$r['account_total'],'sessionsCount'=>(int)$r['sessions_count'],'totalHours'=>(float)$r['total_hours'],'rank'=>!empty($r['final_rank'])?(int)$r['final_rank']:$index+1,'roundTitle'=>$r['round_title']??($round['title']??''),'roundStatus'=>$round['status']??'LEGACY'];}
        jsonResponse(['success'=>true,'total'=>bfLeaderboardCount($pdo,''),'round'=>$round,'users'=>$users]);
    }

    if ($action === 'get_user') {
        if ((getenv('BF_ALLOW_PUBLIC_USER_LOOKUP') ?: '0') !== '1') jsonResponse(['success'=>false,'message'=>'Tra cứu hồ sơ công khai đã bị tắt'],403);
        $email = trim($_GET['email'] ?? '');
        if (empty($email)) {
            jsonResponse(['success' => false, 'message' => 'Email không được để trống'], 400);
        }

        $stmt = $pdo->prepare("SELECT * FROM bf_users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Học viên không tồn tại'], 404);
        }

        // Lấy kèm lịch sử phiên học
        $stmtHistory = $pdo->prepare("
            SELECT * FROM bf_study_sessions 
            WHERE user_email = ? 
            ORDER BY session_timestamp DESC 
            LIMIT 50
        ");
        $stmtHistory->execute([$email]);
        $user['history'] = $stmtHistory->fetchAll();

        unset($user['password_hash']); // Ẩn mật khẩu
        jsonResponse(['success' => true, 'user' => $user]);
    }

    jsonResponse(['success' => false, 'message' => 'Hành động không hợp lệ'], 400);
}

// ================= 2. POST: ĐĂNG KÝ / ĐĂNG NHẬP / ĐỒNG BỘ DỮ LIỆU =================
if ($method === 'POST') {
    $input = getJsonInput();
    $action = $input['action'] ?? $_GET['action'] ?? 'sync_user';

    if ($action === 'change_email') {
        $email=strtolower(trim((string)($input['email']??''))); $newEmail=strtolower(trim((string)($input['newEmail']??''))); $password=(string)($input['password']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)||!filter_var($newEmail,FILTER_VALIDATE_EMAIL)) jsonResponse(['success'=>false,'message'=>'Email không hợp lệ'],400);
        if($email===$newEmail) jsonResponse(['success'=>true,'message'=>'Email không thay đổi']);
        $user=bfVerifyUserPasswordOrFail($pdo,$email,$password);$check=$pdo->prepare("SELECT id FROM bf_users WHERE email=? LIMIT 1");$check->execute([$newEmail]);if($check->fetch())jsonResponse(['success'=>false,'message'=>'Email mới đã được sử dụng'],409);
        $pdo->beginTransaction();try{$pdo->prepare("UPDATE bf_users SET email=? WHERE id=?")->execute([$newEmail,$user['id']]);foreach(['bf_study_sessions','bf_feedback','bf_analytics_events'] as $table){$pdo->prepare("UPDATE `$table` SET user_email=? WHERE user_email=?")->execute([$newEmail,$email]);}foreach(['bf_focus_events','bf_bfs_assessments','bf_gym_sessions','bf_notifications','bf_user_devices','bf_login_history'] as $table){try{$pdo->prepare("UPDATE `$table` SET user_email=? WHERE user_email=?")->execute([$newEmail,$email]);}catch(Throwable $e){}}$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();jsonResponse(['success'=>false,'message'=>'Không thể đổi email trên máy chủ'],500);}jsonResponse(['success'=>true,'message'=>'Đã đổi email học viên']);
    }
    if ($action === 'change_password') {
        $email=strtolower(trim((string)($input['email']??'')));$current=(string)($input['currentPassword']??'');$new=(string)($input['newPassword']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($new)<8)jsonResponse(['success'=>false,'message'=>'Email hoặc mật khẩu mới không hợp lệ'],400);
        $user=bfVerifyUserPasswordOrFail($pdo,$email,$current);$pdo->prepare("UPDATE bf_users SET password_hash=? WHERE id=?")->execute([password_hash($new,PASSWORD_DEFAULT),$user['id']]);jsonResponse(['success'=>true,'message'=>'Đã đổi mật khẩu học viên']);
    }

    // A. ĐỒNG BỘ HOẶC TẠO MỚI HỌC VIÊN
    if ($action === 'sync_user' || $action === 'register') {
        $email = strtolower(trim($input['email'] ?? ''));
        $name = trim($input['name'] ?? '');
        $school = trim($input['school'] ?? 'Người học tập trung');
        $password = trim($input['password'] ?? '');
        $avatar = $input['avatar'] ?? null;
        // SECURITY: score/statistics are server-owned. Client values are ignored.
        $rankPoints = 1000; $bfsScore = 0; $sessionsCount = 0; $totalHours = 0; $streakDays = 1; $purchasedGym = 0;

        if (empty($email) || empty($name) || !filter_var($email,FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'message' => 'Email và Tên không hợp lệ'], 400);
        }

        bfSecurityGate($pdo, $email);
        bfRejectForbidden($pdo, [$name, $school], 'PROFILE');

        // Kiểm tra tồn tại
        $stmt = $pdo->prepare("SELECT id, password_hash, role, status FROM bf_users WHERE email = ?");
        $stmt->execute([$email]);
        $existing = $stmt->fetch();

        if ($existing) {
            if (($existing['status'] ?? '') !== 'ACTIVE') jsonResponse(['success'=>false,'message'=>'Tài khoản học viên đã bị khóa'],403);
            $existingHash=(string)($existing['password_hash']??'');
            if($existingHash!==''){ if($password===''||!password_verify($password,$existingHash)) jsonResponse(['success'=>false,'message'=>'Mật khẩu học viên không chính xác'],401); }
            else { if(strlen($password)<8) jsonResponse(['success'=>false,'message'=>'Tài khoản legacy cần đặt mật khẩu tối thiểu 8 ký tự trước khi đồng bộ'],401); $pdo->prepare("UPDATE bf_users SET password_hash=? WHERE id=?")->execute([password_hash($password,PASSWORD_DEFAULT),$existing['id']]); }
            // Cập nhật thông tin học viên sau khi xác thực mật khẩu
            // Chỉ cho client đồng bộ hồ sơ. Điểm/thống kê không bao giờ nhận từ trình duyệt.
            bfRejectForbidden($pdo, [$name, $school], 'PROFILE');
            $sql = "UPDATE bf_users SET name = :name, school = :school";
            $params = [':name'=>$name, ':school'=>$school, ':email'=>$email];

            if (!empty($avatar)) {
                $sql .= ", avatar = :avatar";
                $params[':avatar'] = $avatar;
            }

            $sql .= " WHERE email = :email";
            $updateStmt = $pdo->prepare($sql);
            $updateStmt->execute($params);

            jsonResponse(['success' => true, 'message' => 'Đã đồng bộ học viên thành công', 'isNew' => false]);
        } else {
            if(strlen($password)<8) jsonResponse(['success'=>false,'message'=>'Mật khẩu phải có tối thiểu 8 ký tự'],400);
            $passHash = password_hash($password, PASSWORD_DEFAULT);
            $insertStmt = $pdo->prepare("
                INSERT INTO bf_users (email, name, school, password_hash, avatar, rank_points, bfs_score, sessions_count, total_hours, streak_days, purchased_gym_plays)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $insertStmt->execute([
                $email, $name, $school, $passHash, $avatar, $rankPoints, $bfsScore, $sessionsCount, $totalHours, $streakDays, $purchasedGym
            ]);
            $newId=(int)$pdo->lastInsertId();
            try{$rem=$pdo->prepare("INSERT INTO bf_study_reminders(user_id,reminder_time,reminder_text,is_active) VALUES(?,?,?,1)");foreach([['08:30:00','Học sâu buổi sáng (Lock In)'],['14:00:00','Gym não giải toả (3 Game)'],['20:00:00','Chu kỳ Ultradian tối (90p)']] as $r)$rem->execute([$newId,$r[0],$r[1]]);}catch(Throwable $ignore){}

            jsonResponse(['success' => true, 'message' => 'Đã tạo học viên mới thành công', 'isNew' => true]);
        }
    }

    // B. LƯU PHIÊN HỌC (SESSION COMPLETE)
    if ($action === 'save_session') {
        $email = strtolower(trim($input['userEmail'] ?? $input['email'] ?? ''));
        if (empty($email)) jsonResponse(['success' => false, 'message' => 'Email học viên không được trống'], 400);
        bfSecurityGate($pdo, $email);
        bfVerifyUserPasswordOrFail($pdo,$email,(string)($input['password']??''));
        $clientSessionId = substr(trim((string)($input['clientSessionId'] ?? '')), 0, 100);
        $mode = $input['mode'] ?? 'ultradian';
        $duration = intval($input['duration'] ?? 90);
        $distractions = intval($input['distractions'] ?? 0);
        $isDeepFocus = !empty($input['isDeepFocus']) ? 1 : 0;
        $focusIntegrity = intval($input['focusIntegrity'] ?? 100);
        $goal = $input['goal'] ?? '';
        $emotion = $input['emotion'] ?? 'Tập trung cao 🚀';
        $reflection = $input['reflection'] ?? '';
        $learned = $input['learnedInsight'] ?? '';
        // SECURITY: endpoint legacy không có đồng hồ server-side đáng tin cậy nên không phát điểm.
        $focusIntegrity = max(0, min(100, $focusIntegrity));
        $duration = max(1, min(180, $duration));
        $rankEarned = 0;
        $bfsEarned = 0;
        bfRejectForbidden($pdo, [$goal, $reflection, $learned], 'FOCUS');
        $timestamp = !empty($input['timestamp']) ? intval($input['timestamp']) : round(microtime(true) * 1000);

        // Lưu vào bf_study_sessions
        $stmt = $pdo->prepare("
            INSERT INTO bf_study_sessions 
            (user_email, client_session_id, mode, duration_minutes, distractions, is_deep_focus, focus_integrity, goal, emotion, reflection, learned_insight, bfs_earned, rank_earned, session_timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $email, $clientSessionId ?: null, $mode, $duration, $distractions, $isDeepFocus, $focusIntegrity, $goal, $emotion, $reflection, $learned, $bfsEarned, $rankEarned, $timestamp
        ]);
        $studySessionId=(int)$pdo->lastInsertId();
        if($clientSessionId!==''){try{$link=$pdo->prepare("UPDATE bf_focus_events SET study_session_id=? WHERE user_email=? AND client_session_id=? AND study_session_id IS NULL");$link->execute([$studySessionId,$email,$clientSessionId]);}catch(Throwable $e){}}

        // Cập nhật tăng số phiên học & giờ học trong bf_users
        $hoursAdded = round($duration / 60, 2);
        $updateUser = $pdo->prepare("
            UPDATE bf_users 
            SET sessions_count = sessions_count + 1,
                total_hours = total_hours + ?,
                rank_points = rank_points + ?,
                bfs_score = bfs_score + ?
            WHERE email = ?
        ");
        $updateUser->execute([$hoursAdded, $rankEarned, $bfsEarned, $email]);
        // Endpoint legacy chỉ lưu lịch sử; không được phát điểm vì không có server timer tin cậy.

        jsonResponse(['success' => true, 'message' => 'Lưu phiên học thành công', 'sessionId' => $studySessionId, 'rankEarned'=>$rankEarned, 'bfsEarned'=>$bfsEarned]);
    }

    jsonResponse(['success' => false, 'message' => 'Hành động không xác định'], 400);
}

jsonResponse(['success' => false, 'message' => 'Phương thức không hỗ trợ'], 405);
