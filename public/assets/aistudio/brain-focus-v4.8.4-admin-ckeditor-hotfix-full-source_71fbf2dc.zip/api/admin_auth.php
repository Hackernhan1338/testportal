<?php
require_once __DIR__ . '/admin_security.php';
$pdo=getDbConnection(); $method=$_SERVER['REQUEST_METHOD']; bfStartAdminSession();
if($method==='GET'){
  if(($_GET['action']??'me')==='me'){ $a=bfCurrentAdmin($pdo); if(!$a)jsonResponse(['success'=>false,'authenticated'=>false],401); bfRecordAdminSession($pdo,(int)$a['id']); jsonResponse(['success'=>true,'authenticated'=>true,'admin'=>$a,'csrfToken'=>bfEnsureCsrfToken()]); }
  jsonResponse(['success'=>false,'message'=>'Hành động không hợp lệ'],400);
}
if($method==='POST'){
  $in=getJsonInput(); $action=$in['action']??'';
  if($action==='login'){
    $u=trim((string)($in['username']??''));$p=(string)($in['password']??''); if($u===''||$p==='')jsonResponse(['success'=>false,'message'=>'Vui lòng nhập tài khoản và mật khẩu'],400);
    $st=$pdo->prepare("SELECT * FROM bf_admins WHERE (username=? OR email=?) LIMIT 1");$st->execute([$u,$u]);$a=$st->fetch();$valid=false;$legacy=false;
    if($a&&$a['status']==='ACTIVE'){ $h=(string)$a['password_hash']; if(preg_match('/^[a-f0-9]{64}$/i',$h)){$legacy=hash_equals(strtolower($h),hash('sha256',$p));$valid=$legacy;}else{$valid=password_verify($p,$h);} }
    if(!$valid){usleep(250000);jsonResponse(['success'=>false,'message'=>'Thông tin đăng nhập không chính xác'],401);} 
    if($legacy||password_needs_rehash($a['password_hash'],PASSWORD_DEFAULT)){ $pdo->prepare("UPDATE bf_admins SET password_hash=? WHERE id=?")->execute([password_hash($p,PASSWORD_DEFAULT),$a['id']]); if($legacy){try{$pdo->prepare("UPDATE bf_admins SET must_change_password=1 WHERE id=?")->execute([$a['id']]);}catch(Throwable $e){}} }
    session_regenerate_id(true);$_SESSION['bf_admin_id']=(int)$a['id'];$_SESSION['bf_login_at']=time();$_SESSION['bf_csrf']=bin2hex(random_bytes(32));$pdo->prepare("UPDATE bf_admins SET last_login=NOW() WHERE id=?")->execute([$a['id']]);bfRecordAdminSession($pdo,(int)$a['id']);$safe=bfCurrentAdmin($pdo);bfAudit($pdo,$safe,'LOGIN','ADMIN_PORTAL','Đăng nhập quản trị thành công');jsonResponse(['success'=>true,'message'=>'Đăng nhập thành công','admin'=>$safe,'csrfToken'=>bfEnsureCsrfToken()]);
  }
  if($action==='logout'){ $a=bfCurrentAdmin($pdo);if($a)bfAudit($pdo,$a,'LOGOUT','ADMIN_PORTAL','Đăng xuất quản trị');bfDestroyAdminSession($pdo);jsonResponse(['success'=>true]); }
  if($action==='change_password'){ $a=bfRequireAdmin($pdo);bfRequireCsrf();$cur=(string)($in['currentPassword']??'');$new=(string)($in['newPassword']??'');if(strlen($new)<12)jsonResponse(['success'=>false,'message'=>'Mật khẩu mới phải có ít nhất 12 ký tự'],400);$st=$pdo->prepare("SELECT password_hash FROM bf_admins WHERE id=?");$st->execute([$a['id']]);$h=(string)$st->fetchColumn();$ok=preg_match('/^[a-f0-9]{64}$/i',$h)?hash_equals(strtolower($h),hash('sha256',$cur)):password_verify($cur,$h);if(!$ok)jsonResponse(['success'=>false,'message'=>'Mật khẩu hiện tại không chính xác'],400);$pdo->prepare("UPDATE bf_admins SET password_hash=?,must_change_password=0 WHERE id=?")->execute([password_hash($new,PASSWORD_DEFAULT),$a['id']]);bfAudit($pdo,$a,'CHANGE_PASSWORD','ADMIN:'.$a['id'],'Đổi mật khẩu quản trị');jsonResponse(['success'=>true,'message'=>'Đã đổi mật khẩu']); }
  jsonResponse(['success'=>false,'message'=>'Hành động không hợp lệ'],400);
}
jsonResponse(['success'=>false,'message'=>'Phương thức không hỗ trợ'],405);
