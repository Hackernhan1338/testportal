<?php
require_once __DIR__.'/db.php';

/**
 * Gmail SMTP client nhỏ gọn dành cho Brain Focus.
 * Không dùng PHP mail(); giao tiếp trực tiếp với smtp.gmail.com qua STARTTLS.
 * Mục tiêu: chạy trên shared hosting mà không cần Composer.
 */
function bfSmtpReadReply($fp): array {
    $lines=[];$code=0;
    while(!feof($fp)){
        $line=fgets($fp,8192);
        if($line===false) break;
        $line=rtrim($line,"\r\n");
        $lines[]=$line;
        if(strlen($line)>=3 && ctype_digit(substr($line,0,3))) $code=(int)substr($line,0,3);
        if(strlen($line)<4 || $line[3]===' ') break;
    }
    return [$code,implode("\n",$lines)];
}
function bfSmtpExpect($fp,array $codes,string $stage): string {
    [$code,$text]=bfSmtpReadReply($fp);
    if(!in_array($code,$codes,true)) throw new RuntimeException($stage.' thất bại (SMTP '.$code.'): '.$text);
    return $text;
}
function bfSmtpCommand($fp,string $command,array $codes,string $stage): string {
    if(fwrite($fp,$command."\r\n")===false) throw new RuntimeException('Không thể gửi lệnh SMTP tại '.$stage.'.');
    return bfSmtpExpect($fp,$codes,$stage);
}
function bfMimeHeader(string $value): string {
    return '=?UTF-8?B?'.base64_encode($value).'?=';
}
function bfSmtpConfigured(): bool {
    $pass=preg_replace('/\s+/','',(string)BF_SMTP_APP_PASSWORD);
    return BF_SMTP_USERNAME!=='' && strlen($pass)>=16 && strpos($pass,'DAN_MAT_KHAU')===false;
}
function bfSendSmtpMail(string $to,string $subject,string $html,string $text=''): array {
    if(!filter_var($to,FILTER_VALIDATE_EMAIL)) return ['success'=>false,'message'=>'Email người nhận không hợp lệ.'];
    if(!bfSmtpConfigured()) return ['success'=>false,'message'=>'SMTP chưa được cấu hình. Hãy dán App Password 16 ký tự vào BF_SMTP_APP_PASSWORD trong api/db.php.'];
    $pass=preg_replace('/\s+/','',(string)BF_SMTP_APP_PASSWORD);
    $host=(string)BF_SMTP_HOST;$port=(int)BF_SMTP_PORT;$timeout=max(5,(int)BF_SMTP_TIMEOUT);
    $errno=0;$errstr='';
    $fp=@stream_socket_client('tcp://'.$host.':'.$port,$errno,$errstr,$timeout,STREAM_CLIENT_CONNECT);
    if(!$fp) return ['success'=>false,'message'=>'Không kết nối được Gmail SMTP: '.$errstr.' ('.$errno.').'];
    stream_set_timeout($fp,$timeout);
    try{
        bfSmtpExpect($fp,[220],'Kết nối SMTP');
        $domain=$_SERVER['SERVER_NAME']??'localhost';
        bfSmtpCommand($fp,'EHLO '.$domain,[250],'EHLO');
        bfSmtpCommand($fp,'STARTTLS',[220],'STARTTLS');
        $crypto=@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT);
        if($crypto!==true) throw new RuntimeException('Không thể bật TLS với Gmail SMTP. Kiểm tra extension OpenSSL trên hosting.');
        bfSmtpCommand($fp,'EHLO '.$domain,[250],'EHLO sau TLS');
        bfSmtpCommand($fp,'AUTH LOGIN',[334],'AUTH LOGIN');
        bfSmtpCommand($fp,base64_encode((string)BF_SMTP_USERNAME),[334],'SMTP username');
        bfSmtpCommand($fp,base64_encode($pass),[235],'SMTP App Password');
        bfSmtpCommand($fp,'MAIL FROM:<'.BF_SMTP_FROM_EMAIL.'>',[250],'MAIL FROM');
        bfSmtpCommand($fp,'RCPT TO:<'.$to.'>',[250,251],'RCPT TO');
        bfSmtpCommand($fp,'DATA',[354],'DATA');

        if($text==='') $text=trim(strip_tags(preg_replace('/<br\s*\/?\s*>/i',"\n",$html)));
        $boundary='=_BrainFocus_'.bin2hex(random_bytes(12));
        $headers=[];
        $headers[]='Date: '.date(DATE_RFC2822);
        $headers[]='From: '.bfMimeHeader(BF_SMTP_FROM_NAME).' <'.BF_SMTP_FROM_EMAIL.'>';
        $headers[]='To: <'.$to.'>';
        $headers[]='Subject: '.bfMimeHeader($subject);
        $headers[]='MIME-Version: 1.0';
        $headers[]='Content-Type: multipart/alternative; boundary="'.$boundary.'"';
        $headers[]='Message-ID: <'.bin2hex(random_bytes(12)).'@'.preg_replace('/[^A-Za-z0-9.-]/','',$domain).'>';

        $body="--{$boundary}\r\n";
        $body.="Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($text))."\r\n";
        $body.="--{$boundary}\r\n";
        $body.="Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($html))."\r\n";
        $body.="--{$boundary}--\r\n";
        $message=implode("\r\n",$headers)."\r\n\r\n".$body;
        // Dot-stuffing theo SMTP RFC 5321.
        $message=preg_replace('/(?m)^\./','..',$message);
        fwrite($fp,$message."\r\n.\r\n");
        bfSmtpExpect($fp,[250],'Gửi nội dung email');
        @bfSmtpCommand($fp,'QUIT',[221],'QUIT');
        fclose($fp);
        return ['success'=>true,'message'=>'Email đã được Gmail SMTP chấp nhận gửi.'];
    }catch(Throwable $e){
        @fwrite($fp,"QUIT\r\n");@fclose($fp);
        error_log('[BrainFocus SMTP] '.$e->getMessage());
        return ['success'=>false,'message'=>$e->getMessage()];
    }
}

function bfSendPasswordResetOtp(string $to,string $code): array {
    $safe=htmlspecialchars($code,ENT_QUOTES,'UTF-8');
    $html='<!doctype html><html><body style="margin:0;background:#f8fafc;font-family:Arial,sans-serif;color:#0f172a"><div style="max-width:560px;margin:30px auto;background:#fff;border:1px solid #e2e8f0;border-radius:18px;overflow:hidden"><div style="background:#0f172a;color:#fff;padding:24px"><div style="font-size:22px;font-weight:700">🧠 Brain Focus</div><div style="font-size:13px;color:#cbd5e1;margin-top:4px">Xác nhận đặt lại mật khẩu</div></div><div style="padding:28px"><p style="font-size:15px">Mã xác nhận của bạn là:</p><div style="font-size:34px;font-weight:800;letter-spacing:8px;text-align:center;padding:20px;border-radius:14px;background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe">'.$safe.'</div><p style="font-size:13px;line-height:1.6;color:#475569">Mã có hiệu lực trong <b>10 phút</b> và chỉ dùng được một lần. Nếu bạn không yêu cầu đổi mật khẩu, hãy bỏ qua email này.</p></div><div style="padding:16px 28px;background:#f8fafc;color:#64748b;font-size:12px">Brain Focus · Email hệ thống gửi từ '.htmlspecialchars(BF_SMTP_FROM_EMAIL).'</div></div></body></html>';
    $text="Brain Focus\n\nMã xác nhận đặt lại mật khẩu: {$code}\nMã có hiệu lực trong 10 phút và chỉ dùng được một lần.";
    return bfSendSmtpMail($to,'[Brain Focus] Mã xác nhận đặt lại mật khẩu',$html,$text);
}
