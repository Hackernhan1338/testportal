<?php
require_once __DIR__.'/../includes/user_auth.php';
require_once __DIR__.'/../includes/metrics.php';
$pdo=getDbConnection();bfStartUserSession();$u=bfCurrentUser($pdo);if(!$u)jsonResponse(['success'=>false,'message'=>'Vui lòng đăng nhập'],401);bfSecurityGate($pdo,$u['email']);
if($_SERVER['REQUEST_METHOD']!=='POST')jsonResponse(['success'=>false,'message'=>'Phương thức không hỗ trợ'],405);bfCheckUserCsrf();
$rank=bfUserRank($pdo,$u);$round=bfLatestLeaderboardRound($pdo);$score=bfUserRoundScore($pdo,$u);$rid=$round?(int)$round['id']:null;
try{
    $st=$pdo->prepare("SELECT share_token FROM bf_rank_share_links WHERE user_id=? AND ((round_id IS NULL AND ? IS NULL) OR round_id=?) ORDER BY id DESC LIMIT 1");$st->execute([$u['id'],$rid,$rid]);$token=$st->fetchColumn();
    if(!$token){$token=bin2hex(random_bytes(20));$pdo->prepare("INSERT INTO bf_rank_share_links(share_token,user_id,round_id,snapshot_rank,snapshot_score) VALUES(?,?,?,?,?)")->execute([$token,$u['id'],$rid,$rank,(int)$score['round_points']]);}
    else{$pdo->prepare("UPDATE bf_rank_share_links SET snapshot_rank=?,snapshot_score=?,created_at=NOW() WHERE share_token=?")->execute([$rank,(int)$score['round_points'],$token]);}
    $scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';$host=$_SERVER['HTTP_HOST']??'';$url=$scheme.'://'.$host.'/rank-share.php?t='.$token;
    jsonResponse(['success'=>true,'url'=>$url,'rank'=>$rank,'score'=>(int)$score['round_points'],'round'=>$round['title']??'Bảng xếp hạng']);
}catch(Throwable $e){jsonResponse(['success'=>false,'message'=>'Chưa thể tạo liên kết chia sẻ. Hãy chạy migration v4.5.4.'],500);}
