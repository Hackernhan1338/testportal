<?php
require_once __DIR__.'/../includes/user_auth.php';
$pdo=getDbConnection();
bfStartUserSession();
$u=bfCurrentUser($pdo);
if(!$u) jsonResponse(['success'=>false,'message'=>'Vui lòng đăng nhập'],401);
bfSecurityGate($pdo,$u['email']);

function gymSetting(PDO $pdo,string $key,$default){
  try{$st=$pdo->prepare("SELECT setting_value FROM bf_settings WHERE setting_key=? LIMIT 1");$st->execute([$key]);$v=$st->fetchColumn();return ($v===false||$v===null||$v==='')?$default:$v;}catch(Throwable $e){return $default;}
}
function gymSessionGameColumn(PDO $pdo){
  static $column=null;if($column!==null)return $column;
  try{$st=$pdo->query("SHOW COLUMNS FROM bf_gym_sessions");$cols=[];foreach($st->fetchAll() as $r)$cols[]=$r['Field'];if(in_array('game_type',$cols,true))return $column='game_type';if(in_array('game_code',$cols,true))return $column='game_code';}catch(Throwable $e){}
  return $column='game_type';
}
function insertGymSession(PDO $pdo,array $u,array $a,$score,$duration,$token,$max,$meta=[]){
  $col=gymSessionGameColumn($pdo);
  $payload=array_merge(['attemptToken'=>$token,'maxScore'=>$max,'accuracy'=>$max?$score/$max:0],$meta);
  $sql="INSERT INTO bf_gym_sessions(user_email,`".$col."`,score,duration_seconds,metadata_json) VALUES(?,?,?,?,?)";
  $pdo->prepare($sql)->execute([$u['email'],$a['game_type'],$score,$duration,json_encode($payload,JSON_UNESCAPED_UNICODE)]);
}
function gymDailyLimit(PDO $pdo){ return max(1,(int)gymSetting($pdo,'max_daily_gym_plays',5)); }
function gymPlayCost(PDO $pdo){ return max(1,(int)gymSetting($pdo,'gym_play_cost',35)); }
function gymStatus(PDO $pdo,array $u){
  $limit=gymDailyLimit($pdo);
  $st=$pdo->prepare("SELECT COUNT(*) FROM bf_gym_attempts WHERE user_id=? AND DATE(started_at)=CURDATE() AND status IN('STARTED','COMPLETED','ABORTED') AND used_paid_play=0");$st->execute([$u['id']]);$freeUsed=(int)$st->fetchColumn();
  $st=$pdo->prepare("SELECT purchased_gym_plays,rank_points,bfs_score FROM bf_users WHERE id=?");$st->execute([$u['id']]);$r=$st->fetch();
  return ['freeUsed'=>$freeUsed,'freeRemaining'=>max(0,$limit-$freeUsed),'purchased'=>(int)$r['purchased_gym_plays'],'rankPoints'=>(int)$r['rank_points'],'bfs'=>(int)$r['bfs_score'],'cost'=>gymPlayCost($pdo),'limit'=>$limit];
}
function shuffle_assoc($arr){$keys=array_keys($arr);shuffle($keys);$out=[];foreach($keys as $k)$out[]=$arr[$k];return $out;}
function buildChallenge($game){
  if($game==='stroop'){
    $names=['ĐỎ','XANH DƯƠNG','LỤC','VÀNG'];$colors=['#dc2626','#2563eb','#16a34a','#eab308'];$items=[];
    for($i=0;$i<12;$i++){$wi=random_int(0,3);$ii=random_int(0,3);$opts=$names;shuffle($opts);$items[]=['word'=>$names[$wi],'ink'=>$names[$ii],'color'=>$colors[$ii],'options'=>$opts];}
    return ['items'=>$items,'timerSeconds'=>36];
  }
  if($game==='math'){
    $items=[];
    for($i=0;$i<12;$i++){
      $mode=random_int(0,2);
      if($mode===0){$a=random_int(8,40);$b=random_int(2,20);$expr="({$a} + {$b}) × 2 - ".random_int(5,18);$ans=($a+$b)*2-(int)substr(strrchr($expr,' '),1);} 
      elseif($mode===1){$a=random_int(15,45);$b=random_int(2,9);$c=random_int(8,25);$expr="{$a} + {$b} × {$c}";$ans=$a+$b*$c;}
      else{$a=random_int(15,40);$b=random_int(4,18);$c=random_int(2,5);$expr="({$a} - {$b}) × {$c}";$ans=($a-$b)*$c;}
      $choices=[$ans]; while(count($choices)<4){$delta=random_int(1,8)*([ -1, 1 ][random_int(0,1)]);$x=$ans+$delta;if(!in_array($x,$choices,true))$choices[]=$x;} shuffle($choices);
      $items[]=['expr'=>$expr,'answer'=>$ans,'choices'=>$choices];
    }
    return ['items'=>$items,'timerSeconds'=>14];
  }
  $rounds=[];for($r=0;$r<6;$r++){$size=$r<2?3:($r<4?4:5);$count=min($size*$size-1,3+$r);$cells=[];while(count($cells)<$count){$x=random_int(0,$size*$size-1);if(!in_array($x,$cells,true))$cells[]=$x;}sort($cells);$rounds[]=['size'=>$size,'cells'=>$cells];}
  return ['rounds'=>$rounds,'timerSeconds'=>45];
}
function gradeChallenge($game,$challenge,$answers){
  $score=0;$max=0;
  if($game==='stroop'){$items=$challenge['items']??[];$max=count($items);foreach($items as $i=>$it){if(isset($answers[$i])&&mb_strtoupper(trim((string)$answers[$i]),'UTF-8')===mb_strtoupper($it['ink'],'UTF-8'))$score++;}}
  elseif($game==='math'){$items=$challenge['items']??[];$max=count($items);foreach($items as $i=>$it){if(isset($answers[$i])&&(int)$answers[$i]===(int)$it['answer'])$score++;}}
  else{$rounds=$challenge['rounds']??[];$max=count($rounds);foreach($rounds as $i=>$it){$a=$answers[$i]??[];if(!is_array($a))continue;$a=array_map('intval',$a);sort($a);$c=array_map('intval',$it['cells']);sort($c);if($a===$c)$score++;}}
  return [$score,$max];
}
function gymEvaluation($game,$score,$max,$duration){
  $accuracy=$max?round($score/$max*100):0;
  $title=$game==='stroop'?'KẾT THÚC BÀI TẬP PHẢN XẠ MÀU':($game==='math'?'KẾT THÚC TÍNH NHẨM PHẢN XẠ':'KẾT THÚC MA TRẬN GHI NHỚ');
  if($score>=9){$rating='Tốt';$note='Hiệu suất rất tích cực. Tiếp tục duy trì nhịp tập luyện đều.';$icon='✨';}
  elseif($score>=6){$rating='Khá';$note='Bạn đã vượt ngưỡng cơ bản. Hãy cố gắng tăng độ chính xác ở lượt sau.';$icon='✅';}
  elseif($score>=3){$rating='Cần rèn luyện thêm';$note='Đã vượt ngưỡng tối thiểu để ghi nhận điểm thưởng, nhưng cần tiếp tục luyện tập.';$icon='⚠️';}
  else{$rating='Cần rèn luyện thêm';$note='Đúng dưới 3 câu: Chưa đủ để kích hoạt thuỳ trán. Không nhận được điểm ở lượt này.';$icon='⚠️';}
  return ['title'=>$title,'accuracy'=>$accuracy,'rating'=>$rating,'note'=>$note,'icon'=>$icon,'durationLabel'=>gmdate('i\p s\s',$duration)];
}

$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET'){ jsonResponse(['success'=>true,'status'=>gymStatus($pdo,$u)]); }
if($method!=='POST') jsonResponse(['success'=>false,'message'=>'Phương thức không hỗ trợ'],405);
bfCheckUserCsrf();
$in=getJsonInput();
$action=$in['action']??'';

if($action==='buy'){
  $qty=max(1,min(20,(int)($in['quantity']??1)));$currency=strtoupper((string)($in['currency']??'RANK'));if(!in_array($currency,['RANK','BFS'],true))jsonResponse(['success'=>false,'message'=>'Loại điểm không hợp lệ'],400);$cost=gymPlayCost($pdo)*$qty;
  $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT rank_points,bfs_score FROM bf_users WHERE id=? FOR UPDATE");$st->execute([$u['id']]);$r=$st->fetch();$field=$currency==='RANK'?'rank_points':'bfs_score';if((int)$r[$field]<$cost) throw new RuntimeException('Không đủ điểm để mua lượt.');
    $pdo->prepare("UPDATE bf_users SET `$field`=`$field`-?,purchased_gym_plays=purchased_gym_plays+? WHERE id=?")->execute([$cost,$qty,$u['id']]);
    $pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,?,?,?,'GYM_SHOP',?)")->execute([$u['id'],-$cost,$currency,'GYM_PLAY_PURCHASE','Mua '.$qty.' lượt rèn luyện',(string)time()]);
    try{$pdo->prepare("INSERT INTO bf_gym_purchase_events(user_id,quantity,currency,cost_points) VALUES(?,?,?,?)")->execute([$u['id'],$qty,$currency,$cost]);}catch(Throwable $ignore){}
    $pdo->commit(); jsonResponse(['success'=>true,'message'=>'Đã mua '.$qty.' lượt','status'=>gymStatus($pdo,$u)]);
  }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); jsonResponse(['success'=>false,'message'=>$e->getMessage()?:'Không thể mua lượt'],422); }
}

if($action==='start'){
  $game=strtolower((string)($in['game']??'')); if(!in_array($game,['stroop','grid','math'],true)) jsonResponse(['success'=>false,'message'=>'Trò chơi không hợp lệ'],400);
  $dailyLimit=gymDailyLimit($pdo);
  $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT purchased_gym_plays FROM bf_users WHERE id=? FOR UPDATE");$st->execute([$u['id']]);$p=(int)$st->fetchColumn();
    $ct=$pdo->prepare("SELECT COUNT(*) FROM bf_gym_attempts WHERE user_id=? AND DATE(started_at)=CURDATE() AND status IN('STARTED','COMPLETED','ABORTED') AND used_paid_play=0");$ct->execute([$u['id']]);$free=(int)$ct->fetchColumn();
    $paid=0;$cur='FREE';
    if($free>=$dailyLimit){ if($p<1) throw new RuntimeException('Bạn đã hết lượt miễn phí hôm nay. Hãy mua thêm lượt để tiếp tục.'); $paid=1;$cur='PURCHASED';$pdo->prepare("UPDATE bf_users SET purchased_gym_plays=purchased_gym_plays-1 WHERE id=?")->execute([$u['id']]); }
    $challenge=buildChallenge($game);$token=bin2hex(random_bytes(32));
    $pdo->prepare("INSERT INTO bf_gym_attempts(attempt_token,user_id,user_email,game_type,challenge_json,used_paid_play,paid_currency,ip_address,user_agent) VALUES(?,?,?,?,?,?,?,?,?)")->execute([$token,$u['id'],$u['email'],$game,json_encode($challenge,JSON_UNESCAPED_UNICODE),$paid,$cur,bfRequestIp(),substr(bfUserAgent(),0,500)]);
    $pdo->commit();
    $public=$challenge; if($game==='math') foreach($public['items'] as &$x) unset($x['answer']);
    jsonResponse(['success'=>true,'attemptToken'=>$token,'challenge'=>$public,'status'=>gymStatus($pdo,$u)]);
  }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); jsonResponse(['success'=>false,'message'=>$e->getMessage()?:'Không thể bắt đầu lượt chơi'],422); }
}

if($action==='complete'){
  $token=preg_replace('/[^a-f0-9]/','',strtolower((string)($in['attemptToken']??'')));$answers=$in['answers']??[]; if(strlen($token)!==64||!is_array($answers)) jsonResponse(['success'=>false,'message'=>'Dữ liệu kết quả không hợp lệ'],400);
  $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT * FROM bf_gym_attempts WHERE attempt_token=? AND user_id=? FOR UPDATE");$st->execute([$token,$u['id']]);$a=$st->fetch(); if(!$a) throw new RuntimeException('Không tìm thấy lượt chơi.');
    if($a['status']==='COMPLETED') jsonResponse(['success'=>true,'duplicate'=>true,'score'=>(int)$a['score'],'maxScore'=>(int)$a['max_score'],'rankAwarded'=>(int)$a['rank_awarded'],'bfsAwarded'=>(int)$a['bfs_awarded']]);
    if($a['status']!=='STARTED') throw new RuntimeException('Lượt chơi không còn hiệu lực.');
    $serverSec=max(1,time()-strtotime($a['started_at'])); if($serverSec>1800) throw new RuntimeException('Lượt chơi đã hết hạn.');
    $challenge=json_decode($a['challenge_json'],true)?:[]; [$score,$max]=gradeChallenge($a['game_type'],$challenge,$answers);
    $duration=min($serverSec,max(1,(int)($in['durationSeconds']??$serverSec)));
    $eval=gymEvaluation($a['game_type'],$score,$max,$duration);
    $ratio=$max?($score/$max):0;
    $rank=$score<3?0:(int)round(34*$ratio);
    $bfs=$score<3?0:(int)round(25*$ratio);
    $pdo->prepare("UPDATE bf_gym_attempts SET score=?,max_score=?,duration_seconds=?,rank_awarded=?,bfs_awarded=?,status='COMPLETED',completed_at=NOW() WHERE id=?")->execute([$score,$max,$duration,$rank,$bfs,$a['id']]);
    insertGymSession($pdo,$u,$a,$score,$duration,$token,$max,['rating'=>$eval['rating'],'accuracy'=>$eval['accuracy']]);
    if($rank||$bfs){
      $pdo->prepare("UPDATE bf_users SET gym_count=gym_count+1,rank_points=rank_points+?,bfs_score=bfs_score+? WHERE id=?")->execute([$rank,$bfs,$u['id']]);
      if($rank)$pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'RANK','GYM_COMPLETE',?,'GYM',?)")->execute([$u['id'],$rank,'Rèn phản xạ '.$a['game_type'],(string)$a['id']]);
      if($bfs)$pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'BFS','GYM_COMPLETE',?,'GYM',?)")->execute([$u['id'],$bfs,'Rèn phản xạ '.$a['game_type'],(string)$a['id']]);
    } else {
      $pdo->prepare("UPDATE bf_users SET gym_count=gym_count+1 WHERE id=?")->execute([$u['id']]);
    }
    $pdo->commit(); bfEvaluateHonors($pdo,(int)$u['id']);
    $status=gymStatus($pdo,$u);
    jsonResponse(['success'=>true,'score'=>$score,'maxScore'=>$max,'accuracyPercent'=>$eval['accuracy'],'title'=>$eval['title'],'rating'=>$eval['rating'],'note'=>$eval['note'],'icon'=>$eval['icon'],'rankAwarded'=>$rank,'bfsAwarded'=>$bfs,'totalAwarded'=>$rank+$bfs,'usedPlay'=>1,'remainingPlays'=>$status['freeRemaining']+$status['purchased'],'status'=>$status]);
  }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); jsonResponse(['success'=>false,'message'=>$e->getMessage()?:'Không thể lưu kết quả'],422); }
}
jsonResponse(['success'=>false,'message'=>'Hành động không hợp lệ'],400);
