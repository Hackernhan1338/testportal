<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
/**
 * BRAIN FOCUS - DATABASE CONFIGURATION & PDO CONNECTION
 * Cấu hình kết nối MySQL bằng PHP PDO an toàn, chống SQL Injection
 */

// Bật thông báo lỗi trong môi trường phát triển (tắt khi lên production)
error_reporting(E_ALL);
ini_set('display_errors', 0);

// API mặc định chạy same-origin. Chỉ bật CORS khi BF_ALLOWED_ORIGIN được cấu hình rõ ràng.
$allowedOrigin = getenv('BF_ALLOWED_ORIGIN') ?: '';
$requestOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($allowedOrigin !== '' && $requestOrigin !== '' && hash_equals($allowedOrigin, $requestOrigin)) {
    header('Access-Control-Allow-Origin: ' . $allowedOrigin);
    header('Access-Control-Allow-Credentials: true');
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Thông tin kết nối MySQL / MariaDB (Thay đổi tương ứng với Hosting / cPanel / XAMPP của bạn)
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'brainfocus_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

// ============================================================================
// GMAIL SMTP - CẤU HÌNH GỬI OTP / QUÊN MẬT KHẨU
// 1) Bật Xác minh 2 bước cho Gmail.
// 2) Tạo App Password 16 ký tự tại Google Account.
// 3) Dán App Password vào BF_SMTP_APP_PASSWORD bên dưới.
// LƯU Ý: Có thể dán có hoặc không có khoảng trắng; hệ thống sẽ tự loại khoảng trắng.
// ============================================================================
define('BF_SMTP_HOST', 'smtp.gmail.com');
define('BF_SMTP_PORT', 587);
define('BF_SMTP_ENCRYPTION', 'tls');
define('BF_SMTP_USERNAME', 'thiennhan1338@gmail.com');
define('BF_SMTP_APP_PASSWORD', 'DAN_MAT_KHAU_UNG_DUNG_16_KY_TU_VAO_DAY');
define('BF_SMTP_FROM_EMAIL', 'thiennhan1338@gmail.com');
define('BF_SMTP_FROM_NAME', 'Brain Focus');
define('BF_SMTP_TIMEOUT', 20);

// ============================================================================
// GOOGLE OAUTH 2.0 - ĐĂNG NHẬP BẰNG GOOGLE
// Tạo OAuth Client ID loại Web application trong Google Cloud Console.
// Redirect URI mẫu: https://YOUR-DOMAIN/google-callback.php
// Brain Focus KHÔNG thu hoặc nhìn thấy mật khẩu Google của người dùng.
// ============================================================================
define('BF_GOOGLE_CLIENT_ID', getenv('BF_GOOGLE_CLIENT_ID') ?: 'DAN_GOOGLE_CLIENT_ID_VAO_DAY');
define('BF_GOOGLE_CLIENT_SECRET', getenv('BF_GOOGLE_CLIENT_SECRET') ?: 'DAN_GOOGLE_CLIENT_SECRET_VAO_DAY');
define('BF_GOOGLE_REDIRECT_URI', getenv('BF_GOOGLE_REDIRECT_URI') ?: 'https://emotionalplaybox4-0.com/google-callback.php');

// CKEditor: đặt false để tắt editor nâng cao và dùng textarea thường.
define('BF_CKEDITOR_ENABLED', filter_var(getenv('BF_CKEDITOR_ENABLED') ?: 'true', FILTER_VALIDATE_BOOLEAN));
define('BF_APP_VERSION', '4.8.4-hotfix');

function getDbConnection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        try { $pdo->exec("SET time_zone = '+07:00'"); } catch (Throwable $ignore) {}
        return $pdo;
    } catch (PDOException $e) {
        error_log('[BrainFocus DB] ' . $e->getMessage());
        // Không trả chi tiết PDO ra client để tránh lộ cấu hình production
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Không thể kết nối cơ sở dữ liệu. Vui lòng kiểm tra cấu hình máy chủ.',
            'code'    => 'DB_CONNECTION_ERROR'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

/**
 * Trả về phản hồi JSON chuẩn
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Đọc dữ liệu JSON từ body của request
 */
function getJsonInput() {
    $raw = file_get_contents('php://input');
    if (empty($raw)) {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}
