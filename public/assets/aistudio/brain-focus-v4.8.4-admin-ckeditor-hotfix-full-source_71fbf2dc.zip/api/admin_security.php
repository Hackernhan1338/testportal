<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../includes/security.php';

function bfStartAdminSession(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (((getenv('BF_TRUST_CF') ?: '0') === '1') && (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'));
    session_name('BFADMINSESSID');
    if (PHP_VERSION_ID >= 70300) { session_set_cookie_params(['lifetime'=>0,'path'=>'/','domain'=>'','secure'=>$isHttps,'httponly'=>true,'samesite'=>'Strict']); } else { session_set_cookie_params(0, '/; samesite=Strict', '', $isHttps, true); }
    session_start();
}
function bfClientIp(): string { return bfRequestIp(); }
function bfDefaultRolePermissions(): array { return [
    'ANALYST'=>['dashboard.view','analytics.view','sessions.view','security.view'],
    'MODERATOR'=>['dashboard.view','analytics.view','sessions.view','content.view','content.create','content.edit','content.publish','feedback.view','feedback.reply','forbidden.view','honors.view'],
    'ADMIN'=>['dashboard.view','analytics.view','analytics.export','users.view','users.edit','users.lock','sessions.view','sessions.export','content.view','content.create','content.edit','content.delete','content.publish','feedback.view','feedback.reply','feedback.delete','settings.view','settings.update','audit.view','security.view','security.block','forbidden.view','forbidden.manage','honors.view','honors.manage','points.manage'],
    'SUPER_ADMIN'=>['*']
]; }
function bfAdminPermissions(PDO $pdo,string $role): array {
    if ($role==='SUPER_ADMIN') return ['*'];
    try { $st=$pdo->prepare("SELECT permission_key FROM bf_role_permissions WHERE role=? AND is_allowed=1"); $st->execute([$role]); $x=$st->fetchAll(PDO::FETCH_COLUMN); if($x) return array_values(array_unique($x)); } catch(Throwable $e){}
    return bfDefaultRolePermissions()[$role]??[];
}
function bfCurrentAdmin(PDO $pdo): ?array {
    bfStartAdminSession(); $id=$_SESSION['bf_admin_id']??null; if(!$id) return null;
    bfSecurityGate($pdo, null);
    try{$ss=$pdo->prepare("SELECT admin_id,user_agent FROM bf_admin_sessions WHERE session_hash=? AND expires_at>NOW() LIMIT 1");$ss->execute([hash('sha256',session_id())]);$sr=$ss->fetch();if(!$sr||(int)$sr['admin_id']!==(int)$id||!hash_equals((string)$sr['user_agent'],substr($_SERVER['HTTP_USER_AGENT']??'',0,255))){bfDestroyAdminSession($pdo);return null;}}catch(Throwable $e){}
    $loginAt=(int)($_SESSION['bf_login_at']??0); if($loginAt<=0 || (time()-$loginAt)>(8*3600)){ bfDestroyAdminSession($pdo); return null; }
    try { $st=$pdo->prepare("SELECT id,username,email,full_name,role,status,last_login,must_change_password FROM bf_admins WHERE id=? LIMIT 1"); $st->execute([$id]); $a=$st->fetch(); }
    catch(Throwable $e){ $st=$pdo->prepare("SELECT id,username,email,full_name,role,status,last_login FROM bf_admins WHERE id=? LIMIT 1"); $st->execute([$id]); $a=$st->fetch(); if($a)$a['must_change_password']=0; }
    if(!$a||$a['status']!=='ACTIVE'){ bfDestroyAdminSession($pdo); return null; }
    $a['permissions']=bfAdminPermissions($pdo,$a['role']); $a['must_change_password']=(bool)($a['must_change_password']??false); return $a;
}
function bfRequireAdmin(PDO $pdo): array { $a=bfCurrentAdmin($pdo); if(!$a) jsonResponse(['success'=>false,'message'=>'Phiên quản trị không hợp lệ hoặc đã hết hạn','code'=>'ADMIN_AUTH_REQUIRED'],401); return $a; }
function bfHasPermission(array $a,string $p): bool { $x=$a['permissions']??[]; return in_array('*',$x,true)||in_array($p,$x,true); }
function bfRequirePermission(array $a,string $p): void { if(!bfHasPermission($a,$p)) jsonResponse(['success'=>false,'message'=>'Bạn không có quyền thực hiện thao tác này','code'=>'FORBIDDEN'],403); }
function bfEnsureCsrfToken(): string { bfStartAdminSession(); if(empty($_SESSION['bf_csrf'])) $_SESSION['bf_csrf']=bin2hex(random_bytes(32)); return $_SESSION['bf_csrf']; }
function bfRequireCsrf(): void { bfStartAdminSession(); $p=$_SERVER['HTTP_X_CSRF_TOKEN']??''; $e=$_SESSION['bf_csrf']??''; if(!$e||!$p||!hash_equals($e,$p)) jsonResponse(['success'=>false,'message'=>'CSRF token không hợp lệ','code'=>'CSRF_FAILED'],419); }
function bfAudit(PDO $pdo,array $a,string $action,string $target,string $details=''): void { try{$st=$pdo->prepare("INSERT INTO bf_audit_logs(admin_id,admin_email,action,target,details,ip_address) VALUES(?,?,?,?,?,?)");$st->execute([(string)$a['id'],$a['email']??'',$action,$target,$details,bfClientIp()]);}catch(Throwable $e){} }
function bfRecordAdminSession(PDO $pdo,int $id): void { bfStartAdminSession(); try{$h=hash('sha256',session_id());$exp=date('Y-m-d H:i:s',time()+8*3600);$st=$pdo->prepare("INSERT INTO bf_admin_sessions(admin_id,session_hash,ip_address,user_agent,expires_at) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE ip_address=VALUES(ip_address),user_agent=VALUES(user_agent),expires_at=VALUES(expires_at),last_seen_at=NOW()");$st->execute([$id,$h,bfClientIp(),substr($_SERVER['HTTP_USER_AGENT']??'',0,255),$exp]);}catch(Throwable $e){} }
function bfDestroyAdminSession(?PDO $pdo=null): void { bfStartAdminSession(); if($pdo&&!empty($_SESSION['bf_admin_id'])){try{$pdo->prepare("DELETE FROM bf_admin_sessions WHERE session_hash=?")->execute([hash('sha256',session_id())]);}catch(Throwable $e){}} $_SESSION=[]; if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],(bool)$p['secure'],(bool)$p['httponly']);} if(session_status()===PHP_SESSION_ACTIVE)session_destroy(); }
