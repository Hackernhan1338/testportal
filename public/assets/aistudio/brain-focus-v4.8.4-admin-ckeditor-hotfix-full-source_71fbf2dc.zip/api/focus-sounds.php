<?php
require_once __DIR__.'/db.php';$pdo=getDbConnection();
try{$st=$pdo->prepare("SELECT setting_value FROM bf_settings WHERE setting_key='module_audio' LIMIT 1");$st->execute();$v=$st->fetchColumn();if(strtolower((string)$v)==='false')jsonResponse(['success'=>true,'data'=>[]]);}catch(Throwable $e){}
try{$rows=$pdo->query("SELECT id,sound_code,name,file_path,default_volume FROM bf_focus_sounds WHERE status='ACTIVE' ORDER BY sort_order,id")->fetchAll();jsonResponse(['success'=>true,'data'=>$rows]);}catch(Throwable $e){jsonResponse(['success'=>true,'data'=>[]]);}
