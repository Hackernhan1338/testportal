# Brain Focus v4

Brain Focus v4 là bản PHP-first, module hóa theo tư duy vận hành EduWall.

## Yêu cầu hosting
- PHP 7.2+ (khuyến nghị PHP 8.1/8.2; source có fallback cookie/session cho PHP 7.2)
- PDO MySQL
- MySQL 5.7+/8.0 hoặc MariaDB tương thích
- Apache/Hostinger có `.htaccess`
- HTTPS bắt buộc trên production

## Nâng cấp từ v3
1. Sao lưu file và database.
2. Import `sql/migration_2026_09_php_first.sql`.
3. Upload toàn bộ source v4, ghi đè source cũ.
4. Kiểm tra `/login.php` và `/admin/login.php`.
5. Vào `/admin/security.php` kiểm tra access log.
6. Vào `/admin/content.php` quản lý Kiến thức/Mẹo.
7. Vào `/admin/honors.php` kiểm tra ledger điểm/vinh danh.

## Cài mới
1. Tạo database.
2. Import `sql/schema.sql`.
3. Cấu hình biến môi trường DB hoặc sửa cấu hình phù hợp hosting.
4. Mở `/admin/setup.php` để tạo Super Admin đầu tiên.
5. Đăng ký tài khoản học viên ở `/login.php?mode=register`.

Đọc `NANG_CAP_PHP_FIRST_V4.md` để biết chi tiết kiến trúc/bảo mật.


## Nâng cấp v4.4
- Từ v4.3: chạy `sql/migration_2026_09_26_v44_features.sql` trước, sau đó upload source mới.
- Cài mới: `sql/schema.sql` đã bao gồm đầy đủ Gym attempts, CMS, leaderboard, thống kê Integrity/F11, khảo sát và Viện giám sát điểm.
- Không import lại dump production có email/IP thật vào source.
