<?php
require_once __DIR__.'/user_auth.php';
require_once __DIR__.'/metrics.php';
require_once __DIR__.'/community.php';
$pdo=getDbConnection();
bfSecurityGate($pdo,null);
if(function_exists('bfEnsureDefaultTerms')) bfEnsureDefaultTerms($pdo);

if(!function_exists('bfSetting')){
    function bfSetting(PDO $pdo,string $key,$default=null){
        static $cache=[];
        if(array_key_exists($key,$cache)) return $cache[$key];
        try{
            $st=$pdo->prepare("SELECT setting_value FROM bf_settings WHERE setting_key=? LIMIT 1");
            $st->execute([$key]);
            $v=$st->fetchColumn();
            if($v===false||$v===null||$v==='') return $cache[$key]=$default;
            return $cache[$key]=$v;
        }catch(Throwable $e){
            return $default;
        }
    }
}


if(!function_exists('bfModuleEnabled')){
    function bfModuleEnabled(PDO $pdo,string $key): bool {
        return strtolower((string)bfSetting($pdo,'module_'.$key,'true'))!=='false';
    }
}
if(!function_exists('bfEnforceModule')){
    function bfEnforceModule(PDO $pdo,string $key,string $label='Tính năng'): void {
        if(bfModuleEnabled($pdo,$key))return;
        http_response_code(503);
        echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.htmlspecialchars($label).' tạm dừng</title><script src="https://cdn.tailwindcss.com"></script></head><body class="min-h-screen bg-slate-950 text-white flex items-center justify-center p-4"><div class="max-w-lg w-full rounded-3xl bg-slate-900 border border-slate-800 p-8 text-center"><div class="text-5xl">⏸️</div><h1 class="mt-4 text-xl font-bold">'.htmlspecialchars($label).' đang tạm dừng</h1><p class="mt-2 text-sm text-slate-300">Ban quản trị đang tạm tắt module này. Các dữ liệu hiện có không bị xoá.</p><a class="inline-block mt-5 px-4 py-2 rounded-xl bg-white text-slate-900 font-semibold" href="/index.php">Về trang chính</a></div></body></html>';exit;
    }
}

if(!function_exists('bfIsMaintenanceActive')){
    function bfIsMaintenanceActive(PDO $pdo): bool {
        return strtolower((string)bfSetting($pdo,'maintenance_mode','false'))==='true';
    }
}

if(!function_exists('bfRenderMaintenancePage')){
    function bfRenderMaintenancePage(PDO $pdo): void {
        $title=(string)bfSetting($pdo,'maintenance_title','Hệ thống đang bảo trì');
        $message=(string)bfSetting($pdo,'maintenance_message','Brain Focus đang được nâng cấp để phục vụ tốt hơn. Vui lòng quay lại sau.');
        http_response_code(503);
        echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.htmlspecialchars($title).'</title><script src="https://cdn.tailwindcss.com"></script></head><body class="min-h-screen bg-slate-950 text-white flex items-center justify-center p-4"><div class="max-w-xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl text-center"><div class="text-5xl mb-4">🛠️</div><h1 class="font-bold text-2xl">'.htmlspecialchars($title).'</h1><p class="text-slate-300 text-sm mt-4 leading-7">'.nl2br(htmlspecialchars($message)).'</p><p class="text-xs text-slate-500 mt-6">Mã trạng thái: 503 · Maintenance Mode</p></div></body></html>';
        exit;
    }
}



if(!function_exists('bfTrackPageVisit')){
    function bfTrackPageVisit(PDO $pdo,$user=null): void {
        if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET')return;
        $path=(string)($_SERVER['REQUEST_URI']??'/');
        if(strpos($path,'/assets/')===0 || strpos($path,'/api/')===0 || strpos($path,'/admin/')===0)return;
        try{
            $st=$pdo->prepare("INSERT INTO bf_page_visits(user_id,user_email,request_path,referrer,ip_address,user_agent) VALUES(?,?,?,?,?,?)");
            $st->execute([$user['id']??null,$user['email']??null,substr($path,0,500),substr((string)($_SERVER['HTTP_REFERER']??''),0,1000),bfRequestIp(),substr(bfUserAgent(),0,500)]);
        }catch(Throwable $e){}
    }
}
if(!function_exists('bfEnsureCurrentLeaderboardMember')){
    function bfEnsureCurrentLeaderboardMember(PDO $pdo,array $user): void {
        try{
            $round=$pdo->query("SELECT id FROM bf_leaderboard_rounds WHERE status='ACTIVE' ORDER BY id DESC LIMIT 1")->fetchColumn();
            if(!$round)return;
            $score=bfUserTotalScore($pdo,$user);
            $pdo->prepare("INSERT IGNORE INTO bf_leaderboard_round_members(round_id,user_id,baseline_score) VALUES(?,?,?)")->execute([(int)$round,(int)$user['id'],(int)$score['total_score']]);
        }catch(Throwable $e){}
    }
}
$user=bfCurrentUser($pdo);
if($user){ bfSecurityGate($pdo,$user['email']); if(function_exists('bfRefreshStudyStreak')){$user['streak_days']=bfRefreshStudyStreak($pdo,$user);} if(function_exists('bfSyncAutomaticTasks')) bfSyncAutomaticTasks($pdo,$user); bfEnsureCurrentLeaderboardMember($pdo,$user); if(function_exists('bfGeneratePersonalNotifications')) bfGeneratePersonalNotifications($pdo,$user); if(function_exists('bfCheckRookieOnboarding')) bfCheckRookieOnboarding($pdo,$user); }
bfTrackPageVisit($pdo,$user);

$script=basename((string)($_SERVER['SCRIPT_NAME']??''));
$maintenanceExempt=['login.php','change-password.php','logout.php'];
if(!$user && !in_array($script,$maintenanceExempt,true) && bfIsMaintenanceActive($pdo)){
    bfRenderMaintenancePage($pdo);
}
