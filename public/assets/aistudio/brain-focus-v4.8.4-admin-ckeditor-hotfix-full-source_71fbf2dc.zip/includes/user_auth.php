<?php
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/terms.php';

function bfStartUserSession(): void {
    if(session_status()===PHP_SESSION_ACTIVE)return;
    $https=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off');
    session_name('BFUSERSESSID');
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
    } else {
        session_set_cookie_params(0, '/; samesite=Lax', '', $https, true);
    }
    session_start();
}

function bfCurrentUser(PDO $pdo): ?array {
    bfStartUserSession(); $id=(int)($_SESSION['bf_user_id']??0); if(!$id)return null;
    if((time()-(int)($_SESSION['bf_user_login_at']??0))>86400*14){bfLogoutUser($pdo);return null;}
    try{
        $ss=$pdo->prepare("SELECT user_id,device_hash FROM bf_user_sessions WHERE session_hash=? AND expires_at>NOW() LIMIT 1");
        $ss->execute([hash('sha256',session_id())]);$sr=$ss->fetch();
        if(!$sr||(int)$sr['user_id']!==$id||!hash_equals((string)$sr['device_hash'],bfDeviceHash())){bfLogoutUser($pdo);return null;}
    }catch(Throwable $e){ /* cho phép migration chạy trước khi kích hoạt session DB */ }
    try {
        $st=$pdo->prepare("SELECT id,email,name,school,avatar,role,status,rank_points,bfs_score,bfs_assessment_score,purchased_gym_plays,total_hours,streak_days,sessions_count,gym_count,must_change_password,password_changed_at,last_login_at,last_ip,last_user_agent,last_device_hash,google_sub,google_linked_at,birthday,gender,province,target_school,study_unit,quote_text,quote_author,profile_visibility,onboarding_seen_at,onboarding_completed_at,email_updates_opt_in,email_updates_decided_at,created_at FROM bf_users WHERE id=? LIMIT 1");
        $st->execute([$id]);$u=$st->fetch();
    } catch (Throwable $e) {
        // Tương thích tạm với schema cũ để tránh HTTP 500 trước khi chạy migration.
        $st=$pdo->prepare("SELECT id,email,name,school,avatar,role,status,rank_points,bfs_score,purchased_gym_plays,total_hours,streak_days,sessions_count,gym_count,created_at FROM bf_users WHERE id=? LIMIT 1");
        $st->execute([$id]);$u=$st->fetch();
        if($u){$u['bfs_assessment_score']=0;$u['must_change_password']=0;$u['password_changed_at']=null;$u['last_login_at']=null;$u['last_ip']=null;$u['last_user_agent']=null;$u['last_device_hash']=null;$u['google_sub']=null;$u['google_linked_at']=null;$u['birthday']=null;$u['gender']=null;$u['province']=null;$u['target_school']=null;$u['study_unit']=null;$u['quote_text']=null;$u['quote_author']=null;$u['profile_visibility']='PUBLIC';$u['onboarding_seen_at']=date('Y-m-d H:i:s');$u['onboarding_completed_at']=null;$u['email_updates_opt_in']=0;$u['email_updates_decided_at']=date('Y-m-d H:i:s');}
    }
    if(!$u||$u['status']!=='ACTIVE'){bfLogoutUser($pdo);return null;}
    try{$pdo->prepare("UPDATE bf_user_sessions SET last_seen_at=NOW(),ip_address=?,user_agent=? WHERE session_hash=?")->execute([bfRequestIp(),bfUserAgent(),hash('sha256',session_id())]);}catch(Throwable $e){}
    return $u;
}



function bfPendingBfsCampaign(PDO $pdo, int $userId): ?array {
    try {
        $st=$pdo->prepare("SELECT c.id campaign_id,c.title,c.reward_bfs,t.penalty_level,t.created_at target_created_at FROM bf_bfs_retake_campaign_targets t JOIN bf_bfs_retake_campaigns c ON c.id=t.campaign_id WHERE t.user_id=? AND t.status='PENDING' AND c.status='ACTIVE' ORDER BY c.id DESC LIMIT 1");
        $st->execute([$userId]);
        $row=$st->fetch();
        return $row?:null;
    } catch (Throwable $e) {
        return null;
    }
}

function bfRequireUser(PDO $pdo): array {
    $u=bfCurrentUser($pdo);
    if(!$u){$next=urlencode($_SERVER['REQUEST_URI']??'/');header('Location: /login.php?next='.$next);exit;}
    bfSecurityGate($pdo,$u['email']);
    $script=basename((string)($_SERVER['SCRIPT_NAME']??''));
    if(!empty($u['must_change_password']) && $script!=='change-password.php' && $script!=='logout.php'){
        header('Location: /change-password.php?required=1');exit;
    }
    if(!in_array($script,['terms-accept.php','terms.php','logout.php','change-password.php'],true)){
        $terms=bfCurrentTerms($pdo);
        if($terms && !bfTermsAccepted($pdo,(int)$u['id'],(int)$terms['id'])){
            header('Location: /terms-accept.php?required=1');exit;
        }
    }
    if(empty($u['onboarding_seen_at']) && !in_array($script,['onboarding.php','logout.php','change-password.php','terms-accept.php','terms.php'],true)){header('Location: /onboarding.php');exit;}
    if(!in_array($script,['assessment.php','logout.php','change-password.php','terms-accept.php','terms.php'],true)){
        $campaign=bfPendingBfsCampaign($pdo,(int)$u['id']);
        if($campaign){header('Location: /assessment.php?required=1&campaign='.(int)$campaign['campaign_id']);exit;}
    }
    return $u;
}

function bfLoginUser(PDO $pdo, array $u): void {
    bfStartUserSession(); session_regenerate_id(true); $_SESSION['bf_user_id']=(int)$u['id'];$_SESSION['bf_user_login_at']=time();$_SESSION['bf_user_csrf']=bin2hex(random_bytes(32));
    $sessionHash=hash('sha256',session_id());$deviceHash=bfDeviceHash();$ip=bfRequestIp();$ua=bfUserAgent();
    try{$pdo->prepare("INSERT INTO bf_user_sessions(user_id,session_hash,device_hash,ip_address,user_agent,expires_at) VALUES(?,?,?,?,?,DATE_ADD(NOW(),INTERVAL 14 DAY)) ON DUPLICATE KEY UPDATE device_hash=VALUES(device_hash),ip_address=VALUES(ip_address),user_agent=VALUES(user_agent),last_seen_at=NOW(),expires_at=VALUES(expires_at)")->execute([(int)$u['id'],$sessionHash,$deviceHash,$ip,$ua]);}catch(Throwable $e){}
    $bfWasKnownDevice=true;try{$q=$pdo->prepare("SELECT COUNT(*) FROM bf_user_devices WHERE user_email=? AND device_hash=?");$q->execute([$u['email'],$deviceHash]);$bfWasKnownDevice=((int)$q->fetchColumn()>0);}catch(Throwable $e){}
    try{$pdo->prepare("INSERT INTO bf_user_devices(user_email,device_hash,device_name,last_ip,last_seen_at) VALUES(?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE device_name=VALUES(device_name),last_ip=VALUES(last_ip),last_seen_at=NOW()")->execute([$u['email'],$deviceHash,substr($ua,0,191),$ip]);}catch(Throwable $e){}
    if(!$bfWasKnownDevice && function_exists('bfNotifyUser')){bfNotifyUser($pdo,(string)$u['email'],'🔐 Đăng nhập trên thiết bị mới','Brain Focus vừa ghi nhận một thiết bị mới đăng nhập vào tài khoản của bạn. Nếu không phải bạn, hãy đổi mật khẩu và liên hệ BQT.','SECURITY','warning','/profile.php','device-login:'.$deviceHash,'HIGH');}
    try{$pdo->prepare("UPDATE bf_users SET last_login_at=NOW(),last_ip=?,last_user_agent=?,last_device_hash=? WHERE id=?")->execute([$ip,$ua,$deviceHash,(int)$u['id']]);}catch(Throwable $e){}
}

function bfLogoutUser(?PDO $pdo=null): void {bfStartUserSession();if($pdo){try{$pdo->prepare("DELETE FROM bf_user_sessions WHERE session_hash=?")->execute([hash('sha256',session_id())]);}catch(Throwable $e){}}$_SESSION=[];if(session_status()===PHP_SESSION_ACTIVE)session_destroy();}
function bfUserCsrf(): string {bfStartUserSession();if(empty($_SESSION['bf_user_csrf']))$_SESSION['bf_user_csrf']=bin2hex(random_bytes(32));return $_SESSION['bf_user_csrf'];}
function bfCheckUserCsrf(): void {$p=(string)($_POST['_csrf']??$_SERVER['HTTP_X_CSRF_TOKEN']??'');if(!$p||!hash_equals((string)($_SESSION['bf_user_csrf']??''),$p)){http_response_code(419);exit('CSRF token không hợp lệ');}}

function bfRecordLoginHistory(PDO $pdo, string $email, bool $success, string $actorType='USER'): void {
    try{
        $st=$pdo->prepare("INSERT INTO bf_login_history(user_email,actor_type,success,ip_address,user_agent) VALUES(?,?,?,?,?)");
        $st->execute([$email,$actorType,$success?1:0,bfRequestIp(),substr(bfUserAgent(),0,255)]);
    }catch(Throwable $e){
        // Tương thích schema login_history kiểu cũ/status nếu có.
        try{$pdo->prepare("INSERT INTO bf_login_history(user_email,status,ip_address,user_agent) VALUES(?,?,?,?)")->execute([$email,$success?'SUCCESS':'FAILED',bfRequestIp(),substr(bfUserAgent(),0,255)]);}catch(Throwable $ignored){}
    }
}

function bfMarkPasswordChanged(PDO $pdo, array $u): void {
    $ip=bfRequestIp();$ua=bfUserAgent();$dev=bfDeviceHash();
    try{$pdo->prepare("UPDATE bf_users SET must_change_password=0,password_changed_at=NOW(),last_login_at=NOW(),last_ip=?,last_user_agent=?,last_device_hash=? WHERE id=?")->execute([$ip,$ua,$dev,(int)$u['id']]);}catch(Throwable $e){}
    try{$pdo->prepare("INSERT INTO bf_user_devices(user_email,device_hash,device_name,last_ip,last_seen_at) VALUES(?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE device_name=VALUES(device_name),last_ip=VALUES(last_ip),last_seen_at=NOW()")->execute([$u['email'],$dev,substr($ua,0,191),$ip]);}catch(Throwable $e){}
    try{$current=hash('sha256',session_id());$pdo->prepare("DELETE FROM bf_user_sessions WHERE user_id=? AND session_hash<>?")->execute([(int)$u['id'],$current]);}catch(Throwable $e){}
    bfLogAccess($pdo,['user_id'=>$u['id'],'email'=>$u['email'],'event_type'=>'PASSWORD_CHANGED']);
}

function bfEvaluateHonors(PDO $pdo,int $userId): void {
    try{
        $st=$pdo->prepare("SELECT u.*, (SELECT COALESCE(AVG(focus_integrity),0) FROM bf_study_sessions s WHERE s.user_email=u.email) avg_integrity FROM bf_users u WHERE u.id=?");$st->execute([$userId]);$u=$st->fetch();if(!$u)return;
        $honors=$pdo->query("SELECT * FROM bf_honors WHERE status='ACTIVE' AND metric<>'MANUAL'")->fetchAll();
        foreach($honors as $h){$v=0;switch($h['metric']){case'SESSIONS':$v=(float)$u['sessions_count'];break;case'HOURS':$v=(float)$u['total_hours'];break;case'STREAK':$v=(float)$u['streak_days'];break;case'INTEGRITY':$v=(float)$u['avg_integrity'];break;case'POINTS':$v=(float)$u['rank_points'];break;}if($v<(float)$h['threshold_value'])continue;
            $ins=$pdo->prepare("INSERT IGNORE INTO bf_user_honors(user_id,honor_id,note) VALUES(?,?,?)");$ins->execute([$userId,$h['id'],'Tự động cấp theo tiêu chí']);if($ins->rowCount()>0){if(function_exists('bfNotifyUser'))bfNotifyUser($pdo,(string)$u['email'],'🏆 Danh hiệu mới: '.$h['title'],'Bạn vừa đạt một danh hiệu mới trong Brain Focus.','ACHIEVEMENT','success','/achievements.php','honor:'.$h['id'].':'.$userId,'NORMAL');}if($ins->rowCount()>0&&(int)$h['reward_points']!==0){$pdo->prepare("UPDATE bf_users SET rank_points=rank_points+? WHERE id=?")->execute([(int)$h['reward_points'],$userId]);$pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'HONOR','HONOR_AWARD',?,'HONOR',?)")->execute([$userId,(int)$h['reward_points'],'Vinh danh: '.$h['title'],(string)$h['id']]);}
        }
    }catch(Throwable $e){}
}
