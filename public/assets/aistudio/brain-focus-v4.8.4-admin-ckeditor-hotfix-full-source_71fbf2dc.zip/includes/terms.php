<?php
function bfDefaultTermsHtml(){
return <<<'HTML'
<section class="space-y-4 text-sm leading-7 text-slate-700">
<h2 class="text-xl font-bold text-slate-900">ĐIỀU KHOẢN SỬ DỤNG VÀ CHÍNH SÁCH BẢO VỆ DỮ LIỆU BRAIN FOCUS</h2>
<p><b>Brain Focus</b> là nền tảng hỗ trợ học tập tập trung, rèn luyện phản xạ, theo dõi tiến độ học tập, thực hiện khảo sát BFS và cung cấp các công cụ hỗ trợ người học cải thiện thói quen tập trung. Việc tạo tài khoản, đăng nhập hoặc tiếp tục sử dụng Brain Focus đồng nghĩa với việc người dùng đã đọc, hiểu và đồng ý với các điều khoản được công bố tại thời điểm sử dụng.</p>
<h3 class="font-bold text-slate-900">1. Mục đích sử dụng</h3><p>Brain Focus được phát triển để hỗ trợ quản lý thời gian học, Pomodoro/Deep Focus, thống kê phiên học, rèn luyện phản xạ, khảo sát BFS, đúc kết, bảng xếp hạng và nội dung kiến thức. Brain Focus không phải công cụ chẩn đoán y khoa, tâm lý hoặc thần kinh.</p>
<h3 class="font-bold text-slate-900">2. Tài khoản</h3><p>Người dùng có trách nhiệm cung cấp thông tin hợp lý, bảo vệ mật khẩu Brain Focus và chịu trách nhiệm với hoạt động phát sinh từ tài khoản của mình, trừ trường hợp bị truy cập trái phép ngoài khả năng kiểm soát.</p>
<h3 class="font-bold text-slate-900">3. Brain Focus không thu mật khẩu Gmail/Google</h3><p>Brain Focus không yêu cầu và không thu thập mật khẩu Gmail, mật khẩu Google hoặc mật khẩu email cá nhân. Khi dùng đăng nhập Google, hệ thống chỉ nhận thông tin được Google cung cấp sau khi người dùng cấp quyền, như mã định danh tài khoản, email đã xác minh, tên và ảnh đại diện. Khi quên mật khẩu, người dùng chỉ nhập email để nhận OTP.</p>
<h3 class="font-bold text-slate-900">4. Bảo vệ mật khẩu</h3><p>Mật khẩu Brain Focus không được lưu dưới dạng văn bản có thể đọc trực tiếp mà được xử lý bằng cơ chế hash mật khẩu. Hệ thống áp dụng phiên đăng nhập, CSRF token, phân quyền quản trị, nhật ký hoạt động và OTP cho khôi phục mật khẩu. Không có hệ thống Internet nào có thể cam kết an toàn tuyệt đối 100%.</p>
<h3 class="font-bold text-slate-900">5. Dữ liệu có thể được xử lý</h3><p>Hệ thống có thể xử lý thông tin tài khoản; dữ liệu phiên học; thời gian học; trạng thái toàn màn hình/chuyển tab; Focus Integrity; dữ liệu Gym não; câu trả lời BFS; điểm/XP; đúc kết; phản hồi và dữ liệu kỹ thuật phục vụ bảo mật như IP, User-Agent, mã thiết bị ngẫu nhiên và thời gian đăng nhập.</p>
<h3 class="font-bold text-slate-900">6. Không thu địa chỉ chính xác</h3><p>Brain Focus không chủ động thu GPS, tọa độ hoặc địa chỉ nhà chính xác của thiết bị. IP chỉ được sử dụng chủ yếu cho bảo mật, chống spam, phát hiện bất thường và nhật ký kỹ thuật.</p>
<h3 class="font-bold text-slate-900">7. Camera, micro và danh bạ</h3><p>Brain Focus không tự động truy cập camera, microphone, danh bạ, tin nhắn hoặc thư viện ảnh. Chỉ khi người dùng chủ động chọn ảnh đại diện hoặc ảnh báo lỗi thì tệp được chọn mới được gửi lên hệ thống.</p>
<h3 class="font-bold text-slate-900">8. Theo dõi phiên học</h3><p>Hệ thống có thể ghi nhận việc chuyển tab, trạng thái toàn màn hình, tạm dừng, thời lượng và hoàn thành phiên. Focus Integrity là chỉ số kỹ thuật tham khảo dựa trên các tín hiệu quan sát được, không phải kết luận tuyệt đối về sự tập trung của một cá nhân.</p>
<h3 class="font-bold text-slate-900">9. BFS</h3><p>BFS là chỉ số nội bộ nhằm hỗ trợ người dùng tự đánh giá thói quen tập trung. BFS không phải IQ, không phải chẩn đoán bệnh và không phải kết luận y khoa.</p>
<h3 class="font-bold text-slate-900">10. Câu kiểm tra chú ý</h3><p>Một số khảo sát có thể có câu kiểm tra chú ý được trình bày giống câu bình thường nhằm hạn chế việc chọn ngẫu nhiên. Nếu không vượt qua, hệ thống có thể yêu cầu làm lại, giảm hoặc không cấp thưởng.</p>
<h3 class="font-bold text-slate-900">11. Điểm, XP và bảng xếp hạng</h3><p>Điểm XH, XP, BFS, Level, danh hiệu và bảng xếp hạng chỉ có giá trị trong Brain Focus, không có giá trị quy đổi thành tiền. Công thức có thể được điều chỉnh để cân bằng hệ thống, khắc phục lỗi hoặc chống gian lận.</p>
<h3 class="font-bold text-slate-900">12. Bảng xếp hạng theo đợt</h3><p>Khi một đợt được chốt, kết quả của đợt đó có thể được giữ cố định; điểm phát sinh sau thời điểm chốt có thể được tính cho đợt tiếp theo.</p>
<h3 class="font-bold text-slate-900">13. Chống gian lận</h3><p>Hệ thống có thể đánh dấu dữ liệu bất thường như điểm tăng quá nhanh, kết quả không phù hợp lịch sử hoặc cố tình sửa request. Việc bị đánh dấu không đồng nghĩa chắc chắn gian lận; quản trị viên có thể kiểm tra thủ công trước khi xử lý.</p>
<h3 class="font-bold text-slate-900">14. Hành vi không được phép</h3><p>Không được khai thác lỗi để tăng điểm, truy cập trái phép, gửi mã độc, thực hiện SQL Injection/XSS, spam, phá hoại dữ liệu hoặc sử dụng thông tin người khác trái phép.</p>
<h3 class="font-bold text-slate-900">15. Nội dung do người dùng cung cấp</h3><p>Người dùng chịu trách nhiệm với ảnh đại diện, đúc kết, phản hồi và dữ liệu do mình gửi. Brain Focus có thể loại bỏ nội dung spam, mã độc, vi phạm pháp luật hoặc gây ảnh hưởng hệ thống.</p>
<h3 class="font-bold text-slate-900">16. Phản hồi và ảnh sự cố</h3><p>Khi gửi phản hồi, hệ thống có thể lưu nội dung, email nhận phản hồi, ảnh sự cố, thời gian và trạng thái xử lý. Không nên gửi mật khẩu, OTP, thông tin ngân hàng hoặc giấy tờ cá nhân không cần thiết.</p>
<h3 class="font-bold text-slate-900">17. Thống kê và nghiên cứu</h3><p>Dữ liệu tổng hợp có thể được sử dụng để cải thiện sản phẩm hoặc phục vụ nghiên cứu. Khi dùng cho nghiên cứu, Brain Focus ưu tiên ẩn danh hóa và loại bỏ thông tin nhận dạng không cần thiết. Nghiên cứu yêu cầu dữ liệu vượt phạm vi thông thường cần thông báo và xin sự đồng ý phù hợp.</p>
<h3 class="font-bold text-slate-900">18. Không bán dữ liệu cá nhân</h3><p>Brain Focus cam kết không bán thông tin cá nhân của người dùng cho bên thứ ba nhằm mục đích quảng cáo hoặc khai thác thương mại dữ liệu.</p>
<h3 class="font-bold text-slate-900">19. Dịch vụ bên thứ ba</h3><p>Một số chức năng có thể phụ thuộc Gmail SMTP, Google OAuth, nhà cung cấp hosting, tên miền, CDN hoặc thư viện giao diện. Các dịch vụ bên thứ ba có chính sách riêng của họ.</p>
<h3 class="font-bold text-slate-900">20. Email hệ thống</h3><p>Brain Focus có thể gửi OTP, thông báo tài khoản, sự kiện, cập nhật điều khoản hoặc thông tin vận hành. Brain Focus không yêu cầu người dùng gửi lại OTP hoặc mật khẩu qua email.</p>
<h3 class="font-bold text-slate-900">21. Lưu trữ dữ liệu</h3><p>Dữ liệu được lưu trong thời gian cần thiết để vận hành tài khoản, thống kê học tập, bảo mật, kiểm toán và xử lý phản hồi. Một số log kỹ thuật có thể được xóa theo chính sách vận hành.</p>
<h3 class="font-bold text-slate-900">22. Quyền của người dùng</h3><p>Trong phạm vi hệ thống hỗ trợ, người dùng có thể cập nhật hồ sơ, đổi mật khẩu, xem dữ liệu học tập, điểm và kết quả BFS; đồng thời có thể liên hệ quản trị viên khi cần hỗ trợ về dữ liệu tài khoản.</p>
<h3 class="font-bold text-slate-900">23. Học sinh và người dùng trẻ tuổi</h3><p>Người dùng nên tuân thủ quy định của gia đình, nhà trường và pháp luật áp dụng. Không nên cung cấp địa chỉ nhà, số giấy tờ tùy thân hoặc thông tin tài chính nếu không cần thiết.</p>
<h3 class="font-bold text-slate-900">24. Độ chính xác của số liệu</h3><p>Số liệu có thể bị ảnh hưởng bởi trình duyệt, mất mạng, thiết bị tắt đột ngột hoặc giới hạn kỹ thuật; vì vậy chúng nên được xem là công cụ hỗ trợ, không phải bằng chứng tuyệt đối.</p>
<h3 class="font-bold text-slate-900">25. Bảo trì và gián đoạn</h3><p>Brain Focus có thể tạm ngừng một số chức năng để bảo trì, sửa lỗi, nâng cấp cơ sở dữ liệu hoặc xử lý sự cố bảo mật.</p>
<h3 class="font-bold text-slate-900">26. Thay đổi tính năng</h3><p>Các tính năng, giao diện, điểm thưởng hoặc cơ chế có thể được thêm, sửa, giới hạn hoặc thay thế để cải thiện hệ thống. Những thay đổi quan trọng nên được thông báo.</p>
<h3 class="font-bold text-slate-900">27. Giới hạn trách nhiệm</h3><p>Brain Focus là công cụ hỗ trợ học tập và không bảo đảm rằng việc sử dụng nền tảng sẽ tự động làm tăng điểm số hoặc khả năng tập trung.</p>
<h3 class="font-bold text-slate-900">28. Quyền sở hữu</h3><p>Giao diện, mã nguồn và nội dung do Brain Focus tự phát triển thuộc phạm vi quyền sở hữu phù hợp; thư viện bên thứ ba tuân theo giấy phép riêng.</p>
<h3 class="font-bold text-slate-900">29. Khóa tài khoản</h3><p>Brain Focus có thể tạm khóa hoặc hạn chế tài khoản khi phát hiện hành vi tấn công, gian lận có chủ đích, spam hoặc phá hoại dữ liệu.</p>
<h3 class="font-bold text-slate-900">30. Cập nhật điều khoản</h3><p>Khi điều khoản thay đổi đáng kể, Brain Focus sẽ công bố phiên bản mới và có thể yêu cầu người dùng xác nhận lại trước khi tiếp tục sử dụng các chức năng chính.</p>
<h3 class="font-bold text-slate-900">31. Cam kết riêng tư ngắn gọn</h3><ul class="list-disc pl-5"><li>Không yêu cầu hoặc thu mật khẩu Gmail/Google.</li><li>Không chủ động thu GPS hoặc địa chỉ chính xác của thiết bị.</li><li>Không bán dữ liệu cá nhân cho nhà quảng cáo.</li><li>Không lưu mật khẩu Brain Focus dưới dạng văn bản thuần.</li><li>Không coi BFS hoặc Focus Integrity là kết luận y khoa.</li></ul>
<h3 class="font-bold text-slate-900">32. Liên hệ</h3><p>Hỗ trợ Brain Focus: <b>thiennhan1338@gmail.com</b>. Người dùng có thể liên hệ khi có vấn đề về tài khoản, dữ liệu, bảo mật, khiếu nại hoặc lỗi hệ thống.</p>
</section>
HTML;
}


function bfEnsureDefaultTerms(PDO $pdo): void {
    try{
        $count=(int)$pdo->query("SELECT COUNT(*) FROM bf_terms_versions WHERE status='PUBLISHED'")->fetchColumn();
        if($count===0){
            $st=$pdo->prepare("INSERT INTO bf_terms_versions(version,title,content_html,reward_xp,status,published_at) VALUES('1.0','Điều khoản sử dụng & Chính sách bảo vệ dữ liệu Brain Focus',?,50,'PUBLISHED',NOW())");
            $st->execute([bfDefaultTermsHtml()]);
        }
    }catch(Throwable $e){}
}
function bfCurrentTerms(PDO $pdo){
    try{$st=$pdo->query("SELECT * FROM bf_terms_versions WHERE status='PUBLISHED' ORDER BY published_at DESC,id DESC LIMIT 1");$r=$st->fetch();return $r?:null;}catch(Throwable $e){return null;}
}
function bfTermsAccepted(PDO $pdo,int $userId,int $termsId): bool{
    try{$st=$pdo->prepare("SELECT 1 FROM bf_terms_acceptances WHERE user_id=? AND terms_id=? LIMIT 1");$st->execute([$userId,$termsId]);return (bool)$st->fetchColumn();}catch(Throwable $e){return false;}
}
function bfUnreadNotificationsCount(PDO $pdo,string $email): int{
    try{$st=$pdo->prepare("SELECT COUNT(*) FROM bf_notifications WHERE (user_email=? OR user_email IS NULL) AND is_read=0");$st->execute([$email]);return (int)$st->fetchColumn();}catch(Throwable $e){return 0;}
}
