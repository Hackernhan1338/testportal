<?php
if(!isset($pageTitle))$pageTitle='Brain Focus';
if(!isset($activePage))$activePage='focus';
$u=is_array($user??null)?$user:[];
$rankPoints=(int)($u['rank_points']??1000);
$bfsScore=(int)($u['bfs_score']??1000);
$totalScore=$rankPoints+$bfsScore;if(!empty($u['id'])&&isset($pdo)){try{$__bfsc=bfUserTotalScore($pdo,$u);$totalScore=(int)$__bfsc['total_score'];}catch(Throwable $e){}}
$streak=max(1,(int)($u['streak_days']??1));
$userName=(string)($u['name']??'Tài khoản');
$initial=function_exists('mb_substr')?mb_strtoupper(mb_substr($userName,0,1,'UTF-8'),'UTF-8'):strtoupper(substr($userName,0,1));
$isAuthed=!empty($u['id']);
$notificationUnread=($isAuthed&&isset($pdo))?bfUnreadNotificationsCount($pdo,(string)$u['email']):0;
$bfModules=[];foreach(['focus','gym','knowledge','tips','leaderboard','achievements','feedback','notifications','audio'] as $__m){$bfModules[$__m]=isset($pdo)?bfModuleEnabled($pdo,$__m):true;}

$seoSite=isset($pdo)?(string)bfSetting($pdo,'seo_site_name','Brain Focus'):'Brain Focus';$seoDescription=isset($pdo)?(string)bfSetting($pdo,'seo_site_description','Brain Focus hỗ trợ học tập tập trung, Deep Focus, Gym não, BFS, thống kê tiến độ và thi đua học tập.'):'Brain Focus hỗ trợ học tập tập trung.';$seoKeywords=isset($pdo)?(string)bfSetting($pdo,'seo_keywords','brain focus,tập trung,học tập'):'brain focus,tập trung,học tập';if(isset($pdo)){if($activePage==='focus'){$pageTitle=(string)bfSetting($pdo,'seo_index_title',$pageTitle);$seoDescription=(string)bfSetting($pdo,'seo_index_description',$seoDescription);}elseif($activePage==='knowledge'){$pageTitle=(string)bfSetting($pdo,'seo_knowledge_title',$pageTitle);$seoDescription=(string)bfSetting($pdo,'seo_knowledge_description',$seoDescription);}elseif($activePage==='leaderboard'){$pageTitle=(string)bfSetting($pdo,'seo_leaderboard_title',$pageTitle);$seoDescription=(string)bfSetting($pdo,'seo_leaderboard_description',$seoDescription);}elseif($activePage==='gym'){$pageTitle=(string)bfSetting($pdo,'seo_gym_title',$pageTitle);$seoDescription=(string)bfSetting($pdo,'seo_gym_description',$seoDescription);}}$seoOg=isset($pdo)?trim((string)bfSetting($pdo,'seo_og_image','')):'';$favicon=isset($pdo)?trim((string)bfSetting($pdo,'site_favicon_url','')):'';$scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';$canonical=$scheme.'://'.($_SERVER['HTTP_HOST']??'localhost').strtok((string)($_SERVER['REQUEST_URI']??'/'),'?');
function bfNavClass($active,$key,$mobile=false){
  if($mobile){return $active===$key?'bg-slate-900 text-white shadow-xs':'text-slate-600 hover:text-slate-900 hover:bg-slate-100';}
  return $active===$key?'bg-slate-900 text-white shadow-xs font-semibold':'text-slate-600 hover:text-slate-900 hover:bg-slate-100 font-medium';
}
?>
<!DOCTYPE html>
<html lang="vi" class="h-full">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <meta name="theme-color" content="#0f172a">
  <title><?=htmlspecialchars($pageTitle.(stripos($pageTitle,$seoSite)===false?' · '.$seoSite:''))?></title>
  <meta name="description" content="<?=htmlspecialchars($seoDescription)?>">
  <meta name="keywords" content="<?=htmlspecialchars($seoKeywords)?>">
  <meta name="robots" content="index,follow,max-image-preview:large">
  <link rel="canonical" href="<?=htmlspecialchars($canonical)?>">
  <meta property="og:site_name" content="<?=htmlspecialchars($seoSite)?>">
  <meta property="og:title" content="<?=htmlspecialchars($pageTitle.(stripos($pageTitle,$seoSite)===false?' · '.$seoSite:''))?>">
  <meta property="og:description" content="<?=htmlspecialchars($seoDescription)?>">
  <meta property="og:url" content="<?=htmlspecialchars($canonical)?>">
  <meta property="og:type" content="website">
  <meta property="og:locale" content="vi_VN">
  <meta name="twitter:card" content="summary_large_image">
  <script type="application/ld+json"><?=json_encode(["@context"=>"https://schema.org","@type"=>"WebSite","name"=>$seoSite,"url"=>$scheme."://".($_SERVER["HTTP_HOST"]??"localhost"),"description"=>$seoDescription],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?></script>
  <?php if($seoOg):?><meta property="og:image" content="<?=htmlspecialchars($seoOg)?>"><?php endif;?>
  <?php if($favicon):?><link rel="icon" href="<?=htmlspecialchars($favicon)?>"><?php else:?><link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🧠</text></svg>"><?php endif;?>
  <link rel="stylesheet" href="/assets/css/site.css?v=4.4.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
  <script>
    tailwind.config={darkMode:'class',theme:{extend:{fontFamily:{sans:['Inter','-apple-system','BlinkMacSystemFont','Segoe UI','Roboto','sans-serif'],mono:['JetBrains Mono','ui-monospace','SFMono-Regular','Menlo','monospace']},colors:{slate:{750:'#293548',850:'#151e2e',950:'#0b0f19'},brand:{50:'#eff6ff',100:'#dbeafe',200:'#bfdbfe',500:'#3b82f6',600:'#2563eb',700:'#1d4ed8',800:'#1e40af',900:'#1e3a8a'}}}}};
    window.BF_USER_AUTHENTICATED=<?= $isAuthed?'true':'false' ?>;
  </script>
  <link rel="stylesheet" href="/assets/css/app.css?v=4.4.0">
  <link rel="stylesheet" href="/assets/css/deep-focus.css?v=4.4.0">
  <link rel="stylesheet" href="/assets/css/mobile-v454.css?v=4.5.4">
</head>
<body class="h-full text-slate-800 antialiased overflow-hidden flex flex-col selection:bg-blue-100 selection:text-blue-900">
<header class="bg-slate-900 px-3 sm:px-5 py-2.5 shadow-sm flex items-center justify-between shrink-0 border-b border-slate-800 z-20 w-full max-w-full overflow-hidden text-white">
  <div class="flex items-center space-x-2.5 sm:space-x-3 shrink-0">
    <div class="relative shrink-0"><div class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-base sm:text-lg font-bold text-blue-400 shadow-xs">🧠</div></div>
    <div class="shrink-0">
      <div class="flex items-center gap-1.5 sm:gap-2"><h1 class="font-bold text-sm sm:text-base tracking-tight leading-tight text-white flex items-center gap-1.5">Brain Focus</h1><a href="https://focusbrain.online/" class="hidden md:inline-flex items-center gap-1 text-[10px] bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded-md font-mono hover:bg-slate-750 hover:text-white transition-colors">focusbrain.online</a></div>
      <p class="text-[10px] sm:text-[11px] text-slate-400 font-normal flex items-center gap-1.5"><span>Không gian học tập & rèn luyện tập trung</span></p>
    </div>
  </div>
  <button type="button" class="lg:hidden w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-lg" onclick="document.getElementById('bf-mobile-drawer').classList.toggle('hidden')" aria-label="Mở menu">☰</button>
  <div class="hidden lg:flex items-center space-x-1.5 sm:space-x-2 shrink-0">
    <?php if($bfModules['audio']):?><button id="quick-sound-btn" onclick="toggleAudio()" class="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-750 active:scale-95 transition-all text-xs font-medium px-2.5 py-1.5 rounded-lg border border-slate-700 text-slate-200 shadow-xs" title="Bật/Tắt âm thanh nền tập trung">
      <div id="equalizer-bars" class="flex items-end gap-0.5 h-3.5 opacity-80"><span class="w-0.5 bg-blue-400 rounded-full h-1"></span><span class="w-0.5 bg-slate-200 rounded-full h-2"></span><span class="w-0.5 bg-blue-300 rounded-full h-1"></span><span class="w-0.5 bg-slate-300 rounded-full h-2.5"></span></div><span id="sound-status" class="hidden lg:inline text-slate-300 text-[11px] font-medium">Âm thanh: Tắt</span>
    </button><?php endif;?>
    <a href="/profile.php" class="cursor-pointer bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 px-2 sm:px-2.5 py-1 rounded-lg flex items-center space-x-1 text-[11px] sm:text-xs font-semibold transition-colors shadow-xs active:scale-95" title="Điểm Xếp Hạng"><span class="text-amber-400 text-xs">🏆</span><span class="hidden sm:inline text-slate-400 text-[11px]">XH:</span><span class="text-amber-300 text-xs sm:text-sm font-bold font-mono"><?=number_format($rankPoints)?>đ</span></a>
    <a href="/assessment.php" class="cursor-pointer bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 px-2 sm:px-2.5 py-1 rounded-lg flex items-center space-x-1 text-[11px] sm:text-xs font-semibold transition-colors shadow-xs active:scale-95" title="Điểm BFS"><span class="text-blue-400 text-xs">⚡</span><span class="hidden sm:inline text-slate-400 text-[11px]">BFS:</span><span class="text-blue-300 text-xs sm:text-sm font-bold font-mono"><?=number_format($bfsScore)?></span></a>
    <?php if($bfModules['leaderboard']):?>    <a href="/leaderboard.php" class="cursor-pointer bg-blue-600 hover:bg-blue-500 text-white px-2.5 sm:px-3 py-1 rounded-lg flex items-center space-x-1 text-[11px] sm:text-xs font-semibold transition-all shadow-xs active:scale-95" title="Tổng Điểm"><span class="hidden sm:inline text-blue-100 text-[11px]">Tổng:</span><span class="font-bold font-mono text-xs sm:text-sm"><?=number_format($totalScore)?>đ</span></a><?php endif;?>
    <?php if($bfModules['focus']):?>    <button onclick="bfStartDeepFocus()" class="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-2.5 py-1.5 rounded-lg shadow-xs active:scale-95 transition-all" title="Bắt đầu phiên Học Sâu Toàn Màn Hình"><span>🧘</span><span class="hidden md:inline">Deep Focus 2.0</span></button><?php endif;?>
    <?php if($bfModules['feedback']):?>    <a href="/feedback.php" class="flex items-center gap-1 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 px-2 py-1.5 rounded-lg text-xs font-medium shadow-xs active:scale-95 transition-all" title="Góp ý & Báo lỗi"><span>💬</span><span class="hidden lg:inline">Góp ý</span></a><?php endif;?><?php if($bfModules['notifications']):?><a href="/notifications.php" class="relative flex items-center gap-1 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 px-2 py-1.5 rounded-lg text-xs font-medium shadow-xs active:scale-95 transition-all" title="Trung tâm thông báo"><span>🔔</span><span class="hidden lg:inline">Thông báo</span><?php if($notificationUnread>0):?><span class="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center"><?=min(99,$notificationUnread)?></span><?php endif;?></a><?php endif;?>
    <a href="/admin/" class="flex items-center gap-1 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 px-2 py-1.5 rounded-lg text-xs font-medium shadow-xs active:scale-95 transition-all" title="Cổng Quản Trị Viên"><span>⚙️</span><span class="hidden xl:inline">Quản trị</span></a>
    <div class="flex items-center gap-1 sm:gap-1.5"><a href="<?=$isAuthed?'/profile.php':'/login.php'?>" class="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 p-1 sm:px-2 sm:py-1 rounded-lg text-slate-200 text-xs font-medium transition-colors shadow-xs active:scale-95" title="Hồ Sơ Của Bạn"><div class="w-6 h-6 rounded-full overflow-hidden bg-slate-700 flex items-center justify-center text-[11px] font-bold text-slate-200 border border-slate-600"><span><?=htmlspecialchars($isAuthed?$initial:'👤')?></span></div><span class="hidden lg:inline text-xs font-medium text-slate-200 max-w-[70px] truncate"><?=htmlspecialchars($userName)?></span></a><a href="<?=$isAuthed?'/logout.php':'/login.php'?>" class="flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg text-slate-300 text-xs transition-colors shadow-xs active:scale-95" title="Khóa màn hình">🔒</a></div>
  </div>
</header>
<div class="bg-white border-b border-slate-200 px-3 sm:px-5 py-1.5 text-xs flex items-center justify-between shrink-0 text-slate-600">
  <div class="flex items-center gap-2 text-[11px] overflow-x-auto whitespace-nowrap custom-scrollbar"><span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-slate-50 border border-slate-200 text-slate-700 font-medium"><span class="w-1.5 h-1.5 rounded-full bg-blue-500"></span>Phương pháp học sâu 90 phút</span><span class="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-slate-50 border border-slate-200 text-slate-600 font-medium">Tối ưu hoá hiệu suất học tập</span></div>
  <div class="bf-streak-strip text-xs text-slate-700 flex items-center gap-1.5 font-medium shrink-0"><span class="text-amber-500">🔥</span><span class="text-slate-500 text-[11px]">Chuỗi ngày tập trung:</span><span class="font-bold text-slate-900 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md text-[11px]"><?=$streak?> ngày</span></div>
</div>
<div id="bf-mobile-drawer" class="hidden lg:hidden bg-white border-b border-slate-200 p-3 shrink-0 z-20 shadow-lg">
  <div class="grid grid-cols-2 gap-2 text-xs">
    <?php if($bfModules['focus']):?><a href="/index.php" class="p-3 rounded-xl border bg-slate-50">⏱️ Phiên học</a><?php endif;?>
    <?php if($bfModules['gym']):?><a href="/gym.php" class="p-3 rounded-xl border bg-slate-50">🎮 Gym não</a><?php endif;?>
    <?php if($bfModules['knowledge']):?><a href="/knowledge.php" class="p-3 rounded-xl border bg-slate-50">📚 Kiến thức</a><?php endif;?>
    <?php if($bfModules['tips']):?><a href="/tips.php" class="p-3 rounded-xl border bg-slate-50">💡 Mẹo học tập</a><?php endif;?>
    <?php if($bfModules['leaderboard']):?><a href="/leaderboard.php" class="p-3 rounded-xl border bg-slate-50">🏆 Xếp hạng</a><?php endif;?>
    <?php if($bfModules['achievements']):?><a href="/achievements.php" class="p-3 rounded-xl border bg-slate-50">🏅 Thành tích</a><?php endif;?>
    <a href="/profile.php" class="p-3 rounded-xl border bg-slate-50">👤 Hồ sơ</a>
    <?php if($bfModules['notifications']):?><a href="/notifications.php" class="p-3 rounded-xl border bg-slate-50">🔔 Thông báo<?php if($notificationUnread):?> (<?=$notificationUnread?>)<?php endif;?></a><?php endif;?>
    <?php if($bfModules['feedback']):?><a href="/feedback.php" class="p-3 rounded-xl border bg-slate-50">💬 Góp ý</a><?php endif;?>
    <button onclick="bfStartDeepFocus()" class="p-3 rounded-xl bg-indigo-600 text-white text-left">🧘 Deep Focus</button>
  </div>
  <?php if($bfModules['audio']):?><div class="mt-3 p-3 rounded-xl bg-slate-50 border"><div class="text-xs font-bold mb-2">🎧 Âm thanh tập trung</div><select id="sound-type-select-mobile" onchange="changeSoundType(this.value)" class="w-full border rounded-lg p-2 text-xs"><option value="gamma">Âm 40Hz</option><option value="white">Tiếng ồn trắng</option><option value="rain">Tiếng mưa</option><option value="pink">Pink Noise</option><option value="brown">Brown Noise</option></select><button id="mobile-sound-toggle-btn" onclick="toggleAudio()" class="mt-2 w-full bg-slate-900 text-white rounded-lg py-2 text-xs font-semibold">Bật âm thanh</button></div><?php endif;?>
</div>
<div class="flex-1 flex overflow-hidden relative">
  <aside class="hidden lg:flex w-64 bg-white flex-col justify-between p-4 border-r border-slate-200 shrink-0 shadow-xs">
    <div class="space-y-1"><div class="text-[11px] font-semibold tracking-wider text-slate-400 px-3 mb-2">CHỨC NĂNG HỌC TẬP</div>
      <?php if($bfModules['focus']):?><a href="/index.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs transition-all <?=bfNavClass($activePage,'focus')?>"><span class="text-base">⏱️</span><span>Phiên học tập trung</span></a><?php endif;?>
      <?php if($bfModules['gym']):?><a href="/gym.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs transition-all <?=bfNavClass($activePage,'gym')?>"><span class="text-base">🎮</span><span>Rèn luyện phản xạ</span></a><?php endif;?>
      <?php if($bfModules['knowledge']):?><a href="/knowledge.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs transition-all <?=bfNavClass($activePage,'knowledge')?>"><span class="text-base">📚</span><span>Kiến thức tập trung</span></a><?php endif;?>
      <?php if($bfModules['tips']):?><a href="/tips.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs transition-all <?=bfNavClass($activePage,'tips')?>"><span class="text-base">💡</span><span>Mẹo trị xao nhãng</span></a><?php endif;?>
      <?php if($bfModules['leaderboard']):?><a href="/leaderboard.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs transition-all <?=bfNavClass($activePage,'leaderboard')?>"><span class="text-base">🏆</span><span>Bảng xếp hạng</span></a><?php endif;?>
      <?php if($bfModules['achievements']):?><a href="/achievements.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs transition-all <?=bfNavClass($activePage,'achievements')?>"><span class="text-base">🏅</span><span>Thư viện thành tích</span></a><?php endif;?>
      <a href="/profile.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs transition-all <?=bfNavClass($activePage,'profile')?>"><span class="text-base">👤</span><span>Hồ sơ cá nhân</span></a>
      <div class="pt-2 pb-1 border-t border-slate-100 mt-2 space-y-1"><button onclick="bfStartDeepFocus()" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2 rounded-xl text-xs font-bold transition-all bg-indigo-50 text-indigo-900 border border-indigo-200 hover:bg-indigo-100"><span class="text-base">🧘</span><span>Deep Focus 2.0</span></button><?php if($bfModules['feedback']):?><a href="/feedback.php" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2 rounded-xl text-xs font-medium transition-all text-slate-600 hover:text-slate-900 hover:bg-slate-100"><span class="text-base">💬</span><span>Góp ý & Báo lỗi</span></a><?php endif;?><a href="/admin/" class="sidebar-item w-full flex items-center space-x-3 px-3.5 py-2 rounded-xl text-xs font-medium transition-all text-slate-600 hover:text-slate-900 hover:bg-slate-100"><span class="text-base">⚙️</span><span>Cổng Quản Trị</span></a></div>
    </div>
    <?php if($bfModules['audio']):?><div class="glass-card-light p-3.5 rounded-xl border border-slate-200"><div class="flex items-center justify-between mb-2"><span class="text-xs font-semibold text-slate-800 flex items-center gap-1.5"><span>🎧</span> Âm thanh nền</span><span id="audio-indicator-dot" class="w-2 h-2 rounded-full bg-slate-300"></span></div><select id="sound-type-select" onchange="changeSoundType(this.value)" class="w-full bg-white border border-slate-200 text-xs text-slate-800 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none mb-2 font-medium"><option value="gamma">Âm 40Hz tập trung</option><option value="white">Tiếng ồn trắng</option><option value="rain">Tiếng mưa</option><option value="pink">Pink Noise</option><option value="brown">Brown Noise</option></select><div class="mb-2"><div class="flex items-center justify-between text-[10px] text-slate-500 mb-1"><span>Âm lượng</span><span id="sound-volume-value">40%</span></div><input id="sound-volume-range" type="range" min="0" max="100" value="40" oninput="changeSoundVolume(this.value)" class="w-full"></div><button onclick="toggleAudio()" id="sidebar-sound-btn" class="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs py-2 rounded-lg transition-colors shadow-xs">BẬT ÂM THANH</button></div><?php endif;?>
  </aside>
  <main class="flex-1 overflow-y-auto custom-scrollbar p-3 sm:p-5 md:p-6 pb-20 sm:pb-24 lg:pb-6 bg-slate-50">
<script>
function bfOpenAuth(){const m=document.getElementById('account-auth-modal');if(m)m.classList.remove('hidden');else location.href='/login.php?next='+encodeURIComponent(location.pathname+location.search)}
function bfStartDeepFocus(){if(!window.BF_USER_AUTHENTICATED){bfOpenAuth();return}location.href='/index.php?duration=90&deep=1'}
</script>
