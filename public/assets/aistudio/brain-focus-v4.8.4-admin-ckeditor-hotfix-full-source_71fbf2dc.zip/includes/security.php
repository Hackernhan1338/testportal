<?php
require_once __DIR__ . '/../api/db.php';

/** PHP 7.2-compatible cookie helper with SameSite support. */
function bfSetCookieCompat($name, $value, $expires, $path, $secure, $httpOnly, $sameSite) {
    if (PHP_VERSION_ID >= 70300) {
        return setcookie($name, $value, [
            'expires' => $expires,
            'path' => $path,
            'secure' => $secure,
            'httponly' => $httpOnly,
            'samesite' => $sameSite
        ]);
    }
    $legacyPath = rtrim($path, '; ') . '; samesite=' . $sameSite;
    return setcookie($name, $value, $expires, $legacyPath, '', $secure, $httpOnly);
}

function bfRequestIp(): string {
    // Mặc định chỉ tin REMOTE_ADDR. Chỉ tin Cloudflare header khi chủ máy chủ chủ động bật BF_TRUST_CF=1.
    if ((getenv('BF_TRUST_CF') ?: '0') === '1') {
        $cf = trim((string)($_SERVER['HTTP_CF_CONNECTING_IP'] ?? ''));
        if ($cf !== '' && filter_var($cf, FILTER_VALIDATE_IP)) return $cf;
    }
    $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
}

function bfDeviceHash(): string {
    $cookie = (string)($_COOKIE['BFDEVICE'] ?? '');
    if (!preg_match('/^[a-f0-9]{64}$/', $cookie)) {
        $cookie = bin2hex(random_bytes(32));
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        bfSetCookieCompat('BFDEVICE', $cookie, time() + 86400 * 365 * 2, '/', $secure, true, 'Lax');
        $_COOKIE['BFDEVICE'] = $cookie;
    }
    return hash('sha256', $cookie);
}

function bfUserAgent(): string { return substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500); }

function bfSecurityGate(PDO $pdo, ?string $email = null): void {
    $ip = bfRequestIp(); $dev = bfDeviceHash(); $ua = bfUserAgent(); $email = strtolower(trim((string)$email));
    try {
        $st = $pdo->query("SELECT rule_type,rule_value,reason FROM bf_block_rules WHERE status='ACTIVE' AND (expires_at IS NULL OR expires_at>NOW())");
        foreach ($st->fetchAll() as $r) {
            $type = $r['rule_type']; $value = trim((string)$r['rule_value']); $blocked = false;
            if ($type === 'IP') $blocked = ($ip !== '' && hash_equals($value, $ip));
            elseif ($type === 'DEVICE') $blocked = ($dev !== '' && hash_equals(strtolower($value), strtolower($dev)));
            elseif ($type === 'EMAIL') $blocked = ($email !== '' && hash_equals(strtolower($value), $email));
            elseif ($type === 'USER_AGENT') $blocked = ($value !== '' && stripos($ua, $value) !== false);
            if ($blocked) {
                http_response_code(403);
                $isApi = strpos((string)($_SERVER['REQUEST_URI'] ?? ''), '/api/') !== false;
                if ($isApi) jsonResponse(['success'=>false,'message'=>'Thiết bị hoặc kết nối này đã bị chặn.','reason'=>$r['reason'] ?: 'Vi phạm quy định hệ thống','code'=>'ACCESS_BLOCKED'],403);
                echo '<!doctype html><meta charset="utf-8"><title>Truy cập bị chặn</title><style>body{font-family:system-ui;background:#f8fafc;color:#0f172a;padding:48px}.box{max-width:620px;margin:auto;background:#fff;border:1px solid #e2e8f0;border-radius:18px;padding:28px}</style><div class="box"><h1>Truy cập bị chặn</h1><p>Thiết bị hoặc kết nối này không được phép truy cập Brain Focus.</p><p><b>Lý do:</b> '.htmlspecialchars($r['reason'] ?: 'Vi phạm quy định hệ thống',ENT_QUOTES,'UTF-8').'</p></div>';
                exit;
            }
        }
    } catch (Throwable $e) { /* migration chưa chạy: không làm sập web */ }
}

function bfLogAccess(PDO $pdo, array $ctx = []): void {
    try {
        $st=$pdo->prepare("INSERT INTO bf_access_logs(user_id,admin_id,email,device_hash,ip_address,user_agent,browser_info,request_path,event_type) VALUES(?,?,?,?,?,?,?,?,?)");
        $st->execute([
            $ctx['user_id']??null,$ctx['admin_id']??null,$ctx['email']??null,bfDeviceHash(),bfRequestIp(),bfUserAgent(),
            substr((string)($ctx['browser_info']??''),0,255),substr((string)($_SERVER['REQUEST_URI']??''),0,500),$ctx['event_type']??'PAGE_VIEW'
        ]);
    } catch(Throwable $e){}
}

function bfForbiddenWord(PDO $pdo, string $text, string $scope='ALL'): ?string {
    if ($text==='') return null;
    try {
        $st=$pdo->prepare("SELECT word,match_type FROM bf_forbidden_words WHERE status='ACTIVE' AND (scope='ALL' OR scope=?) ORDER BY CHAR_LENGTH(word) DESC");
        $st->execute([$scope]);
        $lower=mb_strtolower($text,'UTF-8');
        foreach($st->fetchAll() as $r){
            $w=mb_strtolower(trim((string)$r['word']),'UTF-8'); if($w==='')continue;
            if($r['match_type']==='EXACT' ? ($lower===$w) : (mb_strpos($lower,$w,0,'UTF-8')!==false)) return $r['word'];
        }
    } catch(Throwable $e){}
    return null;
}
function bfRejectForbidden(PDO $pdo, array $texts, string $scope='ALL'): void {
    foreach($texts as $text){$bad=bfForbiddenWord($pdo,(string)$text,$scope);if($bad!==null)jsonResponse(['success'=>false,'message'=>'Nội dung chứa từ/cụm từ không được phép.','code'=>'FORBIDDEN_WORD'],422);}
}
