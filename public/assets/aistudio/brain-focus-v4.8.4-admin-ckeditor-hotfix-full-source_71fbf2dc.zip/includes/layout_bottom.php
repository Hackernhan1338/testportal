<?php
$bfVersion=isset($pdo)?(string)bfSetting($pdo,'app_version','4.8.2'):'4.8.2';
$bfContact=isset($pdo)?(string)bfSetting($pdo,'site_contact_email','thiennhan1338@gmail.com'):'thiennhan1338@gmail.com';
$bfFacebook=isset($pdo)?trim((string)bfSetting($pdo,'social_facebook_url','')):'';
$bfYoutube=isset($pdo)?trim((string)bfSetting($pdo,'social_youtube_url','')):'';
$bfTiktok=isset($pdo)?trim((string)bfSetting($pdo,'social_tiktok_url','')):'';
?>
<footer class="mt-8 -mx-3 sm:-mx-5 md:-mx-6 -mb-20 sm:-mb-24 lg:-mb-6 px-4 sm:px-6 py-7 bg-slate-900 text-slate-300 border-t border-slate-800">
  <div class="max-w-6xl mx-auto grid sm:grid-cols-2 lg:grid-cols-4 gap-6 text-xs">
    <div><div class="font-bold text-white text-sm flex items-center gap-2"><span>🧠</span>Brain Focus</div><p class="mt-2 leading-5 text-slate-400">Nền tảng hỗ trợ học tập tập trung, rèn luyện phản xạ và theo dõi tiến độ học tập.</p></div>
    <div><div class="font-bold text-white">Chuyển trang nhanh</div><div class="mt-2 grid gap-1.5"><a class="hover:text-white" href="/index.php">Phiên học tập trung</a><a class="hover:text-white" href="/gym.php">Gym não</a><a class="hover:text-white" href="/knowledge.php">Kiến thức</a><a class="hover:text-white" href="/leaderboard.php">Bảng xếp hạng</a><a class="hover:text-white" href="/profile.php">Hồ sơ cá nhân</a><a class="hover:text-white" href="/achievements.php">Thư viện thành tích</a><a class="hover:text-white" href="/onboarding.php">Hướng dẫn bắt đầu</a></div></div>
    <div><div class="font-bold text-white">Thông tin & chính sách</div><div class="mt-2 grid gap-1.5"><a class="lg:hidden inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-semibold" href="/admin/">⚙️ Quản trị hệ thống</a><a class="hover:text-white" href="/terms.php">Điều khoản & bảo vệ dữ liệu</a><a class="hover:text-white" href="/notifications.php">Trung tâm thông báo</a><a class="hover:text-white" href="/feedback.php">Góp ý & báo lỗi</a><a class="hover:text-white" href="mailto:<?=htmlspecialchars($bfContact)?>"><?=htmlspecialchars($bfContact)?></a></div></div>
    <div><div class="font-bold text-white">Mạng xã hội</div><div class="mt-2 flex flex-wrap gap-2"><?php if($bfFacebook):?><a class="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 hover:bg-slate-700" target="_blank" rel="noopener" href="<?=htmlspecialchars($bfFacebook)?>">Facebook</a><?php endif;?><?php if($bfYoutube):?><a class="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 hover:bg-slate-700" target="_blank" rel="noopener" href="<?=htmlspecialchars($bfYoutube)?>">YouTube</a><?php endif;?><?php if($bfTiktok):?><a class="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 hover:bg-slate-700" target="_blank" rel="noopener" href="<?=htmlspecialchars($bfTiktok)?>">TikTok</a><?php endif;?><?php if(!$bfFacebook&&!$bfYoutube&&!$bfTiktok):?><span class="text-slate-500">Có thể cấu hình liên kết mạng xã hội trong Admin.</span><?php endif;?></div><div class="mt-4 text-[10px] text-slate-500">Phiên bản đang chạy: <span class="font-mono text-slate-400"><?=htmlspecialchars($bfVersion)?></span></div></div>
  </div>
</footer>
  </main>
</div>
<nav class="lg:hidden fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 z-30 px-2 py-1.5 shadow-[0_-2px_8px_rgba(15,23,42,.04)]"><div class="grid grid-cols-5 gap-1 text-[9px] text-center">
<?php if(!isset($bfModules)||$bfModules['focus']):?><a href="/index.php" class="flex flex-col items-center gap-0.5 py-1 <?=($activePage??'')==='focus'?'text-slate-900 font-bold':'text-slate-500'?>"><span class="text-base">⏱️</span><span>Học</span></a><?php else:?><span></span><?php endif;?>
<?php if(!isset($bfModules)||$bfModules['gym']):?><a href="/gym.php" class="flex flex-col items-center gap-0.5 py-1 <?=($activePage??'')==='gym'?'text-slate-900 font-bold':'text-slate-500'?>"><span class="text-base">🎮</span><span>Gym</span></a><?php else:?><span></span><?php endif;?>
<?php if(!isset($bfModules)||$bfModules['leaderboard']):?><a href="/leaderboard.php" class="flex flex-col items-center gap-0.5 py-1 <?=($activePage??'')==='leaderboard'?'text-slate-900 font-bold':'text-slate-500'?>"><span class="text-base">🏆</span><span>BXH</span></a><?php else:?><span></span><?php endif;?>
<a href="/profile.php" class="flex flex-col items-center gap-0.5 py-1 <?=($activePage??'')==='profile'?'text-slate-900 font-bold':'text-slate-500'?>"><span class="text-base">👤</span><span>Hồ sơ</span></a>
<button type="button" onclick="document.getElementById('bf-mobile-drawer').classList.toggle('hidden')" class="flex flex-col items-center gap-0.5 py-1 text-slate-500"><span class="text-base">☰</span><span>Menu</span></button>
</div></nav>
<script src="/assets/js/audio-engine.js?v=4.5.0" defer></script>
<script src="/assets/js/device.js?v=4.4.0" defer></script>
</body></html>
