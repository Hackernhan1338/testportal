<?php
function bfLeaderboardScoreSql($alias='u') {
    $a=preg_replace('/[^A-Za-z0-9_]/','',$alias);
    return "($a.rank_points + $a.bfs_score + COALESCE((SELECT ROUND(SUM(CASE WHEN COALESCE(s.actual_seconds,0)>0 THEN s.actual_seconds/60 ELSE s.duration_minutes END)) FROM bf_study_sessions s WHERE s.user_email=$a.email),0))";
}
function bfLatestLeaderboardRound(PDO $pdo){
    try{
        $r=$pdo->query("SELECT * FROM bf_leaderboard_rounds WHERE status='ACTIVE' ORDER BY id DESC LIMIT 1")->fetch();
        if($r)return $r;
        $r=$pdo->query("SELECT * FROM bf_leaderboard_rounds ORDER BY id DESC LIMIT 1")->fetch();
        return $r?:null;
    }catch(Throwable $e){return null;}
}
function bfLeaderboardAccountRows(PDO $pdo,$q='',$limit=100000,$offset=0){
    $q=trim((string)$q);$limit=max(1,min(100000,(int)$limit));$offset=max(0,(int)$offset);
    $where="u.status='ACTIVE'";$params=[];
    if($q!==''){$where.=" AND (u.name LIKE ? OR u.school LIKE ? OR u.email LIKE ?)";$x='%'.$q.'%';$params=[$x,$x,$x];}
    $score=bfLeaderboardScoreSql('u');
    $sql="SELECT u.id,u.email,u.name,u.school,u.avatar,u.rank_points,u.bfs_score,u.total_hours,u.sessions_count,COALESCE((SELECT ROUND(SUM(CASE WHEN COALESCE(s.actual_seconds,0)>0 THEN s.actual_seconds/60 ELSE s.duration_minutes END)) FROM bf_study_sessions s WHERE s.user_email=u.email),0) session_points,$score account_total FROM bf_users u WHERE $where ORDER BY account_total DESC,u.total_hours DESC,u.id ASC LIMIT $limit OFFSET $offset";
    $st=$pdo->prepare($sql);$st->execute($params);return $st->fetchAll();
}
function bfLeaderboardRows(PDO $pdo,$q,$limit,$offset){
    $q=trim((string)$q);$limit=max(1,min(100000,(int)$limit));$offset=max(0,(int)$offset);
    $round=bfLatestLeaderboardRound($pdo);
    if(!$round){
        $rows=bfLeaderboardAccountRows($pdo,$q,$limit,$offset);
        foreach($rows as &$r){$r['total_score']=(int)$r['account_total'];$r['round_points']=(int)$r['account_total'];$r['round_id']=0;$r['round_title']='Toàn thời gian';}unset($r);
        return $rows;
    }
    $rid=(int)$round['id'];$params=[];
    $where='1=1';
    if($q!==''){$where.=" AND (u.name LIKE ? OR u.school LIKE ? OR u.email LIKE ?)";$x='%'.$q.'%';$params=[$x,$x,$x];}
    $score=bfLeaderboardScoreSql('u');
    if(($round['status']??'')==='CLOSED'){
        $sql="SELECT u.id,u.email,u.name,u.school,u.avatar,u.rank_points,u.bfs_score,u.total_hours,u.sessions_count,COALESCE((SELECT ROUND(SUM(CASE WHEN COALESCE(s.actual_seconds,0)>0 THEN s.actual_seconds/60 ELSE s.duration_minutes END)) FROM bf_study_sessions s WHERE s.user_email=u.email),0) session_points,$score account_total,m.final_round_points total_score,m.final_round_points round_points,m.final_rank,m.baseline_score,m.final_score,$rid round_id,? round_title FROM bf_leaderboard_round_members m JOIN bf_users u ON u.id=m.user_id WHERE m.round_id=$rid AND $where ORDER BY m.final_rank ASC,u.id ASC LIMIT $limit OFFSET $offset";
        array_unshift($params,(string)$round['title']);
        $st=$pdo->prepare($sql);$st->execute($params);return $st->fetchAll();
    }
    $sql="SELECT u.id,u.email,u.name,u.school,u.avatar,u.rank_points,u.bfs_score,u.total_hours,u.sessions_count,COALESCE((SELECT ROUND(SUM(CASE WHEN COALESCE(s.actual_seconds,0)>0 THEN s.actual_seconds/60 ELSE s.duration_minutes END)) FROM bf_study_sessions s WHERE s.user_email=u.email),0) session_points,$score account_total,($score-COALESCE(m.baseline_score,$score)) total_score,($score-COALESCE(m.baseline_score,$score)) round_points,NULL final_rank,COALESCE(m.baseline_score,$score) baseline_score,NULL final_score,$rid round_id,? round_title FROM bf_users u LEFT JOIN bf_leaderboard_round_members m ON m.round_id=$rid AND m.user_id=u.id WHERE u.status='ACTIVE' AND $where ORDER BY total_score DESC,account_total DESC,u.id ASC LIMIT $limit OFFSET $offset";
    array_unshift($params,(string)$round['title']);
    $st=$pdo->prepare($sql);$st->execute($params);return $st->fetchAll();
}
function bfLeaderboardCount(PDO $pdo,$q){
    $q=trim((string)$q);$round=bfLatestLeaderboardRound($pdo);
    if($round && ($round['status']??'')==='CLOSED'){
        $sql="SELECT COUNT(*) FROM bf_leaderboard_round_members m JOIN bf_users u ON u.id=m.user_id WHERE m.round_id=?";$params=[(int)$round['id']];
        if($q!==''){$sql.=" AND (u.name LIKE ? OR u.school LIKE ? OR u.email LIKE ?)";$x='%'.$q.'%';$params[]=$x;$params[]=$x;$params[]=$x;}
        $st=$pdo->prepare($sql);$st->execute($params);return (int)$st->fetchColumn();
    }
    if($q==='')return (int)$pdo->query("SELECT COUNT(*) FROM bf_users WHERE status='ACTIVE'")->fetchColumn();
    $x='%'.$q.'%';$st=$pdo->prepare("SELECT COUNT(*) FROM bf_users WHERE status='ACTIVE' AND (name LIKE ? OR school LIKE ? OR email LIKE ?)");$st->execute([$x,$x,$x]);return (int)$st->fetchColumn();
}
function bfUserTotalScore(PDO $pdo,array $u){$st=$pdo->prepare("SELECT COALESCE(ROUND(SUM(CASE WHEN COALESCE(actual_seconds,0)>0 THEN actual_seconds/60 ELSE duration_minutes END)),0) FROM bf_study_sessions WHERE user_email=?");$st->execute([$u['email']]);$sp=(int)$st->fetchColumn();return ['session_points'=>$sp,'total_score'=>(int)$u['rank_points']+(int)$u['bfs_score']+$sp];}
function bfUserRank(PDO $pdo,array $u){$all=bfLeaderboardRows($pdo,'',100000,0);foreach($all as $i=>$r)if((int)$r['id']===(int)$u['id'])return !empty($r['final_rank'])?(int)$r['final_rank']:$i+1;return 0;}
function bfUserRoundScore(PDO $pdo,array $u){$rows=bfLeaderboardRows($pdo,$u['email'],100,0);foreach($rows as $r)if((int)$r['id']===(int)$u['id'])return ['round_id'=>(int)($r['round_id']??0),'round_title'=>(string)($r['round_title']??''),'round_points'=>(int)($r['round_points']??$r['total_score']??0),'account_total'=>(int)($r['account_total']??0)];$total=bfUserTotalScore($pdo,$u);return ['round_id'=>0,'round_title'=>'','round_points'=>(int)$total['total_score'],'account_total'=>(int)$total['total_score']];}
function bfTimeframeSince($tf){$now=new DateTimeImmutable('now');switch($tf){case'12h':return $now->modify('-12 hours');case'24h':return $now->modify('-24 hours');case'48h':return $now->modify('-48 hours');case'7d':return $now->modify('-7 days');case'30d':return $now->modify('-30 days');case'90d':return $now->modify('-90 days');default:return null;}}
function bfProfileMetrics(PDO $pdo,array $u,$tf){
    $since=bfTimeframeSince($tf);$params=[$u['email']];$cond='user_email=?';if($since){$cond.=' AND created_at>=?';$params[]=$since->format('Y-m-d H:i:s');}
    $st=$pdo->prepare("SELECT id,duration_minutes,CASE WHEN COALESCE(actual_seconds,0)>0 THEN actual_seconds ELSE duration_minutes*60 END actual_seconds,CASE WHEN COALESCE(fullscreen_seconds,0)>0 THEN fullscreen_seconds WHEN is_deep_focus=1 AND COALESCE(actual_seconds,0)=0 THEN duration_minutes*60 ELSE 0 END fullscreen_seconds,CASE WHEN COALESCE(actual_seconds,0)>0 THEN completion_percent ELSE 100 END completion_percent,focus_integrity,is_deep_focus,created_at FROM bf_study_sessions WHERE $cond ORDER BY created_at");$st->execute($params);$sessions=$st->fetchAll();
    $focusSec=0;$fullSec=0;$integrity=0;$deep=0;$completed=0;$hour=[];
    foreach($sessions as $s){$as=max(0,(int)$s['actual_seconds']);$focusSec+=$as;$fullSec+=max(0,(int)$s['fullscreen_seconds']);$integrity+=(int)$s['focus_integrity'];if((int)$s['is_deep_focus']||((int)$s['fullscreen_seconds']>0))$deep++;if((float)$s['completion_percent']>=95)$completed++;$h=(int)date('G',strtotime($s['created_at']));if(!isset($hour[$h]))$hour[$h]=['sec'=>0,'integrity'=>0,'n'=>0];$hour[$h]['sec']+=$as;$hour[$h]['integrity']+=(int)$s['focus_integrity'];$hour[$h]['n']++;}
    $startedParams=[$u['email']];$startedCond="user_email=? AND event_type='SESSION_START'";if($since){$startedCond.=' AND created_at>=?';$startedParams[]=$since->format('Y-m-d H:i:s');}$st2=$pdo->prepare("SELECT COUNT(DISTINCT client_session_id) FROM bf_focus_events WHERE $startedCond");$st2->execute($startedParams);$started=max(count($sessions),(int)$st2->fetchColumn());
    $gparams=[$u['email']];$gcond='user_email=?';if($since){$gcond.=' AND created_at>=?';$gparams[]=$since->format('Y-m-d H:i:s');}$gst=$pdo->prepare("SELECT duration_seconds,score,created_at FROM bf_gym_sessions WHERE $gcond ORDER BY created_at");$gst->execute($gparams);$gyms=$gst->fetchAll();$gymSec=0;foreach($gyms as $g)$gymSec+=max(0,(int)$g['duration_seconds']);
    $peak=null;$peakVal=-1;foreach($hour as $h=>$d){$avg=$d['n']?$d['integrity']/$d['n']:0;$v=$d['sec']*($avg/100);if($v>$peakVal){$peakVal=$v;$peak=$h;}}
    $avg=count($sessions)?round($integrity/count($sessions)):0;$completion=$started?round($completed/$started*100):0;$fullscreenRate=$focusSec?round($fullSec/$focusSec*100):0;
    $chart=bfBuildActivityChart($sessions,$gyms,$tf,$since);
    $suggest=[];if($avg<80)$suggest[]='Giảm số lần chuyển tab và ưu tiên học trong một cửa sổ duy nhất để tăng Focus Integrity.';if($fullscreenRate<60)$suggest[]='Tăng thời gian học ở chế độ toàn màn hình F11; mục tiêu nên trên 70% thời gian tập trung.';if($completion<80)$suggest[]='Chọn phiên ngắn hơn 15–25 phút trước, sau đó tăng dần để giảm tỷ lệ bỏ ngang.';if($peak!==null)$suggest[]='Khung giờ vàng hiện tại khoảng '.sprintf('%02dh–%02dh',$peak,($peak+2)%24).'; nên xếp nhiệm vụ khó vào khoảng này.';if($gymSec<600)$suggest[]='Rèn phản xạ 5–10 phút/ngày để bổ sung tốc độ xử lý nhưng không thay thế thời gian học sâu.';if(!$suggest)$suggest[]='Các chỉ số đang ổn định; hãy duy trì lịch học đều và tiếp tục theo dõi xu hướng theo tuần.';
    return ['sessions'=>$sessions,'gyms'=>$gyms,'focus_seconds'=>$focusSec,'gym_seconds'=>$gymSec,'fullscreen_seconds'=>$fullSec,'fullscreen_rate'=>$fullscreenRate,'avg_integrity'=>$avg,'deep_sessions'=>$deep,'completion_rate'=>$completion,'started_sessions'=>$started,'peak_hour'=>$peak,'chart'=>$chart,'suggestions'=>$suggest];
}
function bfBuildActivityChart($sessions,$gyms,$tf,$since){
    $now=time();$points=[];
    if(in_array($tf,['12h','24h','48h'],true)){$hours=$tf==='12h'?12:($tf==='24h'?24:48);$step=$tf==='48h'?4:($tf==='24h'?2:1);for($i=$hours;$i>0;$i-=$step){$a=$now-$i*3600;$b=$a+$step*3600;$points[]=['key'=>$a,'label'=>date('H:i',$a),'from'=>$a,'to'=>$b,'focus'=>0,'gym'=>0];}}
    elseif($tf==='7d'||$tf==='30d'||$tf==='90d'){$days=$tf==='7d'?7:($tf==='30d'?30:90);$step=$tf==='90d'?7:($tf==='30d'?3:1);$start=strtotime(date('Y-m-d 00:00:00',$now-($days-1)*86400));for($a=$start;$a<=$now;$a+=$step*86400){$b=min($now+1,$a+$step*86400);$points[]=['key'=>$a,'label'=>date('d/m',$a),'from'=>$a,'to'=>$b,'focus'=>0,'gym'=>0];}}
    else{$min=$now-30*86400;if($sessions)$min=min($min,strtotime($sessions[0]['created_at']));if($gyms)$min=min($min,strtotime($gyms[0]['created_at']));$span=max(1,$now-$min);$step=max(86400,(int)ceil($span/12/86400)*86400);for($a=$min;$a<$now;$a+=$step)$points[]=['key'=>$a,'label'=>date('d/m',$a),'from'=>$a,'to'=>min($now,$a+$step),'focus'=>0,'gym'=>0];}
    foreach($sessions as $s){$t=strtotime($s['created_at']);foreach($points as &$p){if($t>=$p['from']&&$t<$p['to']){$p['focus']+=round(((int)$s['actual_seconds'])/60,1);break;}}unset($p);}foreach($gyms as $g){$t=strtotime($g['created_at']);foreach($points as &$p){if($t>=$p['from']&&$t<$p['to']){$p['gym']+=round(((int)$g['duration_seconds'])/60,1);break;}}unset($p);}return $points;
}
