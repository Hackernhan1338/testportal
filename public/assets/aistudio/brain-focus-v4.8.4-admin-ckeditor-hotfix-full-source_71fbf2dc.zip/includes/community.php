<?php
if(!function_exists('bfNotifyUser')){
function bfNotifyUser(PDO $pdo,string $email,string $title,string $content,string $category='GENERAL',string $type='info',?string $link=null,?string $refKey=null,string $priority='NORMAL',?string $detailHtml=null): bool {
    try{
        if($refKey){$st=$pdo->prepare("SELECT id FROM bf_notifications WHERE user_email=? AND ref_key=? LIMIT 1");$st->execute([$email,$refKey]);if($st->fetchColumn())return false;}
        $st=$pdo->prepare("INSERT INTO bf_notifications(user_email,title,content,detail_html,type,category,link_url,ref_key,priority,is_read) VALUES(?,?,?,?,?,?,?,?,?,0)");
        $st->execute([$email,$title,$content,$detailHtml,$type,$category,$link,$refKey,$priority]);return true;
    }catch(Throwable $e){return false;}
}}
if(!function_exists('bfProfileCompletion')){
function bfProfileCompletion(array $u): array {
    $fields=['name','email','school','birthday','province','target_school','study_unit','quote_text'];$done=0;
    foreach($fields as $f){if(trim((string)($u[$f]??''))!=='')$done++;}
    $pct=(int)round($done/count($fields)*100);
    return ['done'=>$done,'total'=>count($fields),'percent'=>$pct];
}}
if(!function_exists('bfAwardBadgeByCode')){
function bfAwardBadgeByCode(PDO $pdo,int $userId,string $code,string $note='Tự động cấp'): bool {
    try{$st=$pdo->prepare("SELECT id,name,reward_xp FROM bf_badges WHERE badge_code=? AND status='ACTIVE' LIMIT 1");$st->execute([$code]);$b=$st->fetch();if(!$b)return false;
        $ins=$pdo->prepare("INSERT IGNORE INTO bf_user_badges(user_id,badge_id,note) VALUES(?,?,?)");$ins->execute([$userId,$b['id'],$note]);
        if(!$ins->rowCount())return false;
        $xp=(int)$b['reward_xp'];if($xp!==0){$pdo->prepare("UPDATE bf_users SET rank_points=GREATEST(0,rank_points+?) WHERE id=?")->execute([$xp,$userId]);$pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'RANK','BADGE_AWARD',?,'BADGE',?)")->execute([$userId,$xp,'Huy hiệu: '.$b['name'],(string)$b['id']]);}
        $ust=$pdo->prepare("SELECT email FROM bf_users WHERE id=?");$ust->execute([$userId]);$email=(string)$ust->fetchColumn();if($email)bfNotifyUser($pdo,$email,'🏅 Huy hiệu mới: '.$b['name'],'Bạn vừa nhận được huy hiệu mới trong Brain Focus.','ACHIEVEMENT','success','/achievements.php','badge:'.$b['id'].':'.$userId,'NORMAL');
        return true;
    }catch(Throwable $e){return false;}
}}
if(!function_exists('bfTaskPeriodKey')){
function bfTaskPeriodKey(string $scope,?int $ts=null): string {
    $ts=$ts?:time();
    if($scope==='DAILY') return date('Y-m-d',$ts);
    if($scope==='WEEKLY') return date('o-\\WW',$ts);
    if($scope==='MONTHLY') return date('Y-m',$ts);
    return 'ONCE';
}}
if(!function_exists('bfTaskPeriodLabel')){
function bfTaskPeriodLabel(string $scope): string {
    if($scope==='DAILY')return 'ngày';if($scope==='WEEKLY')return 'tuần';if($scope==='MONTHLY')return 'tháng';return 'một lần';
}}
if(!function_exists('bfTaskSetProgress')){
function bfTaskSetProgress(PDO $pdo,int $userId,string $scope): array {
    if(!in_array($scope,['DAILY','WEEKLY','MONTHLY'],true))return ['required'=>0,'done'=>0,'complete'=>false,'period_key'=>'ONCE'];
    $key=bfTaskPeriodKey($scope);
    $st=$pdo->prepare("SELECT COUNT(*) FROM bf_tasks WHERE status='ACTIVE' AND task_scope=? AND required_for_bonus=1 AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW())");$st->execute([$scope]);$required=(int)$st->fetchColumn();
    $st=$pdo->prepare("SELECT COUNT(DISTINCT c.task_id) FROM bf_user_task_completions c JOIN bf_tasks t ON t.id=c.task_id WHERE c.user_id=? AND t.task_scope=? AND t.required_for_bonus=1 AND c.period_key=?");$st->execute([$userId,$scope,$key]);$done=(int)$st->fetchColumn();
    return ['required'=>$required,'done'=>$done,'complete'=>$required>0&&$done>=$required,'period_key'=>$key];
}}
if(!function_exists('bfAwardTaskSetBonus')){
function bfAwardTaskSetBonus(PDO $pdo,array $user,string $scope): int {
    $progress=bfTaskSetProgress($pdo,(int)$user['id'],$scope);if(!$progress['complete'])return 0;
    $bonus=(int)bfSetting($pdo,'task_set_bonus_xp','100');
    $ins=$pdo->prepare("INSERT IGNORE INTO bf_task_period_rewards(user_id,scope,period_key,reward_xp) VALUES(?,?,?,?)");$ins->execute([(int)$user['id'],$scope,$progress['period_key'],$bonus]);if(!$ins->rowCount())return 0;
    if($bonus!==0){$pdo->prepare("UPDATE bf_users SET rank_points=GREATEST(0,rank_points+?) WHERE id=?")->execute([$bonus,(int)$user['id']]);$pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'RANK','TASK_SET_BONUS',?,'TASK_PERIOD',?)")->execute([(int)$user['id'],$bonus,'Hoàn thành đủ nhiệm vụ '.$scope,$scope.':'.$progress['period_key']]);}
    bfNotifyUser($pdo,(string)$user['email'],'🎉 Hoàn thành đủ nhiệm vụ '.bfTaskPeriodLabel($scope),'Bạn đã hoàn thành toàn bộ nhiệm vụ '.$scope.' và nhận thêm +'.$bonus.' XP.','ACHIEVEMENT','success','/profile.php','taskset:'.$scope.':'.$progress['period_key'].':'.$user['id'],'NORMAL');
    return $bonus;
}}
if(!function_exists('bfCompleteTask')){
function bfCompleteTask(PDO $pdo,array $user,int $taskId): array {
    try{$st=$pdo->prepare("SELECT * FROM bf_tasks WHERE id=? AND status='ACTIVE' AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW())");$st->execute([$taskId]);$t=$st->fetch();if(!$t)return [false,0,'Nhiệm vụ không còn khả dụng.'];
        $periodKey=bfTaskPeriodKey((string)$t['task_scope']);
        $pdo->beginTransaction();$ins=$pdo->prepare("INSERT IGNORE INTO bf_user_task_completions(user_id,task_id,reward_xp,period_key) VALUES(?,?,?,?)");$ins->execute([(int)$user['id'],$taskId,(int)$t['reward_xp'],$periodKey]);if(!$ins->rowCount()){$pdo->rollBack();return [false,0,'Nhiệm vụ đã được hoàn thành trong chu kỳ này.'];}
        $xp=(int)$t['reward_xp'];if($xp!==0){$pdo->prepare("UPDATE bf_users SET rank_points=GREATEST(0,rank_points+?) WHERE id=?")->execute([$xp,(int)$user['id']]);$pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'RANK','TASK_COMPLETE',?,'TASK',?)")->execute([(int)$user['id'],$xp,'Nhiệm vụ: '.$t['title'],(string)$taskId.':'.$periodKey]);}
        $pdo->commit();$bonus=0;if(in_array($t['task_scope'],['DAILY','WEEKLY','MONTHLY'],true))$bonus=bfAwardTaskSetBonus($pdo,$user,(string)$t['task_scope']);
        try{$ct=$pdo->prepare("SELECT COUNT(DISTINCT c.task_id) FROM bf_user_task_completions c JOIN bf_tasks t ON t.id=c.task_id WHERE c.user_id=? AND t.task_scope='DISCOVERY'");$ct->execute([(int)$user['id']]);if((int)$ct->fetchColumn()>=6)bfAwardBadgeByCode($pdo,(int)$user['id'],'FOCUS_EXPLORER','Hoàn thành nhóm nhiệm vụ khám phá');}catch(Throwable $e){}
        return [true,$xp+$bonus,'Đã hoàn thành nhiệm vụ.'.($bonus?' Thưởng đủ bộ +'.$bonus.' XP.':'')];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();return [false,0,'Không thể hoàn thành nhiệm vụ.'];}
}}

if(!function_exists('bfTaskPeriodBounds')){
function bfTaskPeriodBounds(string $scope): array {
    $now=new DateTimeImmutable('now');
    if($scope==='DAILY'){
        $from=$now->setTime(0,0,0);$to=$from->modify('+1 day');
    }elseif($scope==='WEEKLY'){
        $from=$now->modify('monday this week')->setTime(0,0,0);$to=$from->modify('+7 days');
    }elseif($scope==='MONTHLY'){
        $from=$now->modify('first day of this month')->setTime(0,0,0);$to=$from->modify('first day of next month');
    }else{
        $from=new DateTimeImmutable('2000-01-01 00:00:00');$to=$now->modify('+1 day');
    }
    return [$from->format('Y-m-d H:i:s'),$to->format('Y-m-d H:i:s')];
}}
if(!function_exists('bfTaskMetricProgress')){
function bfTaskMetricProgress(PDO $pdo,array $user,string $scope,string $metric): int {
    list($from,$to)=bfTaskPeriodBounds($scope);
    $email=(string)$user['email'];$uid=(int)$user['id'];
    try{
        if($metric==='FOCUS_ANY'){
            $st=$pdo->prepare("SELECT COUNT(*) FROM bf_study_sessions WHERE user_email=? AND created_at>=? AND created_at<?");
            $st->execute([$email,$from,$to]);return (int)$st->fetchColumn();
        }
        if($metric==='FOCUS_90'){
            $st=$pdo->prepare("SELECT COUNT(*) FROM bf_study_sessions WHERE user_email=? AND duration_minutes>=90 AND completion_percent>=90 AND created_at>=? AND created_at<?");
            $st->execute([$email,$from,$to]);return (int)$st->fetchColumn();
        }
        if($metric==='GYM_PLAY'){
            $st=$pdo->prepare("SELECT COUNT(*) FROM bf_gym_sessions WHERE user_email=? AND created_at>=? AND created_at<?");
            $st->execute([$email,$from,$to]);return (int)$st->fetchColumn();
        }
        if($metric==='GYM_PURCHASE'){
            $st=$pdo->prepare("SELECT COALESCE(SUM(quantity),0) FROM bf_gym_purchase_events WHERE user_id=? AND created_at>=? AND created_at<?");
            $st->execute([$uid,$from,$to]);return (int)$st->fetchColumn();
        }
        if($metric==='REFLECTION'){
            $st=$pdo->prepare("SELECT COUNT(*) FROM bf_study_sessions WHERE user_email=? AND reflection_xp_awarded=1 AND created_at>=? AND created_at<?");
            $st->execute([$email,$from,$to]);return (int)$st->fetchColumn();
        }
    }catch(Throwable $e){}
    return 0;
}}
if(!function_exists('bfSyncAutomaticTasks')){
function bfSyncAutomaticTasks(PDO $pdo,array $user): void {
    try{
        $st=$pdo->query("SELECT id,task_scope,metric_key,target_value FROM bf_tasks WHERE status='ACTIVE' AND metric_key IS NOT NULL AND metric_key<>'' AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW())");
        foreach($st->fetchAll() as $t){
            $scope=(string)$t['task_scope'];$metric=(string)$t['metric_key'];$target=max(1,(int)$t['target_value']);
            $value=bfTaskMetricProgress($pdo,$user,$scope,$metric);
            if($value>=$target){
                bfCompleteTask($pdo,$user,(int)$t['id']);
            }
        }
    }catch(Throwable $e){}
}}
if(!function_exists('bfRefreshStudyStreak')){
function bfRefreshStudyStreak(PDO $pdo,array $user): int {
    try{
        $st=$pdo->prepare("SELECT DISTINCT DATE(created_at) d FROM bf_study_sessions WHERE user_email=? AND created_at>=DATE_SUB(CURDATE(),INTERVAL 400 DAY) ORDER BY d DESC");
        $st->execute([(string)$user['email']]);$dates=[];foreach($st->fetchAll() as $r)$dates[]=$r['d'];
        if(!$dates){$streak=0;}
        else{
            $today=date('Y-m-d');$yesterday=date('Y-m-d',strtotime('-1 day'));
            if($dates[0]!==$today && $dates[0]!==$yesterday){$streak=0;}
            else{
                $streak=1;$cursor=$dates[0];
                for($i=1;$i<count($dates);$i++){
                    $expected=date('Y-m-d',strtotime($cursor.' -1 day'));
                    if($dates[$i]!==$expected)break;
                    $streak++;$cursor=$dates[$i];
                }
            }
        }
        $pdo->prepare("UPDATE bf_users SET streak_days=? WHERE id=?")->execute([$streak,(int)$user['id']]);
        return $streak;
    }catch(Throwable $e){return (int)($user['streak_days']??0);}
}}

if(!function_exists('bfGeneratePersonalNotifications')){
function bfGeneratePersonalNotifications(PDO $pdo,array $u): void {
    $uid=(int)$u['id'];$email=(string)$u['email'];$today=date('Y-m-d');
    try{
        if(!empty($u['birthday']) && substr((string)$u['birthday'],5)===date('m-d')) bfNotifyUser($pdo,$email,'🎂 Chúc mừng sinh nhật!','Ban quản trị Brain Focus chúc bạn một tuổi mới nhiều sức khỏe, kỷ luật và những phiên học thật hiệu quả.','BIRTHDAY','success','/profile.php','birthday:'.date('Y'),'NORMAL');
        $st=$pdo->prepare("SELECT COUNT(*) c,COALESCE(SUM(CASE WHEN actual_seconds>0 THEN actual_seconds ELSE duration_minutes*60 END),0) sec FROM bf_study_sessions WHERE user_email=? AND created_at>=CURDATE()");$st->execute([$email]);$d=$st->fetch();$mins=(int)round(((int)$d['sec'])/60);bfNotifyUser($pdo,$email,'📈 Tiến độ học hôm nay','Hôm nay bạn đã hoàn thành '.(int)$d['c'].' phiên, tương đương '.$mins.' phút tập trung.','PROGRESS','info','/profile.php','progress-day:'.$today,'LOW');
        $week=date('o-W');$st=$pdo->prepare("SELECT COUNT(*) c,COALESCE(SUM(CASE WHEN actual_seconds>0 THEN actual_seconds ELSE duration_minutes*60 END),0) sec FROM bf_study_sessions WHERE user_email=? AND created_at>=DATE_SUB(CURDATE(),INTERVAL WEEKDAY(CURDATE()) DAY)");$st->execute([$email]);$w=$st->fetch();bfNotifyUser($pdo,$email,'📊 Tổng kết tuần','Tuần này bạn đã có '.(int)$w['c'].' phiên và '.(int)round(((int)$w['sec'])/60).' phút tập trung.','PROGRESS','info','/profile.php','progress-week:'.$week,'LOW');
        $now=date('H:i');$rs=$pdo->prepare("SELECT id,reminder_time,reminder_text FROM bf_study_reminders WHERE user_id=? AND is_active=1");$rs->execute([$uid]);foreach($rs->fetchAll() as $r){$hm=substr((string)$r['reminder_time'],0,5);if(abs(strtotime($today.' '.$hm)-time())<=900)bfNotifyUser($pdo,$email,'⏰ Đến giờ học','Lịch nhắc: '.$r['reminder_text'].' ('.$hm.').','REMINDER','info','/index.php','reminder:'.$r['id'].':'.$today,'HIGH');}
    }catch(Throwable $e){}
}}
if(!function_exists('bfCheckRookieOnboarding')){
function bfCheckRookieOnboarding(PDO $pdo,array $u): void {
    try{
        $pc=bfProfileCompletion($u);if($pc['percent']<100)return;
        if((int)($u['bfs_assessment_score']??0)<=0 || (int)($u['sessions_count']??0)<=0 || (int)($u['gym_count']??0)<=0)return;
        $terms=bfCurrentTerms($pdo);if($terms && !bfTermsAccepted($pdo,(int)$u['id'],(int)$terms['id']))return;
        $pdo->prepare("UPDATE bf_users SET onboarding_completed_at=COALESCE(onboarding_completed_at,NOW()) WHERE id=?")->execute([(int)$u['id']]);
        bfAwardBadgeByCode($pdo,(int)$u['id'],'ROOKIE_BRAIN_FOCUS','Hoàn thành 100% hồ sơ và các bước khởi động');
    }catch(Throwable $e){}
}}
