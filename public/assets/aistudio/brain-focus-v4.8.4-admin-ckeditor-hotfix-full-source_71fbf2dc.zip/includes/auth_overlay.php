<div id="account-auth-modal" class="hidden fixed inset-0 z-[80] bg-slate-950/70 backdrop-blur-sm p-4">
  <div class="min-h-full flex items-center justify-center">
    <div class="w-full max-w-md rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
      <div class="p-6 border-b border-slate-100 flex items-start justify-between gap-4">
        <div>
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-[11px] font-semibold border border-blue-200">🔐 Xác thực học viên</div>
          <h3 class="mt-3 text-xl font-bold text-slate-900">Đăng nhập để tiếp tục</h3>
          <p class="text-sm text-slate-500 mt-1">Đăng nhập hoặc tạo tài khoản Brain Focus để mở khoá toàn bộ chức năng.</p>
        </div>
        <button type="button" onclick="document.getElementById('account-auth-modal').classList.add('hidden')" class="w-10 h-10 rounded-xl border border-slate-200 text-slate-500">✕</button>
      </div>
      <div class="p-6 grid gap-4 sm:grid-cols-2">
        <a href="/login.php?next=<?=urlencode($_SERVER['REQUEST_URI'] ?? '/')?>" class="rounded-2xl border border-slate-200 p-4 hover:border-blue-300 hover:bg-blue-50/40 transition"><div class="text-lg">👤</div><div class="font-bold text-slate-900 mt-2">Đăng nhập</div><p class="text-xs text-slate-500 mt-1">Tiếp tục bằng email và mật khẩu hiện có.</p></a>
        <a href="/login.php?mode=register&next=<?=urlencode($_SERVER['REQUEST_URI'] ?? '/')?>" class="rounded-2xl border border-slate-200 p-4 hover:border-emerald-300 hover:bg-emerald-50/40 transition"><div class="text-lg">📝</div><div class="font-bold text-slate-900 mt-2">Tạo tài khoản</div><p class="text-xs text-slate-500 mt-1">Đăng ký nhanh với mật khẩu mạnh để đồng bộ dữ liệu.</p></a>
      </div>
      <div class="px-6 pb-6 flex items-center justify-between gap-2 text-xs"><a href="/login.php?mode=forgot&next=<?=urlencode($_SERVER['REQUEST_URI'] ?? '/')?>" class="text-blue-700 font-semibold">Quên mật khẩu</a><span class="text-slate-400">Mã xác nhận sẽ gửi qua email.</span></div>
    </div>
  </div>
</div>
