<?php
require_once __DIR__.'/includes/bootstrap.php';
bfStartUserSession();
function bfGoogleHttp($url,$method='GET',$data=null,$headers=[]){
    if(!function_exists('curl_init')) throw new RuntimeException('Hosting chưa bật PHP cURL.');
    $ch=curl_init($url);curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);curl_setopt($ch,CURLOPT_TIMEOUT,20);curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    if($method==='POST'){curl_setopt($ch,CURLOPT_POST,true);curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($data?:[]));}
    $body=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    if($body===false||$code<200||$code>=300) throw new RuntimeException('Google OAuth thất bại: '.($err?:('HTTP '.$code)));
    $j=json_decode($body,true);if(!is_array($j))throw new RuntimeException('Phản hồi Google không hợp lệ.');return $j;
}
$state=(string)($_GET['state']??'');$code=(string)($_GET['code']??'');
if(!$state||!hash_equals((string)($_SESSION['bf_google_oauth_state']??''),$state)||!$code){http_response_code(400);die('Phiên đăng nhập Google không hợp lệ hoặc đã hết hạn.');}
unset($_SESSION['bf_google_oauth_state']);$next=(string)($_SESSION['bf_google_oauth_next']??'/');unset($_SESSION['bf_google_oauth_next']);
try{
    $tok=bfGoogleHttp('https://oauth2.googleapis.com/token','POST',['code'=>$code,'client_id'=>BF_GOOGLE_CLIENT_ID,'client_secret'=>BF_GOOGLE_CLIENT_SECRET,'redirect_uri'=>BF_GOOGLE_REDIRECT_URI,'grant_type'=>'authorization_code']);
    $access=(string)($tok['access_token']??'');if($access==='')throw new RuntimeException('Google không trả access token.');
    $info=bfGoogleHttp('https://openidconnect.googleapis.com/v1/userinfo','GET',null,['Authorization: Bearer '.$access]);
    $sub=trim((string)($info['sub']??''));$email=strtolower(trim((string)($info['email']??'')));$verified=!empty($info['email_verified']);$name=trim((string)($info['name']??''));$avatar=trim((string)($info['picture']??''));
    if(!$sub||!filter_var($email,FILTER_VALIDATE_EMAIL)||!$verified)throw new RuntimeException('Google chưa xác minh được email tài khoản.');
    $pdo->beginTransaction();
    $st=$pdo->prepare("SELECT * FROM bf_users WHERE google_sub=? OR email=? ORDER BY (google_sub=? ) DESC LIMIT 1");$st->execute([$sub,$email,$sub]);$u=$st->fetch();
    $isNewGoogleUser=false;
    if($u){
        if((string)$u['status']!=='ACTIVE')throw new RuntimeException('Tài khoản Brain Focus đang bị khóa.');
        if(empty($u['google_sub']))$pdo->prepare("UPDATE bf_users SET google_sub=?,google_linked_at=NOW(),avatar=CASE WHEN (avatar IS NULL OR avatar='') THEN ? ELSE avatar END WHERE id=?")->execute([$sub,$avatar,$u['id']]);
    }else{
        $pdo->prepare("INSERT INTO bf_users(email,name,school,password_hash,google_sub,google_linked_at,avatar,rank_points,bfs_score,streak_days,sessions_count,gym_count,purchased_gym_plays) VALUES(?,?,?,NULL,?,NOW(),?,1000,0,1,0,0,0)")->execute([$email,$name?:'Học viên Google','Người học tập trung',$sub,$avatar]);
        $id=(int)$pdo->lastInsertId();$isNewGoogleUser=true;
        try{$rem=$pdo->prepare("INSERT INTO bf_study_reminders(user_id,reminder_time,reminder_text,is_active) VALUES(?,?,?,1)");foreach([['08:30:00','Học sâu buổi sáng (Lock In)'],['14:00:00','Gym não giải toả (3 Game)'],['20:00:00','Chu kỳ Ultradian tối (90p)']] as $r)$rem->execute([$id,$r[0],$r[1]]);}catch(Throwable $ignore){}
        $st=$pdo->prepare("SELECT * FROM bf_users WHERE id=?");$st->execute([$id]);$u=$st->fetch();
    }
    $pdo->commit();bfLoginUser($pdo,$u);if($isNewGoogleUser)$_SESSION['bf_new_user_terms_no_reward']=1;bfRecordLoginHistory($pdo,$email,true);bfLogAccess($pdo,['user_id'=>$u['id'],'email'=>$email,'event_type'=>'GOOGLE_LOGIN_SUCCESS']);header('Location: '.($isNewGoogleUser?'/welcome.php':$next));exit;
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log('[BrainFocus Google OAuth] '.$e->getMessage());http_response_code(400);echo '<!doctype html><html><meta charset="utf-8"><body style="font-family:Arial;padding:30px"><h2>Không thể đăng nhập bằng Google</h2><p>'.htmlspecialchars($e->getMessage()).'</p><p><a href="/login.php">Quay lại đăng nhập</a></p></body></html>';}
