(function(){
  window.BFCKEditor = {
    create: function(selector, config){
      var el = typeof selector === 'string' ? document.querySelector(selector) : selector;
      if(!el) return Promise.resolve(null);
      if(!window.ClassicEditor){
        console.warn('[Brain Focus] CKEditor chưa tải được; giữ textarea thường. Kiểm tra CSP/CDN.');
        el.setAttribute('data-ckeditor-fallback','1');
        return Promise.resolve(null);
      }
      return window.ClassicEditor.create(el, config || {}).catch(function(err){
        console.error('[Brain Focus] CKEditor init failed:', err);
        el.setAttribute('data-ckeditor-fallback','1');
        return null;
      });
    }
  };
})();
