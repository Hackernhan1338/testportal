# Brain Focus v4.5.2 – BFS Attention Checks + Classic Login

## Kiểm tra BFS
- BFS thật chỉ tính từ các câu khảo sát chính.
- Chèn ngẫu nhiên các câu kiểm tra chú ý có giao diện giống câu khảo sát thường.
- Câu kiểm tra chú ý không tham gia tính BFS thật.
- Nếu sai câu kiểm tra chú ý, kết quả chưa được công nhận và học viên phải làm lại.
- Thưởng làm lại được cộng vào Điểm XH, không làm thay đổi BFS thật.
- Mức mặc định: làm lại hợp lệ +30 XH; sau một lần bỏ qua câu kiểm tra chú ý +15 XH; tái phạm +5 XH.
- Ghi lịch sử vào `bf_bfs_test_attempts` và point ledger.

## Login
- Khôi phục giao diện khóa Brain Focus theo giao diện classic.
- Luôn yêu cầu nhập email thủ công.
- Không chọn/gợi ý tài khoản theo IP hoặc thiết bị.
- Nút Đổi tài khoản được thay bằng Quên mật khẩu.
- Giữ đầy đủ Gmail SMTP OTP, đăng ký tài khoản và mật khẩu mạnh.

## Cài đặt
Chạy `sql/migration_v4_5_2_bfs_attention_login_classic.sql` nếu nâng từ v4.5.1.
