# BRAIN FOCUS v3 — TRIỂN KHAI TRÊN HOSTINGER / PHP + MYSQL

Bản v3 sử dụng kiến trúc quản trị theo mô hình EduWall: giao diện người dùng tách module, Admin Center độc lập, API PHP, MySQL, RBAC, CSRF, Audit Log và Session Inspector. **Không cần Node.js, React hay VPS.**

## 1. Yêu cầu

- PHP 8.0+ (khuyến nghị 8.1/8.2)
- MySQL 5.7+ hoặc MariaDB tương thích
- PDO MySQL
- HTTPS trên domain production

## 2. Cấu trúc chính

```text
public_html/
├── index.html
├── .htaccess
├── assets/
│   ├── css/app.css
│   ├── css/deep-focus.css
│   ├── js/app.js
│   ├── js/database.js
│   └── js/deep-focus.js
├── admin/
│   ├── index.php
│   ├── setup.php
│   └── assets/
├── api/
│   ├── db.php
│   ├── users.php
│   ├── events.php
│   ├── feedback.php
│   ├── admin_auth.php
│   ├── admin_security.php
│   └── admin.php
└── sql/
    ├── schema.sql
    └── migration_2026_09_admin_center.sql
```

## 3. Nếu cài mới hoàn toàn

1. Tạo database và database user trong Hostinger.
2. Import `sql/schema.sql` bằng phpMyAdmin.
3. Cấu hình thông tin database cho `api/db.php` bằng biến môi trường nếu hosting hỗ trợ; nếu không, thay các giá trị mặc định `DB_NAME`, `DB_USER`, `DB_PASS` trong file.
4. Upload toàn bộ mã nguồn lên `public_html/`.
5. Mở `https://ten-mien-cua-ban/admin/setup.php`.
6. Tạo tài khoản **Super Admin đầu tiên** với mật khẩu tối thiểu 12 ký tự.
7. Sau khi tạo thành công, `setup.php` tự vô hiệu vì bảng `bf_admins` đã có tài khoản.

Không còn mật khẩu Super Admin mặc định trong mã nguồn.

## 4. Nếu nâng cấp từ Brain Focus cũ

**Sao lưu database trước.** Sau đó:

1. Import `sql/migration_2026_09_admin_center.sql` vào database hiện tại. Migration chỉ bổ sung cột/bảng/quyền, không xóa dữ liệu học viên cũ.
2. Upload và ghi đè mã nguồn web bằng bản v3.
3. Giữ nguyên thông tin kết nối database đang dùng.
4. Truy cập `/admin/` và đăng nhập bằng tài khoản admin hiện tại.
5. Nếu tài khoản cũ dùng SHA-256 64 ký tự, lần đăng nhập hợp lệ đầu tiên sẽ tự nâng lên `password_hash()` và hệ thống đánh dấu yêu cầu đổi mật khẩu.

## 5. Admin Center

Đường dẫn: `https://ten-mien-cua-ban/admin/`

Các module gồm Dashboard, Analytics, Users, Session Inspector, CMS, Feedback, Audit Logs, Admin Accounts và Settings. Menu tự ẩn theo quyền của tài khoản.

RBAC mặc định:
- `ANALYST`: Dashboard, Analytics, Sessions (read-only)
- `MODERATOR`: thêm CMS và Feedback
- `ADMIN`: thêm Users, Settings, Audit và quyền vận hành
- `SUPER_ADMIN`: toàn quyền, bao gồm quản trị tài khoản admin

## 6. Lưu ý bảo mật

- Bật HTTPS.
- Không public file SQL; `.htaccess` trong gói đã chặn truy cập web trực tiếp tới `.sql`.
- Admin dùng PHP Session HttpOnly + SameSite Strict, CSRF token, permission check và Audit Log.
- API ghi dữ liệu phiên học yêu cầu mật khẩu học viên hiện tại.
- Không bật `BF_ALLOW_PUBLIC_USER_LOOKUP=1` trên production trừ khi thật sự cần.
- Nếu cần CORS cho một frontend khác domain, chỉ đặt chính xác `BF_ALLOWED_ORIGIN`; mặc định API dùng same-origin.

## 7. Sau khi upload

Kiểm tra lần lượt:

- `/` tải được Brain Focus.
- `/admin/` hiện màn hình đăng nhập.
- Cài mới: `/admin/setup.php` cho phép tạo admin đầu tiên; sau đó tự chuyển về `/admin/`.
- Một phiên Deep Focus hoàn tất xuất hiện trong Admin → Phiên học.
- Session Inspector hiển thị timeline như fullscreen/tab/pause/resume đối với phiên mới.
- Feedback người dùng xuất hiện trong Admin → Góp ý & báo lỗi.

---

## Bổ sung cho Brain Focus v4 PHP-first

Nếu đang nâng cấp từ bản v3, sau khi backup database hãy import thêm:

`sql/migration_2026_09_php_first.sql`

Sau đó upload toàn bộ source v4. `DirectoryIndex` đã ưu tiên `index.php`.

### Các route kiểm tra sau deploy
- `/login.php`
- `/index.php`
- `/focus.php`
- `/admin/login.php`
- `/admin/security.php`
- `/admin/forbidden-words.php`
- `/admin/honors.php`

### Cloudflare
Mặc định Brain Focus chỉ tin `REMOTE_ADDR` để tránh giả `X-Forwarded-For`. Nếu domain thực sự đặt sau Cloudflare và hosting nhận request từ Cloudflare, cấu hình biến môi trường `BF_TRUST_CF=1` để ghi IP client từ `CF-Connecting-IP`.

### Lưu ý dữ liệu
Không xóa bảng cũ. Migration v4 chỉ thêm bảng/quyền/dữ liệu seed bằng `CREATE TABLE IF NOT EXISTS` và `INSERT IGNORE`.
