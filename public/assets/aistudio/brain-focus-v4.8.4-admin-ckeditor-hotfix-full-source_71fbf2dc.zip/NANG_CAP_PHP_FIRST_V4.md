# Brain Focus v4 — PHP-first / EduWall-style architecture

## Mục tiêu
Bản v4 chuyển Brain Focus từ mô hình single-page lớn sang nhiều trang PHP nhỏ, dùng MySQL làm nguồn dữ liệu trung tâm và tách rõ user/admin/security/content/points.

## Trang người dùng
- `/index.php` — tổng quan.
- `/focus.php` — tự học + White/Pink/Brown noise.
- `/gym.php` — Brain Gym module riêng.
- `/knowledge.php` — kiến thức tập trung từ CMS.
- `/tips.php` — mẹo trị xao nhãng từ CMS.
- `/honors.php` — sổ điểm + huy hiệu/vinh danh.
- `/leaderboard.php` — bảng xếp hạng server-side.
- `/profile.php` — hồ sơ + thiết bị đã ghi nhận.
- `/feedback.php` — góp ý có lọc từ cấm.
- `/login.php`, `/logout.php` — PHP session cho học viên.

## Trang quản trị
- `/admin/index.php` — dashboard.
- `/admin/users.php` — học viên + chi tiết device/login/points/honors.
- `/admin/admins.php` — tài khoản admin, vai trò, khóa/mở.
- `/admin/sessions.php` — Session Inspector + timeline.
- `/admin/content.php` — CMS article/tip/FAQ.
- `/admin/feedback.php` — hàng đợi phản hồi.
- `/admin/honors.php` — giao dịch điểm + cấp vinh danh.
- `/admin/security.php` — access log + block IP/device/email/User-Agent.
- `/admin/forbidden-words.php` — từ/cụm từ cấm.
- `/admin/analytics.php`, `/admin/audit.php`, `/admin/settings.php`.
- `/admin/account.php` — đổi mật khẩu admin; bắt buộc với mật khẩu legacy/tạm.

## Bảo mật mới
- User và admin đều dùng session cookie HttpOnly.
- Device ID là cookie ngẫu nhiên; server chỉ lưu SHA-256 của ID này.
- IP mặc định lấy từ `REMOTE_ADDR`; không tin `X-Forwarded-For` tùy tiện.
- Nếu dùng Cloudflare thật, đặt `BF_TRUST_CF=1` để dùng `CF-Connecting-IP`.
- Access log lưu IP, device hash, User-Agent và browser info do trình duyệt báo cáo.
- Admin có thể chặn IP/device/email/User-Agent và đặt hạn chặn.
- Chặn nhanh IP/device ngay từ Access Log.
- Không cho admin tự chặn IP/device của phiên quản trị hiện tại.
- CSRF cho form user/admin.
- Rate limit đăng nhập sai theo IP: 10 lần/15 phút (khi bảng access log đã migration).
- Danh sách từ cấm áp dụng server-side theo phạm vi PROFILE/FEEDBACK/FOCUS/COMMUNITY/ALL.

## Chống gian lận điểm
- `rank_points` / `bfs_score` không còn nhận giá trị sync từ client.
- Endpoint legacy `save_session` vẫn lưu lịch sử nhưng không phát điểm.
- `/api/focus.php` yêu cầu `SESSION_START` đã được server ghi thời gian.
- Khi hoàn thành, điểm dựa trên thời gian thực server quan sát + Focus Integrity.
- Mọi cộng/trừ điểm có dòng trong `bf_point_transactions`.
- Vinh danh tự động có tiêu chí và reward; cấp thủ công ghi admin thực hiện.

## Migration
Database đang chạy v3: import `sql/migration_2026_09_php_first.sql` sau khi sao lưu DB.
Cài mới: chỉ cần import `sql/schema.sql` (đã kèm schema v4).

## Quyền riêng tư
Bản v4 không triển khai fingerprint bí mật hoặc thu thập canvas/font fingerprint. Dữ liệu thiết bị dùng cho bảo mật gồm IP mà server thấy, User-Agent, một device ID ngẫu nhiên và thông tin platform/language/screen cơ bản từ browser.
