# Brain Focus v4.5.1 Gmail SMTP

## Cấu hình nhanh
Mở `api/db.php`, tìm `BF_SMTP_APP_PASSWORD` và thay giá trị mẫu bằng App Password 16 ký tự của Gmail.

Ví dụ:
```php
define('BF_SMTP_APP_PASSWORD', 'abcd efgh ijkl mnop');
```

Hệ thống tự bỏ khoảng trắng trong App Password.

## Trước khi sử dụng
1. Bật Xác minh 2 bước cho tài khoản Gmail.
2. Tạo App Password dành cho Brain Focus.
3. Dán mã 16 ký tự vào `api/db.php`.
4. Import `sql/migration_v4_5_1_gmail_smtp.sql` nếu đã dùng DB cũ.
5. Đăng nhập Admin > Email SMTP > gửi email thử.
6. Nếu test thành công, học viên có thể dùng Quên mật khẩu.

## Bảo mật OTP
- OTP 6 số, hiệu lực 10 phút.
- OTP chỉ lưu SHA-256 trong DB.
- Chờ 60 giây giữa hai lần gửi.
- Tối đa 5 yêu cầu/giờ/email.
- Tối đa 5 lần nhập sai/mã.
- Đổi mật khẩu thành công sẽ thu hồi toàn bộ session cũ.

## Lưu ý hosting
Hosting phải cho phép kết nối outbound TCP tới `smtp.gmail.com:587` và PHP phải bật OpenSSL. Nếu bị chặn, trang Admin > Email SMTP sẽ trả thông báo lỗi kết nối.
