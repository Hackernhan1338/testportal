# Brain Focus v4.6.0 – Giai đoạn 1

## Nội dung
- Điều khoản sử dụng + chính sách bảo vệ dữ liệu có version.
- Đăng ký thường phải cuộn hết điều khoản mới bật checkbox đồng ý.
- Người dùng cũ chưa đồng ý phiên bản hiện tại bị chuyển tới `/terms-accept.php`; xác nhận được thưởng theo `reward_xp` (mặc định +50 XP), mỗi version chỉ một lần.
- Admin `/admin/terms.php`: công bố version mới, đặt XP, xem số/tỷ lệ đã đồng ý.
- Khi công bố version mới, toàn bộ học viên ACTIVE nhận thông báo TERMS.
- Trung tâm thông báo `/notifications.php` với đánh dấu từng thông báo / tất cả đã đọc.
- Google OAuth 2.0: `/google-login.php` và `/google-callback.php`.
- Admin gửi mail hàng loạt `/admin/mail-broadcast.php` qua Gmail SMTP, queue theo lô 5 để giảm timeout shared hosting.
- Footer: link nhanh, điều khoản, thông báo, feedback, email liên hệ, social URL, app version.

## Google OAuth
Trong Google Cloud Console tạo OAuth Client ID loại **Web application**.

Authorized redirect URI phải khớp chính xác:
`https://TEN-MIEN-CUA-BAN/google-callback.php`

Trong `api/db.php`, thay:
- `BF_GOOGLE_CLIENT_ID`
- `BF_GOOGLE_CLIENT_SECRET`
- `BF_GOOGLE_REDIRECT_URI`

Brain Focus không nhận mật khẩu Google. Người dùng đăng nhập trực tiếp trên trang của Google; Brain Focus chỉ lấy `sub`, email đã xác minh, tên và avatar từ Google OAuth userinfo.

## Nâng cấp từ v4.5.4
1. Backup DB và source.
2. Import `sql/migration_v4_6_phase1_terms_google_footer_mail.sql`.
3. Upload source v4.6.0 Phase 1.
4. Giữ App Password Gmail hiện tại trong `api/db.php`.
5. Điền Google OAuth Client ID/Secret/Redirect URI.
6. Vào Admin → Điều khoản, kiểm tra version 1.0 và tỷ lệ đồng ý.
7. Test đăng ký mới, tài khoản cũ, Google Login và email campaign.
