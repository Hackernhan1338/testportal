<?php
require_once __DIR__.'/includes/bootstrap.php';
bfStartUserSession();
if(strpos((string)BF_GOOGLE_CLIENT_ID,'DAN_GOOGLE_CLIENT_ID')!==false){http_response_code(503);die('Google Login chưa được cấu hình. Hãy nhập Client ID/Secret trong api/db.php.');}
$next=(string)($_GET['next']??'/');if($next===''||substr($next,0,1)!=='/'||substr($next,0,2)==='//')$next='/';
$state=bin2hex(random_bytes(24));$_SESSION['bf_google_oauth_state']=$state;$_SESSION['bf_google_oauth_next']=$next;
$params=['client_id'=>BF_GOOGLE_CLIENT_ID,'redirect_uri'=>BF_GOOGLE_REDIRECT_URI,'response_type'=>'code','scope'=>'openid email profile','state'=>$state,'access_type'=>'online','prompt'=>'select_account'];
header('Location: https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query($params));exit;
