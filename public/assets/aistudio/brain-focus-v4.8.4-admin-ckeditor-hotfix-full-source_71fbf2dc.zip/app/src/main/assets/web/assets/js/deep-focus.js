/**
 * BRAIN FOCUS v3 - USER RUNTIME MODULE
 * Chỉ chứa Deep Focus, analytics phía người dùng và feedback.
 * Admin Center đã được tách hoàn toàn sang /admin/.
 */
(function(window){
  'use strict';
  const STORAGE_KEYS={
    ANALYTICS:'adminpagentn_analytics_events',
    FEEDBACK:'adminpagentn_feedback_store',
    SETTINGS:'adminpagentn_system_settings',
    DYNAMIC_CONTENT:'adminpagentn_dynamic_content',
    DEEP_FOCUS_ACTIVE:'adminpagentn_deep_focus_active'
  };
  async function adminpagentnSeedInitialData(){
    // Xóa dấu vết cổng admin localStorage v2.
    localStorage.removeItem('adminpagentn_admins');
    sessionStorage.removeItem('adminpagentn_session');
    if(!localStorage.getItem(STORAGE_KEYS.SETTINGS)){
      localStorage.setItem(STORAGE_KEYS.SETTINGS,JSON.stringify({siteName:'Brain Focus',siteTagline:'Nền Tảng Quản Lý Tập Trung & Rèn Luyện Não Bộ',defaultFocusDuration:90,deepFocusAllowedDurations:[15,25,50,60,90,120],maxDailySessions:3,maxDailyGymPlays:5,maintenanceMode:false,systemAnnouncement:'',showAnnouncement:false,enableGSheetSync:true}));
    }
    if(!localStorage.getItem(STORAGE_KEYS.DYNAMIC_CONTENT)){
      localStorage.setItem(STORAGE_KEYS.DYNAMIC_CONTENT,JSON.stringify([]));
    }
  }

  // ================= 5. ANALYTICS ENGINE =================
  const adminpagentnAnalytics = {
    getEvents() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.ANALYTICS);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    },

    track(eventName, data = {}) {
      const events = this.getEvents();
      const deviceType = window.innerWidth <= 640 ? 'Mobile' : (window.innerWidth <= 1024 ? 'Tablet' : 'Desktop');
      
      let browser = 'Other';
      const ua = navigator.userAgent;
      if (ua.includes('Edg/')) browser = 'Edge';
      else if (ua.includes('Chrome/')) browser = 'Chrome';
      else if (ua.includes('Safari/') && !ua.includes('Chrome/')) browser = 'Safari';
      else if (ua.includes('Firefox/')) browser = 'Firefox';

      const eventItem = {
        id: 'ev_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        name: eventName,
        timestamp: Date.now(),
        date: new Date().toISOString().split('T')[0],
        hour: new Date().getHours(),
        path: window.location.pathname || '/',
        device: deviceType,
        browser: browser,
        data: data
      };

      events.push(eventItem);
      // Keep last 5000 events
      if (events.length > 5000) events.splice(0, events.length - 5000);
      try {
        localStorage.setItem(STORAGE_KEYS.ANALYTICS, JSON.stringify(events));
      } catch (e) {}
      if (typeof window.bfTrackAnalyticsEvent === 'function') {
        window.bfTrackAnalyticsEvent(eventName, window.APP_STATE?.userEmail || '', { ...data, device: deviceType, browser, path: eventItem.path });
      }
    },

    getKPIs() {
      const events = this.getEvents();
      const now = new Date();
      const todayStr = now.toISOString().split('T')[0];
      const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);

      // Load registered users from app state / localStorage
      let users = [];
      try {
        const uRaw = localStorage.getItem('bf_registered_users');
        users = uRaw ? JSON.parse(uRaw) : [];
      } catch (e) { users = []; }

      // Total users
      const totalUsers = users.length;
      
      // Calculate Sessions from all users
      let totalSessions = 0;
      let totalFocusMinutes = 0;
      let totalDeepFocusSessions = 0;
      let totalFullscreenSessions = 0;
      let totalIntegritySum = 0;
      let integrityCount = 0;
      let totalGymPlays = 0;
      let totalBfsSum = 0;

      users.forEach(u => {
        const sCount = Number(u.sessionsCount) || 0;
        totalSessions += sCount;
        totalFocusMinutes += (Number(u.totalHours) || 0) * 60;
        totalGymPlays += (Number(u.gymCompletedCount) || 0);
        totalBfsSum += (Number(u.bfs) || 0);

        if (Array.isArray(u.history)) {
          u.history.forEach(h => {
            if (h.isDeepFocus || (h.subject && h.subject.toLowerCase().includes('sâu'))) {
              totalDeepFocusSessions++;
            }
            if (h.usedFullscreen) {
              totalFullscreenSessions++;
            }
            if (h.focusIntegrity !== undefined) {
              totalIntegritySum += Number(h.focusIntegrity);
              integrityCount++;
            }
          });
        }
      });

      // Events-based today KPIs
      const todayPageviews = events.filter(e => e.name === 'page_view' && e.date === todayStr).length;
      const todayFocusStarts = events.filter(e => (e.name === 'focus_start' || e.name === 'deep_focus_start') && e.date === todayStr).length;
      const todayFocusCompletes = events.filter(e => e.name === 'focus_complete' && e.date === todayStr).length;
      const todayFocusCancels = events.filter(e => e.name === 'focus_cancel' && e.date === todayStr).length;

      const activeUsersTodaySet = new Set();
      const activeUsers7DaysSet = new Set();
      events.forEach(e => {
        if (e.data && e.data.userEmail) {
          if (e.date === todayStr) activeUsersTodaySet.add(e.data.userEmail);
          if (e.timestamp >= sevenDaysAgo) activeUsers7DaysSet.add(e.data.userEmail);
        }
      });

      const avgIntegrity = integrityCount > 0 ? Math.round(totalIntegritySum / integrityCount) : 95;
      const avgBfs = totalUsers > 0 ? Math.round(totalBfsSum / totalUsers) : 760;
      const completionRate = (todayFocusStarts > 0) 
        ? Math.round((todayFocusCompletes / todayFocusStarts) * 100) 
        : 88;

      return {
        totalUsers: totalUsers,
        activeUsersToday: Math.max(activeUsersTodaySet.size, 1),
        activeUsers7Days: Math.max(activeUsers7DaysSet.size, 1),
        totalSessions: totalSessions,
        todaySessions: todayFocusCompletes,
        totalFocusMinutes: Math.round(totalFocusMinutes),
        todayFocusMinutes: todayFocusCompletes * 50,
        completionRate: completionRate,
        dropRate: Math.max(0, 100 - completionRate),
        deepFocusSessions: totalDeepFocusSessions,
        fullscreenRate: totalDeepFocusSessions > 0 ? Math.round((totalFullscreenSessions / totalDeepFocusSessions) * 100) : 92,
        avgIntegrity: avgIntegrity,
        avgBfs: avgBfs,
        totalGymPlays: totalGymPlays,
        totalPageViews: events.filter(e => e.name === 'page_view').length || 120,
        todayPageViews: todayPageviews
      };
    }
  };

  // ================= 6. FEEDBACK SERVICE =================
  const adminpagentnFeedbackService = {
    getAll() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.FEEDBACK);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    },

    submitFeedback(feedbackData) {
      const items = this.getAll();
      const newItem = {
        id: 'fb_' + Date.now(),
        type: feedbackData.type || 'Góp ý', // 'Báo lỗi', 'Yêu cầu tính năng', 'UI/UX', 'Nội dung', 'Khác'
        severity: feedbackData.severity || 'Trung bình', // 'Thấp', 'Trung bình', 'Cao', 'Khẩn cấp'
        title: feedbackData.title || '',
        content: feedbackData.content || '',
        userEmail: feedbackData.userEmail || '',
        userName: feedbackData.userName || 'Học viên',
        screenshot: feedbackData.screenshot || null, // Base64 data URL
        status: 'NEW', // 'NEW', 'REVIEWING', 'IN_PROGRESS', 'RESOLVED', 'REJECTED'
        adminNote: '',
        adminReply: '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      items.unshift(newItem);
      localStorage.setItem(STORAGE_KEYS.FEEDBACK, JSON.stringify(items));
      adminpagentnAnalytics.track('feedback_submit', { id: newItem.id, type: newItem.type });

      // Gửi đồng bộ lên PHP/MySQL backend nếu đang chạy trên hosting
      if (typeof bfSendFeedbackToDatabase === 'function') {
        bfSendFeedbackToDatabase({
          type: newItem.type,
          severity: newItem.severity,
          title: newItem.title,
          content: newItem.content,
          user_email: newItem.userEmail,
          user_name: newItem.userName,
          screenshot: newItem.screenshot
        });
      }

      return newItem;
    },

  };

  // ================= 7. DEEP FOCUS 2.0 & FOCUS INTEGRITY ENGINE =================
  const adminpagentnDeepFocus = {
    session: null,
    heartbeatInterval: null,

    startPreparation(durationMinutes = 90) {
      // Render Preparation Modal
      const modalHtml = `
        <div id="adminpagentn-deep-prep-modal" class="adminpagentn-modal-backdrop">
          <div class="adminpagentn-modal-content p-6 max-w-lg space-y-5">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
              <div class="flex items-center gap-2">
                <span class="text-2xl">🧘</span>
                <h3 class="text-base font-bold text-slate-900">CHUẨN BỊ PHIÊN HỌC SÂU (DEEP FOCUS 2.0)</h3>
              </div>
              <button onclick="document.getElementById('adminpagentn-deep-prep-modal').remove()" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center">✕</button>
            </div>

            <div class="space-y-3">
              <div>
                <label class="text-xs font-bold text-slate-700 block mb-1">1. Lựa chọn thời lượng phiên học:</label>
                <div class="grid grid-cols-3 gap-2">
                  ${[15, 25, 50, 60, 90, 120].map(m => `
                    <button type="button" onclick="window.adminpagentnSetDuration(${m})" id="adminpagentn-dur-${m}" class="adminpagentn-dur-btn py-2 text-xs font-bold rounded-lg border ${m === durationMinutes ? 'bg-blue-900 text-white border-blue-900' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'}">
                      ${m} phút
                    </button>
                  `).join('')}
                </div>
              </div>

              <div>
                <label class="text-xs font-bold text-slate-700 block mb-1">2. Mục tiêu trọng tâm của phiên này:</label>
                <input type="text" id="adminpagentn-deep-goal-input" placeholder="Ví dụ: Giải xong 15 bài toán hình chuyên đề Oxy..." class="adminpagentn-input" />
              </div>

              <div class="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 space-y-1">
                <p class="font-bold flex items-center gap-1.5">
                  <span>🖥️</span> <span>Chế độ Toàn Màn Hình & Liêm Chính (Focus Integrity):</span>
                </p>
                <p class="leading-relaxed text-amber-800">
                  Khi bắt đầu, hệ thống sẽ kích hoạt <strong>Fullscreen API</strong>. Hệ thống tự động ghi nhận nếu bạn thoát Fullscreen hoặc chuyển Tab để tính <strong>Chỉ số Focus Integrity (0-100)</strong> minh bạch. Bạn cũng có thể bấm <strong>F11</strong> để sử dụng chế độ toàn màn hình mặc định của trình duyệt.
                </p>
              </div>
            </div>

            <div class="flex gap-2 pt-2">
              <button onclick="document.getElementById('adminpagentn-deep-prep-modal').remove()" class="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl">
                Hủy bỏ
              </button>
              <button onclick="window.adminpagentnLaunchDeepSession()" class="flex-2 py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5">
                <span>🚀</span> BẮT ĐẦU HỌC SÂU TOÀN MÀN HÌNH
              </button>
            </div>
          </div>
        </div>
      `;

      const existing = document.getElementById('adminpagentn-deep-prep-modal');
      if (existing) existing.remove();
      document.body.insertAdjacentHTML('beforeend', modalHtml);
      window.adminpagentnSelectedDuration = durationMinutes;

      window.adminpagentnSetDuration = (m) => {
        window.adminpagentnSelectedDuration = m;
        document.querySelectorAll('.adminpagentn-dur-btn').forEach(btn => {
          btn.className = 'adminpagentn-dur-btn py-2 text-xs font-bold rounded-lg border bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100';
        });
        const active = document.getElementById(`adminpagentn-dur-${m}`);
        if (active) active.className = 'adminpagentn-dur-btn py-2 text-xs font-bold rounded-lg border bg-blue-900 text-white border-blue-900';
      };

      window.adminpagentnLaunchDeepSession = () => {
        const goalInput = document.getElementById('adminpagentn-deep-goal-input');
        const goal = (goalInput && goalInput.value.trim()) || 'Hoàn thành phiên học sâu chuyên tâm';
        const dur = window.adminpagentnSelectedDuration || 90;
        document.getElementById('adminpagentn-deep-prep-modal').remove();
        adminpagentnDeepFocus.launch(dur, goal);
      };
    },

    async launch(durationMinutes, goal) {
      // 1. Request Fullscreen API
      let isFullscreen = false;
      try {
        if (document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
          isFullscreen = true;
        } else if (document.documentElement.webkitRequestFullscreen) {
          await document.documentElement.webkitRequestFullscreen();
          isFullscreen = true;
        }
      } catch (e) {
        console.warn('Fullscreen request rejected or not supported. Instruct user with F11:', e);
      }

      // 2. Initialize Session
      this.session = {
        id: 'deep_' + Date.now(),
        durationSeconds: durationMinutes * 60,
        remainingSeconds: durationMinutes * 60,
        goal: goal,
        startTime: Date.now(),
        targetEndTime: Date.now() + (durationMinutes * 60 * 1000),
        exitFullscreenCount: 0,
        tabSwitchCount: 0,
        pauseMinutes: 0,
        isPaused: false,
        isFullscreen: isFullscreen,
        focusIntegrity: 100
      };

      this.saveState();
      adminpagentnAnalytics.track('deep_focus_start', { duration: durationMinutes, goal: goal });
      if (typeof window.bfTrackFocusEvent === 'function') {
        window.bfTrackFocusEvent('SESSION_START', { clientSessionId: this.session.id, durationMinutes, goal, integrity: 100 });
        if (isFullscreen) window.bfTrackFocusEvent('FULLSCREEN_ENTER', { clientSessionId: this.session.id, integrity: 100 });
      }

      // 3. Render Zen Mode UI
      this.renderZenUI();

      // 4. Bind Listeners for Disruption & Integrity
      this.bindIntegrityWatchers();

      // 5. Start Heartbeat Timer
      this.startHeartbeat();
    },

    bindIntegrityWatchers() {
      // Fullscreen exit detection
      const handleFsChange = () => {
        const isFs = Boolean(document.fullscreenElement || document.webkitFullscreenElement);
        if (this.session) {
          this.session.isFullscreen = isFs;
          if (!isFs) {
            this.session.exitFullscreenCount++;
            this.recalculateIntegrity();
            adminpagentnAnalytics.track('fullscreen_exit', { count: this.session.exitFullscreenCount });
            if (typeof window.bfTrackFocusEvent === 'function') window.bfTrackFocusEvent('FULLSCREEN_EXIT', { clientSessionId: this.session.id, count: this.session.exitFullscreenCount, integrity: this.session.focusIntegrity });
            this.showZenNotification('⚠️ Bạn vừa rời chế độ Toàn màn hình! Chỉ số Liêm chính đã bị điều chỉnh.');
          } else {
            adminpagentnAnalytics.track('fullscreen_enter');
            if (typeof window.bfTrackFocusEvent === 'function') window.bfTrackFocusEvent('FULLSCREEN_ENTER', { clientSessionId: this.session.id, integrity: this.session.focusIntegrity });
          }
        }
      };
      document.addEventListener('fullscreenchange', handleFsChange);
      document.addEventListener('webkitfullscreenchange', handleFsChange);

      // Visibility & Tab Switch detection
      const handleVisibilityChange = () => {
        if (!this.session) return;
        if (document.hidden && !this.session.isPaused) {
          this.session.tabSwitchCount++;
          this.recalculateIntegrity();
          adminpagentnAnalytics.track('tab_switch', { count: this.session.tabSwitchCount });
          if (typeof window.bfTrackFocusEvent === 'function') window.bfTrackFocusEvent('TAB_HIDDEN', { clientSessionId: this.session.id, count: this.session.tabSwitchCount, integrity: this.session.focusIntegrity });
        } else if (!document.hidden && typeof window.bfTrackFocusEvent === 'function') {
          window.bfTrackFocusEvent('TAB_VISIBLE', { clientSessionId: this.session.id, integrity: this.session.focusIntegrity });
        }
      };
      document.addEventListener('visibilitychange', handleVisibilityChange);
    },

    recalculateIntegrity() {
      if (!this.session) return 100;
      // Calculation: 100 - (exitFullscreen * 8) - (tabSwitch * 5) - (pauseMin * 3)
      let score = 100;
      score -= (this.session.exitFullscreenCount * 8);
      score -= (this.session.tabSwitchCount * 5);
      score -= Math.floor(this.session.pauseMinutes * 3);
      if (score < 0) score = 0;
      if (score > 100) score = 100;
      this.session.focusIntegrity = score;
      this.updateZenIntegrityBadge();
      this.saveState();
      return score;
    },

    renderZenUI() {
      const existing = document.getElementById('adminpagentn-deep-zen-overlay');
      if (existing) existing.remove();

      const overlay = document.createElement('div');
      overlay.id = 'adminpagentn-deep-zen-overlay';
      overlay.className = 'adminpagentn-deep-focus-zen';
      overlay.innerHTML = `
        <!-- Top Bar Zen -->
        <div class="flex items-center justify-between shrink-0">
          <div class="flex items-center gap-3">
            <span class="text-xl">🧠</span>
            <div>
              <div class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">CHẾ ĐỘ HỌC SÂU TẬP TRUNG</div>
              <div class="text-sm font-semibold text-white truncate max-w-md" id="adminpagentn-zen-goal-text">${this.session.goal}</div>
            </div>
          </div>

          <div class="flex items-center gap-3">
            <div id="adminpagentn-zen-integrity-badge" class="adminpagentn-integrity-badge text-emerald-400">
              <span>🛡️ Focus Integrity:</span>
              <span id="adminpagentn-zen-integrity-val">100/100</span>
            </div>
            <button onclick="window.adminpagentnToggleFullscreenDirect()" class="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5" title="Bật/Tắt Toàn Màn Hình (F11)">
              <span>⛶</span> <span class="hidden sm:inline">Toàn màn hình</span>
            </button>
          </div>
        </div>

        <!-- Center Display Timer -->
        <div class="flex flex-col items-center justify-center my-auto space-y-4">
          <div id="adminpagentn-zen-timer-text" class="adminpagentn-deep-timer-display">
            ${this.formatTime(this.session.remainingSeconds)}
          </div>
          <div class="flex items-center gap-4 text-xs font-mono text-slate-400">
            <span id="adminpagentn-zen-fs-indicator">Rời màn hình: 0 lần</span>
            <span>•</span>
            <span id="adminpagentn-zen-tab-indicator">Chuyển tab: 0 lần</span>
          </div>
          <div id="adminpagentn-zen-toast-box" class="h-6 text-xs text-amber-400 font-medium transition-opacity opacity-0"></div>
        </div>

        <!-- Bottom Controls -->
        <div class="flex items-center justify-between shrink-0 pt-4 border-t border-slate-900">
          <div class="text-xs text-slate-500">
            <span>* Nhấn phím </span><kbd class="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded text-[10px]">F11</kbd><span> để bật/tắt toàn màn hình trình duyệt.</span>
          </div>

          <div class="flex items-center gap-3">
            <button id="adminpagentn-zen-pause-btn" onclick="window.adminpagentnTogglePauseDeep()" class="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center gap-2">
              <span>⏸</span> <span>Tạm dừng</span>
            </button>
            <button onclick="window.adminpagentnEndDeepSession()" class="px-5 py-2.5 rounded-xl bg-rose-900/80 hover:bg-rose-800 text-white font-bold text-xs flex items-center gap-2">
              <span>⏹</span> <span>Kết thúc phiên</span>
            </button>
          </div>
        </div>
      `;

      document.body.appendChild(overlay);

      // Global window helpers for buttons
      window.adminpagentnToggleFullscreenDirect = () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      };

      window.adminpagentnTogglePauseDeep = () => {
        if (!this.session) return;
        this.session.isPaused = !this.session.isPaused;
        const btn = document.getElementById('adminpagentn-zen-pause-btn');
        if (btn) {
          btn.innerHTML = this.session.isPaused 
            ? '<span>▶</span> <span>Tiếp tục</span>' 
            : '<span>⏸</span> <span>Tạm dừng</span>';
        }
        if (this.session.isPaused) {
          this.showZenNotification('Phiên học đang tạm dừng.');
          if (typeof window.bfTrackFocusEvent === 'function') window.bfTrackFocusEvent('PAUSE', { clientSessionId: this.session.id, integrity: this.session.focusIntegrity });
        } else {
          this.session.targetEndTime = Date.now() + (this.session.remainingSeconds * 1000);
          if (typeof window.bfTrackFocusEvent === 'function') window.bfTrackFocusEvent('RESUME', { clientSessionId: this.session.id, integrity: this.session.focusIntegrity });
        }
        this.saveState();
      };

      window.adminpagentnEndDeepSession = () => {
        if (confirm('Bạn có chắc chắn muốn kết thúc sớm phiên học sâu này không?')) {
          this.complete(false);
        }
      };
    },

    updateZenIntegrityBadge() {
      const valEl = document.getElementById('adminpagentn-zen-integrity-val');
      const badge = document.getElementById('adminpagentn-zen-integrity-badge');
      const fsEl = document.getElementById('adminpagentn-zen-fs-indicator');
      const tabEl = document.getElementById('adminpagentn-zen-tab-indicator');
      if (valEl && this.session) {
        valEl.innerText = `${this.session.focusIntegrity}/100`;
        if (this.session.focusIntegrity >= 85) {
          badge.className = 'adminpagentn-integrity-badge text-emerald-400 border-emerald-500/30';
        } else if (this.session.focusIntegrity >= 60) {
          badge.className = 'adminpagentn-integrity-badge text-amber-400 border-amber-500/30';
        } else {
          badge.className = 'adminpagentn-integrity-badge text-rose-400 border-rose-500/30';
        }
      }
      if (fsEl && this.session) fsEl.innerText = `Rời màn hình: ${this.session.exitFullscreenCount} lần`;
      if (tabEl && this.session) tabEl.innerText = `Chuyển tab: ${this.session.tabSwitchCount} lần`;
    },

    showZenNotification(msg) {
      const box = document.getElementById('adminpagentn-zen-toast-box');
      if (box) {
        box.innerText = msg;
        box.style.opacity = '1';
        setTimeout(() => { if (box) box.style.opacity = '0'; }, 3500);
      }
    },

    startHeartbeat() {
      if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = setInterval(() => {
        if (!this.session) return;
        if (this.session.isPaused) {
          this.session.pauseMinutes += (1 / 60);
          return;
        }

        const now = Date.now();
        this.session.remainingSeconds = Math.max(0, Math.round((this.session.targetEndTime - now) / 1000));

        // Update timer UI
        const timerText = document.getElementById('adminpagentn-zen-timer-text');
        if (timerText) {
          timerText.innerText = this.formatTime(this.session.remainingSeconds);
        }

        // Save session state for resilience against browser reloads
        this.saveState();

        // If time completed
        if (this.session.remainingSeconds <= 0) {
          this.complete(true);
        }
      }, 1000);
    },

    complete(isFull = true) {
      if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
      const sessionData = { ...this.session };
      this.session = null;
      localStorage.removeItem(STORAGE_KEYS.DEEP_FOCUS_ACTIVE);

      // Exit fullscreen if active
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      }

      // Remove zen overlay
      const overlay = document.getElementById('adminpagentn-deep-zen-overlay');
      if (overlay) overlay.remove();

      // Final integrity calculation
      const integrity = sessionData.focusIntegrity || 95;
      const minutesCompleted = Math.round((sessionData.durationSeconds - sessionData.remainingSeconds) / 60);
      const pointsEarned = minutesCompleted; // 1 min = 1 point

      // Save into global APP_STATE history if present
      if (window.APP_STATE) {
        const d = new Date();
        const timeStr = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
        const dateStr = `${timeStr} - ${d.toLocaleDateString('vi-VN')}`;

        const histItem = {
          id: Date.now(),
          timestamp: Date.now(),
          subject: sessionData.goal || 'Phiên Học Sâu Deep Focus',
          minutes: minutesCompleted,
          points: pointsEarned,
          date: dateStr,
          emotion: integrity >= 85 ? 'Tập trung tuyệt đỉnh 🎯' : 'Có xao nhãng nhẹ ⚠️',
          note: `Hoàn thành ${minutesCompleted}p Deep Focus. Focus Integrity: ${integrity}/100. (Rời FS: ${sessionData.exitFullscreenCount}, Chuyển tab: ${sessionData.tabSwitchCount})`,
          isDeepFocus: true,
          usedFullscreen: true,
          focusIntegrity: integrity,
          hasReflected: false
        };

        if (!Array.isArray(window.APP_STATE.history)) window.APP_STATE.history = [];
        window.APP_STATE.history.unshift(histItem);

        window.APP_STATE.sessionsCompletedCount = (window.APP_STATE.sessionsCompletedCount || 0) + 1;
        window.APP_STATE.totalHours = Number(((window.APP_STATE.totalHours || 0) + (minutesCompleted / 60)).toFixed(1));
        window.APP_STATE.rankPoints = (window.APP_STATE.rankPoints || 1000) + pointsEarned;

      }

      adminpagentnAnalytics.track('focus_complete', { 
        isDeepFocus: true, 
        minutes: minutesCompleted, 
        integrity: integrity,
        isFull: isFull
      });
      const completionEvent = isFull ? 'SESSION_COMPLETE' : 'SESSION_ABORT';
      if (typeof window.bfTrackFocusEvent === 'function') {
        window.bfTrackFocusEvent(completionEvent, { clientSessionId: sessionData.id, minutesCompleted, integrity, exitFullscreenCount: sessionData.exitFullscreenCount, tabSwitchCount: sessionData.tabSwitchCount });
      }
      if (typeof window.bfSaveSessionToDatabase === 'function' && window.APP_STATE?.userEmail) {
        window.bfSaveSessionToDatabase({
          userEmail: window.APP_STATE.userEmail,
          clientSessionId: sessionData.id,
          mode: 'deep_focus',
          duration: minutesCompleted,
          distractions: (sessionData.exitFullscreenCount || 0) + (sessionData.tabSwitchCount || 0),
          isDeepFocus: 1,
          focusIntegrity: integrity,
          goal: sessionData.goal || '',
          emotion: integrity >= 85 ? 'Tập trung tuyệt đỉnh' : 'Có xao nhãng',
          bfsEarned: 0,
          rankEarned: pointsEarned,
          timestamp: Date.now()
        }).then(() => { if (typeof window.syncCurrentUserToDatabase === 'function') window.syncCurrentUserToDatabase(); });
      }

      // Show summary completion dialog
      alert(`🎉 CHÚC MỪNG HOÀN THÀNH PHIÊN HỌC SÂU!\n\n` +
            `• Thời lượng tập trung: ${minutesCompleted} phút (+${pointsEarned} điểm)\n` +
            `• Mục tiêu: ${sessionData.goal}\n` +
            `• Focus Integrity: ${integrity}/100đ\n` +
            `  - Rời toàn màn hình: ${sessionData.exitFullscreenCount} lần\n` +
            `  - Chuyển tab/thu nhỏ: ${sessionData.tabSwitchCount} lần\n\n` +
            `Dữ liệu đã được ghi nhận vào Lịch sử và Bảng Xếp Hạng.`);
    },

    saveState() {
      if (this.session) {
        localStorage.setItem(STORAGE_KEYS.DEEP_FOCUS_ACTIVE, JSON.stringify(this.session));
      }
    },

    restoreIfActive() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.DEEP_FOCUS_ACTIVE);
        if (raw) {
          const saved = JSON.parse(raw);
          if (saved && saved.targetEndTime && saved.targetEndTime > Date.now()) {
            this.session = saved;
            this.renderZenUI();
            this.bindIntegrityWatchers();
            this.startHeartbeat();
          } else {
            localStorage.removeItem(STORAGE_KEYS.DEEP_FOCUS_ACTIVE);
          }
        }
      } catch (e) {}
    },

    formatTime(sec) {
      const s = Math.max(0, Math.floor(sec));
      const m = Math.floor(s / 60);
      const remSec = s % 60;
      return `${String(m).padStart(2, '0')}:${String(remSec).padStart(2, '0')}`;
    }
  };

  // ================= 10. USER-FACING FEEDBACK MODAL =================
  const adminpagentnFeedbackView = {
    showUserModal() {
      const existing = document.getElementById('adminpagentn-user-feedback-modal');
      if (existing) existing.remove();

      const userEmail = (window.APP_STATE && window.APP_STATE.userEmail) || '';
      const userName = (window.APP_STATE && window.APP_STATE.userName) || '';

      const modalHtml = `
        <div id="adminpagentn-user-feedback-modal" class="adminpagentn-modal-backdrop">
          <div class="adminpagentn-modal-content p-6 space-y-4 max-w-lg">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
              <div class="flex items-center gap-2">
                <span class="text-xl">💬</span>
                <h3 class="font-bold text-sm text-slate-900">GỬI GÓP Ý & PHẢN HỒI CHO BRAIN FOCUS</h3>
              </div>
              <button onclick="document.getElementById('adminpagentn-user-feedback-modal').remove()" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center">✕</button>
            </div>

            <form onsubmit="window.adminpagentnSubmitUserFeedback(event)" class="space-y-3">
              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="text-xs font-bold text-slate-700 block mb-1">Loại phản hồi:</label>
                  <select id="adminpagentn-ufb-type" class="adminpagentn-select">
                    <option value="Góp ý phát triển">💡 Góp ý tính năng mới</option>
                    <option value="Báo lỗi hệ thống">🐞 Báo lỗi / Sự cố</option>
                    <option value="Phản hồi UX/UI">🎨 Trải nghiệm giao diện</option>
                    <option value="Nội dung sai sót">📖 Nội dung khoa học / Mẹo</option>
                    <option value="Khác">💬 Ý kiến khác</option>
                  </select>
                </div>
                <div>
                  <label class="text-xs font-bold text-slate-700 block mb-1">Mức độ ưu tiên:</label>
                  <select id="adminpagentn-ufb-sev" class="adminpagentn-select">
                    <option value="Bình thường">Bình thường</option>
                    <option value="Quan trọng">Quan trọng</option>
                    <option value="Khẩn cấp">Khẩn cấp</option>
                  </select>
                </div>
              </div>

              <div>
                <label class="text-xs font-bold text-slate-700 block mb-1">Tiêu đề:</label>
                <input type="text" id="adminpagentn-ufb-title" required placeholder="Ví dụ: Mong muốn có thêm âm thanh mưa rào..." class="adminpagentn-input" />
              </div>

              <div>
                <label class="text-xs font-bold text-slate-700 block mb-1">Nội dung chi tiết:</label>
                <textarea id="adminpagentn-ufb-content" required rows="4" placeholder="Mô tả cụ thể mong muốn hoặc các bước xảy ra lỗi..." class="adminpagentn-textarea"></textarea>
              </div>

              <div>
                <label class="text-xs font-bold text-slate-700 block mb-1">Email nhận phản hồi:</label>
                <input type="email" id="adminpagentn-ufb-email" value="${userEmail}" placeholder="email@gmail.com" class="adminpagentn-input" />
              </div>

              <div>
                <label class="text-xs font-bold text-slate-700 block mb-1">Đính kèm ảnh màn hình (tùy chọn):</label>
                <input type="file" id="adminpagentn-ufb-file" accept="image/*" class="text-xs text-slate-500" />
              </div>

              <div class="flex justify-end gap-2 pt-2">
                <button type="button" onclick="document.getElementById('adminpagentn-user-feedback-modal').remove()" class="adminpagentn-btn adminpagentn-btn-secondary">Hủy</button>
                <button type="submit" class="adminpagentn-btn adminpagentn-btn-primary">Gửi Phản Hồi Ngay</button>
              </div>
            </form>
          </div>
        </div>
      `;

      document.body.insertAdjacentHTML('beforeend', modalHtml);

      window.adminpagentnSubmitUserFeedback = (e) => {
        e.preventDefault();
        const type = document.getElementById('adminpagentn-ufb-type').value;
        const severity = document.getElementById('adminpagentn-ufb-sev').value;
        const title = document.getElementById('adminpagentn-ufb-title').value;
        const content = document.getElementById('adminpagentn-ufb-content').value;
        const email = document.getElementById('adminpagentn-ufb-email').value;
        const fileInput = document.getElementById('adminpagentn-ufb-file');

        const doSubmit = (screenshotData = null) => {
          adminpagentnFeedbackService.submitFeedback({
            type, severity, title, content, userEmail: email, userName: userName || 'Học viên', screenshot: screenshotData
          });
          alert(' cảm ơn bạn! Góp ý của bạn đã được gửi trực tiếp đến Ban Quản Trị Brain Focus.');
          document.getElementById('adminpagentn-user-feedback-modal')?.remove();
        };

        if (fileInput && fileInput.files && fileInput.files[0]) {
          const reader = new FileReader();
          reader.onload = (re) => doSubmit(re.target.result);
          reader.readAsDataURL(fileInput.files[0]);
        } else {
          doSubmit(null);
        }
      };
    }
  };


  // ================= INITIALIZATION =================
  async function adminpagentnInit(){
    await adminpagentnSeedInitialData();
    adminpagentnAnalytics.track('page_view',{userEmail:window.APP_STATE?.userEmail||''});
    adminpagentnDeepFocus.restoreIfActive();
  }
  window.adminpagentnInit=adminpagentnInit;
  window.adminpagentnAnalytics=adminpagentnAnalytics;
  window.adminpagentnFeedbackService=adminpagentnFeedbackService;
  window.adminpagentnDeepFocus=adminpagentnDeepFocus;
  window.adminpagentnFeedbackView=adminpagentnFeedbackView;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',adminpagentnInit);else adminpagentnInit();
})(window);
