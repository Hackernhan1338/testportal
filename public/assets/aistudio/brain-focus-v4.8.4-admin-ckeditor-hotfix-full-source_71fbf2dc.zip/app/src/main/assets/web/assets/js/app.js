    var tempUploadedAvatarBase64 = null;
    // ================= STATE =================
    const APP_STATE = {
      userEmail: "",
      userName: "",
      userSchool: "",
      userAvatar: "", // Base64 data or image url
      userPassword: "",
      isAuthenticated: false,
      isAuthModalStartupLock: false,
      rankPoints: 1000, // Điểm xếp hạng rèn luyện khởi tạo 1000đ
      bfsScore: 0,     // Chỉ số đánh giá não bộ BFS (sau 10 câu hỏi & gym)
      purchasedGymPlays: 0, // Số lượt gym mua thêm từ Cửa Hàng (35đ/lượt)
      totalHours: 0,
      streakDays: 1,
      sessionsCompletedCount: 0,
      gymCompletedCount: 0,
      currentTab: 'timer',
      
      // Timer
      timerMode: 'ultradian',
      timerDuration: 90 * 60,
      timerRemaining: 90 * 60,
      isTimerRunning: false,
      timerTargetEndTime: null,
      timerInterval: null,
      distractionsCount: 0,
      
      // Cooldown (15p nghỉ ngơi sau phiên 90p) & Giới hạn tối đa 3 phiên/ngày
      cooldownEndTime: null,
      restInterval: null,
      dailyTracker: null,
      dailyGymTracker: null, // Giới hạn tối đa 5 lượt tập gym não bộ/ngày
      
      // Do Not Disturb (DND) / Phone Notification Mute Shield
      isDndActive: false,
      autoDndOnSession: true,
      
      // Web Audio Synth
      audioContext: null,
      soundType: 'gamma',
      isPlayingAudio: false,
      audioNodes: [],
      
      selectedEmotion: 'Tập trung cao 🚀',
      
      reminders: [
        { id: 1, title: 'Học sâu buổi sáng (Lock In)', time: '08:30', active: true },
        { id: 2, title: 'Gym não giải toả (3 Game)', time: '14:00', active: true },
        { id: 3, title: 'Chu kỳ Ultradian tối (90p)', time: '20:00', active: true }
      ],
      
      history: []
    };
    // Brain Focus v3: expose state to modular bridge / Deep Focus runtime.
    window.APP_STATE = APP_STATE;

    const ASSESSMENT_QUESTIONS = [
      {
        id: 1,
        question: "Khi bắt đầu ngồi vào bàn học hoặc làm bài tập, bạn thường mở điện thoại sau bao lâu?",
        category: "Kiểm soát xung động",
        options: [
          { text: "Ngay lập tức hoặc dưới 5 phút", score: 10 },
          { text: "Khoảng 10 - 15 phút", score: 40 },
          { text: "Khoảng 30 - 45 phút", score: 75 },
          { text: "Giữ vững trên 60 - 90 phút mà không chạm vào điện thoại", score: 100 }
        ]
      },
      {
        id: 2,
        question: "Bạn có thói quen vừa học vừa nghe nhạc có lời hoặc liên tục đổi bài hát không?",
        category: "Độ tập trung",
        options: [
          { text: "Thường xuyên, nếu không có tiếng nhạc/clip thì không ngồi yên được", score: 15 },
          { text: "Thỉnh thoảng đổi bài hoặc lướt chọn playlist", score: 45 },
          { text: "Chỉ nghe nhạc không lời/lofi/tiếng ồn trắng cố định", score: 85 },
          { text: "Học trong không gian yên tĩnh tuyệt đối hoặc không bị phụ thuộc", score: 100 }
        ]
      },
      {
        id: 3,
        question: "Khi gặp một bài toán khó hoặc đoạn văn dài, cảm giác đầu tiên của bạn là gì?",
        category: "Sức bền nhận thức",
        options: [
          { text: "Cực kỳ bồn chồn, muốn bỏ qua hoặc mở app khác ngay lập tức", score: 10 },
          { text: "Đọc lướt nhanh, dễ mất kiên nhẫn sau 2-3 phút", score: 35 },
          { text: "Cố gắng đọc lại 1-2 lần để tìm hướng giải", score: 70 },
          { text: "Bình tĩnh phân tích từng bước, duy trì chú ý cho đến khi giải xong", score: 100 }
        ]
      },
      {
        id: 4,
        question: "Thời gian bạn lướt các video ngắn (TikTok, Reels, Shorts) mỗi ngày là bao nhiêu?",
        category: "Thói quen số",
        options: [
          { text: "Trên 3 - 4 tiếng mỗi ngày", score: 10 },
          { text: "Từ 1.5 - 3 tiếng", score: 40 },
          { text: "Dưới 1 tiếng mỗi ngày", score: 75 },
          { text: "Rất hiếm khi hoặc dưới 20 phút mỗi ngày", score: 100 }
        ]
      },
      {
        id: 5,
        question: "Bạn có thường cảm thấy 'rung chuông ảo' (nghĩ điện thoại có thông báo dù không có) không?",
        category: "Xung động vô thức",
        options: [
          { text: "Liên tục trong ngày, luôn vô thức mở màn hình kiểm tra", score: 15 },
          { text: "Thỉnh thoảng, đặc biệt khi cảm thấy chán bài học", score: 40 },
          { text: "Hiếm khi", score: 80 },
          { text: "Hoàn toàn không", score: 100 }
        ]
      },
      {
        id: 6,
        question: "Khả năng duy trì đọc một cuốn sách giáo khoa/tài liệu giấy liên tục 30 phút của bạn thế nào?",
        category: "Độ sâu chú ý",
        options: [
          { text: "Gần như không thể, mắt đọc nhưng đầu nghĩ việc khác", score: 15 },
          { text: "Đọc được 10-15 phút là muốn với tay lấy điện thoại", score: 45 },
          { text: "Đọc tốt khoảng 25-30 phút với độ hiểu bài khá", score: 80 },
          { text: "Đọc say mê 45-60 phút mà không hề bị phân tâm", score: 100 }
        ]
      },
      {
        id: 7,
        question: "Khi có thông báo tin nhắn mới khi đang học, phản xạ của bạn là gì?",
        category: "Kiểm soát kích thích",
        options: [
          { text: "Mở xem và trả lời ngay lập tức, sau đó bị cuốn vào lướt mạng xã hội", score: 10 },
          { text: "Mở xem tin nhắn rồi cố gắng quay lại học tiếp", score: 40 },
          { text: "Liếc nhìn preview, nếu không khẩn cấp sẽ đợi hết phiên học", score: 75 },
          { text: "Tắt toàn bộ thông báo hoặc để điện thoại ở chế độ Không làm phiền", score: 100 }
        ]
      },
      {
        id: 8,
        question: "Sau một phiên học dài 60-90 phút, bạn cảm thấy thế nào?",
        category: "Năng lượng não bộ",
        options: [
          { text: "Rất hiếm khi học được 60 phút, thường bỏ dở giữa chừng", score: 15 },
          { text: "Căng thẳng, mệt mỏi và thèm kích thích từ điện thoại", score: 45 },
          { text: "Khá thoải mái nếu có quãng nghỉ ngắn giữa chừng", score: 80 },
          { text: "Cảm giác sảng khoái và tự hào vì đạt trạng thái tập trung sâu", score: 100 }
        ]
      },
      {
        id: 9,
        question: "Bạn có thực hiện đa nhiệm (vừa học vừa nhắn tin, xem video phụ) không?",
        category: "Tập trung đơn nhiệm",
        options: [
          { text: "Thường xuyên làm nhiều việc một lúc", score: 10 },
          { text: "Thỉnh thoảng mở tab phụ để trò chuyện", score: 40 },
          { text: "Chủ yếu chỉ tập trung vào tài liệu môn học", score: 80 },
          { text: "Luôn thực hiện đơn nhiệm tuyệt đối (Monotasking)", score: 100 }
        ]
      },
      {
        id: 10,
        question: "Buổi tối trước khi đi ngủ, bạn thường sử dụng điện thoại đến khi nào?",
        category: "Nhịp sinh học",
        options: [
          { text: "Dùng đến tận lúc ngủ thiếp đi, để điện thoại ngay đầu giường", score: 10 },
          { text: "Dùng đến trước khi ngủ 10-15 phút", score: 40 },
          { text: "Cất điện thoại trước khi ngủ 30-45 phút", score: 75 },
          { text: "Ngừng dùng thiết bị điện tử trước khi ngủ 60 phút và để ngoài tầm với", score: 100 }
        ]
      }
    ];

    const ARTICLES = [
      {
        id: 1,
        title: "Khắc phục thói quen mất tập trung khi dùng điện thoại",
        author: "Chuyên đề Phương pháp học tập",
        tag: "PHƯƠNG PHÁP HỌC",
        summary: "Tìm hiểu nguyên nhân khiến suy nghĩ hay bị nhảy cóc do thói quen lướt mạng xã hội và cách thiết lập lại sự tập trung khi học.",
        content: "Thói quen thường xuyên kiểm tra điện thoại, xem video ngắn và nhận thông báo liên tục khiến khả năng duy trì chú ý bị gián đoạn. Khi đã quen với các phản hồi tức thì, bạn sẽ cảm thấy khó khăn hơn khi phải ngồi đọc sách hay giải một bài toán đòi hỏi tư duy lâu. Để khắc phục, bạn có thể tạo khoảng cách với điện thoại trước khi ngồi vào bàn học và bắt đầu bằng các phiên học tập trung từ 25 đến 45 phút, sau đó tăng dần lên 90 phút."
      },
      {
        id: 2,
        title: "Phương pháp học sâu 90 phút và thời gian nghỉ hợp lý",
        author: "Nghiên cứu Hiệu suất học tập",
        tag: "QUẢN LÝ THỜI GIAN",
        summary: "Tại sao học tập trung khoảng 90 phút kết hợp giải lao ngắn 15 phút lại mang lại kết quả tiếp thu tốt nhất.",
        content: "Khả năng tập trung tự nhiên của con người thường diễn ra theo từng chu kỳ. Trong 10-15 phút đầu tiên, bạn cần thời gian để làm quen và vào guồng bài học. Giai đoạn từ phút 15 đến 75 là lúc bạn tiếp thu và giải quyết vấn đề hiệu quả nhất. Sau khoảng 90 phút, sự mỏi mệt bắt đầu xuất hiện. Dành 15 phút giải lao, đi lại hoặc uống nước sẽ giúp bạn nạp lại năng lượng cho phiên học tiếp theo."
      },
      {
        id: 3,
        title: "Làm thế nào để tìm lại niềm vui khi học bài khó?",
        author: "Tâm lý học học đường",
        tag: "ĐỘNG LỰC HỌC TẬP",
        summary: "Cách giảm bớt thói quen tiêu thụ thông tin giải trí quá nhiều để cảm thấy hào hứng hơn khi chinh phục các môn học thử thách.",
        content: "Khi bạn dành nhiều giờ lướt mạng xã hội trước lúc học, não bộ đã quen với các kích thích vui vẻ nhanh chóng, dẫn đến cảm giác chán nản và buồn ngủ khi mở sách vở. Thử áp dụng thói quen để điện thoại ở phòng khác ít nhất 30 phút trước khi bắt đầu học. Khi không bị phân tâm bởi các thông báo, bạn sẽ dần tìm lại sự hứng thú và cảm giác hoàn thành khi tự mình giải xong một bài tập khó."
      }
    ];

    const TIPS_DATA = [
      { id: 1, category: 'ENV', title: 'Quy tắc khoảng cách 20 giây', text: 'Để điện thoại ở ngăn kéo hoặc phòng khác. Khi mất nhiều thời gian hơn để với tới máy, bạn sẽ hạn chế được thói quen vô thức cầm điện thoại khi đang học.', tag: 'Góc học tập' },
      { id: 2, category: 'TECH', title: 'Chuyển màn hình sang đen trắng', text: 'Bật chế độ Grayscale (đen trắng) trên điện thoại trong giờ học. Màn hình không màu sắc giúp giảm bớt sự cuốn hút từ các ứng dụng.', tag: 'Thiết bị' },
      { id: 3, category: 'STRAT', title: 'Quy tắc 5 phút khởi động', text: 'Khi cảm thấy ngại học, hãy tự nhủ chỉ cần ngồi làm bài đúng 5 phút. Khi đã bắt đầu viết vài dòng đầu tiên, bạn sẽ dễ dàng học tiếp.', tag: 'Phương pháp' },
      { id: 4, category: 'ENV', title: 'Bàn học gọn gàng, tối giản', text: 'Chỉ để đúng một cuốn sách hoặc tài liệu đang làm trên bàn. Bàn học thoáng đãng giúp tâm trí bạn không bị phân tán.', tag: 'Góc học tập' },
      { id: 5, category: 'STRAT', title: 'Ghi lại 1 điều tâm đắc sau buổi học', text: 'Viết ra 1 kiến thức hoặc bài học quan trọng nhất vừa học được trước khi đứng dậy. Thói quen này giúp bạn nhớ bài lâu hơn.', tag: 'Phương pháp' },
      { id: 6, category: 'TECH', title: 'Sử dụng âm thanh nền tập trung', text: 'Bật tiếng mưa rơi, tiếng ồn trắng hoặc âm thanh 40Hz ở âm lượng vừa phải để che bớt tạp âm xung quanh khi học.', tag: 'Thiết bị' }
    ];

    // ================= 3-LEVEL BFS EVALUATION SYSTEM =================
    const BFS_LEVELS_DATA = {
      LEVEL_1: {
        level: 1,
        title: "LEVEL 1 – KHÁ ỔN ĐỊNH",
        dot: "🟢",
        badgeClass: "bg-emerald-100 text-emerald-800 border-emerald-300",
        headline: "Bạn đang có nền tảng tập trung khá tốt.",
        description: "Thói quen sử dụng thiết bị số của bạn tương đối hợp lý và khả năng duy trì bài học khá ổn định.",
        recommendations: [
          "Duy trì các phiên học từ 30 đến 90 phút.",
          "Giữ vững chuỗi ngày học đều đặn.",
          "Thử thách đọc sách hoặc học bài liên tục không chạm máy.",
          "Xem lại nhật ký tiến độ học tập mỗi tuần."
        ],
        quote: "“Duy trì hôm nay để vững vàng ngày mai.”"
      },
      LEVEL_2: {
        level: 2,
        title: "LEVEL 2 – DỄ PHÂN TÂM",
        dot: "🟡",
        badgeClass: "bg-amber-100 text-amber-900 border-amber-300",
        headline: "Sự chú ý của bạn đôi khi bị gián đoạn.",
        description: "Bạn có một số thói quen cầm máy cần điều chỉnh để việc học trở nên chủ động và hiệu quả hơn.",
        recommendations: [
          "Bắt đầu với phiên học 25 phút (Pomodoro).",
          "Dành 2 phút hít thở sâu, chuẩn bị tài liệu trước khi bấm giờ.",
          "Tắt hết chuông và thông báo trong thời gian học.",
          "Thử thách 7 ngày học tập trung.",
          "Ghi chép nhanh các ý tưởng xao nhãng ra giấy nháp để xử lý sau."
        ],
        quote: "“Mỗi thay đổi nhỏ hôm nay là một bước tiến.”"
      },
      LEVEL_3: {
        level: 3,
        title: "LEVEL 3 – CẦN RÈN LUYỆN THÊM",
        dot: "🔴",
        badgeClass: "bg-rose-100 text-rose-800 border-rose-300",
        headline: "Bạn thường xuyên bị phân tán bởi điện thoại và mạng xã hội.",
        description: "Điều này hoàn toàn bình thường khi môi trường có nhiều cám dỗ. Đây là lúc bắt đầu xây dựng lại thói quen từng bước nhỏ.",
        recommendations: [
          "Khởi đầu với phiên học ngắn từ 15 đến 20 phút, sau đó tăng dần.",
          "Để điện thoại ở phòng khác trong giờ học.",
          "Nhắc nhở bản thân hít thở sâu trước khi bắt đầu bài tập.",
          "Theo dõi số phiên học hoàn thành mỗi tuần.",
          "Giảm dần thời gian lướt mạng xã hội trước giờ học."
        ],
        quote: "“Không cần thay đổi tất cả trong một ngày. Hãy bắt đầu từ một thói quen nhỏ.”"
      }
    };

    function getBFSLevelDetails(score) {
      const num = Number(score) || 0;
      if (num >= 700) return BFS_LEVELS_DATA.LEVEL_1;
      if (num >= 400) return BFS_LEVELS_DATA.LEVEL_2;
      return BFS_LEVELS_DATA.LEVEL_3;
    }

    // ================= GOOGLE SHEETS / GOOGLE EXCEL DATA ENGINE =================
    const GOOGLE_SHEETS_CONFIG = {
      get webAppUrl() {
        return localStorage.getItem('bf_gsheet_webapp_url') || '';
      },
      set webAppUrl(val) {
        if (val) localStorage.setItem('bf_gsheet_webapp_url', val.trim());
        else localStorage.removeItem('bf_gsheet_webapp_url');
      },
      get sheetUrl() {
        return localStorage.getItem('bf_gsheet_url') || '';
      },
      set sheetUrl(val) {
        if (val) localStorage.setItem('bf_gsheet_url', val.trim());
        else localStorage.removeItem('bf_gsheet_url');
      },
      get sheetId() {
        const raw = this.sheetUrl || '';
        const match = raw.match(/\/d\/([a-zA-Z0-9-_]+)/);
        return match ? match[1] : '';
      }
    };

    async function fetchFromGoogleSheets() {
      // 1. Đọc từ Web App Google Apps Script nếu có
      if (GOOGLE_SHEETS_CONFIG.webAppUrl) {
        try {
          const sep = GOOGLE_SHEETS_CONFIG.webAppUrl.includes('?') ? '&' : '?';
          const fetchUrl = `${GOOGLE_SHEETS_CONFIG.webAppUrl}${sep}action=getUsers&_t=${Date.now()}`;
          const res = await fetch(fetchUrl, { cache: 'no-store' });
          if (res.ok) {
            const data = await res.json();
            if (data && Array.isArray(data.users)) {
              return data.users;
            }
          }
        } catch (e) {
          console.warn('Web App fetch error:', e);
        }
      }

      // 2. Đọc từ Google Sheet trực tiếp thông qua Google Visualization (GViz) API
      const sid = GOOGLE_SHEETS_CONFIG.sheetId;
      if (sid) {
        try {
          const gvizUrl = `https://docs.google.com/spreadsheets/d/${sid}/gviz/tq?tqx=out:json&_t=${Date.now()}`;
          const res = await fetch(gvizUrl, { cache: 'no-store' });
          if (res.ok) {
            const text = await res.text();
            const jsonMatch = text.match(/google\.visualization\.Query\.setResponse\(([\s\S]*)\);/);
            if (jsonMatch && jsonMatch[1]) {
              const gvizData = JSON.parse(jsonMatch[1]);
              const rows = (gvizData.table && gvizData.table.rows) ? gvizData.table.rows : [];
              const parsedUsers = [];
              rows.forEach(r => {
                if (!r || !r.c) return;
                const c = r.c;
                const email = c[0] && (c[0].v !== undefined) ? String(c[0].v).trim() : '';
                const name = c[1] && (c[1].v !== undefined) ? String(c[1].v).trim() : '';
                if (!name && !email) return;
                const school = c[2] && (c[2].v !== undefined) ? String(c[2].v).trim() : 'Học viên tích cực';
                const rankPoints = c[3] && !isNaN(c[3].v) ? Number(c[3].v) : 1000;
                const bfs = c[4] && !isNaN(c[4].v) ? Number(c[4].v) : 0;
                const sessionsCount = c[5] && !isNaN(c[5].v) ? Number(c[5].v) : 0;
                const sessionPoints = c[6] && !isNaN(c[6].v) ? Number(c[6].v) : (sessionsCount * 90);
                const streakDays = c[7] && !isNaN(c[7].v) ? Number(c[7].v) : 1;
                const totalHours = c[8] && !isNaN(c[8].v) ? Number(c[8].v) : 0;

                parsedUsers.push({
                  email: email || `${name.toLowerCase().replace(/\s+/g, '')}@student.brainfocus`,
                  name: name || 'Học viên',
                  school: school,
                  rankPoints: rankPoints,
                  bfs: bfs,
                  sessionsCount: sessionsCount,
                  sessionPoints: sessionPoints,
                  streakDays: streakDays,
                  totalHours: totalHours
                });
              });
              if (parsedUsers.length > 0) return parsedUsers;
            }
          }
        } catch (e) {
          console.warn('GViz fetch error:', e);
        }
      }

      return null;
    }

    async function pushToGoogleSheets(users) {
      if (!GOOGLE_SHEETS_CONFIG.webAppUrl) return;
      try {
        await fetch(GOOGLE_SHEETS_CONFIG.webAppUrl, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'text/plain' },
          body: JSON.stringify({ action: 'sync', users: users })
        });
      } catch (e) {
        console.warn('Push to Google Sheets error:', e);
      }
    }

    // ================= CLOUD LEADERBOARD SYNCHRONIZATION ENGINE =================
    const CLOUD_LEADERBOARD_ENDPOINT = 'https://api.restful-api.dev/objects/ff808181a067127101a077a82e722a01';
    let isCloudSyncInProgress = false;

    function updateCloudSyncBadge(status) {
      const badge = document.getElementById('cloud-sync-status-badge');
      if (!badge) return;
      if (status === 'syncing') {
        badge.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-spin"></span> <span>Google Sheets: Đang đồng bộ...</span>`;
        badge.className = 'text-[10px] bg-amber-50 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shadow-xs';
      } else if (status === 'online') {
        badge.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> <span>Google Sheets: Trực tuyến (100k+ sức chứa)</span>`;
        badge.className = 'text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shadow-xs';
      } else {
        badge.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span> <span>Ngoại tuyến (Lưu thiết bị)</span>`;
        badge.className = 'text-[10px] bg-slate-100 text-slate-700 border border-slate-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shadow-xs';
      }
    }

    function sanitizeUserForCloud(u) {
      if (!u || !u.name) return null;
      const email = String(u.email || '').toLowerCase().trim();
      const name = String(u.name || '').trim();
      if (!name) return null;

      // Không gửi Base64 ảnh nặng lên Cloud để tránh quá tải
      const avatarClean = (u.avatar && typeof u.avatar === 'string' && u.avatar.length < 250 && !u.avatar.startsWith('data:image')) ? u.avatar : '';
      
      return {
        email: email || `${name.toLowerCase().replace(/\s+/g, '')}@student.brainfocus`,
        password: String(u.password || '').trim(),
        name: name,
        school: String(u.school || 'Học viên tích cực').trim().slice(0, 50),
        avatar: avatarClean,
        rankPoints: Math.round(Number(u.rankPoints) || 1000),
        sessionsCount: Math.round(Number(u.sessionsCount) || 0),
        sessionPoints: Math.round(Number(u.sessionPoints) || 0),
        bfs: Math.round(Number(u.bfs) || 0),
        streakDays: Number(u.streakDays) || 1,
        totalHours: Number(u.totalHours) || 0
      };
    }

    async function fetchLeaderboardFromCloud(notify = false) {
      if (isCloudSyncInProgress) return;
      isCloudSyncInProgress = true;
      updateCloudSyncBadge('syncing');

      const refreshIcon = document.getElementById('refresh-icon');
      if (refreshIcon) refreshIcon.classList.add('animate-spin');

      // Tự động giải phóng trạng thái sau tối đa 7 giây đề phòng nghẽn mạng
      const safetyTimeout = setTimeout(() => {
        isCloudSyncInProgress = false;
        if (refreshIcon) refreshIcon.classList.remove('animate-spin');
      }, 7000);

      try {
        let incomingUsers = null;

        // Ưu tiên 0: Đọc từ Cơ sở dữ liệu MySQL máy chủ (thông qua PHP API) nếu có
        if (typeof bfFetchLeaderboardFromDatabase === 'function') {
          try {
            const dbUsers = await bfFetchLeaderboardFromDatabase();
            if (Array.isArray(dbUsers) && dbUsers.length > 0) {
              incomingUsers = dbUsers;
              updateCloudSyncBadge('online');
            }
          } catch (_) {}
        }

        // Ưu tiên 1: Đọc từ Google Sheets (nếu có cấu hình Web App hoặc Sheet link)
        if (!incomingUsers || incomingUsers.length === 0) {
          try {
            incomingUsers = await fetchFromGoogleSheets();
          } catch (_) {}
        }

        // Ưu tiên 2: Đọc từ Cloud Leaderboard Endpoint
        if (!incomingUsers || incomingUsers.length === 0) {
          const nocacheUrl = `${CLOUD_LEADERBOARD_ENDPOINT}?_t=${Date.now()}_${Math.floor(Math.random() * 10000)}`;
          const response = await fetch(nocacheUrl, {
            cache: 'no-store',
            headers: {
              'Cache-Control': 'no-cache, no-store, max-age=0, must-revalidate',
              'Pragma': 'no-cache'
            }
          });
          if (response.ok) {
            const resJson = await response.json();
            incomingUsers = (resJson && resJson.data && Array.isArray(resJson.data.users)) ? resJson.data.users : [];
          }
        }

        const cloudUsers = Array.isArray(incomingUsers) ? incomingUsers : [];

        loadUsersDatabase();

        // Hợp nhất dữ liệu học viên vào cơ sở dữ liệu trên thiết bị (hoàn toàn không giới hạn số lượng)
        cloudUsers.forEach(cu => {
          if (!cu || isCloneAccount(cu)) return;
          const cleanCloud = sanitizeUserForCloud(cu);
          if (!cleanCloud) return;

          const localIdx = REGISTERED_USERS_DB.findIndex(u => {
            if (!u) return false;
            if (u.email && cleanCloud.email && u.email.toLowerCase().trim() === cleanCloud.email.toLowerCase().trim()) {
              return true;
            }
            if (u.name && cleanCloud.name && u.name.toLowerCase().trim() === cleanCloud.name.toLowerCase().trim()) {
              return true;
            }
            return false;
          });

          if (localIdx === -1) {
            REGISTERED_USERS_DB.push(cleanCloud);
          } else {
            const lu = REGISTERED_USERS_DB[localIdx];
            const isLocalActiveUser = APP_STATE.userEmail && lu.email && lu.email.toLowerCase().trim() === APP_STATE.userEmail.toLowerCase().trim();
            const cloudTotal = cleanCloud.rankPoints + cleanCloud.bfs + cleanCloud.sessionPoints;
            const localTotal = (Number(lu.rankPoints) || 1000) + (Number(lu.bfs) || 0) + (Number(lu.sessionPoints) || 0);

            // Giữ lại bản ghi có tổng điểm cao nhất, bảo tồn mật khẩu và avatar của thiết bị
            if (!isLocalActiveUser || cloudTotal > localTotal) {
              REGISTERED_USERS_DB[localIdx] = {
                ...lu,
                ...cleanCloud,
                password: lu.password || cleanCloud.password || '',
                avatar: lu.avatar || cleanCloud.avatar || ''
              };
            }
          }
        });

        // Đảm bảo thông tin của tài khoản hiện tại trên thiết bị không bị mất
        if (APP_STATE.userName || APP_STATE.userEmail) {
          syncCurrentUserToDatabase();
        }

        saveUsersDatabase(false); // Lưu local mà không lặp vô tận
        renderLeaderboard();
        updateCloudSyncBadge('online');

        if (notify) {
          const totalCount = REGISTERED_USERS_DB.length;
          const topList = getFullLeaderboard();
          const topSummary = topList.slice(0, 3).map((u, i) => `#${i + 1} ${u.name}: ${u.totalScore}đ`).join('\n');
          alert(`🌟 ĐỒNG BỘ DỮ LIỆU THÀNH CÔNG!\n\nTổng cộng: ${totalCount} học viên (Sức chứa 100,000+ học viên trên Google Sheets).\n\nTop 3 Bảng Xếp Hạng hiện tại:\n${topSummary}`);
        }
      } catch (err) {
        console.warn('Leaderboard cloud sync issue:', err);
        updateCloudSyncBadge('offline');
        renderLeaderboard();
        if (notify) {
          alert('⚠️ Không thể kết nối tới Google Cloud / Sheets lúc này. Đang hiển thị dữ liệu trên thiết bị!');
        }
      } finally {
        clearTimeout(safetyTimeout);
        isCloudSyncInProgress = false;
        if (refreshIcon) refreshIcon.classList.remove('animate-spin');
      }
    }

    let cloudPushTimeout = null;
    function pushLeaderboardToCloud() {
      if (cloudPushTimeout) clearTimeout(cloudPushTimeout);
      const jitter = 300 + Math.floor(Math.random() * 500);
      cloudPushTimeout = setTimeout(async () => {
        try {
          // Bước 1: Tải danh sách hiện tại trên Cloud về trước để không đè mất người dùng khác
          let currentCloudUsers = [];
          try {
            const getRes = await fetch(`${CLOUD_LEADERBOARD_ENDPOINT}?_t=${Date.now()}_${Math.floor(Math.random()*1000)}`, { cache: 'no-store' });
            if (getRes.ok) {
              const j = await getRes.json();
              if (j && j.data && Array.isArray(j.data.users)) {
                currentCloudUsers = j.data.users;
              }
            }
          } catch (_) {}

          // Bước 2: Hợp nhất Cloud + Local (khử trùng theo email chính xác, fallback name)
          const mergedMap = new Map();

          const getUserKey = (u) => {
            if (u && u.email && typeof u.email === 'string') {
              return 'email:' + u.email.toLowerCase().trim();
            }
            if (u && u.name && typeof u.name === 'string') {
              return 'name:' + u.name.toLowerCase().trim();
            }
            return null;
          };

          // Thêm các user trên Cloud trước
          currentCloudUsers.forEach(cu => {
            const s = sanitizeUserForCloud(cu);
            if (s) {
              const key = getUserKey(s);
              if (key) mergedMap.set(key, s);
            }
          });

          // Thêm hoặc cập nhật user của Local
          REGISTERED_USERS_DB.forEach(lu => {
            const s = sanitizeUserForCloud(lu);
            if (s) {
              const key = getUserKey(s);
              if (key) {
                const existing = mergedMap.get(key);
                if (!existing) {
                  mergedMap.set(key, s);
                } else {
                  const localTotal = (s.rankPoints || 1000) + (s.bfs || 0) + (s.sessionPoints || 0);
                  const cloudTotal = (existing.rankPoints || 1000) + (existing.bfs || 0) + (existing.sessionPoints || 0);
                  if (localTotal >= cloudTotal) {
                    mergedMap.set(key, { ...existing, ...s });
                  }
                }
              }
            }
          });

          const finalCloudList = Array.from(mergedMap.values());

          // Đẩy đồng bộ lên Cơ sở dữ liệu MySQL PHP Backend nếu đang chạy trên hosting
          if (typeof bfSyncUserToDatabase === 'function' && APP_STATE.userEmail) {
            bfSyncUserToDatabase({
              email: APP_STATE.userEmail,
              name: APP_STATE.userName,
              school: APP_STATE.userSchool,
              avatar: APP_STATE.userAvatar,
              rankPoints: APP_STATE.rankPoints,
              bfsScore: APP_STATE.bfsScore,
              sessionsCount: APP_STATE.sessionsCompletedCount,
              totalHours: APP_STATE.totalHours,
              streakDays: APP_STATE.streakDays,
              purchasedGymPlays: APP_STATE.purchasedGymPlays
            });
          }

          // Đẩy đồng bộ lên Google Sheets Web App nếu có
          pushToGoogleSheets(finalCloudList);

          // Đẩy đồng bộ lên Cloud Storage
          const payload = {
            name: "brainfocus_leaderboard",
            data: {
              users: finalCloudList,
              lastSynced: Date.now()
            }
          };

          const putRes = await fetch(CLOUD_LEADERBOARD_ENDPOINT, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });

          if (putRes.ok) {
            updateCloudSyncBadge('online');
          }
        } catch (err) {
          console.warn('Failed to push leaderboard to cloud:', err);
        }
      }, jitter);
    }

    // ================= GOOGLE SHEETS MODAL CONTROLLER =================
    function openGoogleSheetsModal() {
      const modal = document.getElementById('google-sheets-modal');
      if (!modal) return;
      const input = document.getElementById('gsheet-url-input');
      if (input) {
        input.value = GOOGLE_SHEETS_CONFIG.webAppUrl || GOOGLE_SHEETS_CONFIG.sheetUrl || '';
      }
      updateGoogleSheetsModalStatus();
      switchGSheetTab('sync');
      modal.classList.remove('hidden');
    }

    function closeGoogleSheetsModal() {
      const modal = document.getElementById('google-sheets-modal');
      if (modal) modal.classList.add('hidden');
    }

    function switchGSheetTab(tab) {
      const tabs = ['sync', 'files', 'code'];
      tabs.forEach(t => {
        const content = document.getElementById(`gsheet-tab-${t}`);
        const btn = document.getElementById(`gsheet-tab-btn-${t}`);
        if (content) {
          if (t === tab) content.classList.remove('hidden');
          else content.classList.add('hidden');
        }
        if (btn) {
          if (t === tab) {
            btn.className = 'px-3.5 py-2 text-xs font-bold border-b-2 border-emerald-600 text-emerald-700 transition-all';
          } else {
            btn.className = 'px-3.5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 border-b-2 border-transparent transition-all';
          }
        }
      });
    }

    function updateGoogleSheetsModalStatus() {
      const statusLabel = document.getElementById('gsheet-status-label');
      const dot = document.getElementById('gsheet-dot-status');
      const badge = document.getElementById('gsheet-total-count-badge');
      const openBtn = document.getElementById('gsheet-open-link-btn');
      const totalCount = REGISTERED_USERS_DB.length;

      if (badge) badge.innerText = `${totalCount} học viên`;

      const hasCustom = Boolean(GOOGLE_SHEETS_CONFIG.webAppUrl || GOOGLE_SHEETS_CONFIG.sheetUrl);
      if (statusLabel) {
        statusLabel.innerText = hasCustom 
          ? `Đã liên kết Google Sheet riêng (${GOOGLE_SHEETS_CONFIG.sheetId ? 'Xem qua GViz API' : 'Apps Script 2 chiều'})` 
          : 'Đang kết nối Google Sheets Cloud mặc định';
      }
      if (dot) {
        dot.className = 'w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse';
      }
      if (openBtn) {
        if (GOOGLE_SHEETS_CONFIG.sheetUrl) {
          openBtn.classList.remove('hidden');
        } else {
          openBtn.classList.add('hidden');
        }
      }
    }

    function saveGoogleSheetsConfig() {
      const input = document.getElementById('gsheet-url-input');
      const val = input ? input.value.trim() : '';

      if (!val) {
        GOOGLE_SHEETS_CONFIG.webAppUrl = '';
        GOOGLE_SHEETS_CONFIG.sheetUrl = '';
        updateGoogleSheetsModalStatus();
        alert('ℹ️ Đã đặt lại về cơ sở dữ liệu Google Sheets Cloud mặc định (Dung lượng 100,000+ học viên).');
        fetchLeaderboardFromCloud(true);
        return;
      }

      if (val.includes('script.google.com/macros/s/')) {
        GOOGLE_SHEETS_CONFIG.webAppUrl = val;
        GOOGLE_SHEETS_CONFIG.sheetUrl = '';
      } else if (val.includes('docs.google.com/spreadsheets')) {
        GOOGLE_SHEETS_CONFIG.sheetUrl = val;
        GOOGLE_SHEETS_CONFIG.webAppUrl = '';
      } else {
        alert('⚠️ URL không hợp lệ. Vui lòng nhập link Google Sheet (docs.google.com/spreadsheets/d/...) hoặc URL Web App Apps Script (script.google.com/macros/s/...)');
        return;
      }

      updateGoogleSheetsModalStatus();
      alert('💾 Đã lưu cấu hình Google Sheet thành công! Bắt đầu đồng bộ...');
      fetchLeaderboardFromCloud(true);
    }

    async function testGoogleSheetsConnection() {
      const statusLabel = document.getElementById('gsheet-status-label');
      if (statusLabel) statusLabel.innerText = 'Đang kiểm tra kết nối...';

      try {
        const users = await fetchFromGoogleSheets();
        if (users && users.length > 0) {
          if (statusLabel) statusLabel.innerText = `✅ Kết nối thành công! Đọc được ${users.length} học viên từ Google Sheet.`;
          alert(`✅ KẾT NỐI THÀNH CÔNG!\nĐã đọc được ${users.length} dòng học viên từ Google Sheet.\nSức chứa hệ thống: 100,000+ học viên!`);
          fetchLeaderboardFromCloud(false);
        } else {
          if (statusLabel) statusLabel.innerText = '✅ Kết nối tốt (Bảng tính hiện chưa có dòng dữ liệu học viên).';
          alert('✅ Kết nối Google Sheet thành công!\nBảng tính hiện đang trống hoặc sẵn sàng tiếp nhận dữ liệu mới.');
        }
      } catch (err) {
        if (statusLabel) statusLabel.innerText = '❌ Kiểm tra kết nối thất bại: ' + err.message;
        alert('❌ Không thể đọc dữ liệu từ Google Sheet: ' + err.message + '\nHãy đảm bảo bạn đã cấp quyền "Bất kỳ ai có liên kết đều có thể xem"!');
      }
      updateGoogleSheetsModalStatus();
    }

    function openCurrentGoogleSheetInNewTab() {
      if (GOOGLE_SHEETS_CONFIG.sheetUrl) {
        window.open(GOOGLE_SHEETS_CONFIG.sheetUrl, '_blank');
      } else {
        alert('⚠️ Chưa có link Google Sheet nào được lưu!');
      }
    }

    function copyAppsScriptCode() {
      const code = document.getElementById('apps-script-code-block');
      if (!code) return;
      const text = code.innerText || code.textContent;
      navigator.clipboard.writeText(text).then(() => {
        const btn = document.getElementById('copy-script-btn');
        if (btn) {
          const original = btn.innerHTML;
          btn.innerHTML = '<span>✅</span> <span>Đã sao chép!</span>';
          setTimeout(() => { btn.innerHTML = original; }, 2000);
        }
        alert('📋 Đã sao chép toàn bộ mã Google Apps Script vào bộ nhớ tạm!\nBạn chỉ cần dán vào mục Apps Script trên Google Trang Tính của bạn.');
      }).catch(() => {
        alert('Không thể sao chép tự động, vui lòng bôi đen và nhấn Ctrl+C.');
      });
    }

    function downloadExcelTemplate() {
      try {
        if (typeof XLSX === 'undefined') {
          alert('⚠️ Thư viện Excel đang tải, vui lòng thử lại sau giây lát.');
          return;
        }

        const templateRows = [
          {
            'Hạng': 1,
            'Họ Và Tên': 'Nguyễn Văn Minh',
            'Email (Tài khoản)': 'minh.nguyen@student.brainfocus',
            'Trường / Đơn vị': 'THPT Chuyên Lê Hồng Phong',
            'Tổng Điểm': 2180,
            'Điểm Xếp Hạng': 1000,
            'Điểm Bài Test BFS': 820,
            'Số Phiên Học Hoàn Thành': 4,
            'Điểm Phiên Học': 360,
            'Chuỗi Ngày (Streak)': '5 ngày',
            'Tổng Giờ Học (Giờ)': 6
          },
          {
            'Hạng': 2,
            'Họ Và Tên': 'Trần Thị Thu Trang',
            'Email (Tài khoản)': 'trang.tran@student.brainfocus',
            'Trường / Đơn vị': 'Đại học Bách Khoa',
            'Tổng Điểm': 2050,
            'Điểm Xếp Hạng': 1000,
            'Điểm Bài Test BFS': 780,
            'Số Phiên Học Hoàn Thành': 3,
            'Điểm Phiên Học': 270,
            'Chuỗi Ngày (Streak)': '4 ngày',
            'Tổng Giờ Học (Giờ)': 4.5
          },
          {
            'Hạng': 3,
            'Họ Và Tên': 'Lê Hoàng Nam',
            'Email (Tài khoản)': 'nam.le@student.brainfocus',
            'Trường / Đơn vị': 'Đại học Quốc Gia',
            'Tổng Điểm': 1930,
            'Điểm Xếp Hạng': 1000,
            'Điểm Bài Test BFS': 750,
            'Số Phiên Học Hoàn Thành': 2,
            'Điểm Phiên Học': 180,
            'Chuỗi Ngày (Streak)': '3 ngày',
            'Tổng Giờ Học (Giờ)': 3
          }
        ];

        const ws = XLSX.utils.json_to_sheet(templateRows);
        ws['!cols'] = [
          { wch: 6 }, { wch: 25 }, { wch: 32 }, { wch: 28 },
          { wch: 12 }, { wch: 15 }, { wch: 18 }, { wch: 24 },
          { wch: 16 }, { wch: 20 }, { wch: 18 }
        ];

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Mau_Hoc_Vien");
        XLSX.writeFile(wb, "BrainFocus_MauNhapLieu_HocVien.xlsx");
      } catch (e) {
        alert('Lỗi tạo file mẫu: ' + e.message);
      }
    }

    // Bảng xếp hạng người dùng thực tế & Quản lý danh sách tài khoản đã đăng ký
    let REGISTERED_USERS_DB = [];

    // Lọc và phát hiện các tài khoản clone / ảo / thử nghiệm
    function isCloneAccount(u) {
      if (!u) return true;
      const name = String(u.name || '').trim();
      const email = String(u.email || '').trim().toLowerCase();
      if (!name || !email) return true;
      // Chỉ loại bỏ các email thử nghiệm mẫu cụ thể nếu người dùng không dùng
      const blockedEmails = ['abc@gmail.com', 'test@gmail.com', 'example@gmail.com'];
      if (blockedEmails.includes(email)) return true;
      const blockedNames = ['tài khoản test', 'thử nghiệm clone'];
      if (blockedNames.includes(name.toLowerCase())) return true;
      return false;
    }

    function loadUsersDatabase() {
      try {
        const saved = localStorage.getItem('bf_registered_users');
        const parsed = saved ? JSON.parse(saved) : [];
        REGISTERED_USERS_DB = Array.isArray(parsed)
          ? parsed.filter(u => u && !isCloneAccount(u))
          : [];
      } catch (e) {
        REGISTERED_USERS_DB = [];
      }
    }

    function saveUsersDatabase(triggerCloud = true) {
      try {
        const cleanList = REGISTERED_USERS_DB.filter(u => u && !isCloneAccount(u));
        localStorage.setItem('bf_registered_users', JSON.stringify(cleanList));
        if (triggerCloud) {
          pushLeaderboardToCloud();
        }
      } catch (e) {}
    }

    // Làm sạch toàn bộ tài khoản clone và cập nhật lại giao diện
    function purgeCloneAccounts(notify = false) {
      loadUsersDatabase();
      REGISTERED_USERS_DB = REGISTERED_USERS_DB.filter(u => u && !isCloneAccount(u));
      saveUsersDatabase(true);
      renderLeaderboard();
      syncProfileDOM();
      updateStatsUI();

      const modal = document.getElementById('switch-account-modal');
      if (modal && !modal.classList.contains('hidden')) {
        openSwitchAccountModal();
      }

      if (notify) {
        alert('✨ Đã quét sạch và loại bỏ toàn bộ tài khoản clone/thử nghiệm!');
      }
    }

    // Xóa sạch 100% dữ liệu toàn bộ người dùng cả trên Cloud và LocalStorage để bắt đầu sử dụng thật
    async function clearAllSystemUsersAndReset(confirmTwice = true) {
      if (confirmTwice) {
        const c1 = confirm('⚠️ CẢNH BÁO XÓA SẠCH DỮ LIỆU:\nBạn có chắc chắn muốn xóa toàn bộ học viên và điểm số để bắt đầu đưa vào sử dụng thật 100% không?');
        if (!c1) return;
        const c2 = confirm('Xác nhận lần cuối: Mọi tài khoản thử nghiệm trên cả Cloud và máy này sẽ bị xóa trắng hoàn toàn. Tiếp tục?');
        if (!c2) return;
      }

      try {
        // 1. Gửi lệnh xóa trắng lên Cloud
        await fetch(CLOUD_LEADERBOARD_ENDPOINT, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: 'brainfocus_leaderboard',
            data: {
              users: [],
              lastSynced: Date.now()
            }
          })
        });
      } catch (err) {
        console.warn('Clear cloud error:', err);
      }

      // 2. Xóa sạch dữ liệu trong LocalStorage
      try {
        localStorage.removeItem('bf_registered_users');
        localStorage.removeItem('bf_user_profile');
        localStorage.removeItem('bf_onboarded_completed');
        localStorage.removeItem('bf_active_session');
        localStorage.removeItem('bf_active_session_backup');
        localStorage.removeItem('bf_daily_tracker');
        localStorage.removeItem('bf_daily_gym_tracker');
        localStorage.removeItem('bf_cooldown_until');
        localStorage.removeItem('bf_cooldown_total_seconds');
        localStorage.removeItem('bf_restored_user_test_sessions');
      } catch (e) {}

      // 3. Reset APP_STATE về trạng thái ban đầu
      REGISTERED_USERS_DB = [];
      APP_STATE.userEmail = "";
      APP_STATE.userName = "";
      APP_STATE.userSchool = "";
      APP_STATE.userAvatar = "";
      APP_STATE.userPassword = "";
      APP_STATE.isAuthenticated = false;
      APP_STATE.isAuthModalStartupLock = false;
      APP_STATE.rankPoints = 1000;
      APP_STATE.bfsScore = 0;
      APP_STATE.totalHours = 0;
      APP_STATE.streakDays = 1;
      APP_STATE.sessionsCompletedCount = 0;
      APP_STATE.gymCompletedCount = 0;
      APP_STATE.history = [];

      const authModal = document.getElementById('account-auth-modal');
      if (authModal) authModal.classList.add('hidden');
      const switchModal = document.getElementById('switch-account-modal');
      if (switchModal) switchModal.classList.add('hidden');

      saveAppStateToLocal();
      syncProfileDOM();
      updateStatsUI();
      renderLeaderboard();
      renderHistory();
      openRegisterModal(true);

      alert('🎉 ĐÃ XÓA TRẮNG TOÀN BỘ DỮ LIỆU CLONE THÀNH CÔNG!\nWeb đã được làm mới tinh 100% để khởi động lại.');
    }

    // Đồng bộ thông tin người dùng hiện tại vào danh sách người dùng toàn hệ thống
    function syncCurrentUserToDatabase() {
      if (!APP_STATE.userName && !APP_STATE.userEmail) return;

      const currentSessionPoints = getSessionPointsTotal();
      const currentSessionsCount = APP_STATE.sessionsCompletedCount || (Array.isArray(APP_STATE.history) ? APP_STATE.history.length : 0);
      const email = (APP_STATE.userEmail || '').trim() || `${(APP_STATE.userName || 'user').toLowerCase().replace(/\s+/g, '')}@student.brainfocus`;

      const existingUser = REGISTERED_USERS_DB.find(u => 
        (u.email && u.email.toLowerCase().trim() === email.toLowerCase().trim())
      );
      const userPassword = (existingUser && existingUser.password) ? existingUser.password : (APP_STATE.userPassword || '');

      const userEntry = {
        id: email.toLowerCase().trim(),
        email: email,
        password: userPassword,
        name: (APP_STATE.userName || 'Học viên').trim(),
        school: APP_STATE.userSchool || 'Người học tích cực',
        avatar: APP_STATE.userAvatar || '',
        rankPoints: Number(APP_STATE.rankPoints) || 1000,
        sessionsCount: currentSessionsCount,
        sessionPoints: currentSessionPoints,
        bfs: Number(APP_STATE.bfsScore) || 0,
        totalHours: APP_STATE.totalHours || 0,
        streakDays: APP_STATE.streakDays || 1,
        streak: `${APP_STATE.streakDays || 1} ngày`,
        history: Array.isArray(APP_STATE.history) ? APP_STATE.history : [],
        lastUpdated: Date.now()
      };

      const existingIdx = REGISTERED_USERS_DB.findIndex(u => 
        (u.email && u.email.toLowerCase().trim() === userEntry.email.toLowerCase().trim())
      );
      if (existingIdx >= 0) {
        REGISTERED_USERS_DB[existingIdx] = { ...REGISTERED_USERS_DB[existingIdx], ...userEntry };
      } else {
        REGISTERED_USERS_DB.push(userEntry);
      }
      saveUsersDatabase();
    }

    // Tính tổng điểm từ tất cả các phiên học: mỗi phiên tính điểm tùy theo thời gian chạy (1 phút = 1 điểm, ví dụ 90p = 90đ)
    function getSessionPointsTotal() {
      let totalPts = 0;
      if (Array.isArray(APP_STATE.history) && APP_STATE.history.length > 0) {
        totalPts = APP_STATE.history.reduce((sum, item) => sum + (Number(item.points) || Number(item.minutes) || 90), 0);
      } else {
        const count = Number(APP_STATE.sessionsCompletedCount) || 0;
        totalPts = count * 90; // Mặc định mỗi phiên học sâu 90 phút = 90 điểm
      }
      return totalPts;
    }

    function getFullLeaderboard() {
      // Đảm bảo dữ liệu người dùng hiện tại được đồng bộ vào database
      syncCurrentUserToDatabase();
      loadUsersDatabase();

      // Lọc các user có email và tên hợp lệ
      const validUsers = REGISTERED_USERS_DB.filter(u => u && u.email && u.name);

      const all = validUsers.map(u => {
        const isCurrent = Boolean(APP_STATE.userEmail && u.email.toLowerCase().trim() === APP_STATE.userEmail.toLowerCase().trim());
        const rankPts = isCurrent ? (Number(APP_STATE.rankPoints) || 1000) : (Number(u.rankPoints) || 1000);
        const sessCount = isCurrent ? (APP_STATE.sessionsCompletedCount || (Array.isArray(APP_STATE.history) ? APP_STATE.history.length : 0)) : (u.sessionsCount || 0);
        const sessPts = isCurrent ? getSessionPointsTotal() : (u.sessionPoints !== undefined ? u.sessionPoints : (sessCount * 90));
        const bfsVal = isCurrent ? (Number(APP_STATE.bfsScore) || 0) : (Number(u.bfs) || 0);
        
        // Công thức tính điểm chuẩn xác:
        // 1000 (Điểm Xếp Hạng khởi tạo) + Điểm BFS (từ 10 câu test) + Số phiên học × Điểm theo thời gian học (vd 1 phiên 90p = 90đ)
        const total = rankPts + bfsVal + sessPts;
        
        return {
          ...u,
          name: isCurrent ? `${APP_STATE.userName} (Bạn)` : u.name,
          school: isCurrent ? (APP_STATE.userSchool || 'Người học tích cực') : (u.school || 'Người học tích cực'),
          avatar: isCurrent ? APP_STATE.userAvatar : u.avatar,
          rankPoints: rankPts,
          sessionsCount: sessCount,
          sessionPoints: sessPts,
          bfs: bfsVal,
          totalScore: total,
          isUser: isCurrent
        };
      });

      // Sắp xếp theo tổng điểm giảm dần
      all.sort((a, b) => b.totalScore - a.totalScore);

      // Khử trùng lặp: Phân định theo email định danh (khóa chính)
      const uniqueMap = new Map();
      all.forEach(item => {
        const normKey = (item.email || item.name || '').trim().toLowerCase();
        const existing = uniqueMap.get(normKey);
        if (!existing) {
          uniqueMap.set(normKey, item);
        } else {
          // Ưu tiên tài khoản đang đăng nhập hoặc có tổng điểm cao hơn
          if (item.isUser || item.totalScore > existing.totalScore) {
            uniqueMap.set(normKey, item);
          }
        }
      });

      const uniqueList = Array.from(uniqueMap.values());
      uniqueList.sort((a, b) => b.totalScore - a.totalScore);
      return uniqueList.map((u, idx) => ({ ...u, rank: idx + 1 }));
    }

    function switchToUserAccountSilently(user) {
      if (!user) return;
      APP_STATE.userEmail = user.email;
      APP_STATE.userName = user.name;
      APP_STATE.userSchool = user.school || '';
      APP_STATE.userAvatar = user.avatar || '';
      APP_STATE.rankPoints = Number(user.rankPoints) || 1000;
      APP_STATE.bfsScore = Number(user.bfs) || 0;
      APP_STATE.sessionsCompletedCount = user.sessionsCount || 0;
      APP_STATE.totalHours = user.totalHours || 0;
      APP_STATE.streakDays = user.streakDays || 1;
      APP_STATE.history = Array.isArray(user.history) ? user.history : [];
    }

    function createNewAccountFromSwitchModal() {
      const switchModal = document.getElementById('switch-account-modal');
      if (switchModal) {
        switchModal.classList.add('hidden');
        switchModal.style.display = 'none';
      }
      const authModal = document.getElementById('account-auth-modal');
      if (authModal) {
        authModal.classList.add('hidden');
        authModal.style.display = 'none';
      }
      openRegisterModal(false);
    }

    function openSwitchAccountModal() {
      const authModal = document.getElementById('account-auth-modal');
      if (authModal) authModal.classList.add('hidden');
      const regModal = document.getElementById('register-modal');
      if (regModal) regModal.classList.add('hidden');
      syncCurrentUserToDatabase();
      loadUsersDatabase();
      const listEl = document.getElementById('switch-account-list');
      if (!listEl) return;
      
      if (!REGISTERED_USERS_DB || REGISTERED_USERS_DB.length === 0) {
        listEl.innerHTML = `
          <div class="p-6 text-center text-slate-500 text-xs space-y-2">
            <span class="text-3xl">👤</span>
            <p class="font-bold text-slate-700">Chưa có tài khoản nào trên thiết bị</p>
            <p class="text-[11px] text-slate-500">Hãy nhấn nút bên dưới để tạo tài khoản Gmail đầu tiên và bắt đầu đua Top!</p>
          </div>
        `;
      } else {
        listEl.innerHTML = REGISTERED_USERS_DB.map(u => {
          const isCurrent = Boolean(APP_STATE.userEmail && u.email.toLowerCase().trim() === APP_STATE.userEmail.toLowerCase().trim());
          const sessCount = u.sessionsCount || (u.history ? u.history.length : 0) || 0;
          const sessPts = u.sessionPoints !== undefined ? u.sessionPoints : (sessCount * 90);
          const rankPts = Number(u.rankPoints) || 1000;
          const bfsPts = Number(u.bfs) || 0;
          const total = rankPts + bfsPts + sessPts;

          return `
            <div class="p-3 rounded-2xl border ${isCurrent ? 'border-blue-500 bg-blue-50/80 ring-2 ring-blue-400/40' : 'border-slate-200 bg-slate-50/80 hover:bg-slate-100'} flex items-center justify-between gap-3 transition-all">
              <div class="flex items-center gap-2.5 min-w-0 flex-1">
                <div class="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-500 text-white flex items-center justify-center text-base font-black shrink-0 overflow-hidden shadow-xs border border-white">
                  ${u.avatar ? `<img src="${u.avatar}" class="w-full h-full object-cover" />` : (u.name || 'U').charAt(0).toUpperCase()}
                </div>
                <div class="min-w-0 flex-1">
                  <div class="text-xs font-bold text-slate-900 truncate flex items-center gap-1.5">
                    <span class="truncate">${u.name}</span>
                    ${isCurrent ? '<span class="text-[9px] bg-blue-600 text-white px-1.5 py-0.5 rounded-full font-black shrink-0">Đang chọn</span>' : ''}
                  </div>
                  <div class="text-[10px] text-slate-500 truncate">${u.email}</div>
                  <div class="text-[10px] text-amber-700 font-semibold mt-0.5">Tổng: ${total}đ (${rankPts} XH + ${bfsPts} BFS)</div>
                </div>
              </div>
              <div class="shrink-0 flex items-center gap-1.5">
                ${isCurrent ? `
                  <span class="text-xs font-bold text-blue-700 flex items-center gap-1 bg-blue-100/70 px-2.5 py-1 rounded-xl">✓ Đang dùng</span>
                ` : `
                  <button onclick="requestAccountSwitch('${u.email.replace(/'/g, "\\'")}')" class="px-3 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-bold rounded-xl shadow-xs hover:opacity-95 transition-all flex items-center gap-1">
                    <span>${u.password ? '🔒' : ''}</span> <span>Chuyển</span>
                  </button>
                `}
                <button onclick="event.stopPropagation(); deleteSpecificAccount('${u.email.replace(/'/g, "\\'")}')" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all" title="Xoá tài khoản này">
                  🗑️
                </button>
              </div>
            </div>
          `;
        }).join('');
      }
      const modal = document.getElementById('switch-account-modal');
      if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
      }
    }

    function closeSwitchAccountModal() {
      const modal = document.getElementById('switch-account-modal');
      if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
      }
      if (!APP_STATE.isAuthenticated) {
        loadUsersDatabase();
        const targetUser = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === (APP_STATE.userEmail || '').toLowerCase().trim()) || {
          email: APP_STATE.userEmail,
          name: APP_STATE.userName,
          avatar: APP_STATE.userAvatar,
          password: APP_STATE.userPassword
        };
        openAccountAuthModal(targetUser, true);
      }
    }

    function deleteSpecificAccount(email) {
      if (!confirm(`Bạn có chắc muốn xoá tài khoản "${email}" khỏi thiết bị này?`)) return;
      loadUsersDatabase();
      REGISTERED_USERS_DB = REGISTERED_USERS_DB.filter(u => u.email.toLowerCase().trim() !== email.toLowerCase().trim());
      saveUsersDatabase();

      if (APP_STATE.userEmail.toLowerCase().trim() === email.toLowerCase().trim()) {
        if (REGISTERED_USERS_DB.length > 0) {
          switchToUserAccountSilently(REGISTERED_USERS_DB[0]);
          saveAppStateToLocal();
        } else {
          APP_STATE.userEmail = "";
          APP_STATE.userName = "";
          APP_STATE.userSchool = "";
          APP_STATE.userAvatar = "";
          APP_STATE.rankPoints = 1000;
          APP_STATE.bfsScore = 0;
          APP_STATE.totalHours = 0;
          APP_STATE.streakDays = 1;
          APP_STATE.sessionsCompletedCount = 0;
          APP_STATE.gymCompletedCount = 0;
          APP_STATE.history = [];
          saveAppStateToLocal();
        }
      }

      syncProfileDOM();
      updateStatsUI();
      renderLeaderboard();
      openSwitchAccountModal();
      alert(`🗑️ Đã xoá tài khoản ${email} thành công! Bảng xếp hạng đã được dọn sạch.`);
    }

    function togglePasswordVisibility(inputId, btn) {
      const input = document.getElementById(inputId);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        if (btn) btn.innerText = '🙈';
      } else {
        input.type = 'password';
        if (btn) btn.innerText = '👁️';
      }
    }

    function requestAccountSwitch(email) {
      loadUsersDatabase();
      const user = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === email.toLowerCase().trim());
      if (!user) return;

      const switchModal = document.getElementById('switch-account-modal');
      if (switchModal) switchModal.classList.add('hidden');

      // Bắt buộc nhập mật khẩu của tài khoản đó để chuyển
      openAccountAuthModal(user, !APP_STATE.isAuthenticated);
    }

    function openAccountAuthModal(user, isStartup = false) {
      if (!user) return;
      APP_STATE.isAuthModalStartupLock = Boolean(isStartup);

      const modal = document.getElementById('account-auth-modal');
      const closeBtn = document.getElementById('auth-modal-close-btn');
      const cancelBtn = document.getElementById('auth-cancel-btn');
      const titleEl = document.getElementById('auth-modal-title');
      const subtitleEl = document.getElementById('auth-modal-subtitle');
      const labelEl = document.getElementById('auth-input-label');
      const submitBtn = document.getElementById('auth-submit-btn');
      const emailHidden = document.getElementById('auth-target-email-hidden');
      const nameEl = document.getElementById('auth-target-name');
      const emailEl = document.getElementById('auth-target-email');
      const avatarEl = document.getElementById('auth-target-avatar');
      const passInput = document.getElementById('auth-input-password');
      const errorMsg = document.getElementById('auth-error-msg');

      if (emailHidden) emailHidden.value = user.email || '';
      if (nameEl) nameEl.innerText = user.name || 'Học viên';
      if (emailEl) emailEl.innerText = user.email || '';
      if (avatarEl) {
        if (user.avatar) {
          avatarEl.innerHTML = `<img src="${user.avatar}" class="w-full h-full object-cover" />`;
        } else {
          avatarEl.innerText = (user.name || 'U').charAt(0).toUpperCase();
        }
      }

      const hasExistingPass = Boolean(user.password && String(user.password).trim().length > 0);
      if (hasExistingPass) {
        if (titleEl) titleEl.innerText = isStartup ? "MỞ KHÓA BRAIN FOCUS" : "XÁC THỰC MẬT KHẨU";
        if (subtitleEl) subtitleEl.innerText = isStartup ? "Chắc chắn nhập mật khẩu để vào ứng dụng" : "Bảo mật truy cập tài khoản";
        if (labelEl) labelEl.innerText = "Mật khẩu tài khoản:";
        if (passInput) passInput.placeholder = "Nhập mật khẩu tài khoản...";
        if (submitBtn) submitBtn.innerHTML = `<span>Mở Khóa</span> <span>🔓</span>`;
      } else {
        if (titleEl) titleEl.innerText = "THIẾT LẬP MẬT KHẨU";
        if (subtitleEl) subtitleEl.innerText = "Tài khoản của bạn chưa có mật khẩu. Vui lòng đặt mật khẩu để bảo vệ:";
        if (labelEl) labelEl.innerText = "Tạo mật khẩu mới (tối thiểu 4 ký tự):";
        if (passInput) passInput.placeholder = "Tạo mật khẩu bảo vệ...";
        if (submitBtn) submitBtn.innerHTML = `<span>Lưu & Mở Khóa</span> <span>🔓</span>`;
      }

      if (closeBtn) {
        if (isStartup || !APP_STATE.isAuthenticated) {
          closeBtn.classList.add('hidden');
        } else {
          closeBtn.classList.remove('hidden');
        }
      }

      if (cancelBtn) {
        if (isStartup || !APP_STATE.isAuthenticated) {
          cancelBtn.innerText = "Đổi TK";
        } else {
          cancelBtn.innerText = "Huỷ";
        }
      }

      if (passInput) {
        passInput.value = '';
        passInput.type = 'password';
      }
      if (errorMsg) {
        errorMsg.innerText = '';
        errorMsg.classList.add('hidden');
      }

      if (modal) modal.classList.remove('hidden');
      setTimeout(() => {
        if (passInput) passInput.focus();
      }, 150);
    }

    function handleAuthCancelClick() {
      if (APP_STATE.isAuthModalStartupLock || !APP_STATE.isAuthenticated) {
        openSwitchAccountModal();
      } else {
        closeAccountAuthModal();
      }
    }

    function closeAccountAuthModal() {
      if (!APP_STATE.isAuthenticated) {
        // Bắt buộc nhập mật khẩu khi vào web, không thể đóng
        return;
      }
      const modal = document.getElementById('account-auth-modal');
      if (modal) modal.classList.add('hidden');
    }

    function handleAccountAuthSubmit(e) {
      e.preventDefault();
      const emailHidden = document.getElementById('auth-target-email-hidden');
      const passInput = document.getElementById('auth-input-password');
      const errorMsg = document.getElementById('auth-error-msg');

      const targetEmail = (emailHidden ? emailHidden.value : '').trim();
      const enteredPassword = (passInput ? passInput.value : '').trim();

      loadUsersDatabase();
      const user = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === targetEmail.toLowerCase().trim()) || (
        targetEmail.toLowerCase().trim() === (APP_STATE.userEmail || '').toLowerCase().trim() ? {
          email: APP_STATE.userEmail,
          name: APP_STATE.userName,
          avatar: APP_STATE.userAvatar,
          password: APP_STATE.userPassword
        } : null
      );

      if (!user) {
        if (errorMsg) {
          errorMsg.innerText = '❌ Không tìm thấy tài khoản trong hệ thống!';
          errorMsg.classList.remove('hidden');
        }
        return;
      }

      const correctPassword = String(user.password || '').trim();

      // Nếu tài khoản cũ chưa từng có mật khẩu, lưu mật khẩu người dùng vừa tạo
      if (!correctPassword) {
        if (enteredPassword.length < 4) {
          if (errorMsg) {
            errorMsg.innerText = '❌ Mật khẩu phải có tối thiểu 4 ký tự!';
            errorMsg.classList.remove('hidden');
          }
          if (passInput) passInput.focus();
          return;
        }
        user.password = enteredPassword;
        if (user.email.toLowerCase().trim() === (APP_STATE.userEmail || '').toLowerCase().trim()) {
          APP_STATE.userPassword = enteredPassword;
        }
        const idx = REGISTERED_USERS_DB.findIndex(u => u.email.toLowerCase().trim() === user.email.toLowerCase().trim());
        if (idx >= 0) {
          REGISTERED_USERS_DB[idx].password = enteredPassword;
        } else {
          REGISTERED_USERS_DB.push(user);
        }
        saveUsersDatabase();
        saveAppStateToLocal();
      } else if (enteredPassword !== correctPassword) {
        if (errorMsg) {
          errorMsg.innerText = '❌ Mật khẩu không chính xác! Vui lòng thử lại.';
          errorMsg.classList.remove('hidden');
        }
        if (passInput) {
          passInput.focus();
          passInput.select();
        }
        return;
      }

      // Xác thực mật khẩu thành công!
      APP_STATE.isAuthenticated = true;
      APP_STATE.isAuthModalStartupLock = false;

      const modal = document.getElementById('account-auth-modal');
      if (modal) modal.classList.add('hidden');

      switchToUserAccount(user.email, true);
    }

    function switchToUserAccount(email, isFromAuth = false) {
      syncCurrentUserToDatabase();
      loadUsersDatabase();

      const user = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === email.toLowerCase().trim());
      if (!user) return;

      APP_STATE.userEmail = user.email;
      APP_STATE.userName = user.name;
      APP_STATE.userSchool = user.school || '';
      APP_STATE.userAvatar = user.avatar || '';
      APP_STATE.userPassword = user.password || '';
      APP_STATE.rankPoints = Number(user.rankPoints) || 1000;
      APP_STATE.bfsScore = Number(user.bfs) || 0;
      APP_STATE.sessionsCompletedCount = user.sessionsCount || 0;
      APP_STATE.totalHours = user.totalHours || 0;
      APP_STATE.streakDays = user.streakDays || 1;
      APP_STATE.history = Array.isArray(user.history) ? user.history : [];

      saveAppStateToLocal();
      syncProfileDOM();
      updateStatsUI();
      renderLeaderboard();
      renderHistory();
      
      const switchModal = document.getElementById('switch-account-modal');
      if (switchModal) switchModal.classList.add('hidden');

      if (isFromAuth) {
        alert(`🔓 Mở khóa thành công! Chào mừng ${user.name} (${user.email}) quay lại.`);
      } else {
        alert(`✅ Đã chọn tài khoản: ${user.name} (${user.email})!`);
      }
    }

    function lockScreenNow() {
      APP_STATE.isAuthenticated = false;
      loadUsersDatabase();
      const targetUser = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === (APP_STATE.userEmail || '').toLowerCase().trim()) || {
        email: APP_STATE.userEmail,
        name: APP_STATE.userName,
        avatar: APP_STATE.userAvatar,
        password: APP_STATE.userPassword
      };
      openAccountAuthModal(targetUser, true);
    }

    // ================= EXCEL (XLSX) IMPORT / EXPORT =================
    function exportLeaderboardToExcel() {
      try {
        if (typeof XLSX === 'undefined') {
          alert('⚠️ Thư viện Excel đang được tải, vui lòng thử lại sau 3 giây.');
          return;
        }

        const leaderboard = getFullLeaderboard();
        if (!leaderboard || leaderboard.length === 0) {
          alert('⚠️ Chưa có dữ liệu học viên để xuất file Excel.');
          return;
        }

        const excelData = leaderboard.map((u, idx) => ({
          'Hạng': idx + 1,
          'Họ Và Tên': (u.name || '').replace(/\s*\(Bạn\)$/i, '').trim(),
          'Email (Tài khoản)': u.email || '',
          'Trường / Đơn vị': u.school || 'Người học tích cực',
          'Tổng Điểm': u.totalScore || 0,
          'Điểm Xếp Hạng': u.rankPoints || 1000,
          'Điểm Bài Test BFS': u.bfs || 0,
          'Số Phiên Học Hoàn Thành': u.sessionsCount || 0,
          'Điểm Phiên Học': u.sessionPoints || 0,
          'Chuỗi Ngày (Streak)': u.streak || `${u.streakDays || 1} ngày`,
          'Tổng Giờ Học (Giờ)': u.totalHours || 0
        }));

        const ws = XLSX.utils.json_to_sheet(excelData);
        // Tối ưu độ rộng cột
        ws['!cols'] = [
          { wch: 6 },  // Hạng
          { wch: 25 }, // Họ tên
          { wch: 30 }, // Email
          { wch: 25 }, // Trường
          { wch: 12 }, // Tổng điểm
          { wch: 15 }, // Điểm XH
          { wch: 18 }, // Điểm BFS
          { wch: 24 }, // Số phiên
          { wch: 16 }, // Điểm phiên
          { wch: 20 }, // Streak
          { wch: 18 }  // Tổng giờ
        ];

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "BangXepHang_BrainFocus");

        const todayStr = getTodayDateString();
        const fileName = `BrainFocus_DanhSachHocVien_${todayStr}.xlsx`;
        XLSX.writeFile(wb, fileName);
        alert(`📥 Đã xuất file Excel thành công: ${fileName}\nTổng số học viên: ${excelData.length}`);
      } catch (err) {
        console.error('Export Excel error:', err);
        alert('❌ Có lỗi khi xuất file Excel: ' + err.message);
      }
    }

    function importLeaderboardFromExcel(event) {
      const file = event.target.files && event.target.files[0];
      if (!file) return;

      if (typeof XLSX === 'undefined') {
        alert('⚠️ Thư viện Excel đang được tải, vui lòng thử lại sau giây lát.');
        return;
      }

      const reader = new FileReader();
      reader.onload = function(e) {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const rawRows = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

          if (!rawRows || rawRows.length === 0) {
            alert('⚠️ File Excel không có dòng dữ liệu nào!');
            return;
          }

          loadUsersDatabase();
          let importedCount = 0;
          let updatedCount = 0;

          rawRows.forEach(row => {
            // Linh hoạt nhận diện tên cột tiếng Việt hoặc tiếng Anh
            const name = String(row['Họ Và Tên'] || row['Họ và Tên'] || row['Tên'] || row['Name'] || row['FullName'] || '').replace(/\s*\(Bạn\)$/i, '').trim();
            let email = String(row['Email (Tài khoản)'] || row['Email'] || row['Mail'] || '').trim().toLowerCase();
            const school = String(row['Trường / Đơn vị'] || row['Trường'] || row['School'] || 'Người học tích cực').trim();
            const totalScore = Number(row['Tổng Điểm'] || row['TotalScore'] || row['Total']) || 0;
            const rankPoints = Number(row['Điểm Xếp Hạng'] || row['RankPoints']) || 1000;
            const bfs = Number(row['Điểm Bài Test BFS'] || row['Điểm BFS'] || row['BFS']) || 0;
            const sessionsCount = Number(row['Số Phiên Học Hoàn Thành'] || row['Số Phiên'] || row['Sessions']) || 0;
            const sessionPoints = Number(row['Điểm Phiên Học'] || row['SessionPoints']) || (sessionsCount * 90);
            const totalHours = Number(row['Tổng Giờ Học (Giờ)'] || row['TotalHours']) || 0;
            const streakDays = parseInt(String(row['Chuỗi Ngày (Streak)'] || row['Streak'] || '1').replace(/\D/g, '')) || 1;

            if (!name && !email) return;
            if (!email) {
              email = `${name.toLowerCase().replace(/\s+/g, '')}@student.brainfocus`;
            }

            const existingIdx = REGISTERED_USERS_DB.findIndex(u => 
              (u.email && u.email.toLowerCase().trim() === email)
            );

            const userObj = {
              id: email,
              email: email,
              name: name || 'Học viên',
              school: school,
              avatar: '',
              rankPoints: rankPoints,
              bfs: bfs,
              sessionsCount: sessionsCount,
              sessionPoints: sessionPoints,
              totalHours: totalHours,
              streakDays: streakDays,
              streak: `${streakDays} ngày`,
              lastUpdated: Date.now()
            };

            if (existingIdx === -1) {
              REGISTERED_USERS_DB.push(userObj);
              importedCount++;
            } else {
              REGISTERED_USERS_DB[existingIdx] = {
                ...REGISTERED_USERS_DB[existingIdx],
                ...userObj,
                avatar: REGISTERED_USERS_DB[existingIdx].avatar || ''
              };
              updatedCount++;
            }
          });

          saveUsersDatabase(true); // Lưu và tự động đồng bộ lên Cloud
          renderLeaderboard();
          alert(`🎉 Nhập file Excel thành công!\n- Thêm mới: ${importedCount} học viên\n- Cập nhật: ${updatedCount} học viên\nBảng xếp hạng đã được làm mới!`);
        } catch (err) {
          console.error('Import Excel error:', err);
          alert('❌ Đọc file Excel thất bại: ' + err.message);
        } finally {
          event.target.value = ''; // Reset input để có thể chọn lại cùng file
        }
      };
      reader.readAsArrayBuffer(file);
    }

    // ================= INIT =================
    window.addEventListener('DOMContentLoaded', () => {
      // Brain Focus v3: giữ nguyên dữ liệu local hiện có khi nâng cấp; không reset tự động.
      loadAppStateFromLocal();
      purgeCloneAccounts(false);

      // Nếu APP_STATE rỗng, KHÔNG tự động lấy tài khoản của người khác gán vào!
      // Mỗi thiết bị mới phải có tài khoản riêng của chính mình.
      const hasAccount = Boolean(APP_STATE.userEmail && APP_STATE.userName);

      syncProfileDOM();
      renderArticles();
      renderTips('ALL');
      renderLeaderboard();
      renderReminders();
      renderHistory();
      renderQuestions();
      updateStatsUI();
      
      // Check native Android bridge for initial DND status if present
      if (window.AndroidBridge && typeof window.AndroidBridge.isDndActive === 'function') {
        try {
          APP_STATE.isDndActive = window.AndroidBridge.isDndActive();
        } catch (_) {}
      }
      updateDndUI();

      // ================= CHẮC CHẮN KHI VÀO WEB LÀ PHẢI NHẬP MẬT KHẨU =================
      if (!hasAccount) {
        // Chưa có tài khoản: bắt buộc tạo tài khoản mới & thiết lập mật khẩu
        setTimeout(() => {
          openRegisterModal(true);
        }, 300);
      } else {
        // Đã có tài khoản: BẮT BUỘC KHÓA MÀN HÌNH & NHẬP MẬT KHẨU ĐỂ VÀO WEB
        APP_STATE.isAuthenticated = false;
        setTimeout(() => {
          loadUsersDatabase();
          const targetUser = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === (APP_STATE.userEmail || '').toLowerCase().trim()) || {
            email: APP_STATE.userEmail,
            name: APP_STATE.userName,
            avatar: APP_STATE.userAvatar,
            password: APP_STATE.userPassword
          };
          openAccountAuthModal(targetUser, true /* isStartupLock */);
        }, 200);
      }

      // Lắng nghe cập nhật đa tab (cross-tab) trong trình duyệt
      window.addEventListener('storage', (e) => {
        if (e.key === 'bf_registered_users') {
          loadUsersDatabase();
          renderLeaderboard();
        }
      });

      // Restore active session if user refreshed or browser restored tab
      restoreSessionBackup();
      restoreRestCooldown();
      updateDailySessionUI();
      updateDailyGymUI();

      // Listen for window blur / focus (anti-distraction detector & seamless timer sync)
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          if (APP_STATE.isTimerRunning) {
            APP_STATE.distractionsCount++;
            const distCountEl = document.getElementById('timer-distraction-count');
            if (distCountEl) distCountEl.innerText = `Xao nhãng: ${APP_STATE.distractionsCount} lần`;
            const alertEl = document.getElementById('distraction-alert');
            if (alertEl) alertEl.classList.remove('hidden');
            saveSessionBackup();
          }
        } else {
          // Returning to tab: immediately recalculate delta to avoid any drift/freeze
          resyncActiveSession();
        }
      });

      window.addEventListener('focus', () => {
        resyncActiveSession();
      });

      window.addEventListener('pageshow', () => {
        resyncActiveSession();
      });

      // Khởi động đồng bộ Bảng Xếp Hạng từ Cloud toàn hệ thống
      fetchLeaderboardFromCloud(false);
      // Tự động kiểm tra đồng bộ ngầm định kỳ mỗi 60 giây
      setInterval(() => {
        fetchLeaderboardFromCloud(false);
      }, 60000);
    });

    function restoreSessionBackup() {
      try {
        const saved = localStorage.getItem('bf_active_session');
        if (!saved) return;
        const data = JSON.parse(saved);
        if (data && data.isRunning && data.targetEndTime) {
          const now = Date.now();
          const diffMs = data.targetEndTime - now;
          const diffSec = Math.max(0, Math.ceil(diffMs / 1000));
          APP_STATE.timerDuration = data.duration || 90 * 60;
          APP_STATE.timerMode = data.mode || 'ultradian';
          APP_STATE.distractionsCount = data.distractions || 0;
          APP_STATE.timerTargetEndTime = data.targetEndTime;
          
          if (diffSec > 0) {
            APP_STATE.timerRemaining = diffSec;
            startTimer(true);
          } else {
            APP_STATE.timerRemaining = 0;
            updateTimerDisplay();
            completeTimer();
          }
        } else if (data && data.remaining !== undefined && data.remaining > 0 && data.remaining < (data.duration || 90 * 60)) {
          // Phục hồi an toàn phiên học đang tạm dừng, bảo vệ 100% tiến độ của người học
          APP_STATE.timerDuration = data.duration || 90 * 60;
          APP_STATE.timerMode = data.mode || 'ultradian';
          APP_STATE.distractionsCount = data.distractions || 0;
          APP_STATE.timerRemaining = data.remaining;
          APP_STATE.isTimerRunning = false;
          APP_STATE.timerTargetEndTime = null;
          updateTimerDisplay();
          updateTimerButtonsUI(false);
          updateModeButtonsUI();
        }
      } catch (e) {
        console.warn('Failed to restore active session backup', e);
      }
    }

    // ================= NAVIGATION =================
    function switchTab(tabId) {
      APP_STATE.currentTab = tabId;
      document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
      const activeContent = document.getElementById(`tab-${tabId}`);
      if (activeContent) activeContent.classList.remove('hidden');

      // Cuộn nội dung lên đầu khi đổi tab và triệt tiêu hoàn toàn cuộn ngang
      const mainEl = document.querySelector('main');
      if (mainEl) {
        mainEl.scrollTop = 0;
        mainEl.scrollLeft = 0;
      }
      window.scrollTo(0, 0);
      document.body.scrollLeft = 0;
      document.documentElement.scrollLeft = 0;

      // Desktop Sidebar sync
      document.querySelectorAll('.sidebar-item').forEach(btn => {
        btn.classList.remove('bg-slate-900', 'text-white', 'shadow-xs', 'font-semibold');
        btn.classList.add('text-slate-600', 'hover:text-slate-900', 'hover:bg-slate-100', 'font-medium');
      });
      const currentSidebarBtn = document.getElementById(`sidebar-btn-${tabId}`);
      if (currentSidebarBtn) {
        currentSidebarBtn.classList.remove('text-slate-600', 'hover:text-slate-900', 'hover:bg-slate-100', 'font-medium');
        currentSidebarBtn.classList.add('bg-slate-900', 'text-white', 'shadow-xs', 'font-semibold');
      }

      // Mobile Sticky Top Tabs Scroller sync - CHỈ cuộn riêng thanh tabs bar, không cuộn window
      document.querySelectorAll('.top-nav-tab').forEach(btn => {
        btn.classList.remove('bg-slate-900', 'text-white', 'shadow-xs', 'font-semibold');
        btn.classList.add('text-slate-600', 'hover:text-slate-900', 'hover:bg-slate-100', 'font-medium');
      });
      const currentTopBtn = document.getElementById(`top-tab-${tabId}`);
      const tabsBar = document.getElementById('mobile-top-tabs-bar');
      if (currentTopBtn && tabsBar) {
        currentTopBtn.classList.remove('text-slate-600', 'hover:text-slate-900', 'hover:bg-slate-100', 'font-medium');
        currentTopBtn.classList.add('bg-slate-900', 'text-white', 'shadow-xs', 'font-semibold');
        
        const scrollTarget = currentTopBtn.offsetLeft - (tabsBar.clientWidth / 2) + (currentTopBtn.clientWidth / 2);
        tabsBar.scrollTo({ left: Math.max(0, scrollTarget), behavior: 'smooth' });
      }

      // Mobile Bottom Nav sync
      document.querySelectorAll('.mob-nav-btn').forEach(btn => {
        btn.classList.remove('text-blue-600', 'font-bold', 'bg-blue-50/80');
        btn.classList.add('text-slate-500', 'font-semibold');
      });
      const currentMobBtn = document.getElementById(`mob-nav-${tabId}`);
      if (currentMobBtn) {
        currentMobBtn.classList.remove('text-slate-500', 'font-semibold');
        currentMobBtn.classList.add('text-blue-600', 'font-bold', 'bg-blue-50/80');
      }

      if (tabId === 'timer') {
        updateDailySessionUI();
        updateTimerButtonsUI(APP_STATE.isTimerRunning);
      } else if (tabId === 'profile') {
        updateStatsUI();
        renderHistory();
        renderReminders();
        updateUserInfoUI();
      } else if (tabId === 'leaderboard') {
        renderLeaderboard();
        fetchLeaderboardFromCloud(false);
      }

      if (tabId !== 'gym') {
        closeGameContainer();
      } else {
        updateDailyGymUI();
      }
    }

    // ================= TIMER ENGINE (WEB WORKER + WAKE LOCK + RESILIENT SYNC) =================
    let timerWorker = null;
    let wakeLockSentinel = null;

    function initTimerWorker() {
      if (timerWorker) return;
      try {
        const workerBlob = new Blob([`
          let intervalId = null;
          self.onmessage = function(e) {
            if (e.data === 'start') {
              if (intervalId) clearInterval(intervalId);
              intervalId = setInterval(() => {
                self.postMessage('tick');
              }, 250);
            } else if (e.data === 'stop') {
              if (intervalId) clearInterval(intervalId);
              intervalId = null;
            }
          };
        `], { type: 'application/javascript' });
        const workerUrl = URL.createObjectURL(workerBlob);
        timerWorker = new Worker(workerUrl);
        timerWorker.onmessage = function(e) {
          if (e.data === 'tick') {
            tickTimer();
          }
        };
      } catch (err) {
        console.warn('Web Worker not supported or blocked in current context, using fallback interval', err);
      }
    }

    async function requestScreenWakeLock() {
      if ('wakeLock' in navigator && !wakeLockSentinel) {
        try {
          wakeLockSentinel = await navigator.wakeLock.request('screen');
          wakeLockSentinel.addEventListener('release', () => {
            wakeLockSentinel = null;
          });
        } catch (_) {}
      }
    }

    function releaseScreenWakeLock() {
      if (wakeLockSentinel) {
        try {
          wakeLockSentinel.release();
        } catch (_) {}
        wakeLockSentinel = null;
      }
    }

    function saveSessionBackup() {
      try {
        const hasProgress = APP_STATE.timerRemaining < APP_STATE.timerDuration;
        if (APP_STATE.isTimerRunning && APP_STATE.timerTargetEndTime) {
          localStorage.setItem('bf_active_session', JSON.stringify({
            isRunning: true,
            targetEndTime: APP_STATE.timerTargetEndTime,
            duration: APP_STATE.timerDuration,
            remaining: APP_STATE.timerRemaining,
            mode: APP_STATE.timerMode,
            distractions: APP_STATE.distractionsCount,
            savedAt: Date.now()
          }));
        } else if (hasProgress) {
          // Lưu trạng thái tạm dừng dở dang để bảo vệ phiên học không bị mất
          localStorage.setItem('bf_active_session', JSON.stringify({
            isRunning: false,
            duration: APP_STATE.timerDuration,
            remaining: APP_STATE.timerRemaining,
            mode: APP_STATE.timerMode,
            distractions: APP_STATE.distractionsCount,
            savedAt: Date.now()
          }));
        } else {
          localStorage.removeItem('bf_active_session');
        }
      } catch (_) {}
    }

    function resyncActiveSession() {
      if (APP_STATE.isTimerRunning && APP_STATE.timerTargetEndTime) {
        const now = Date.now();
        const diffMs = APP_STATE.timerTargetEndTime - now;
        const diffSec = Math.max(0, Math.ceil(diffMs / 1000));
        APP_STATE.timerRemaining = diffSec;
        updateTimerDisplay();

        if (diffSec <= 0) {
          completeTimer();
        } else {
          requestScreenWakeLock();
        }
      }
    }

    function tickTimer() {
      if (!APP_STATE.isTimerRunning || !APP_STATE.timerTargetEndTime) return;

      const now = Date.now();
      const diffMs = APP_STATE.timerTargetEndTime - now;
      const diffSec = Math.max(0, Math.ceil(diffMs / 1000));

      if (APP_STATE.timerRemaining !== diffSec) {
        APP_STATE.timerRemaining = diffSec;
        updateTimerDisplay();
      }

      if (diffSec <= 0) {
        completeTimer();
      }
    }

    // ================= REST COOLDOWN & GIỚI HẠN 3 PHIÊN/NGÀY =================
    const MAX_SESSIONS_PER_DAY = 3;
    const REST_COOLDOWN_SECONDS = 15 * 60; // Mặc định phiên 90p nghỉ 15 phút

    function escapeHtml(str) {
      if (!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    // Thời gian nghỉ ngơi tỉ lệ khoa học theo độ dài phiên học:
    // - Phiên học sâu 90p: nghỉ 15 phút (Adenosine clearance)
    // - Phiên 45-60p: nghỉ 10 phút
    // - Phiên 15-25p (Khởi động / Pomodoro): nghỉ 5 phút
    function getCooldownSecondsForSession(sessionMinutes) {
      const mins = Number(sessionMinutes) || 90;
      if (mins >= 90) {
        return 15 * 60; // 90p -> nghỉ 15 phút
      } else if (mins >= 45) {
        return 10 * 60; // 45-60p -> nghỉ 10 phút
      } else {
        return 5 * 60;  // 15p hoặc 25p -> nghỉ 5 phút
      }
    }

    function getTodayDateString() {
      const now = new Date();
      const y = now.getFullYear();
      const m = String(now.getMonth() + 1).padStart(2, '0');
      const d = String(now.getDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }

    function getTodayCompletedSessionsCount() {
      const today = getTodayDateString();
      let historyCount = 0;
      if (Array.isArray(APP_STATE.history)) {
        historyCount = APP_STATE.history.filter(item => {
          const ts = item.timestamp || item.id;
          if (!ts) return false;
          const d = new Date(ts);
          const itemDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
          return itemDate === today;
        }).length;
      }
      let trackerCount = 0;
      if (APP_STATE.dailyTracker && APP_STATE.dailyTracker.date === today) {
        trackerCount = Number(APP_STATE.dailyTracker.count) || 0;
      }
      return Math.max(historyCount, trackerCount);
    }

    function syncTodaySessionTracker() {
      const today = getTodayDateString();
      const count = getTodayCompletedSessionsCount();
      APP_STATE.dailyTracker = { date: today, count: count };
      try {
        localStorage.setItem('bf_daily_tracker', JSON.stringify(APP_STATE.dailyTracker));
      } catch (_) {}
      updateDailySessionUI();
    }

    function recordTodaySession() {
      syncTodaySessionTracker();
    }

    function isRestCooldownActive() {
      if (!APP_STATE.cooldownEndTime) return false;
      return Date.now() < APP_STATE.cooldownEndTime;
    }

    function getRestCooldownRemaining() {
      if (!APP_STATE.cooldownEndTime) return 0;
      return Math.max(0, Math.ceil((APP_STATE.cooldownEndTime - Date.now()) / 1000));
    }

    function startRestCooldown(seconds) {
      const sessionMinutes = Math.round(APP_STATE.timerDuration / 60) || 90;
      const cooldownSec = seconds || getCooldownSecondsForSession(sessionMinutes);
      APP_STATE.currentCooldownTotalSeconds = cooldownSec;
      APP_STATE.cooldownEndTime = Date.now() + (cooldownSec * 1000);
      try {
        localStorage.setItem('bf_cooldown_until', String(APP_STATE.cooldownEndTime));
        localStorage.setItem('bf_cooldown_total_seconds', String(cooldownSec));
      } catch (_) {}
      startCooldownTicker();
      updateDailySessionUI();
      updateTimerButtonsUI(false);
    }

    function startCooldownTicker() {
      if (APP_STATE.restInterval) {
        clearInterval(APP_STATE.restInterval);
      }
      updateCooldownDisplay();
      APP_STATE.restInterval = setInterval(() => {
        if (!isRestCooldownActive()) {
          finishRestCooldown();
          return;
        }
        updateCooldownDisplay();
        updateTimerButtonsUI(false);
      }, 1000);
    }

    function finishRestCooldown() {
      if (APP_STATE.restInterval) {
        clearInterval(APP_STATE.restInterval);
        APP_STATE.restInterval = null;
      }
      APP_STATE.cooldownEndTime = null;
      const cooldownMin = Math.round((APP_STATE.currentCooldownTotalSeconds || 900) / 60);
      try {
        localStorage.removeItem('bf_cooldown_until');
        localStorage.removeItem('bf_cooldown_total_seconds');
      } catch (_) {}

      updateDailySessionUI();
      updateTimerButtonsUI(false);

      // Âm thanh nhẹ báo hết giờ nghỉ ngơi
      playGentleChime();

      setTimeout(() => {
        alert(`✨ HẾT ${cooldownMin} PHÚT NGHỈ NGƠI HỒI PHỤC!\n\nVỏ não của bạn đã hạ nhiệt và nạp lại Adenosine thành công. Bạn đã sẵn sàng bước vào phiên học tiếp theo!`);
      }, 100);
    }

    function restoreRestCooldown() {
      try {
        const saved = localStorage.getItem('bf_cooldown_until');
        const savedTotal = localStorage.getItem('bf_cooldown_total_seconds');
        if (savedTotal) {
          APP_STATE.currentCooldownTotalSeconds = Number(savedTotal) || (15 * 60);
        }
        if (saved) {
          const target = Number(saved);
          if (target && target > Date.now()) {
            APP_STATE.cooldownEndTime = target;
            startCooldownTicker();
          } else {
            localStorage.removeItem('bf_cooldown_until');
            localStorage.removeItem('bf_cooldown_total_seconds');
            APP_STATE.cooldownEndTime = null;
          }
        }
      } catch (_) {}
    }

    function updateCooldownDisplay() {
      const banner = document.getElementById('mandatory-rest-banner');
      const timeDisplay = document.getElementById('cooldown-timer-display');
      const progressBar = document.getElementById('cooldown-progress-bar');
      const titleEl = document.getElementById('cooldown-banner-title');
      const subtextEl = document.getElementById('cooldown-banner-subtext');
      if (!banner) return;

      if (!isRestCooldownActive()) {
        banner.classList.add('hidden');
        return;
      }

      banner.classList.remove('hidden');
      const remSec = getRestCooldownRemaining();
      const mm = String(Math.floor(remSec / 60)).padStart(2, '0');
      const ss = String(remSec % 60).padStart(2, '0');
      if (timeDisplay) timeDisplay.innerText = `${mm}:${ss}`;

      const totalCooldown = APP_STATE.currentCooldownTotalSeconds || (15 * 60);
      const cooldownMin = Math.round(totalCooldown / 60);
      const pct = Math.max(0, Math.min(100, (remSec / totalCooldown) * 100));
      if (progressBar) progressBar.style.width = `${pct}%`;

      if (titleEl) {
        titleEl.innerText = `THỜI GIAN NGHỈ NGƠI HỒI PHỤC (${cooldownMin} PHÚT BẮT BUỘC)`;
      }
      if (subtextEl) {
        if (cooldownMin >= 15) {
          subtextEl.innerText = `Sau phiên học sâu 90 phút, vỏ não cần 15 phút hạ nhiệt và giải tỏa Adenosine. Bạn hãy thư giãn và không bắt đầu phiên mới.`;
        } else {
          subtextEl.innerText = `Sau phiên tập trung, não bộ cần ${cooldownMin} phút nghỉ ngơi nạp lại năng lượng trước khi bắt đầu phiên tiếp theo.`;
        }
      }
    }

    function updateDailySessionUI() {
      const todayCount = getTodayCompletedSessionsCount();
      const counterBadge = document.getElementById('daily-sessions-counter-badge');
      const subtext = document.getElementById('daily-sessions-subtext');
      const limitBanner = document.getElementById('daily-limit-banner');

      if (counterBadge) {
        counterBadge.innerText = `${todayCount}/${MAX_SESSIONS_PER_DAY} Phiên`;
        if (todayCount >= MAX_SESSIONS_PER_DAY) {
          counterBadge.className = 'font-bold text-xs text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-full';
        } else if (todayCount > 0) {
          counterBadge.className = 'font-bold text-xs text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-full';
        } else {
          counterBadge.className = 'font-bold text-xs text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full';
        }
      }

      if (subtext) {
        if (todayCount >= MAX_SESSIONS_PER_DAY) {
          subtext.innerText = 'Đã đạt hạn mức 3 phiên hôm nay. Não bộ cần nghỉ ngơi và ngủ đủ giấc!';
        } else {
          subtext.innerText = `Còn lại ${MAX_SESSIONS_PER_DAY - todayCount} phiên học sâu. Khoa học thần kinh khuyến nghị tối đa 3 chu kỳ Ultradian (4.5h)/ngày.`;
        }
      }

      // Update 3 session pills
      for (let i = 1; i <= MAX_SESSIONS_PER_DAY; i++) {
        const dot = document.getElementById(`session-dot-${i}`);
        if (dot) {
          if (todayCount >= i) {
            dot.className = 'flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs';
            dot.innerHTML = `<span>✓</span> <span>Phiên ${i}</span>`;
          } else if (todayCount === i - 1 && APP_STATE.isTimerRunning) {
            dot.className = 'flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-black bg-blue-100 text-blue-800 border border-blue-300 animate-pulse';
            dot.innerHTML = `<span>●</span> <span>Phiên ${i}</span>`;
          } else {
            dot.className = 'flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-bold bg-slate-100 text-slate-500 border border-slate-200';
            dot.innerHTML = `<span>○</span> <span>Phiên ${i}</span>`;
          }
        }
      }

      // Show/hide daily limit banner
      if (limitBanner) {
        if (todayCount >= MAX_SESSIONS_PER_DAY) {
          limitBanner.classList.remove('hidden');
        } else {
          limitBanner.classList.add('hidden');
        }
      }

      updateCooldownDisplay();
    }

    function playGentleChime() {
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc1.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.3); // E5

        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(659.25, ctx.currentTime + 0.3);
        osc2.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.7); // G5

        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start();
        osc2.start(ctx.currentTime + 0.3);
        osc1.stop(ctx.currentTime + 0.3);
        osc2.stop(ctx.currentTime + 1.2);
      } catch (_) {}
    }

    function updateTimerButtonsUI(isRunning) {
      const playPauseIcon = document.getElementById('play-pause-icon');
      const playPauseText = document.getElementById('play-pause-text');
      const mainBtn = document.getElementById('main-timer-action-btn');
      
      if (!mainBtn) return;

      const cooldownActive = isRestCooldownActive();
      const dailyLimitReached = getTodayCompletedSessionsCount() >= MAX_SESSIONS_PER_DAY;

      if (isRunning) {
        if (playPauseIcon) playPauseIcon.innerText = '⏸️';
        if (playPauseText) playPauseText.innerText = 'TẠM DỪNG';
        mainBtn.className = 'px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-2';
        return;
      }

      if (cooldownActive) {
        const remSec = getRestCooldownRemaining();
        const mm = String(Math.floor(remSec / 60)).padStart(2, '0');
        const ss = String(remSec % 60).padStart(2, '0');
        if (playPauseIcon) playPauseIcon.innerText = '☕';
        if (playPauseText) playPauseText.innerText = `ĐANG NGHỈ NGƠI (${mm}:${ss})`;
        mainBtn.className = 'px-6 py-3 rounded-xl bg-slate-100 text-slate-500 font-semibold text-xs sm:text-sm border border-slate-200 cursor-not-allowed flex items-center gap-2';
        return;
      }

      if (dailyLimitReached && APP_STATE.timerRemaining === APP_STATE.timerDuration) {
        if (playPauseIcon) playPauseIcon.innerText = '🔒';
        if (playPauseText) playPauseText.innerText = 'ĐÃ ĐẠT 3 PHIÊN/NGÀY';
        mainBtn.className = 'px-6 py-3 rounded-xl bg-slate-100 text-slate-400 font-semibold text-xs sm:text-sm border border-slate-200 cursor-not-allowed flex items-center gap-2';
        return;
      }

      if (playPauseIcon) playPauseIcon.innerText = '▶️';
      if (playPauseText) {
        playPauseText.innerText = (APP_STATE.timerRemaining < APP_STATE.timerDuration) ? 'TIẾP TỤC PHIÊN HỌC' : 'BẮT ĐẦU PHIÊN HỌC';
      }
      mainBtn.className = 'px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-2';
    }

    // ================= SAFE SESSION SWITCHING & PROGRESS SHIELD =================
    let pendingTimerModeSwitch = null;

    function getSessionModeName(mode) {
      if (mode === 'ultradian') return 'Phiên Học Sâu Ultradian 90p';
      if (mode === 'pomodoro') return 'Phiên Tập Trung Pomodoro 25p';
      return 'Phiên Khởi Động Não 15p';
    }

    function updateModeButtonsUI() {
      const current = APP_STATE.timerMode;
      ['ultradian', 'pomodoro', 'sprint', 'break'].forEach(m => {
        const btn = document.getElementById(`mode-btn-${m}`);
        if (!btn) return;
        if (m === current || (m === 'break' && current === 'sprint') || (m === 'sprint' && current === 'break')) {
          btn.className = 'px-4 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all bg-slate-900 text-white shadow-xs';
        } else {
          btn.className = 'px-4 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all text-slate-600 hover:text-slate-900 hover:bg-slate-100';
        }
      });
    }

    function setTimerMode(mode) {
      const normalizedMode = (mode === 'break') ? 'sprint' : mode;

      // 1. Nếu bấm đúng vào chế độ đang chọn -> TUYỆT ĐỐI KHÔNG LÀM GÌ, giữ nguyên 100% tiến độ
      if (normalizedMode === APP_STATE.timerMode) {
        return;
      }

      // 2. Kiểm tra điều kiện nghỉ ngơi cooldown hoặc Giới hạn 3 phiên/ngày
      if (isRestCooldownActive()) {
        const remSec = getRestCooldownRemaining();
        const mm = Math.floor(remSec / 60);
        const ss = remSec % 60;
        const cooldownMin = Math.round((APP_STATE.currentCooldownTotalSeconds || 900) / 60);
        alert(`☕ Đang trong thời gian nghỉ ngơi ${cooldownMin} phút hồi phục (Còn ${mm}p ${ss}s). Bạn hãy nghỉ ngơi và không thể bắt đầu phiên học mới trong khoảng thời gian này!`);
        return;
      }

      if (getTodayCompletedSessionsCount() >= MAX_SESSIONS_PER_DAY && (APP_STATE.timerRemaining === APP_STATE.timerDuration)) {
        alert(`🛑 Bạn đã hoàn thành tối đa 3 phiên học trong ngày hôm nay (4.5 tiếng). Não bộ cần nghỉ ngơi để phục hồi cho ngày mai!`);
        return;
      }

      // 3. Kiểm tra xem phiên hiện tại có đang chạy hoặc có tiến độ dở dang không
      const isSessionActive = APP_STATE.isTimerRunning || (APP_STATE.timerRemaining < APP_STATE.timerDuration);
      if (isSessionActive) {
        // Mở modal xác nhận an toàn với các tùy chọn bảo vệ phiên học
        pendingTimerModeSwitch = normalizedMode;
        openSessionSwitchModal(normalizedMode);
        return;
      }

      // 4. Nếu chưa chạy giây nào, chuyển chế độ an toàn ngay lập tức
      applyTimerModeSwitch(normalizedMode);
    }

    function openSessionSwitchModal(targetMode) {
      const modal = document.getElementById('session-switch-confirm-modal');
      if (!modal) {
        // Fallback an toàn nếu modal chưa gắn DOM
        const curName = getSessionModeName(APP_STATE.timerMode);
        const tarName = getSessionModeName(targetMode);
        if (confirm(`Bạn đang có ${curName} chưa hoàn thành. Bạn có chắc muốn hủy phiên này để chuyển sang ${tarName}?`)) {
          resetTimer();
          applyTimerModeSwitch(targetMode);
        }
        return;
      }

      const currentNameEl = document.getElementById('switch-modal-current-name');
      const currentStatusEl = document.getElementById('switch-modal-current-status');
      const targetNameEl = document.getElementById('switch-modal-target-name');
      const saveBtn = document.getElementById('switch-modal-save-btn');
      const saveTextEl = document.getElementById('switch-modal-save-text');

      const elapsedSec = Math.max(0, APP_STATE.timerDuration - APP_STATE.timerRemaining);
      const elapsedMin = Math.floor(elapsedSec / 60);
      const elapsedRemainSec = elapsedSec % 60;
      const remMin = Math.floor(APP_STATE.timerRemaining / 60);
      const remSec = APP_STATE.timerRemaining % 60;

      const currentModeName = getSessionModeName(APP_STATE.timerMode);
      const targetModeName = getSessionModeName(targetMode);

      if (currentNameEl) currentNameEl.innerText = currentModeName;
      if (currentStatusEl) {
        const stateStr = APP_STATE.isTimerRunning ? 'Đang chạy' : 'Tạm dừng';
        currentStatusEl.innerText = `${stateStr} • Đã học: ${elapsedMin}p ${elapsedRemainSec}s • Còn lại: ${remMin}p ${remSec}s`;
      }
      if (targetNameEl) targetNameEl.innerText = targetModeName;

      // Nếu đã học được từ 1 phút trở lên, hiển thị nút Lưu tiến độ
      if (saveBtn && saveTextEl) {
        if (elapsedMin >= 1) {
          saveBtn.classList.remove('hidden');
          saveTextEl.innerText = `Lưu ${elapsedMin} phút đã học & Đổi sang ${targetModeName}`;
        } else {
          saveBtn.classList.add('hidden');
        }
      }

      modal.classList.remove('hidden');
    }

    function cancelSessionSwitch() {
      pendingTimerModeSwitch = null;
      const modal = document.getElementById('session-switch-confirm-modal');
      if (modal) modal.classList.add('hidden');
      // Không làm gì cả: Phiên hiện tại tiếp tục 100% nguyên vẹn an toàn!
    }

    function saveAndSwitchSession() {
      const targetMode = pendingTimerModeSwitch;
      pendingTimerModeSwitch = null;
      const modal = document.getElementById('session-switch-confirm-modal');
      if (modal) modal.classList.add('hidden');

      if (!targetMode) return;

      const elapsedSec = Math.max(0, APP_STATE.timerDuration - APP_STATE.timerRemaining);
      const elapsedMin = Math.floor(elapsedSec / 60);

      pauseTimer();

      if (elapsedMin >= 1) {
        const now = Date.now();
        const d = new Date();
        const timeStr = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
        const dateStr = `${timeStr} - ${d.toLocaleDateString('vi-VN')}`;
        const prevModeName = getSessionModeName(APP_STATE.timerMode);

        const sessionItem = {
          id: now,
          timestamp: now,
          subject: `${prevModeName} (${elapsedMin}p)`,
          minutes: elapsedMin,
          points: elapsedMin, // 1 phút = 1 điểm thời lượng
          date: dateStr,
          emotion: APP_STATE.selectedEmotion || 'Tập trung cao 🚀',
          note: `Đã hoàn thành ${elapsedMin} phút tập trung trước khi chuyển đổi phiên.`,
          hasReflected: true
        };
        if (!Array.isArray(APP_STATE.history)) {
          APP_STATE.history = [];
        }
        APP_STATE.history.unshift(sessionItem);
        APP_STATE.sessionsCompletedCount = (APP_STATE.sessionsCompletedCount || 0) + 1;
        APP_STATE.totalHours = parseFloat(((APP_STATE.totalHours || 0) + (elapsedMin / 60)).toFixed(1));
        APP_STATE.totalMinutes = (APP_STATE.totalMinutes || 0) + elapsedMin;
        APP_STATE.rankPoints = (APP_STATE.rankPoints || 1000) + elapsedMin;
        APP_STATE.bfsScore = (APP_STATE.bfsScore || 0) + Math.min(20, Math.ceil(elapsedMin / 3));

        syncTodaySessionTracker();
        saveAppStateToLocal();
        updateStatsUI();
        updateDailySessionUI();
        renderLeaderboard();
        renderHistory();
      }

      resetTimer();
      applyTimerModeSwitch(targetMode);
    }

    function confirmSessionSwitch() {
      const targetMode = pendingTimerModeSwitch;
      pendingTimerModeSwitch = null;
      const modal = document.getElementById('session-switch-confirm-modal');
      if (modal) modal.classList.add('hidden');

      if (targetMode) {
        // Chỉ khi người dùng chủ động bấm xác nhận thì mới reset phiên cũ và chuyển
        resetTimer();
        applyTimerModeSwitch(targetMode);
      }
    }

    function applyTimerModeSwitch(normalizedMode) {
      APP_STATE.timerMode = normalizedMode;
      updateModeButtonsUI();

      if (normalizedMode === 'ultradian') {
        APP_STATE.timerDuration = 90 * 60;
        const phaseEl = document.getElementById('timer-phase-label');
        if (phaseEl) phaseEl.innerText = 'Khởi động vỏ não (0-15p)';
      } else if (normalizedMode === 'pomodoro') {
        APP_STATE.timerDuration = 25 * 60;
        const phaseEl = document.getElementById('timer-phase-label');
        if (phaseEl) phaseEl.innerText = 'Pomodoro Lock-In (25p)';
      } else {
        APP_STATE.timerDuration = 15 * 60;
        const phaseEl = document.getElementById('timer-phase-label');
        if (phaseEl) phaseEl.innerText = 'Sprint Khởi Động Não (15p)';
      }

      APP_STATE.timerRemaining = APP_STATE.timerDuration;
      APP_STATE.timerTargetEndTime = null;
      saveSessionBackup();
      updateTimerDisplay();
      updateTimerButtonsUI(false);
    }

    // ================= PHONE NOTIFICATIONS & DO NOT DISTURB (DND) =================
    function toggleDnd(forceState) {
      const target = (typeof forceState === 'boolean') ? forceState : !APP_STATE.isDndActive;
      APP_STATE.isDndActive = target;

      if (window.AndroidBridge && typeof window.AndroidBridge.toggleDnd === 'function') {
        try {
          window.AndroidBridge.toggleDnd(target);
          if (typeof window.AndroidBridge.showToast === 'function') {
            window.AndroidBridge.showToast(target ? '🔕 Đã kích hoạt Chế độ Không làm phiền (Tắt chuông & thông báo)' : '🔔 Đã khôi phục thông báo bình thường');
          }
        } catch (e) {
          console.warn('AndroidBridge error:', e);
        }
      }
      updateDndUI();
    }

    function openSystemDndSettings() {
      if (window.AndroidBridge && typeof window.AndroidBridge.openDndSettings === 'function') {
        try {
          window.AndroidBridge.openDndSettings();
        } catch (e) {
          alert('Không thể mở cài đặt: ' + e.message);
        }
      } else {
        alert('💡 Gợi ý: Trên điện thoại của bạn, hãy cấp quyền "Không làm phiền" (DND) cho Brain Focus để app tự động tắt mọi chuông và rung thông báo khi bạn bắt đầu học bài!');
      }
    }

    function toggleAutoDnd(enable) {
      APP_STATE.autoDndOnSession = enable;
    }

    function updateDndUI() {
      const isDnd = APP_STATE.isDndActive;
      const dndToggleBtn = document.getElementById('dnd-toggle-switch');
      const dndStatusBadge = document.getElementById('dnd-status-badge');
      const dndStatusText = document.getElementById('dnd-status-text');
      const dndIcon = document.getElementById('dnd-icon-display');
      const dndCard = document.getElementById('dnd-shield-card');

      if (dndToggleBtn) {
        dndToggleBtn.checked = isDnd;
      }
      if (dndStatusBadge) {
        if (isDnd) {
          dndStatusBadge.innerText = '🔕 Đang Chặn Thông Báo';
          dndStatusBadge.className = 'text-[10px] font-black text-rose-700 bg-rose-100 border border-rose-300 px-2 py-0.5 rounded-full shadow-xs animate-pulse';
        } else {
          dndStatusBadge.innerText = '🔔 Bình thường';
          dndStatusBadge.className = 'text-[10px] font-bold text-slate-600 bg-slate-100 border border-slate-300 px-2 py-0.5 rounded-full shadow-xs';
        }
      }
      if (dndStatusText) {
        dndStatusText.innerText = isDnd 
          ? 'Toàn bộ chuông, rung và thông báo mạng xã hội đã bị chặn để bạn đắm chìm vào Flow State.' 
          : 'Tự động chặn thông báo, chuông và tin nhắn làm vỡ dòng tập trung khi học.';
      }
      if (dndIcon) {
        dndIcon.innerText = isDnd ? '🔕' : '🔔';
        dndIcon.className = isDnd 
          ? 'w-10 h-10 rounded-2xl bg-gradient-to-br from-rose-500 to-red-600 text-white flex items-center justify-center text-xl shadow-md animate-pulse'
          : 'w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 text-white flex items-center justify-center text-xl shadow-md';
      }
      if (dndCard) {
        if (isDnd) {
          dndCard.classList.add('border-rose-300', 'bg-rose-50/50');
          dndCard.classList.remove('border-sky-200/90');
        } else {
          dndCard.classList.remove('border-rose-300', 'bg-rose-50/50');
          dndCard.classList.add('border-sky-200/90');
        }
      }
    }

    function toggleTimer() {
      if (APP_STATE.isTimerRunning) {
        pauseTimer();
        return;
      }

      // Kiểm tra 1: Thời gian nghỉ ngơi hồi phục theo phiên học
      if (isRestCooldownActive()) {
        const remSec = getRestCooldownRemaining();
        const mm = Math.floor(remSec / 60);
        const ss = remSec % 60;
        const cooldownMin = Math.round((APP_STATE.currentCooldownTotalSeconds || 900) / 60);
        alert(`☕ ĐANG TRONG THỜI GIAN NGHỈ NGƠI HỒI PHỤC!\n\nSau phiên học, bạn cần nghỉ ngơi ${cooldownMin} phút để não bộ hạ nhiệt và phục hồi nồng độ dẫn truyền thần kinh.\n\nThời gian nghỉ còn lại: ${mm} phút ${ss} giây.\nHãy cho mắt nghỉ ngơi, uống nước hoặc vận động nhẹ nhàng nhé!`);
        return;
      }

      // Kiểm tra 2: Tối đa 3 phiên học trong ngày
      if (getTodayCompletedSessionsCount() >= MAX_SESSIONS_PER_DAY && APP_STATE.timerRemaining === APP_STATE.timerDuration) {
        alert(`🛑 ĐÃ ĐẠT GIỚI HẠN TỐI ĐA 3 PHIÊN HỌC TRONG NGÀY!\n\nBạn đã hoàn thành 3 chu kỳ học sâu hôm nay.\n\nKhoa học thần kinh khuyến cáo não bộ cần nghỉ ngơi và ngủ đủ giấc sau 3 chu kỳ để không bị kiệt sức và Não Bỏng Ngô.\n\nHãy nghỉ ngơi và quay lại vào ngày mai bạn nhé!`);
        return;
      }

      startTimer();
    }

    function startTimer(isResumingBackup = false) {
      if (!isResumingBackup) {
        if (isRestCooldownActive()) {
          return;
        }
        if (getTodayCompletedSessionsCount() >= MAX_SESSIONS_PER_DAY && APP_STATE.timerRemaining === APP_STATE.timerDuration) {
          return;
        }
      }

      if (APP_STATE.timerRemaining <= 0) {
        APP_STATE.timerRemaining = APP_STATE.timerDuration;
      }

      APP_STATE.isTimerRunning = true;
      if (!isResumingBackup || !APP_STATE.timerTargetEndTime) {
        APP_STATE.timerTargetEndTime = Date.now() + (APP_STATE.timerRemaining * 1000);
      }

      saveSessionBackup();
      requestScreenWakeLock();

      // Auto enable DND when starting session if enabled
      if (APP_STATE.autoDndOnSession && !APP_STATE.isDndActive) {
        toggleDnd(true);
      }

      // Initialize and trigger Web Worker (runs unthrottled in background)
      initTimerWorker();
      if (timerWorker) {
        timerWorker.postMessage('start');
      }

      // Also keep fallback interval
      if (APP_STATE.timerInterval) {
        clearInterval(APP_STATE.timerInterval);
      }
      APP_STATE.timerInterval = setInterval(() => {
        tickTimer();
      }, 300);

      updateTimerButtonsUI(true);

      if (!APP_STATE.isPlayingAudio) {
        try {
          toggleAudio();
        } catch (_) {}
      }
    }

    function pauseTimer() {
      APP_STATE.isTimerRunning = false;
      releaseScreenWakeLock();

      if (timerWorker) {
        timerWorker.postMessage('stop');
      }
      if (APP_STATE.timerInterval) {
        clearInterval(APP_STATE.timerInterval);
        APP_STATE.timerInterval = null;
      }
      if (APP_STATE.timerTargetEndTime) {
        const diffMs = APP_STATE.timerTargetEndTime - Date.now();
        APP_STATE.timerRemaining = Math.max(0, Math.ceil(diffMs / 1000));
        APP_STATE.timerTargetEndTime = null;
      }
      saveSessionBackup();
      updateTimerButtonsUI(false);
      updateTimerDisplay();
    }

    function resetTimer() {
      pauseTimer();
      APP_STATE.timerRemaining = APP_STATE.timerDuration;
      APP_STATE.timerTargetEndTime = null;
      APP_STATE.distractionsCount = 0;
      saveSessionBackup();

      const distEl = document.getElementById('timer-distraction-count');
      if (distEl) distEl.innerText = 'Xao nhãng: 0 lần';
      const alertEl = document.getElementById('distraction-alert');
      if (alertEl) alertEl.classList.add('hidden');
      
      // Restore notifications if auto-DND was activated
      if (APP_STATE.autoDndOnSession && APP_STATE.isDndActive) {
        toggleDnd(false);
      }

      updateTimerDisplay();
      updateTimerButtonsUI(false);
    }

    function completeTimer() {
      pauseTimer();
      APP_STATE.timerRemaining = 0;
      APP_STATE.timerTargetEndTime = null;
      saveSessionBackup();

      const sessionMinutes = Math.round(APP_STATE.timerDuration / 60) || 15;
      const pointsEarned = sessionMinutes; // 15p = 15đ, 25p = 25đ, 90p = 90đ
      const cooldownSec = getCooldownSecondsForSession(sessionMinutes);
      const cooldownMinutes = Math.round(cooldownSec / 60);

      const now = Date.now();
      const d = new Date();
      const timeStr = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
      const dateStr = `${timeStr} - ${d.toLocaleDateString('vi-VN')}`;
      const subjectInput = document.getElementById('session-subject-input');
      const defaultSubject = APP_STATE.timerMode === 'ultradian' 
        ? 'Phiên Học Sâu Ultradian 90p' 
        : (APP_STATE.timerMode === 'pomodoro' ? 'Phiên Tập Trung Pomodoro 25p' : 'Phiên Khởi Động Não 15p');
      const subject = (subjectInput && subjectInput.value.trim()) || defaultSubject;

      // 1. TỰ ĐỘNG LƯU PHIÊN HỌC VÀO LỊCH SỬ & HỒ SƠ NGAY LẬP TỨC
      const sessionItem = {
        id: now,
        timestamp: now,
        subject: subject,
        minutes: sessionMinutes,
        points: pointsEarned,
        date: dateStr,
        emotion: APP_STATE.selectedEmotion || 'Tập trung cao 🚀',
        note: `Hoàn thành trọn vẹn phiên học ${sessionMinutes} phút tập trung cao độ.`,
        hasReflected: false
      };
      if (!Array.isArray(APP_STATE.history)) {
        APP_STATE.history = [];
      }
      APP_STATE.history.unshift(sessionItem);
      APP_STATE.lastCompletedSessionId = now;
      APP_STATE.pendingReflectionSessionId = now;

      // 2. CẬP NHẬT CHỈ SỐ & ĐIỂM THƯỞNG CÔNG BẰNG THEO THỜI LƯỢNG HỌC
      APP_STATE.sessionsCompletedCount = (APP_STATE.sessionsCompletedCount || 0) + 1;
      APP_STATE.totalHours = parseFloat(((APP_STATE.totalHours || 0) + (sessionMinutes / 60)).toFixed(1));
      
      let rankBonus = 20;
      let bfsBonus = 10;
      if (sessionMinutes >= 90) {
        rankBonus = 100; // Phiên 90p học sâu xứng đáng nhận thưởng lớn
        bfsBonus = 30;
      } else if (sessionMinutes >= 25) {
        rankBonus = 35;  // Phiên Pomodoro 25p
        bfsBonus = 15;
      } else {
        rankBonus = 20;  // Phiên Sprint 15p
        bfsBonus = 10;
      }
      APP_STATE.rankPoints = (APP_STATE.rankPoints || 1000) + rankBonus;
      APP_STATE.bfsScore = (APP_STATE.bfsScore || 0) + bfsBonus;
      APP_STATE.totalMinutes = (APP_STATE.totalMinutes || 0) + sessionMinutes;

      // 3. ĐỒNG BỘ BỘ ĐẾM SỐ PHIÊN HÔM NAY (TỐI ĐA 3 PHIÊN/NGÀY)
      syncTodaySessionTracker();

      // 4. LƯU LOCALSTORAGE & GỬI SERVER DATABASE (PHP/MYSQL) NGAY LẬP TỨC
      saveAppStateToLocal();
      if (typeof bfSaveSessionToDatabase === 'function' && APP_STATE.userEmail) {
        bfSaveSessionToDatabase({
          userEmail: APP_STATE.userEmail,
          mode: APP_STATE.timerMode,
          duration: sessionMinutes,
          distractions: APP_STATE.distractionsCount || 0,
          isDeepFocus: sessionMinutes >= 90 ? 1 : 0,
          focusIntegrity: 100,
          goal: subject,
          emotion: APP_STATE.selectedEmotion || 'Tập trung cao 🚀',
          bfsEarned: bfsBonus,
          rankEarned: rankBonus,
          timestamp: now
        });
      }

      // 5. CẬP NHẬT GIAO DIỆN TOÀN BỘ CÁC BẢNG & PROFILE
      updateStatsUI();
      updateDailySessionUI();
      renderLeaderboard();
      renderHistory();
      updateTimerDisplay();

      // 6. KÍCH HOẠT THỜI GIAN NGHỈ NGƠI TỈ LỆ KHOA HỌC (90p -> nghỉ 15p, 15p/25p -> nghỉ 5p)
      startRestCooldown(cooldownSec);

      // 7. KHÔI PHỤC THÔNG BÁO NẾU AUTO-DND ĐANG BẬT
      if (APP_STATE.autoDndOnSession && APP_STATE.isDndActive) {
        toggleDnd(false);
      }

      // 8. PHÁT CHUÔNG BÁO HOÀN THÀNH
      playGentleChime();

      // 9. THÔNG BÁO VÀ MỞ MODAL ĐÚC KẾT (TÙY CHỌN NHẬN THÊM +25 BFS)
      const todayCount = getTodayCompletedSessionsCount();
      const remainingToday = Math.max(0, MAX_SESSIONS_PER_DAY - todayCount);
      const limitNotice = remainingToday > 0 
        ? `📅 Hôm nay: Đã hoàn thành ${todayCount}/${MAX_SESSIONS_PER_DAY} phiên (Còn ${remainingToday} phiên).` 
        : `👑 Bạn đã hoàn thành trọn vẹn 3/3 phiên tối đa trong ngày hôm nay!`;

      alert(`🎉 XUẤT SẮC! BẠN ĐÃ HOÀN THÀNH PHIÊN HỌC ${sessionMinutes} PHÚT!\n\n` +
            `✅ Đã lưu phiên vào Hồ Sơ & Lịch Sử (+${pointsEarned} điểm theo thời lượng).\n` +
            `${limitNotice}\n\n` +
            `☕ Thời gian nghỉ ngơi ${cooldownMinutes} phút hồi phục đã bắt đầu.\n` +
            `Hãy ghi lại 1 câu đúc kết để nhận thêm +25 BFS củng cố hồi hải mã nhé!`);

      openReflectionModal();
    }

    function updateTimerDisplay() {
      const minutes = Math.floor(APP_STATE.timerRemaining / 60);
      const seconds = APP_STATE.timerRemaining % 60;
      const formatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
      const displayEl = document.getElementById('timer-display');
      if (displayEl) displayEl.innerText = formatted;

      const total = APP_STATE.timerDuration;
      const progress = Math.min(1, Math.max(0, (total - APP_STATE.timerRemaining) / total));
      const circumference = 2 * Math.PI * 42; // ~263.89
      const offset = circumference * (1 - progress);
      const ringEl = document.getElementById('timer-progress-ring');
      if (ringEl) ringEl.style.strokeDashoffset = offset;

      if (APP_STATE.timerMode === 'ultradian') {
        const elapsedMinutes = (total - APP_STATE.timerRemaining) / 60;
        const labelEl = document.getElementById('timer-phase-label');
        if (labelEl) {
          if (elapsedMinutes < 15) {
            labelEl.innerText = 'Khởi động vỏ não (0-15p)';
            labelEl.className = 'text-[11px] font-extrabold text-blue-700 bg-blue-50 border border-blue-200 px-3 py-0.5 rounded-full mt-1.5 shadow-xs';
          } else if (elapsedMinutes < 75) {
            labelEl.innerText = '🔥 VÙNG DÒNG CHẢY (FLOW STATE)';
            labelEl.className = 'text-[11px] font-extrabold text-amber-700 bg-amber-50 border border-amber-300 px-3 py-0.5 rounded-full mt-1.5 shadow-xs animate-pulse';
          } else {
            labelEl.innerText = 'Hạ nhiệt & Đúc kết (75-90p)';
            labelEl.className = 'text-[11px] font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-0.5 rounded-full mt-1.5 shadow-xs';
          }
        }
      }
    }

    function dismissDistractionAlert() {
      document.getElementById('distraction-alert').classList.add('hidden');
    }

    // ================= AUDIO SYNTH ENGINE (Web Audio API) =================
    function initAudioContext() {
      if (!APP_STATE.audioContext) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        APP_STATE.audioContext = new AudioCtx();
      }
      if (APP_STATE.audioContext.state === 'suspended') {
        APP_STATE.audioContext.resume();
      }
    }

    function toggleAudio() {
      initAudioContext();
      if (APP_STATE.isPlayingAudio) {
        stopAudio();
      } else {
        startAudio();
      }
    }

    function changeSoundType(type) {
      APP_STATE.soundType = type;
      if (APP_STATE.isPlayingAudio) {
        stopAudio();
        startAudio();
      }
    }

    function startAudio() {
      initAudioContext();
      stopAudioNodes();
      
      const ctx = APP_STATE.audioContext;
      const type = APP_STATE.soundType;

      if (type === 'gamma') {
        // Binaural 40Hz (left 200Hz, right 240Hz simulation)
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(200, ctx.currentTime);
        
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(240, ctx.currentTime);
        
        gain.gain.setValueAtTime(0.08, ctx.currentTime);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start();
        osc2.start();
        APP_STATE.audioNodes.push(osc1, osc2, gain);

      } else if (type === 'lofi') {
        // Gentle warm chords
        const chords = [261.63, 329.63, 392.00]; // C Major
        chords.forEach(freq => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, ctx.currentTime);
          gain.gain.setValueAtTime(0.04, ctx.currentTime);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          APP_STATE.audioNodes.push(osc, gain);
        });

      } else {
        // Pink / White noise buffer
        const bufferSize = ctx.sampleRate * 2;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = (Math.random() * 2 - 1) * 0.05;
        }
        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        noise.loop = true;
        
        const filter = ctx.createBiquadFilter();
        filter.type = (type === 'rain') ? 'lowpass' : 'bandpass';
        filter.frequency.setValueAtTime(800, ctx.currentTime);
        
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.12, ctx.currentTime);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        noise.start();
        APP_STATE.audioNodes.push(noise, filter, gain);
      }

      APP_STATE.isPlayingAudio = true;
      updateAudioUI(true);
    }

    function stopAudio() {
      stopAudioNodes();
      APP_STATE.isPlayingAudio = false;
      updateAudioUI(false);
    }

    function stopAudioNodes() {
      APP_STATE.audioNodes.forEach(node => {
        try {
          if (node.stop) node.stop();
          if (node.disconnect) node.disconnect();
        } catch (_) {}
      });
      APP_STATE.audioNodes = [];
    }

    function updateAudioUI(isPlaying) {
      const statusText = document.getElementById('sound-status');
      const sideBtn = document.getElementById('sidebar-sound-btn');
      const dot = document.getElementById('audio-indicator-dot');
      const eq = document.getElementById('equalizer-bars');

      if (isPlaying) {
        if (statusText) statusText.innerText = 'Sóng 40Hz: Đang Bật 🔊';
        if (sideBtn) sideBtn.innerText = 'TẮT ÂM THANH';
        if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 animate-pulse';
        if (eq) {
          eq.classList.remove('opacity-50');
          eq.children[0].className = 'w-1 bg-blue-500 rounded-full equalizer-bar-1';
          eq.children[1].className = 'w-1 bg-blue-600 rounded-full equalizer-bar-2';
          eq.children[2].className = 'w-1 bg-blue-500 rounded-full equalizer-bar-3';
          eq.children[3].className = 'w-1 bg-blue-400 rounded-full equalizer-bar-4';
        }
      } else {
        if (statusText) statusText.innerText = 'Sóng 40Hz: Tắt';
        if (sideBtn) sideBtn.innerText = 'BẬT ÂM THANH';
        if (dot) dot.className = 'w-2 h-2 rounded-full bg-slate-600';
        if (eq) {
          eq.classList.add('opacity-50');
          for (let i = 0; i < eq.children.length; i++) {
            eq.children[i].className = 'w-1 bg-blue-400 rounded-full h-1';
          }
        }
      }
    }

    // ================= MINI GAMES (HIGH DIFFICULTY BRAIN GYM) =================
    
    // ---------------- GAME 1: STROOP SIÊU CẤP (Dual Rules & 2.5s Pressure) ----------------
    let stroopCurrentRound = 0;
    let stroopScore = 0;
    let stroopStreak = 0;
    let stroopCorrectCount = 0;
    let isStroopGameActive = false;
    let stroopRoundTimer = null;
    let stroopFeedbackTimeout = null;
    let isStroopHandlingAnswer = false;
    let stroopTimeLeftMs = 3000;
    const STROOP_PALETTE = [
      { name: "Đỏ", color: "#ef4444", dot: "#ef4444" },
      { name: "Xanh Dương", color: "#3b82f6", dot: "#3b82f6" },
      { name: "Xanh Lá", color: "#22c55e", dot: "#22c55e" },
      { name: "Vàng", color: "#facc15", dot: "#eab308" },
      { name: "Tím", color: "#c084fc", dot: "#a855f7" },
      { name: "Cam", color: "#fb923c", dot: "#f97316" },
      { name: "Hồng", color: "#f472b6", dot: "#ec4899" },
      { name: "Trắng", color: "#f8fafc", dot: "#ffffff" }
    ];

    // ================= BRAIN FOCUS GYM LOGIC & DAILY LIMIT =================
    const MAX_GYM_PLAYS_PER_DAY = 5;

    function getTodayGymPlaysCount() {
      const today = getTodayDateString();
      if (APP_STATE.dailyGymTracker && APP_STATE.dailyGymTracker.date === today) {
        return Math.max(0, Number(APP_STATE.dailyGymTracker.count) || 0);
      }
      return 0;
    }

    function recordTodayGymPlay() {
      const today = getTodayDateString();
      const current = getTodayGymPlaysCount();
      APP_STATE.dailyGymTracker = { date: today, count: current + 1 };
      try {
        localStorage.setItem('bf_daily_gym_tracker', JSON.stringify(APP_STATE.dailyGymTracker));
      } catch (_) {}
      updateDailyGymUI();
    }

    function getGymRemainingPlays() {
      const todayCount = getTodayGymPlaysCount();
      const freeRemaining = Math.max(0, MAX_GYM_PLAYS_PER_DAY - todayCount);
      const bonusPlays = Math.max(0, Number(APP_STATE.purchasedGymPlays) || 0);
      return {
        todayCount,
        freeRemaining,
        bonusPlays,
        totalAvailable: freeRemaining + bonusPlays
      };
    }

    function isGymDailyLimitReached() {
      const { totalAvailable } = getGymRemainingPlays();
      return totalAvailable <= 0;
    }

    function handleGymCardClick(gameType) {
      if (isGymDailyLimitReached()) {
        openGymShopModal();
        const alertEl = document.getElementById('shop-alert-msg');
        if (alertEl) {
          alertEl.className = "p-2.5 rounded-xl text-xs font-bold text-center bg-amber-50 text-amber-900 border border-amber-300";
          alertEl.innerText = "🛑 Bạn đã dùng hết 5 lượt tập Gym miễn phí hôm nay! Hãy đổi 35đ (XH hoặc BFS) tại Cửa Hàng để nhận thêm lượt nhé.";
          alertEl.classList.remove('hidden');
        }
        return;
      }
      if (gameType === 'stroop') startStroopGame();
      else if (gameType === 'grid') startMemoryGridGame();
      else if (gameType === 'math') startRapidMathGame();
    }

    function promptGymOutOfPlays() {
      openGymShopModal();
      const alertEl = document.getElementById('shop-alert-msg');
      if (alertEl) {
        alertEl.className = "p-2.5 rounded-xl text-xs font-bold text-center bg-amber-50 text-amber-900 border border-amber-300";
        alertEl.innerText = "🛑 Bạn đã dùng hết 5 lượt tập Gym miễn phí hôm nay! Hãy đổi 35đ (XH hoặc BFS) tại Cửa Hàng để nhận thêm lượt nhé.";
        alertEl.classList.remove('hidden');
      }
    }

    function consumeOneGymPlay() {
      const todayCount = getTodayGymPlaysCount();
      if (todayCount < MAX_GYM_PLAYS_PER_DAY) {
        recordTodayGymPlay();
      } else if ((APP_STATE.purchasedGymPlays || 0) > 0) {
        APP_STATE.purchasedGymPlays--;
        saveAppStateToLocal();
        updateDailyGymUI();
      }
    }

    // ================= CỬA HÀNG LƯỢT CHƠI GYM (35Đ/LƯỢT) =================
    function openGymShopModal() {
      const modal = document.getElementById('gym-shop-modal');
      if (!modal) return;
      const rankEl = document.getElementById('shop-rank-points');
      const bfsEl = document.getElementById('shop-bfs-points');
      const bonusEl = document.getElementById('shop-bonus-plays');
      if (rankEl) rankEl.innerText = `${APP_STATE.rankPoints || 0}đ`;
      if (bfsEl) bfsEl.innerText = `${APP_STATE.bfsScore || 0}đ`;
      if (bonusEl) bonusEl.innerText = `${APP_STATE.purchasedGymPlays || 0} lượt`;
      const alertEl = document.getElementById('shop-alert-msg');
      if (alertEl) alertEl.classList.add('hidden');
      modal.classList.remove('hidden');
      modal.style.display = 'flex';
    }

    function closeGymShopModal() {
      const modal = document.getElementById('gym-shop-modal');
      if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
      }
    }

    function buyGymPlays(currency, amount = 1) {
      const COST_PER_PLAY = 35;
      const totalCost = COST_PER_PLAY * amount;
      const alertEl = document.getElementById('shop-alert-msg');

      if (currency === 'rank') {
        if ((APP_STATE.rankPoints || 0) < totalCost) {
          if (alertEl) {
            alertEl.className = "p-2.5 rounded-xl text-xs font-bold text-center bg-rose-100 text-rose-800 border border-rose-300";
            alertEl.innerText = `❌ Bạn không đủ Điểm XH! Cần ${totalCost}đ (hiện có ${APP_STATE.rankPoints || 0}đ).`;
            alertEl.classList.remove('hidden');
          }
          return;
        }
        APP_STATE.rankPoints -= totalCost;
      } else if (currency === 'bfs') {
        if ((APP_STATE.bfsScore || 0) < totalCost) {
          if (alertEl) {
            alertEl.className = "p-2.5 rounded-xl text-xs font-bold text-center bg-rose-100 text-rose-800 border border-rose-300";
            alertEl.innerText = `❌ Bạn không đủ Điểm BFS! Cần ${totalCost}đ (hiện có ${APP_STATE.bfsScore || 0}đ).`;
            alertEl.classList.remove('hidden');
          }
          return;
        }
        APP_STATE.bfsScore -= totalCost;
      }

      APP_STATE.purchasedGymPlays = (APP_STATE.purchasedGymPlays || 0) + amount;
      saveAppStateToLocal();
      updateStatsUI();
      updateDailyGymUI();
      renderLeaderboard();

      // Cập nhật số dư trong modal shop
      const rankEl = document.getElementById('shop-rank-points');
      const bfsEl = document.getElementById('shop-bfs-points');
      const bonusEl = document.getElementById('shop-bonus-plays');
      if (rankEl) rankEl.innerText = `${APP_STATE.rankPoints || 0}đ`;
      if (bfsEl) bfsEl.innerText = `${APP_STATE.bfsScore || 0}đ`;
      if (bonusEl) bonusEl.innerText = `${APP_STATE.purchasedGymPlays || 0} lượt`;

      if (alertEl) {
        alertEl.className = "p-2.5 rounded-xl text-xs font-bold text-center bg-emerald-100 text-emerald-800 border border-emerald-300 animate-bounce";
        alertEl.innerText = `🎉 MUA THÀNH CÔNG +${amount} LƯỢT CHƠI! (-${totalCost}đ ${currency === 'rank' ? 'XH' : 'BFS'}).`;
        alertEl.classList.remove('hidden');
      }
    }

    function updateDailyGymUI() {
      const { todayCount, freeRemaining, bonusPlays, totalAvailable } = getGymRemainingPlays();
      const badge = document.getElementById('daily-gym-counter-badge');
      const bonusBadge = document.getElementById('daily-gym-bonus-badge');
      const subtext = document.getElementById('daily-gym-subtext');
      const banner = document.getElementById('daily-gym-limit-banner');

      if (bonusBadge) {
        if (bonusPlays > 0) {
          bonusBadge.innerText = `+${bonusPlays} lượt mua`;
          bonusBadge.classList.remove('hidden');
        } else {
          bonusBadge.classList.add('hidden');
        }
      }

      if (badge) {
        if (bonusPlays > 0) {
          badge.innerText = `${todayCount}/${MAX_GYM_PLAYS_PER_DAY} (Dự trữ: ${bonusPlays})`;
          badge.className = "font-bold text-xs text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded-full shadow-xs";
        } else if (todayCount >= MAX_GYM_PLAYS_PER_DAY) {
          badge.innerText = `${todayCount}/${MAX_GYM_PLAYS_PER_DAY} Lượt 🔒`;
          badge.className = "font-bold text-xs text-amber-900 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded-full shadow-xs";
        } else {
          badge.innerText = `${todayCount}/${MAX_GYM_PLAYS_PER_DAY} Lượt`;
          badge.className = "font-bold text-xs text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded-full";
        }
      }

      if (subtext) {
        if (totalAvailable <= 0) {
          subtext.innerText = "Đã dùng hết 5 lượt miễn phí hôm nay. Bạn có thể mua thêm lượt tại Cửa Hàng (35đ/lượt).";
        } else if (bonusPlays > 0) {
          subtext.innerText = `Còn ${freeRemaining} lượt miễn phí + ${bonusPlays} lượt mua dự trữ. Thua hay thắng đều tính 1 lượt (vẫn có điểm).`;
        } else {
          subtext.innerText = `Còn lại ${freeRemaining} lượt miễn phí hôm nay. Chơi hoặc thua đều mất 1 lượt (vẫn nhận điểm theo vòng).`;
        }
      }

      if (banner) {
        if (totalAvailable <= 0) {
          banner.classList.remove('hidden');
        } else {
          banner.classList.add('hidden');
        }
      }

      // Update 5 pills
      for (let i = 1; i <= MAX_GYM_PLAYS_PER_DAY; i++) {
        const dot = document.getElementById(`gym-dot-${i}`);
        if (dot) {
          if (i <= todayCount) {
            dot.className = "flex items-center gap-0.5 px-2 py-0.5 rounded-lg text-[10px] font-black bg-gradient-to-r from-emerald-500 to-teal-600 text-white border border-emerald-400 shadow-xs";
            dot.innerHTML = `<span>✓</span><span>L${i}</span>`;
          } else if (i === todayCount + 1) {
            dot.className = "flex items-center gap-0.5 px-2 py-0.5 rounded-lg text-[10px] font-black bg-indigo-100 text-indigo-800 border border-indigo-400 ring-2 ring-indigo-300 animate-pulse";
            dot.innerHTML = `<span>⚡</span><span>L${i}</span>`;
          } else {
            dot.className = "flex items-center gap-0.5 px-2 py-0.5 rounded-lg text-[10px] font-bold bg-slate-100 text-slate-400 border border-slate-200";
            dot.innerHTML = `<span>${i}</span><span>L${i}</span>`;
          }
        }
      }

      // Update game cards state
      const isMuted = totalAvailable <= 0;
      ['stroop', 'grid', 'math'].forEach(id => {
        const card = document.getElementById(`gym-card-${id}`);
        const badgeEl = document.getElementById(`gym-badge-${id}`);
        if (card) {
          if (isMuted) {
            card.classList.add('opacity-80', 'bg-slate-50');
          } else {
            card.classList.remove('opacity-80', 'bg-slate-50');
          }
        }
        if (badgeEl && isMuted) {
          badgeEl.innerText = "Mua lượt (35đ) 🛒";
          badgeEl.className = "text-amber-700 font-black text-[11px]";
        } else if (badgeEl) {
          badgeEl.innerText = '+50 BFS & XH →';
          badgeEl.className = "text-blue-700 font-black";
        }
      });
    }

    // ---------------- GAME 1: STROOP TEST (CHỌN ĐÚNG MÀU MỰC) ----------------
    function startStroopGame() {
      if (isGymDailyLimitReached()) {
        promptGymOutOfPlays();
        return;
      }

      stroopCurrentRound = 0;
      stroopScore = 0;
      stroopStreak = 0;
      stroopCorrectCount = 0;
      isStroopGameActive = true;
      isStroopHandlingAnswer = false;
      if (stroopRoundTimer) {
        clearInterval(stroopRoundTimer);
        stroopRoundTimer = null;
      }
      if (stroopFeedbackTimeout) {
        clearTimeout(stroopFeedbackTimeout);
        stroopFeedbackTimeout = null;
      }
      
      const titleEl = document.getElementById('active-game-title');
      if (titleEl) titleEl.innerText = "STROOP TEST: CHỌN ĐÚNG MÀU MỰC CỦA CHỮ";

      const container = document.getElementById('active-game-container');
      container.classList.remove('hidden');
      container.scrollIntoView({ behavior: 'smooth', block: 'start' });
      renderNextStroopRound();
    }

    function renderNextStroopRound() {
      if (stroopRoundTimer) {
        clearInterval(stroopRoundTimer);
        stroopRoundTimer = null;
      }
      if (stroopFeedbackTimeout) {
        clearTimeout(stroopFeedbackTimeout);
        stroopFeedbackTimeout = null;
      }
      isStroopHandlingAnswer = false;

      if (stroopCurrentRound >= 12) {
        finishStroopGame();
        return;
      }
      stroopCurrentRound++;

      // Chọn chữ và màu mực hiển thị lệch nhau để tạo hiệu ứng Stroop kinh điển
      const textItem = STROOP_PALETTE[Math.floor(Math.random() * STROOP_PALETTE.length)];
      let colorItem = STROOP_PALETTE[Math.floor(Math.random() * STROOP_PALETTE.length)];
      while (colorItem.name === textItem.name) {
        colorItem = STROOP_PALETTE[Math.floor(Math.random() * STROOP_PALETTE.length)];
      }

      // ĐÁP ÁN ĐÚNG 100% LUÔN LÀ MÀU MỰC MÀ MẮT ĐANG NHÌN THẤY
      const targetAnswer = colorItem.name;
      // Đáp án bẫy tâm lý (tên chữ viết ra) luôn luôn có mặt để kích hoạt vỏ não ức chế
      const trickDistractor = textItem.name;

      // Chọn thêm 2 màu gây nhiễu khác trong danh sách màu còn lại
      const remaining = STROOP_PALETTE.filter(p => p.name !== targetAnswer && p.name !== trickDistractor);
      for (let i = remaining.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [remaining[i], remaining[j]] = [remaining[j], remaining[i]];
      }
      const distractor1 = remaining[0].name;
      const distractor2 = remaining[1].name;

      // 4 lựa chọn đảm bảo 100% CÓ ĐÁP ÁN ĐÚNG và không bao giờ trùng lặp
      const options = [targetAnswer, trickDistractor, distractor1, distractor2];
      for (let i = options.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [options[i], options[j]] = [options[j], options[i]];
      }

      const html = `
        <div class="space-y-3 text-center">
          <div class="flex items-center justify-between">
            <span class="text-xs font-black text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-lg">Lượt ${stroopCurrentRound}/12</span>
            <span class="text-xs font-black text-amber-600 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg">Điểm: ${stroopScore} ${stroopStreak > 1 ? `(🔥x${stroopStreak})` : ''}</span>
            <button onclick="closeGameContainer()" class="px-2.5 py-1 rounded-lg text-rose-600 hover:bg-rose-50 text-xs font-bold border border-rose-200 flex items-center gap-1 active:scale-95 transition-all">
              <span>✕</span> <span>Thoát</span>
            </button>
          </div>

          <!-- Thanh đếm ngược thời gian (3.0 giây) -->
          <div class="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden shadow-inner">
            <div id="stroop-time-bar" class="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-rose-500 transition-all duration-75" style="width: 100%;"></div>
          </div>

          <!-- Hướng dẫn câu hỏi rõ ràng -->
          <div class="py-1">
            <span class="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-black bg-rose-50 text-rose-700 border border-rose-200 shadow-xs">
              <span>🎯</span> <span>CHỌN ĐÚNG MÀU MỰC CỦA CHỮ</span>
            </span>
            <p class="text-[11px] text-slate-500 mt-1">Đừng đọc nghĩa của chữ! Hãy nhìn xem chữ bên dưới đang mang <strong>màu gì</strong>:</p>
          </div>

          <!-- Bảng chữ tương phản cao, hiển thị màu sắc sống động rực rỡ -->
          <div class="py-6 my-1 bg-slate-950 border-2 border-slate-800 rounded-2xl shadow-md flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-radial from-slate-900 to-slate-950 opacity-70 pointer-events-none"></div>
            <span class="text-4xl sm:text-5xl font-black tracking-wider select-none relative z-10 transition-transform" style="color: ${colorItem.color};">
              ${textItem.name.toUpperCase()}
            </span>
          </div>

          <!-- Phản hồi trạng thái tức thì -->
          <div id="stroop-feedback-banner" class="min-h-[26px] flex items-center justify-center text-xs font-bold text-slate-600">
            <span>👇 Nhấn chọn 1 trong 4 màu bên dưới:</span>
          </div>

          <!-- 4 Nút đáp án trực quan, to bản, có chấm màu rõ ràng -->
          <div class="grid grid-cols-2 gap-2.5 pt-0.5">
            ${options.map((opt, idx) => {
              const pal = STROOP_PALETTE.find(p => p.name === opt) || { dot: '#94a3b8' };
              return `
                <button 
                  id="stroop-opt-btn-${idx}" 
                  data-opt="${opt}"
                  onclick="checkStroopAnswer('${opt}', '${targetAnswer}', ${idx})" 
                  class="py-3.5 px-4 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-extrabold text-xs sm:text-sm border-2 border-slate-200 active:scale-95 transition-all shadow-xs hover:border-blue-400 flex items-center justify-center gap-2.5"
                >
                  <span class="w-4 h-4 rounded-full shrink-0 shadow-xs border border-slate-300" style="background-color: ${pal.dot}"></span>
                  <span>${opt}</span>
                </button>
              `;
            }).join('')}
          </div>
        </div>
      `;
      document.getElementById('game-dynamic-area').innerHTML = html;

      // Bộ đếm 3.0s cho mỗi câu
      stroopTimeLeftMs = 3000;
      const stepMs = 50;
      stroopRoundTimer = setInterval(() => {
        stroopTimeLeftMs -= stepMs;
        const pct = Math.max(0, (stroopTimeLeftMs / 3000) * 100);
        const bar = document.getElementById('stroop-time-bar');
        if (bar) bar.style.width = `${pct}%`;

        if (stroopTimeLeftMs <= 0) {
          clearInterval(stroopRoundTimer);
          stroopRoundTimer = null;
          handleStroopTimeout(targetAnswer);
        }
      }, stepMs);
    }

    // Xử lý khi hết thời gian 3.0s
    function handleStroopTimeout(correct) {
      if (isStroopHandlingAnswer) return;
      isStroopHandlingAnswer = true;
      stroopStreak = 0;

      const feedbackBanner = document.getElementById('stroop-feedback-banner');
      if (feedbackBanner) {
        feedbackBanner.className = "min-h-[26px] py-1 px-3 rounded-lg bg-amber-100 text-amber-900 border border-amber-300 text-xs font-black flex items-center justify-center gap-1.5 animate-pulse";
        feedbackBanner.innerHTML = `<span>⏰ HẾT GIỜ! Màu đúng của chữ là: <strong>${correct}</strong></span>`;
      }

      // Làm sáng nút đáp án đúng
      for (let i = 0; i < 4; i++) {
        const btn = document.getElementById(`stroop-opt-btn-${i}`);
        if (btn && btn.getAttribute('data-opt') === correct) {
          btn.className = "py-3.5 px-4 rounded-xl bg-emerald-50 text-emerald-800 font-black text-xs sm:text-sm border-2 border-emerald-500 shadow-md flex items-center justify-center gap-2.5 scale-[1.02] transition-all";
        }
      }

      stroopFeedbackTimeout = setTimeout(() => {
        renderNextStroopRound();
      }, 700);
    }

    // Xử lý khi người chơi bấm chọn đáp án
    function checkStroopAnswer(chosen, correct, clickedIdx) {
      if (isStroopHandlingAnswer) return;
      isStroopHandlingAnswer = true;

      if (stroopRoundTimer) {
        clearInterval(stroopRoundTimer);
        stroopRoundTimer = null;
      }

      const clickedBtn = document.getElementById(`stroop-opt-btn-${clickedIdx}`);
      const feedbackBanner = document.getElementById('stroop-feedback-banner');

      if (chosen === correct) {
        stroopStreak++;
        stroopCorrectCount++;
        const bonus = (stroopStreak >= 3) ? 15 : 10;
        stroopScore += bonus;

        if (clickedBtn) {
          clickedBtn.className = "py-3.5 px-4 rounded-xl bg-emerald-50 text-emerald-800 font-black text-xs sm:text-sm border-2 border-emerald-500 shadow-md flex items-center justify-center gap-2.5 scale-[1.02] transition-all";
        }
        if (feedbackBanner) {
          feedbackBanner.className = "min-h-[26px] py-1 px-3 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-black flex items-center justify-center gap-1.5 animate-bounce";
          feedbackBanner.innerHTML = `<span>✅ CHÍNH XÁC! +${bonus} Điểm ${stroopStreak > 1 ? `(Combo x${stroopStreak} 🔥)` : ''}</span>`;
        }

        stroopFeedbackTimeout = setTimeout(() => {
          renderNextStroopRound();
        }, 400);
      } else {
        stroopStreak = 0;

        if (clickedBtn) {
          clickedBtn.className = "py-3.5 px-4 rounded-xl bg-rose-50 text-rose-800 font-black text-xs sm:text-sm border-2 border-rose-500 shadow-md flex items-center justify-center gap-2.5 transition-all";
        }

        // Hiện rõ đáp án đúng để người chơi thấy ngay
        for (let i = 0; i < 4; i++) {
          const btn = document.getElementById(`stroop-opt-btn-${i}`);
          if (btn && btn.getAttribute('data-opt') === correct) {
            btn.className = "py-3.5 px-4 rounded-xl bg-emerald-50 text-emerald-800 font-black text-xs sm:text-sm border-2 border-emerald-500 shadow-md flex items-center justify-center gap-2.5 scale-[1.02] transition-all";
          }
        }

        if (feedbackBanner) {
          feedbackBanner.className = "min-h-[26px] py-1 px-3 rounded-lg bg-rose-100 text-rose-900 border border-rose-300 text-xs font-black flex items-center justify-center gap-1.5";
          feedbackBanner.innerHTML = `<span>❌ CHƯA ĐÚNG! Chữ đang có màu: <strong>${correct}</strong></span>`;
        }

        stroopFeedbackTimeout = setTimeout(() => {
          renderNextStroopRound();
        }, 650);
      }
    }

    function finishStroopGame() {
      if (!isStroopGameActive) return;
      isStroopGameActive = false;
      if (stroopRoundTimer) {
        clearInterval(stroopRoundTimer);
        stroopRoundTimer = null;
      }
      if (stroopFeedbackTimeout) {
        clearTimeout(stroopFeedbackTimeout);
        stroopFeedbackTimeout = null;
      }
      isStroopHandlingAnswer = false;

      // Tiêu hao 1 lượt chơi (Thắng hay thua đều mất 1 lượt)
      consumeOneGymPlay();

      // Cơ chế tính điểm công bằng & thưởng phạt rõ ràng (Bài tập Stroop 12 câu):
      // - Dưới 3 câu đúng (<= 2 câu): Thất bại sớm / Không đạt phản xạ tối thiểu. Phạt: Tiêu hao 1 lượt chơi, nhận 0 điểm thưởng.
      // - 3-4 câu đúng: Đạt mức Cơ bản -> Thưởng: +10 BFS, +3 Rank (Tổng 13đ)
      // - 5-6 câu đúng: Đạt mức Khá -> Thưởng: +18 BFS, +6 Rank (Tổng 24đ)
      // - 7-9 câu đúng: Đạt mức Tốt -> Thưởng: +25 BFS, +9 Rank (Tổng 34đ)
      // - 10-11 câu đúng: Đạt mức Xuất sắc -> Thưởng: +30 BFS, +12 Rank (Tổng 42đ - sinh lời so với phí vào 35đ)
      // - 12/12 câu đúng: Hoàn hảo tuyệt đối -> Thưởng tối đa: +35 BFS, +15 Rank (Tổng 50đ)
      let earnedBfs = 0;
      let earnedRank = 0;
      let performanceLevel = 'Chưa đạt';

      if (stroopCorrectCount <= 2) {
        earnedBfs = 0;
        earnedRank = 0;
        performanceLevel = 'Cần rèn luyện thêm';
      } else if (stroopCorrectCount <= 4) {
        earnedBfs = 10;
        earnedRank = 3;
        performanceLevel = 'Cơ bản';
      } else if (stroopCorrectCount <= 6) {
        earnedBfs = 18;
        earnedRank = 6;
        performanceLevel = 'Khá';
      } else if (stroopCorrectCount <= 9) {
        earnedBfs = 25;
        earnedRank = 9;
        performanceLevel = 'Tốt';
      } else if (stroopCorrectCount <= 11) {
        earnedBfs = 30;
        earnedRank = 12;
        performanceLevel = 'Xuất sắc';
      } else {
        earnedBfs = 35;
        earnedRank = 15;
        performanceLevel = 'Hoàn hảo tuyệt đối';
      }

      const totalEarned = earnedBfs + earnedRank;
      if (totalEarned > 0) {
        APP_STATE.bfsScore += earnedBfs;
        APP_STATE.rankPoints += earnedRank;
      }
      APP_STATE.gymCompletedCount++;
      updateStatsUI();
      saveAppStateToLocal();
      renderLeaderboard();
      updateDailyGymUI();

      const { totalAvailable } = getGymRemainingPlays();

      document.getElementById('game-dynamic-area').innerHTML = `
        <div class="text-center space-y-3 py-4 max-w-md mx-auto">
          <span class="text-3xl">${totalEarned >= 35 ? '🏆' : (totalEarned > 0 ? '✨' : '⚠️')}</span>
          <h3 class="text-base font-bold text-slate-900">KẾT THÚC BÀI TẬP PHẢN XẠ MÀU</h3>
          <div class="text-xs text-slate-500">
            Chính xác: <strong class="text-slate-900">${stroopCorrectCount}/12 câu</strong> (${Math.round((stroopCorrectCount / 12) * 100)}%) • Đánh giá: <span class="font-semibold text-blue-600">${performanceLevel}</span>
          </div>

          <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1.5">
            ${totalEarned > 0 ? `
              <div class="flex items-center justify-between text-slate-700">
                <span>Thưởng năng lực não (BFS):</span>
                <span class="font-semibold text-blue-700">+${earnedBfs} BFS</span>
              </div>
              <div class="flex items-center justify-between text-slate-700">
                <span>Thưởng điểm xếp hạng:</span>
                <span class="font-semibold text-slate-900">+${earnedRank} Rank</span>
              </div>
              <div class="pt-1 border-t border-slate-200 flex items-center justify-between font-bold text-slate-900">
                <span>Tổng điểm nhận được:</span>
                <span class="text-blue-600">+${totalEarned} điểm</span>
              </div>
            ` : `
              <div class="text-rose-600 font-medium py-1">
                ⚠️ Đúng dưới 3 câu: Chưa vượt ngưỡng kích hoạt thùy trán. Không nhận được điểm thưởng ở lượt này.
              </div>
            `}
          </div>

          <div class="text-[11px] text-slate-500">
            Tiêu hao: <span class="font-semibold text-slate-700">-1 lượt chơi</span> • Còn lại: <strong class="text-slate-900">${totalAvailable} lượt</strong>
          </div>

          <div class="pt-2 flex items-center justify-center gap-2">
            ${totalAvailable > 0 
              ? `<button onclick="startStroopGame()" class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">🔄 Lượt tiếp theo (-1 Lượt)</button>` 
              : `<button onclick="openGymShopModal()" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">🛒 Mua thêm lượt (35đ)</button>`}
            <button onclick="closeGameContainer()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-xl border border-slate-200 transition-colors">✕ Về phòng Gym</button>
          </div>
        </div>
      `;
    }

    // ---------------- GAME 2: MEMORY MATRIX & BẪY BOM (6 Stages up to 5x5) ----------------
    let gridLevel = 1;
    let targetCells = [];
    let trapCells = [];
    let userSelectedCells = [];
    let gridRecallTimer = null;
    let gridRecallSeconds = 8;
    let gridFlashTimeout = null;
    let gridFeedbackTimeout = null;
    let isGridGameActive = false;

    function startMemoryGridGame() {
      if (isGymDailyLimitReached()) {
        promptGymOutOfPlays();
        return;
      }

      // Reset state and clear all existing timers cleanly
      gridLevel = 1;
      isGridGameActive = true;
      if (gridRecallTimer) {
        clearInterval(gridRecallTimer);
        gridRecallTimer = null;
      }
      if (gridFlashTimeout) {
        clearTimeout(gridFlashTimeout);
        gridFlashTimeout = null;
      }
      if (gridFeedbackTimeout) {
        clearTimeout(gridFeedbackTimeout);
        gridFeedbackTimeout = null;
      }

      const titleEl = document.getElementById('active-game-title');
      if (titleEl) titleEl.innerText = "MA TRẬN Ô NHỚ & BẪY BOM (WORKING MEMORY)";

      const container = document.getElementById('active-game-container');
      container.classList.remove('hidden');
      container.scrollIntoView({ behavior: 'smooth', block: 'start' });
      renderMemoryGridRound();
    }

    function renderMemoryGridRound() {
      if (!isGridGameActive) return;

      if (gridRecallTimer) {
        clearInterval(gridRecallTimer);
        gridRecallTimer = null;
      }
      if (gridFlashTimeout) {
        clearTimeout(gridFlashTimeout);
        gridFlashTimeout = null;
      }

      targetCells = [];
      trapCells = [];
      userSelectedCells = [];

      // Nâng cấp độ khó ma trận (tăng bẫy bom, tăng tốc độ chớp tắt, rút ngắn thời gian nhớ)
      let gridSize = 3;
      let numTargets = 4;
      let numTraps = 1;
      let flashTimeMs = 1100;
      let recallDuration = 7;

      if (gridLevel === 2) {
        gridSize = 4; numTargets = 5; numTraps = 2; flashTimeMs = 950; recallDuration = 7;
      } else if (gridLevel === 3) {
        gridSize = 4; numTargets = 6; numTraps = 3; flashTimeMs = 850; recallDuration = 6;
      } else if (gridLevel === 4) {
        gridSize = 5; numTargets = 7; numTraps = 3; flashTimeMs = 750; recallDuration = 6;
      } else if (gridLevel === 5) {
        gridSize = 5; numTargets = 8; numTraps = 4; flashTimeMs = 700; recallDuration = 6;
      } else if (gridLevel === 6) {
        gridSize = 5; numTargets = 9; numTraps = 5; flashTimeMs = 650; recallDuration = 5;
      }

      const totalCells = gridSize * gridSize;

      while (targetCells.length < numTargets) {
        const r = Math.floor(Math.random() * totalCells);
        if (!targetCells.includes(r)) targetCells.push(r);
      }

      while (trapCells.length < numTraps) {
        const r = Math.floor(Math.random() * totalCells);
        if (!targetCells.includes(r) && !trapCells.includes(r)) trapCells.push(r);
      }

      const gridColsClass = gridSize === 3 ? 'grid-cols-3 max-w-[240px]' : (gridSize === 4 ? 'grid-cols-4 max-w-[280px]' : 'grid-cols-5 max-w-[320px]');
      const cellSizeClass = gridSize === 5 ? 'w-11 h-11 text-xs' : (gridSize === 4 ? 'w-14 h-14 text-sm' : 'w-16 h-16 text-base');

      document.getElementById('game-dynamic-area').innerHTML = `
        <div class="space-y-3 text-center">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-blue-600">Cấp độ ${gridLevel}/6 (${gridSize}x${gridSize})</span>
            <span class="text-xs font-black text-rose-600" id="grid-timer-display">Ghi nhớ...</span>
            <button onclick="closeGameContainer()" class="px-2.5 py-1 rounded-lg text-rose-600 hover:bg-rose-50 text-xs font-bold border border-rose-200 flex items-center gap-1">
              <span>✕</span> <span>Thoát</span>
            </button>
          </div>
          
          <div class="flex items-center justify-center gap-2">
            <span class="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              Cần chọn: ${numTargets} ô xanh
            </span>
            ${numTraps > 0 ? `<span class="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">💣 Né: ${numTraps} ô bẫy</span>` : ''}
          </div>

          <p class="text-xs text-slate-700 font-semibold" id="memory-grid-instruction">Ghi nhớ nhanh vị trí các ô phát sáng...</p>
          
          <div class="grid ${gridColsClass} gap-2 mx-auto py-2" id="grid-box-container">
            ${Array.from({ length: totalCells }).map((_, idx) => {
              const isTarget = targetCells.includes(idx);
              const isTrap = trapCells.includes(idx);
              let initialStyle = 'bg-slate-100 border border-slate-300';
              let initialText = '';
              if (isTarget) {
                initialStyle = 'bg-blue-600 text-white shadow-md font-bold scale-105';
                initialText = '●';
              } else if (isTrap) {
                initialStyle = 'bg-rose-500 text-white shadow-md font-bold animate-pulse';
                initialText = '💣';
              }
              return `<div id="grid-cell-${idx}" class="${cellSizeClass} rounded-xl ${initialStyle} transition-all flex items-center justify-center">${initialText}</div>`;
            }).join('')}
          </div>
        </div>
      `;

      gridFlashTimeout = setTimeout(() => {
        if (!isGridGameActive) return;

        const instr = document.getElementById('memory-grid-instruction');
        if (instr) instr.innerText = '⚡ CHẠM LẠI CÁC Ô XANH (Tuyệt đối tránh ô Bẫy Bom!):';
        
        gridRecallSeconds = recallDuration;
        const timerDisp = document.getElementById('grid-timer-display');
        if (timerDisp) timerDisp.innerText = `Còn: ${gridRecallSeconds}s`;

        gridRecallTimer = setInterval(() => {
          if (!isGridGameActive) {
            clearInterval(gridRecallTimer);
            gridRecallTimer = null;
            return;
          }

          gridRecallSeconds--;
          const td = document.getElementById('grid-timer-display');
          if (td) td.innerText = `Còn: ${gridRecallSeconds}s`;

          if (gridRecallSeconds <= 0) {
            clearInterval(gridRecallTimer);
            gridRecallTimer = null;
            showMemoryGameOver('timeout');
          }
        }, 1000);

        for (let i = 0; i < totalCells; i++) {
          const el = document.getElementById(`grid-cell-${i}`);
          if (el) {
            el.className = `${cellSizeClass} rounded-xl bg-slate-100 border border-slate-300 cursor-pointer active:scale-95 transition-all flex items-center justify-center hover:bg-slate-200`;
            el.innerText = '';
            el.onclick = () => selectGridCell(i, totalCells);
          }
        }
      }, flashTimeMs);
    }

    function selectGridCell(index, totalCells) {
      if (!isGridGameActive) return;
      if (userSelectedCells.includes(index)) return;
      userSelectedCells.push(index);
      const el = document.getElementById(`grid-cell-${index}`);
      
      if (trapCells.includes(index)) {
        if (gridRecallTimer) {
          clearInterval(gridRecallTimer);
          gridRecallTimer = null;
        }
        if (el) {
          el.className = 'rounded-xl bg-rose-600 text-white font-black flex items-center justify-center animate-ping';
          el.innerText = '💥';
        }
        gridFeedbackTimeout = setTimeout(() => {
          showMemoryGameOver('bomb');
        }, 400);
        return;
      }

      if (targetCells.includes(index)) {
        if (el) {
          el.className = 'rounded-xl bg-blue-600 text-white shadow-md flex items-center justify-center font-black';
          el.innerText = '✓';
        }
        if (userSelectedCells.length === targetCells.length) {
          if (gridRecallTimer) {
            clearInterval(gridRecallTimer);
            gridRecallTimer = null;
          }
          if (gridLevel >= 6) {
            // Thắng toàn bộ 6 vòng
            isGridGameActive = false;
            consumeOneGymPlay();
            APP_STATE.bfsScore += 35;
            APP_STATE.rankPoints += 15;
            APP_STATE.gymCompletedCount++;
            updateStatsUI();
            saveAppStateToLocal();
            renderLeaderboard();
            updateDailyGymUI();

            const { totalAvailable } = getGymRemainingPlays();

            document.getElementById('game-dynamic-area').innerHTML = `
              <div class="text-center space-y-3 py-4 max-w-md mx-auto">
                <span class="text-3xl">👑</span>
                <h3 class="text-base font-bold text-slate-900">CHINH PHỤC TOÀN BỘ 6 CẤP ĐỘ!</h3>
                <p class="text-xs text-slate-600">Bạn đã vượt qua xuất sắc cả 6 ma trận nơ-ron và vô hiệu hóa toàn bộ bẫy xao nhãng.</p>

                <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1.5">
                  <div class="flex items-center justify-between text-slate-700">
                    <span>Thưởng năng lực não (BFS):</span>
                    <span class="font-semibold text-blue-700">+35 BFS</span>
                  </div>
                  <div class="flex items-center justify-between text-slate-700">
                    <span>Thưởng điểm xếp hạng:</span>
                    <span class="font-semibold text-slate-900">+15 Rank</span>
                  </div>
                  <div class="pt-1 border-t border-slate-200 flex items-center justify-between font-bold text-slate-900">
                    <span>Tổng điểm nhận được:</span>
                    <span class="text-blue-600">+50 điểm (Tối đa)</span>
                  </div>
                </div>

                <div class="text-[11px] text-slate-500">
                  Tiêu hao: <span class="font-semibold text-slate-700">-1 lượt chơi</span> • Còn lại: <strong class="text-slate-900">${totalAvailable} lượt</strong>
                </div>

                <div class="pt-2 flex items-center justify-center gap-2">
                  ${totalAvailable > 0 
                    ? `<button onclick="startMemoryGridGame()" class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">🔄 Lượt tiếp theo (-1 Lượt)</button>` 
                    : `<button onclick="openGymShopModal()" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">🛒 Mua thêm lượt (35đ)</button>`}
                  <button onclick="closeGameContainer()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-xl border border-slate-200 transition-colors">✕ Về phòng Gym</button>
                </div>
              </div>
            `;
          } else {
            gridLevel++;
            gridFeedbackTimeout = setTimeout(renderMemoryGridRound, 500);
          }
        }
      } else {
        if (gridRecallTimer) {
          clearInterval(gridRecallTimer);
          gridRecallTimer = null;
        }
        if (el) {
          el.className = 'rounded-xl bg-rose-500 text-white font-bold flex items-center justify-center';
          el.innerText = '✕';
        }
        gridFeedbackTimeout = setTimeout(() => {
          showMemoryGameOver('wrong');
        }, 400);
      }
    }

    // GIAO DIỆN DỪNG VÀ BÁO KẾT QUẢ: CƠ CHẾ THƯỞNG PHẠT CÔNG BẰNG THEO VÒNG ĐÃ VƯỢT QUA
    function showMemoryGameOver(reason) {
      if (!isGridGameActive) return;
      isGridGameActive = false;
      if (gridRecallTimer) {
        clearInterval(gridRecallTimer);
        gridRecallTimer = null;
      }
      if (gridFlashTimeout) {
        clearTimeout(gridFlashTimeout);
        gridFlashTimeout = null;
      }

      // 1. Phạt trừ 1 lượt chơi
      consumeOneGymPlay();

      // 2. Thưởng điểm công bằng theo số vòng đã vượt qua:
      // Thắng 0 vòng (thua ở vòng 1): 0đ (Thất bại sớm, phạt mất lượt chơi)
      // Thắng 1 vòng (thua ở vòng 2): +5 BFS, +2 Rank (Tổng 7đ)
      // Thắng 2 vòng (thua ở vòng 3): +10 BFS, +5 Rank (Tổng 15đ)
      // Thắng 3 vòng (thua ở vòng 4): +18 BFS, +7 Rank (Tổng 25đ)
      // Thắng 4 vòng (thua ở vòng 5): +25 BFS, +10 Rank (Tổng 35đ)
      // Thắng 5 vòng (thua ở vòng 6): +30 BFS, +12 Rank (Tổng 42đ)
      const wonRounds = Math.max(0, gridLevel - 1);
      const MEMORY_REWARDS = [
        { bfs: 0, rank: 0 },
        { bfs: 5, rank: 2 },
        { bfs: 10, rank: 5 },
        { bfs: 18, rank: 7 },
        { bfs: 25, rank: 10 },
        { bfs: 30, rank: 12 },
        { bfs: 35, rank: 15 }
      ];
      const reward = MEMORY_REWARDS[wonRounds] || { bfs: 0, rank: 0 };
      const totalEarned = reward.bfs + reward.rank;

      if (totalEarned > 0) {
        APP_STATE.bfsScore += reward.bfs;
        APP_STATE.rankPoints += reward.rank;
      }
      APP_STATE.gymCompletedCount++;
      saveAppStateToLocal();
      updateStatsUI();
      renderLeaderboard();
      updateDailyGymUI();

      const { totalAvailable } = getGymRemainingPlays();

      let icon = '⏰';
      let title = 'HẾT THỜI GIAN GHI NHỚ';
      let desc = 'Thời gian ghi nhớ của cấp độ này đã kết thúc. Vùng nhớ làm việc tạm thời bão hòa.';

      if (reason === 'bomb') {
        icon = '💥';
        title = 'CHẠM PHẢI Ô BẪY XAO NHÃNG';
        desc = 'Bạn đã kích hoạt trúng ô bẫy làm gián đoạn chuỗi liên kết ghi nhớ của vỏ não.';
      } else if (reason === 'wrong') {
        icon = '✕';
        title = 'CHỌN CHƯA CHÍNH XÁC';
        desc = 'Bạn đã chạm nhầm ô không phát sáng. Hãy quan sát thật kỹ các vị trí kích hoạt ở lượt tiếp theo.';
      }

      const area = document.getElementById('game-dynamic-area');
      if (!area) return;

      area.innerHTML = `
        <div class="space-y-3 text-center py-4 max-w-md mx-auto">
          <span class="text-3xl">${icon}</span>
          <div>
            <h3 class="font-bold text-base text-slate-900">${title}</h3>
            <p class="text-xs text-slate-500 mt-1 leading-relaxed">
              ${desc}
            </p>
          </div>

          <!-- Thông tin số vòng thắng và điểm cộng -->
          <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1.5 text-left">
            <div class="flex items-center justify-between text-slate-700">
              <span>Tiến độ vượt ải:</span>
              <span class="font-semibold text-slate-900">Thắng ${wonRounds}/6 vòng (Dừng ở vòng ${gridLevel})</span>
            </div>
            ${totalEarned > 0 ? `
              <div class="flex items-center justify-between text-slate-700">
                <span>Thưởng năng lực não (BFS):</span>
                <span class="font-semibold text-blue-700">+${reward.bfs} BFS</span>
              </div>
              <div class="flex items-center justify-between text-slate-700">
                <span>Thưởng điểm xếp hạng:</span>
                <span class="font-semibold text-slate-900">+${reward.rank} Rank</span>
              </div>
              <div class="pt-1 border-t border-slate-200 flex items-center justify-between font-bold text-slate-900">
                <span>Tổng điểm nhận được:</span>
                <span class="text-blue-600">+${totalEarned} điểm</span>
              </div>
            ` : `
              <div class="text-rose-600 font-medium py-1 text-center">
                ⚠️ Dừng ngay ở vòng 1: Chưa vượt ngưỡng tích lũy để nhận điểm thưởng.
              </div>
            `}
          </div>

          <div class="text-[11px] text-slate-500">
            Tiêu hao: <span class="font-semibold text-slate-700">-1 lượt chơi</span> • Còn lại: <strong class="text-slate-900">${totalAvailable} lượt</strong>
          </div>

          <div class="flex items-center justify-center gap-2 pt-2">
            ${totalAvailable > 0 ? `
              <button onclick="startMemoryGridGame()" class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1.5">
                <span>🔄</span> <span>Lượt tiếp theo (-1 Lượt)</span>
              </button>
            ` : `
              <button onclick="openGymShopModal()" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1.5">
                <span>🛒</span> <span>Mua thêm lượt (35đ)</span>
              </button>
            `}
            <button onclick="closeGameContainer()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-xl border border-slate-200 transition-colors flex items-center gap-1.5">
              <span>✕</span> <span>Về phòng Gym</span>
            </button>
          </div>
        </div>
      `;
    }

    // ---------------- GAME 3: TÍNH NHẨM ĐA BIỂU THỨC (Complex Arithmetic & Dynamic Time) ----------------
    let mathScore = 0;
    let mathTimeRemaining = 20; // Khởi đầu 20s cho người chơi dễ tính hơn
    let mathInterval = null;
    let mathStreak = 0;
    let mathCorrectCount = 0;
    let isMathGameActive = false;
    let currentMathType = 'tf'; // 'tf' (đúng/sai) hoặc 'mc' (tự tính đáp án)
    let currentMathAnswer = true;
    let currentExactMathAnswer = 0;
    let isMathHandlingAnswer = false;

    function startRapidMathGame() {
      if (isGymDailyLimitReached()) {
        promptGymOutOfPlays();
        return;
      }

      mathScore = 0;
      mathStreak = 0;
      mathCorrectCount = 0;
      isMathGameActive = true;
      mathTimeRemaining = 20; // 20s theo yêu cầu
      isMathHandlingAnswer = false;
      if (mathInterval) {
        clearInterval(mathInterval);
        mathInterval = null;
      }

      const titleEl = document.getElementById('active-game-title');
      if (titleEl) titleEl.innerText = "TÍNH NHẨM ĐA BIỂU THỨC (PHẢN XẠ NHẬN THỨC)";

      const container = document.getElementById('active-game-container');
      container.classList.remove('hidden');
      container.scrollIntoView({ behavior: 'smooth', block: 'start' });
      
      mathInterval = setInterval(() => {
        mathTimeRemaining--;
        const timeEl = document.getElementById('math-time-display');
        if (timeEl) timeEl.innerText = `${mathTimeRemaining}s`;
        if (mathTimeRemaining <= 0) {
          clearInterval(mathInterval);
          mathInterval = null;
          finishRapidMath();
        }
      }, 1000);

      renderNextMathProblem();
    }

    function renderNextMathProblem() {
      isMathHandlingAnswer = false;
      const templates = [
        () => {
          const a = Math.floor(Math.random() * 12) + 5;
          const b = Math.floor(Math.random() * 7) + 3;
          const c = Math.floor(Math.random() * 30) + 10;
          const exact = (a * b) - c;
          return { exprStr: `(${a} × ${b}) - ${c}`, exact };
        },
        () => {
          const b = Math.floor(Math.random() * 7) + 3;
          const c = Math.floor(Math.random() * 7) + 3;
          const a = (b * c) + Math.floor(Math.random() * 35) + 10;
          const exact = a - (b * c);
          return { exprStr: `${a} - (${b} × ${c})`, exact };
        },
        () => {
          const b = Math.floor(Math.random() * 5) + 3;
          const quotient = Math.floor(Math.random() * 8) + 3;
          const a = b * quotient;
          const c = Math.floor(Math.random() * 5) + 3;
          const d = Math.floor(Math.random() * 25) + 10;
          const exact = (a / b) * c + d;
          return { exprStr: `(${a} ÷ ${b}) × ${c} + ${d}`, exact };
        },
        () => {
          const a = Math.floor(Math.random() * 15) + 8;
          const b = Math.floor(Math.random() * 15) + 8;
          const mult = Math.floor(Math.random() * 3) + 2;
          const c = Math.floor(Math.random() * 30) + 10;
          const exact = (a + b) * mult - c;
          return { exprStr: `(${a} + ${b}) × ${mult} - ${c}`, exact };
        }
      ];

      const chosenGen = templates[Math.floor(Math.random() * templates.length)];
      const prob = chosenGen();
      currentExactMathAnswer = prob.exact;

      // Chèn ngẫu nhiên các câu hỏi tự tính đáp án (50% tỷ lệ)
      const isSelfCalc = Math.random() > 0.45;
      currentMathType = isSelfCalc ? 'mc' : 'tf';

      if (currentMathType === 'tf') {
        const isCorrect = Math.random() > 0.5;
        const delta = (Math.random() > 0.5 ? 1 : -1) * (Math.floor(Math.random() * 4) + 1);
        const shown = isCorrect ? prob.exact : prob.exact + delta;
        currentMathAnswer = isCorrect;

        document.getElementById('game-dynamic-area').innerHTML = `
          <div class="space-y-4 text-center">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-1.5">
                <span class="text-xs font-black text-rose-500 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-lg" id="math-time-display">${mathTimeRemaining}s</span>
                <span class="text-[10px] text-slate-500 font-bold">(Đúng +2s | Sai -3s)</span>
              </div>
              <span class="text-xs font-black text-amber-600">Điểm: ${mathScore} ${mathStreak > 1 ? `(🔥x${mathStreak})` : ''}</span>
              <button onclick="closeGameContainer()" class="px-2.5 py-1 rounded-lg text-rose-600 hover:bg-rose-50 text-xs font-bold border border-rose-200 flex items-center gap-1">
                <span>✕</span> <span>Thoát</span>
              </button>
            </div>

            <div class="flex items-center justify-center">
              <span class="text-[10px] uppercase font-bold tracking-wider bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full border border-slate-200">
                Dạng 1: Kiểm Tra Đúng / Sai
              </span>
            </div>

            <p class="text-xs text-slate-700 font-semibold">Phép tính phức hợp sau Đúng hay Sai?</p>
            
            <div class="py-5 my-1 bg-slate-50 border border-slate-200 rounded-2xl shadow-xs">
              <span class="text-2xl sm:text-3xl font-black text-slate-900 tracking-wide">${prob.exprStr} = ${shown}</span>
            </div>

            <div class="flex gap-3 justify-center">
              <button onclick="submitMathChoice(true)" class="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-base rounded-2xl active:scale-95 transition-all shadow-md">
                ✓ ĐÚNG (+2s)
              </button>
              <button onclick="submitMathChoice(false)" class="flex-1 py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-base rounded-2xl active:scale-95 transition-all shadow-md">
                ✕ SAI (+2s)
              </button>
            </div>
          </div>
        `;
      } else {
        // Dạng 2: Tự tính đáp án chính xác (chọn trong 4 phương án)
        const deltas = [-4, -3, -2, -1, 1, 2, 3, 4, 5, -5];
        deltas.sort(() => Math.random() - 0.5);
        const choices = [prob.exact];
        for (const d of deltas) {
          const val = prob.exact + d;
          if (!choices.includes(val)) {
            choices.push(val);
          }
          if (choices.length === 4) break;
        }
        choices.sort(() => Math.random() - 0.5);

        document.getElementById('game-dynamic-area').innerHTML = `
          <div class="space-y-4 text-center">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-1.5">
                <span class="text-xs font-black text-rose-500 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-lg" id="math-time-display">${mathTimeRemaining}s</span>
                <span class="text-[10px] text-slate-500 font-bold">(Đúng +2s | Sai -3s)</span>
              </div>
              <span class="text-xs font-black text-amber-600">Điểm: ${mathScore} ${mathStreak > 1 ? `(🔥x${mathStreak})` : ''}</span>
              <button onclick="closeGameContainer()" class="px-2.5 py-1 rounded-lg text-rose-600 hover:bg-rose-50 text-xs font-bold border border-rose-200 flex items-center gap-1">
                <span>✕</span> <span>Thoát</span>
              </button>
            </div>

            <div class="flex items-center justify-center">
              <span class="text-[10px] uppercase font-black tracking-wider bg-gradient-to-r from-amber-500 to-orange-500 text-white px-3 py-0.5 rounded-full shadow-xs animate-pulse">
                ⚡ TỰ TÍNH ĐÁP ÁN
              </span>
            </div>

            <p class="text-xs text-slate-700 font-semibold">Tự tính nhẩm và chọn kết quả chính xác của biểu thức:</p>
            
            <div class="py-5 my-1 bg-slate-50 border border-slate-200 rounded-2xl shadow-xs">
              <span class="text-2xl sm:text-3xl font-black text-slate-900 tracking-wide">${prob.exprStr} = <span class="text-blue-600 font-black">?</span></span>
            </div>

            <div class="grid grid-cols-2 gap-2.5 max-w-sm mx-auto">
              ${choices.map(c => `
                <button onclick="submitMathExactChoice(${c}, ${prob.exact})" id="math-choice-btn-${c}" class="py-3 px-4 rounded-xl bg-white hover:bg-slate-50 text-slate-900 font-bold text-lg border border-slate-200 active:scale-95 transition-all shadow-xs hover:border-blue-400">
                  ${c}
                </button>
              `).join('')}
            </div>
          </div>
        `;
      }
    }

    function submitMathChoice(userChoice) {
      if (isMathHandlingAnswer) return;
      isMathHandlingAnswer = true;

      if (userChoice === currentMathAnswer) {
        mathStreak++;
        mathCorrectCount++;
        const pts = mathStreak >= 3 ? 20 : 15;
        mathScore += pts;
        mathTimeRemaining = Math.min(45, mathTimeRemaining + 2);
      } else {
        mathStreak = 0;
        mathTimeRemaining = Math.max(0, mathTimeRemaining - 3);
      }
      
      const timeEl = document.getElementById('math-time-display');
      if (timeEl) timeEl.innerText = `${mathTimeRemaining}s`;

      if (mathTimeRemaining <= 0) {
        if (mathInterval) {
          clearInterval(mathInterval);
          mathInterval = null;
        }
        finishRapidMath();
      } else {
        setTimeout(renderNextMathProblem, 300);
      }
    }

    function submitMathExactChoice(chosenVal, exactVal) {
      if (isMathHandlingAnswer) return;
      isMathHandlingAnswer = true;

      const chosenBtn = document.getElementById(`math-choice-btn-${chosenVal}`);
      const exactBtn = document.getElementById(`math-choice-btn-${exactVal}`);

      if (chosenVal === exactVal) {
        mathStreak++;
        mathCorrectCount++;
        const pts = mathStreak >= 3 ? 25 : 20;
        mathScore += pts;
        mathTimeRemaining = Math.min(45, mathTimeRemaining + 2);
        if (chosenBtn) {
          chosenBtn.className = "py-3 px-4 rounded-xl bg-emerald-600 text-white font-bold text-base shadow-xs scale-105 transition-all";
        }
      } else {
        mathStreak = 0;
        mathTimeRemaining = Math.max(0, mathTimeRemaining - 3);
        if (chosenBtn) {
          chosenBtn.className = "py-3 px-4 rounded-xl bg-rose-600 text-white font-bold text-base shadow-xs";
        }
        if (exactBtn) {
          exactBtn.className = "py-3 px-4 rounded-xl bg-emerald-600 text-white font-bold text-base shadow-xs scale-105 transition-all";
        }
      }
      
      const timeEl = document.getElementById('math-time-display');
      if (timeEl) timeEl.innerText = `${mathTimeRemaining}s`;

      if (mathTimeRemaining <= 0) {
        if (mathInterval) {
          clearInterval(mathInterval);
          mathInterval = null;
        }
        setTimeout(finishRapidMath, 450);
      } else {
        setTimeout(renderNextMathProblem, 400);
      }
    }

    function finishRapidMath() {
      if (!isMathGameActive) return;
      isMathGameActive = false;
      if (mathInterval) {
        clearInterval(mathInterval);
        mathInterval = null;
      }
      isMathHandlingAnswer = false;

      // Tiêu hao 1 lượt chơi (Thắng hay thua đều mất 1 lượt)
      consumeOneGymPlay();

      // Cơ chế tính điểm công bằng & thưởng phạt rõ ràng (Tính nhẩm phản xạ):
      // - Dưới 3 câu đúng (<= 2 câu) hoặc điểm phản xạ < 30: Thất bại sớm. Phạt: Tiêu hao 1 lượt chơi, nhận 0 điểm thưởng.
      // - 3-4 câu đúng: Đạt mức Cơ bản -> Thưởng: +10 BFS, +3 Rank (Tổng 13đ)
      // - 5-7 câu đúng: Đạt mức Khá -> Thưởng: +18 BFS, +6 Rank (Tổng 24đ)
      // - 8-10 câu đúng: Đạt mức Tốt -> Thưởng: +25 BFS, +9 Rank (Tổng 34đ)
      // - 11-13 câu đúng: Đạt mức Xuất sắc -> Thưởng: +30 BFS, +12 Rank (Tổng 42đ)
      // - 14+ câu đúng: Hoàn hảo tuyệt đối -> Thưởng tối đa: +35 BFS, +15 Rank (Tổng 50đ)
      let earnedBfs = 0;
      let earnedRank = 0;
      let performanceLevel = 'Chưa đạt';

      if (mathCorrectCount <= 2 || mathScore < 30) {
        earnedBfs = 0;
        earnedRank = 0;
        performanceLevel = 'Cần rèn luyện thêm';
      } else if (mathCorrectCount <= 4) {
        earnedBfs = 10;
        earnedRank = 3;
        performanceLevel = 'Cơ bản';
      } else if (mathCorrectCount <= 7) {
        earnedBfs = 18;
        earnedRank = 6;
        performanceLevel = 'Khá';
      } else if (mathCorrectCount <= 10) {
        earnedBfs = 25;
        earnedRank = 9;
        performanceLevel = 'Tốt';
      } else if (mathCorrectCount <= 13) {
        earnedBfs = 30;
        earnedRank = 12;
        performanceLevel = 'Xuất sắc';
      } else {
        earnedBfs = 35;
        earnedRank = 15;
        performanceLevel = 'Hoàn hảo tuyệt đối';
      }

      const totalEarned = earnedBfs + earnedRank;
      if (totalEarned > 0) {
        APP_STATE.bfsScore += earnedBfs;
        APP_STATE.rankPoints += earnedRank;
      }
      APP_STATE.gymCompletedCount++;
      updateStatsUI();
      saveAppStateToLocal();
      renderLeaderboard();
      updateDailyGymUI();

      const { totalAvailable } = getGymRemainingPlays();

      document.getElementById('game-dynamic-area').innerHTML = `
        <div class="text-center space-y-3 py-4 max-w-md mx-auto">
          <span class="text-3xl">${totalEarned >= 35 ? '⚡' : (totalEarned > 0 ? '✨' : '⚠️')}</span>
          <h3 class="text-base font-bold text-slate-900">KẾT THÚC TÍNH NHẨM PHẢN XẠ</h3>
          <div class="text-xs text-slate-500">
            Chính xác: <strong class="text-slate-900">${mathCorrectCount} câu</strong> • Điểm tốc độ: <strong class="text-slate-900">${mathScore}đ</strong> • Đánh giá: <span class="font-semibold text-blue-600">${performanceLevel}</span>
          </div>

          <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1.5">
            ${totalEarned > 0 ? `
              <div class="flex items-center justify-between text-slate-700">
                <span>Thưởng năng lực não (BFS):</span>
                <span class="font-semibold text-blue-700">+${earnedBfs} BFS</span>
              </div>
              <div class="flex items-center justify-between text-slate-700">
                <span>Thưởng điểm xếp hạng:</span>
                <span class="font-semibold text-slate-900">+${earnedRank} Rank</span>
              </div>
              <div class="pt-1 border-t border-slate-200 flex items-center justify-between font-bold text-slate-900">
                <span>Tổng điểm nhận được:</span>
                <span class="text-blue-600">+${totalEarned} điểm</span>
              </div>
            ` : `
              <div class="text-rose-600 font-medium py-1">
                ⚠️ Đúng dưới 3 câu: Chưa đủ điều kiện nhận điểm thưởng ở lượt này.
              </div>
            `}
          </div>

          <div class="text-[11px] text-slate-500">
            Tiêu hao: <span class="font-semibold text-slate-700">-1 lượt chơi</span> • Còn lại: <strong class="text-slate-900">${totalAvailable} lượt</strong>
          </div>

          <div class="pt-2 flex items-center justify-center gap-2">
            ${totalAvailable > 0 
              ? `<button onclick="startRapidMathGame()" class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">🔄 Lượt tiếp theo (-1 Lượt)</button>` 
              : `<button onclick="openGymShopModal()" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">🛒 Mua thêm lượt (35đ)</button>`}
            <button onclick="closeGameContainer()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-xl border border-slate-200 transition-colors">✕ Về phòng Gym</button>
          </div>
        </div>
      `;
    }

    // DỪNG TOÀN DIỆN VÀ AN TOÀN MỌI TIẾN TRÌNH TRÒ CHƠI
    function closeGameContainer() {
      // Nếu đang trong trò chơi dở dang mà người dùng bấm Dừng/Thoát, cảnh báo bảo vệ lượt chơi
      const isAnyGameActive = isGridGameActive || isStroopGameActive || isMathGameActive;
      if (isAnyGameActive) {
        const confirmQuit = confirm("⚠️ BẠN ĐANG TRONG LƯỢT TẬP GYM!\n\nNếu dừng chơi lúc này, lượt chơi này sẽ bị tính là kết thúc và điểm sẽ chốt theo kết quả hiện tại.\n\nBạn có chắc chắn muốn dừng không?");
        if (!confirmQuit) return;

        if (isGridGameActive) {
          showMemoryGameOver('wrong');
          return;
        }
        if (isStroopGameActive) {
          finishStroopGame();
          return;
        }
        if (isMathGameActive) {
          finishRapidMath();
          return;
        }
      }

      isGridGameActive = false;
      isStroopGameActive = false;
      isMathGameActive = false;
      isStroopHandlingAnswer = false;
      isMathHandlingAnswer = false;
      if (stroopRoundTimer) {
        clearInterval(stroopRoundTimer);
        stroopRoundTimer = null;
      }
      if (stroopFeedbackTimeout) {
        clearTimeout(stroopFeedbackTimeout);
        stroopFeedbackTimeout = null;
      }
      if (gridRecallTimer) {
        clearInterval(gridRecallTimer);
        gridRecallTimer = null;
      }
      if (gridFlashTimeout) {
        clearTimeout(gridFlashTimeout);
        gridFlashTimeout = null;
      }
      if (gridFeedbackTimeout) {
        clearTimeout(gridFeedbackTimeout);
        gridFeedbackTimeout = null;
      }
      if (mathInterval) {
        clearInterval(mathInterval);
        mathInterval = null;
      }
      const container = document.getElementById('active-game-container');
      if (container) container.classList.add('hidden');
      const area = document.getElementById('game-dynamic-area');
      if (area) area.innerHTML = '';
      updateDailyGymUI();

      // Cuộn mượt màn hình lên đầu để tránh bị kẹt ở khoảng trắng phía dưới
      const mainEl = document.querySelector('main');
      if (mainEl) {
        mainEl.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }

    // ================= RENDERING LISTS =================
    function renderArticles() {
      const container = document.getElementById('article-list-container');
      container.innerHTML = ARTICLES.map(art => `
        <div class="glass-card p-5 rounded-2xl space-y-2 border-slate-200 hover:border-blue-300 transition-all shadow-sm">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-black uppercase text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">${art.tag}</span>
            <span class="text-[11px] text-slate-500 font-medium">${art.author}</span>
          </div>
          <h3 class="text-sm sm:text-base font-bold text-slate-900">${art.title}</h3>
          <p class="text-xs text-slate-600 leading-relaxed">${art.content}</p>
        </div>
      `).join('');
    }

    function renderTips(category) {
      const container = document.getElementById('tips-grid-container');
      const filtered = category === 'ALL' ? TIPS_DATA : TIPS_DATA.filter(t => t.category === category);

      document.querySelectorAll('.tip-filter-btn').forEach(b => {
        if (b.dataset.category === category) {
          b.className = 'tip-filter-btn px-3 py-1.5 rounded-xl text-xs font-bold bg-blue-600 text-white shadow-sm';
        } else {
          b.className = 'tip-filter-btn px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 border border-slate-300 text-slate-700 hover:bg-slate-200';
        }
      });

      container.innerHTML = filtered.map(tip => `
        <div class="glass-card p-4 rounded-2xl flex flex-col justify-between space-y-3 border-slate-200 shadow-xs">
          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">${tip.tag}</span>
              <span class="text-xs">⚡</span>
            </div>
            <h4 class="font-bold text-sm text-slate-900">${tip.title}</h4>
            <p class="text-xs text-slate-600 mt-1 leading-relaxed">${tip.text}</p>
          </div>
          <div class="text-[11px] text-blue-600 font-bold flex items-center justify-end gap-1">
            <span>Áp dụng ngay</span>
            <span>✓</span>
          </div>
        </div>
      `).join('');
    }

    function filterTips(cat) {
      renderTips(cat);
    }

    // ================= LEADERBOARD SEARCH & PAGINATION CONTROLLER =================
    let LEADERBOARD_PAGE_SIZE = 50;
    let LEADERBOARD_CURRENT_PAGE = 1;
    let LEADERBOARD_SEARCH_QUERY = '';

    function handleLeaderboardSearch(val) {
      LEADERBOARD_SEARCH_QUERY = (val || '').trim().toLowerCase();
      LEADERBOARD_CURRENT_PAGE = 1;
      renderLeaderboard();
    }

    function changeLeaderboardPageSize(val) {
      LEADERBOARD_PAGE_SIZE = val === 'all' ? 'all' : parseInt(val, 10);
      LEADERBOARD_CURRENT_PAGE = 1;
      renderLeaderboard();
    }

    function changeLeaderboardPage(delta) {
      LEADERBOARD_CURRENT_PAGE += delta;
      renderLeaderboard();
    }

    function scrollToMyRankInLeaderboard() {
      if (!APP_STATE.userEmail && !APP_STATE.userName) {
        alert('Bạn chưa đăng nhập tài khoản nào!');
        return;
      }
      const allUsers = getFullLeaderboard();
      const myIdx = allUsers.findIndex(u => u.isUser);
      if (myIdx === -1) {
        alert('Tài khoản của bạn chưa xuất hiện trên Bảng xếp hạng. Hãy bấm Làm mới!');
        return;
      }
      // Tính toán trang chứa tài khoản nếu đang bật phân trang
      if (LEADERBOARD_PAGE_SIZE !== 'all') {
        const targetPage = Math.floor(myIdx / LEADERBOARD_PAGE_SIZE) + 1;
        if (LEADERBOARD_CURRENT_PAGE !== targetPage) {
          LEADERBOARD_CURRENT_PAGE = targetPage;
          renderLeaderboard();
        }
      }
      setTimeout(() => {
        const userRow = document.getElementById('leaderboard-user-active-row');
        if (userRow) {
          userRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
          userRow.classList.add('ring-2', 'ring-blue-500', 'animate-pulse');
          setTimeout(() => {
            userRow.classList.remove('animate-pulse');
          }, 2000);
        } else {
          const table = document.getElementById('leaderboard-table');
          if (table) table.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }

    function renderLeaderboard() {
      const allUsers = getFullLeaderboard();
      const podiumContainer = document.getElementById('leaderboard-podium-container');
      const table = document.getElementById('leaderboard-table');
      const countText = document.getElementById('leaderboard-count-text');
      const summaryText = document.getElementById('gsheet-sync-summary-text');
      const stickyBar = document.getElementById('user-sticky-rank-bar');
      const stickyRankText = document.getElementById('user-sticky-rank-text');
      const paginationFooter = document.getElementById('leaderboard-pagination-footer');
      const pageIndicator = document.getElementById('leaderboard-page-indicator');
      const prevBtn = document.getElementById('leaderboard-prev-btn');
      const nextBtn = document.getElementById('leaderboard-next-btn');

      if (!allUsers || allUsers.length === 0) {
        if (podiumContainer) podiumContainer.innerHTML = '';
        if (countText) countText.innerText = 'Tổng: 0 học viên';
        if (stickyBar) stickyBar.classList.add('hidden');
        if (paginationFooter) paginationFooter.classList.add('hidden');
        if (table) {
          table.innerHTML = `
            <div class="p-8 text-center text-slate-500 space-y-2">
              <span class="text-4xl">🏆</span>
              <p class="text-sm font-bold text-slate-700">Chưa có dữ liệu bảng xếp hạng</p>
              <p class="text-xs text-slate-500">Hãy tạo tài khoản Gmail hoặc hoàn thành 1 phiên học sâu để ghi danh vào Top 1!</p>
              <button onclick="openRegisterModal()" class="mt-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold shadow-md">Tạo Tài Khoản (+1000đ)</button>
            </div>
          `;
        }
        return;
      }

      // Cập nhật tổng số học viên không giới hạn
      if (countText) {
        countText.innerText = `Tổng: ${allUsers.length} học viên (Không giới hạn)`;
      }
      if (summaryText) {
        summaryText.innerText = `Đang lưu trữ ${allUsers.length} học viên trên Google Sheets. Đã xóa bỏ hoàn toàn giới hạn 100 học viên cũ!`;
      }

      // Cập nhật thẻ sticky rank của tài khoản hiện tại
      const myUser = allUsers.find(u => u.isUser);
      if (myUser && stickyBar && stickyRankText) {
        stickyBar.classList.remove('hidden');
        stickyRankText.innerText = `#${myUser.rank} (${myUser.totalScore}đ) trên tổng ${allUsers.length} học viên`;
      } else if (stickyBar) {
        stickyBar.classList.add('hidden');
      }

      // Lọc danh sách theo tìm kiếm nếu có
      let displayList = allUsers;
      if (LEADERBOARD_SEARCH_QUERY) {
        displayList = allUsers.filter(u => {
          const nameMatch = (u.name || '').toLowerCase().includes(LEADERBOARD_SEARCH_QUERY);
          const emailMatch = (u.email || '').toLowerCase().includes(LEADERBOARD_SEARCH_QUERY);
          const schoolMatch = (u.school || '').toLowerCase().includes(LEADERBOARD_SEARCH_QUERY);
          return nameMatch || emailMatch || schoolMatch;
        });
        if (countText) {
          countText.innerText = `Tìm thấy: ${displayList.length} / ${allUsers.length} học viên`;
        }
      }

      // Render Podium Top 3 (chỉ hiển thị khi không tìm kiếm hoặc hiển thị top của kết quả tìm kiếm)
      const top3 = (!LEADERBOARD_SEARCH_QUERY) ? allUsers.slice(0, 3) : displayList.slice(0, 3);

      if (podiumContainer) {
        if (top3.length === 0) {
          podiumContainer.innerHTML = '';
        } else if (top3.length === 1) {
          const first = top3[0];
          podiumContainer.innerHTML = `
            <div></div>
            <!-- 1st Place Only -->
            <div class="glass-card p-3.5 rounded-2xl border-2 border-amber-400 shadow-md flex flex-col items-center text-center relative bg-gradient-to-b from-amber-50 to-white ring-2 ring-blue-500">
              <div class="w-12 h-12 rounded-full bg-amber-100 border-2 border-amber-400 flex items-center justify-center text-xl font-extrabold mb-1 shadow-sm overflow-hidden">
                ${first.avatar ? `<img src="${first.avatar}" class="w-full h-full object-cover" />` : '👑'}
              </div>
              <span class="text-xs font-black text-blue-600 truncate w-full">${first.name}</span>
              <span class="text-xs text-amber-600 font-bold">${first.totalScore}đ</span>
              <span class="text-[9px] text-slate-600 font-mono font-bold">${first.rankPoints} XH + ${first.bfs} BFS + ${first.sessionsCount} phiên (+${first.sessionPoints}đ)</span>
              <div class="h-20 w-full bg-amber-200 border border-amber-300 rounded-t-xl mt-2 flex items-center justify-center text-amber-800 font-extrabold text-base">#1</div>
            </div>
            <div></div>
          `;
        } else {
          const first = top3[0];
          const second = top3[1];
          const third = top3[2] || null;

          podiumContainer.innerHTML = `
            <!-- 2nd Place -->
            <div class="glass-card p-3 rounded-2xl flex flex-col items-center text-center border-slate-200 shadow-sm ${second && second.isUser ? 'border-2 border-blue-500 bg-blue-50/50' : ''}">
              <div class="w-10 h-10 rounded-full bg-slate-200 border-2 border-slate-400 flex items-center justify-center text-base font-extrabold mb-1 overflow-hidden">
                ${second && second.avatar ? `<img src="${second.avatar}" class="w-full h-full object-cover" />` : '🥈'}
              </div>
              <span class="text-xs font-bold ${second && second.isUser ? 'text-blue-600' : 'text-slate-900'} truncate w-full">${second ? second.name : 'Đang chờ...'}</span>
              <span class="text-[11px] text-amber-600 font-bold">${second ? second.totalScore + 'đ' : '-'}</span>
              <span class="text-[9px] text-slate-500 font-mono font-bold">${second ? `${second.rankPoints} XH + ${second.bfs} BFS + ${second.sessionsCount} phiên (+${second.sessionPoints}đ)` : ''}</span>
              <div class="h-16 w-full bg-slate-200 rounded-t-xl mt-2 flex items-center justify-center text-slate-700 font-extrabold text-sm">#2</div>
            </div>

            <!-- 1st Place -->
            <div class="glass-card p-3.5 rounded-2xl border-2 border-amber-400 shadow-md flex flex-col items-center text-center relative -top-3 bg-gradient-to-b from-amber-50 to-white ${first.isUser ? 'ring-2 ring-blue-500' : ''}">
              <div class="w-12 h-12 rounded-full bg-amber-100 border-2 border-amber-400 flex items-center justify-center text-xl font-extrabold mb-1 shadow-sm overflow-hidden">
                ${first.avatar ? `<img src="${first.avatar}" class="w-full h-full object-cover" />` : '👑'}
              </div>
              <span class="text-xs font-black ${first.isUser ? 'text-blue-600' : 'text-amber-800'} truncate w-full">${first.name}</span>
              <span class="text-xs text-amber-600 font-bold">${first.totalScore}đ</span>
              <span class="text-[9px] text-slate-600 font-mono font-bold">${first.rankPoints} XH + ${first.bfs} BFS + ${first.sessionsCount} phiên (+${first.sessionPoints}đ)</span>
              <div class="h-24 w-full bg-amber-200 border border-amber-300 rounded-t-xl mt-2 flex items-center justify-center text-amber-800 font-extrabold text-base">#1</div>
            </div>

            <!-- 3rd Place -->
            <div class="glass-card p-3 rounded-2xl flex flex-col items-center text-center border-slate-200 shadow-sm ${third && third.isUser ? 'border-2 border-blue-500 bg-blue-50/50' : ''}">
              <div class="w-10 h-10 rounded-full bg-orange-100 border-2 border-orange-400 flex items-center justify-center text-base font-extrabold mb-1 overflow-hidden">
                ${third && third.avatar ? `<img src="${third.avatar}" class="w-full h-full object-cover" />` : '🥉'}
              </div>
              <span class="text-xs font-bold ${third && third.isUser ? 'text-blue-600' : 'text-slate-900'} truncate w-full">${third ? third.name : 'Đang chờ...'}</span>
              <span class="text-[11px] text-amber-600 font-bold">${third ? third.totalScore + 'đ' : '-'}</span>
              <span class="text-[9px] text-slate-500 font-mono font-bold">${third ? `${third.rankPoints} XH + ${third.bfs} BFS + ${third.sessionsCount} phiên (+${third.sessionPoints}đ)` : ''}</span>
              <div class="h-12 w-full bg-orange-200 rounded-t-xl mt-2 flex items-center justify-center text-orange-800 font-extrabold text-sm">#3</div>
            </div>
          `;
        }
      }

      // Phân trang danh sách học viên
      // Loại bỏ top 3 nếu không tìm kiếm, hoặc hiển thị đầy đủ nếu người dùng đang tìm kiếm
      const tableUsers = (!LEADERBOARD_SEARCH_QUERY) ? displayList.slice(3) : displayList;

      if (!tableUsers || tableUsers.length === 0) {
        if (table) {
          table.innerHTML = `
            <div class="p-6 text-center text-xs text-slate-500">
              ${LEADERBOARD_SEARCH_QUERY ? 'Không tìm thấy học viên nào phù hợp với từ khóa.' : 'Chưa có thứ hạng tiếp theo. Hãy chia sẻ cho bạn bè cùng đua Top!'}
            </div>
          `;
        }
        if (paginationFooter) paginationFooter.classList.add('hidden');
        return;
      }

      const pageSize = LEADERBOARD_PAGE_SIZE === 'all' ? tableUsers.length : LEADERBOARD_PAGE_SIZE;
      const totalPages = Math.max(1, Math.ceil(tableUsers.length / pageSize));
      
      if (LEADERBOARD_CURRENT_PAGE > totalPages) LEADERBOARD_CURRENT_PAGE = totalPages;
      if (LEADERBOARD_CURRENT_PAGE < 1) LEADERBOARD_CURRENT_PAGE = 1;

      const startIndex = (LEADERBOARD_CURRENT_PAGE - 1) * pageSize;
      const paginatedUsers = tableUsers.slice(startIndex, startIndex + pageSize);

      if (table) {
        table.innerHTML = paginatedUsers.map(user => `
          <div ${user.isUser ? 'id="leaderboard-user-active-row"' : ''} class="flex items-center justify-between p-3.5 border-b border-slate-200 ${user.isUser ? 'bg-blue-50/70 border-l-4 border-l-blue-600' : 'hover:bg-slate-50'} transition-all">
            <div class="flex items-center space-x-3">
              <span class="font-bold text-xs w-7 text-slate-500">#${user.rank}</span>
              <div class="w-7 h-7 rounded-full bg-slate-200 overflow-hidden flex items-center justify-center text-xs font-bold text-slate-600 shrink-0">
                ${user.avatar ? `<img src="${user.avatar}" class="w-full h-full object-cover" />` : user.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <div class="font-bold text-xs ${user.isUser ? 'text-blue-600 font-black' : 'text-slate-800'}">${user.name}</div>
                <div class="text-[10px] text-slate-500">${user.school} • ${user.streak || '1 ngày'}</div>
              </div>
            </div>
            <div class="text-right">
              <div class="font-bold text-xs text-blue-700">Tổng: ${user.totalScore}đ</div>
              <div class="text-[10px] text-amber-600 font-medium font-mono">${user.rankPoints} XH + ${user.bfs} BFS + ${user.sessionsCount} phiên (+${user.sessionPoints}đ)</div>
            </div>
          </div>
        `).join('');
      }

      // Điều khiển phân trang
      if (paginationFooter) {
        if (LEADERBOARD_PAGE_SIZE === 'all' || totalPages <= 1) {
          paginationFooter.classList.add('hidden');
        } else {
          paginationFooter.classList.remove('hidden');
          if (pageIndicator) {
            pageIndicator.innerText = `Trang ${LEADERBOARD_CURRENT_PAGE} / ${totalPages} (${startIndex + 1} - ${Math.min(startIndex + pageSize, tableUsers.length)} trong ${tableUsers.length} học viên)`;
          }
          if (prevBtn) prevBtn.disabled = (LEADERBOARD_CURRENT_PAGE <= 1);
          if (nextBtn) nextBtn.disabled = (LEADERBOARD_CURRENT_PAGE >= totalPages);
        }
      }
    }

    function renderReminders() {
      const container = document.getElementById('reminders-list');
      container.innerHTML = APP_STATE.reminders.map(rem => `
        <div class="glass-card-light p-3 rounded-2xl flex items-center justify-between border-slate-200 shadow-xs">
          <div class="flex items-center space-x-3">
            <span class="text-base font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-xl border border-blue-200">${rem.time}</span>
            <span class="text-xs font-bold text-slate-800">${rem.title}</span>
          </div>
          <button onclick="toggleReminder(${rem.id})" class="text-xs font-bold px-2.5 py-1 rounded-lg ${rem.active ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'}">
            ${rem.active ? 'Bật' : 'Tắt'}
          </button>
        </div>
      `).join('');
    }

    function toggleReminder(id) {
      const r = APP_STATE.reminders.find(x => x.id === id);
      if (r) r.active = !r.active;
      renderReminders();
    }

    function addNewReminderPrompt() {
      const title = prompt('Nhập tên lời nhắc học tập:', 'Ca học sâu buổi chiều');
      const time = prompt('Nhập giờ nhắc (vd: 15:30):', '15:30');
      if (title && time) {
        APP_STATE.reminders.push({ id: Date.now(), title, time, active: true });
        renderReminders();
      }
    }

    function renderHistory() {
      const container = document.getElementById('session-history-list');
      if (!container) return;
      if (!Array.isArray(APP_STATE.history) || APP_STATE.history.length === 0) {
        container.innerHTML = `
          <div class="glass-card-light p-6 rounded-2xl text-center space-y-2 border-slate-200">
            <div class="text-3xl">🌱</div>
            <div class="font-bold text-xs text-slate-700">Chưa có phiên học nào được ghi nhận</div>
            <div class="text-[11px] text-slate-500 leading-relaxed">Hãy bắt đầu một phiên học để ghi lại lịch sử tập trung và tích luỹ điểm thưởng vào hồ sơ nhé!</div>
          </div>
        `;
        return;
      }

      container.innerHTML = APP_STATE.history.map(item => `
        <div class="glass-card-light p-3.5 rounded-2xl space-y-1.5 border-slate-200 shadow-xs hover:border-blue-300 transition-all">
          <div class="flex items-center justify-between">
            <span class="font-bold text-xs text-slate-900 flex items-center gap-1.5">
              <span>🎯</span>
              <span>${escapeHtml(item.subject || 'Phiên học sâu')}</span>
            </span>
            <div class="flex items-center gap-1.5">
              <span class="text-[10px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 font-bold">${item.minutes || 15} phút</span>
              <span class="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 font-extrabold font-mono">+${item.points || item.minutes || 15}đ</span>
            </div>
          </div>
          <div class="text-[11px] text-slate-600 leading-relaxed">${escapeHtml(item.note || 'Hoàn thành chu kỳ tập trung.')}</div>
          <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-100">
            <span class="font-medium">${escapeHtml(item.date || 'Hôm nay')}</span>
            <span class="font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">${escapeHtml(item.emotion || 'Tập trung cao 🚀')}</span>
          </div>
        </div>
      `).join('');
    }

    function updateStatsUI() {
      const sessionPts = getSessionPointsTotal();
      const sessCount = APP_STATE.sessionsCompletedCount || (Array.isArray(APP_STATE.history) ? APP_STATE.history.length : 0);
      const rankPts = Number(APP_STATE.rankPoints) || 1000;
      const bfsPts = Number(APP_STATE.bfsScore) || 0;
      const totalScore = rankPts + bfsPts + sessionPts;

      const headerRankEl = document.getElementById('header-rank-points');
      if (headerRankEl) headerRankEl.innerText = `${rankPts}đ`;

      const headerBfsEl = document.getElementById('header-bfs-score');
      if (headerBfsEl) headerBfsEl.innerText = bfsPts;

      const headerTotalEl = document.getElementById('header-total-score');
      if (headerTotalEl) headerTotalEl.innerText = `${totalScore}đ`;

      const statBfsEl = document.getElementById('stat-bfs-score');
      if (statBfsEl) statBfsEl.innerText = bfsPts;

      const statRankEl = document.getElementById('stat-rank-points');
      if (statRankEl) statRankEl.innerText = `${rankPts} đ`;

      const statSessionPtsEl = document.getElementById('stat-session-points');
      if (statSessionPtsEl) statSessionPtsEl.innerText = `+${sessionPts} đ`;

      const statSessionsEl = document.getElementById('stat-sessions-count');
      if (statSessionsEl) statSessionsEl.innerText = `${sessCount} phiên (+${sessionPts}đ)`;

      const statTotalEl = document.getElementById('stat-total-score');
      if (statTotalEl) statTotalEl.innerText = `${totalScore} đ`;

      const statHoursEl = document.getElementById('stat-total-hours');
      if (statHoursEl) statHoursEl.innerText = `${APP_STATE.totalHours}h tổng học`;

      const statStreakEl = document.getElementById('stat-streak-days');
      if (statStreakEl) statStreakEl.innerText = `${APP_STATE.streakDays} 🔥`;

      const headerStreakEl = document.getElementById('header-streak-badge');
      if (headerStreakEl) headerStreakEl.innerText = `${APP_STATE.streakDays || 1} Ngày Cháy Hết Mình`;

      const statGymEl = document.getElementById('stat-gym-count');
      if (statGymEl) statGymEl.innerText = APP_STATE.gymCompletedCount;

      // Cập nhật thẻ Level BFS & Lời khuyên trong Tab Profile
      const levelData = getBFSLevelDetails(bfsPts);
      const profLevelBadge = document.getElementById('profile-level-badge');
      if (profLevelBadge) {
        profLevelBadge.className = `inline-block text-xs font-bold px-3 py-0.5 rounded-full shadow-xs ${levelData.badgeClass}`;
        profLevelBadge.innerText = levelData.title;
      }
      const profLevelIcon = document.getElementById('profile-level-icon');
      if (profLevelIcon) profLevelIcon.innerText = levelData.dot;
      const profLevelPts = document.getElementById('profile-level-bfs-pts');
      if (profLevelPts) profLevelPts.innerText = bfsPts;
      const profHeadline = document.getElementById('profile-level-headline');
      if (profHeadline) profHeadline.innerText = levelData.headline;
      const profDesc = document.getElementById('profile-level-desc');
      if (profDesc) profDesc.innerText = levelData.description;
      const profRecs = document.getElementById('profile-level-recommendations');
      if (profRecs) profRecs.innerHTML = levelData.recommendations.map(r => `<li>${r}</li>`).join('');
      const profQuote = document.getElementById('profile-level-quote');
      if (profQuote) profQuote.innerText = levelData.quote;

      const userDisplayLevel = document.getElementById('user-display-level');
      if (userDisplayLevel) {
        userDisplayLevel.innerText = `Level ${levelData.level}`;
        userDisplayLevel.className = `text-[10px] px-2 py-0.5 rounded-full font-bold border ${levelData.badgeClass}`;
      }

      renderLeaderboard();
    }

    // ================= 10-QUESTION ASSESSMENT MODAL =================
    function openAssessmentModal(isRetake = false, isOnboarding = false) {
      APP_STATE.isOnboardingActive = isOnboarding;
      const modal = document.getElementById('assessment-modal');
      const closeBtn = document.getElementById('assessment-modal-close-btn');
      const skipBtn = document.getElementById('assessment-skip-btn');
      const banner = document.getElementById('assessment-onboarding-banner');
      const titleEl = document.getElementById('assessment-modal-title');
      const subtitleEl = document.getElementById('assessment-modal-subtitle');
      const userInputs = document.getElementById('assessment-user-inputs');
      const resBox = document.getElementById('assessment-result-box');
      const submitBtn = document.getElementById('assess-submit-btn');

      // Sync name & school fields
      const inputName = document.getElementById('assess-input-name');
      const inputSchool = document.getElementById('assess-input-school');
      if (inputName) inputName.value = APP_STATE.userName || '';
      if (inputSchool) inputSchool.value = APP_STATE.userSchool || '';

      if (isOnboarding) {
        if (closeBtn) closeBtn.classList.add('hidden');
        if (skipBtn) skipBtn.classList.add('hidden');
        if (banner) banner.classList.remove('hidden');
        if (userInputs) userInputs.classList.add('hidden');
        if (titleEl) titleEl.innerText = `CHÀO MỪNG ${APP_STATE.userName ? APP_STATE.userName.toUpperCase() : 'BẠN'}`;
        if (subtitleEl) subtitleEl.innerText = "Bước 2/2: Hoàn thành 10 câu hỏi để xác định chỉ số BFS não bộ";
      } else {
        if (closeBtn) closeBtn.classList.remove('hidden');
        if (skipBtn) skipBtn.classList.remove('hidden');
        if (banner) banner.classList.add('hidden');
        if (userInputs) userInputs.classList.remove('hidden');
        if (titleEl) titleEl.innerText = "BỘ CHẨN ĐOÁN CHỈ SỐ BFS & NÃO BỎNG NGÔ";
        if (subtitleEl) subtitleEl.innerText = "10 câu hỏi trắc nghiệm tâm lý - thần kinh chuẩn hóa";
      }

      if (resBox) resBox.classList.add('hidden');
      if (submitBtn) submitBtn.classList.remove('hidden');
      renderQuestions();
      modal.classList.remove('hidden');
      
      const contentEl = document.getElementById('assessment-content');
      if (contentEl) contentEl.scrollTop = 0;
    }

    function closeAssessmentModal() {
      document.getElementById('assessment-modal').classList.add('hidden');
    }

    function shuffleArray(arr) {
      const copy = [...arr];
      for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
      }
      return copy;
    }

    function markQuestionAnswered(qId) {
      const card = document.getElementById(`question-card-${qId}`);
      if (card) {
        card.classList.remove('border-rose-400', 'bg-rose-50/40');
        card.classList.add('border-emerald-300');
      }
    }

    function renderQuestions() {
      const container = document.getElementById('questions-list-container');
      const alphabet = ['A', 'B', 'C', 'D'];

      container.innerHTML = ASSESSMENT_QUESTIONS.map((q) => {
        // Đảo lộn ngẫu nhiên thứ tự các đáp án của từng câu hỏi để không theo trình tự điểm
        const shuffled = shuffleArray(q.options);
        return `
        <div id="question-card-${q.id}" class="bg-white p-4 sm:p-5 rounded-2xl space-y-3 border border-slate-200 shadow-xs transition-all duration-200 hover:border-blue-300">
          <div class="flex items-center justify-between gap-2">
            <span class="inline-block bg-blue-100 text-blue-800 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              ${q.category}
            </span>
            <span class="text-blue-600 font-bold text-xs">CÂU ${q.id} / 10</span>
          </div>
          <p class="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
            ${q.question}
          </p>
          <div class="space-y-2 pt-1">
            ${shuffled.map((opt, optIdx) => `
              <label class="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 cursor-pointer transition-all active:scale-[0.99] group">
                <input type="radio" name="question_${q.id}" value="${opt.score}" onchange="markQuestionAnswered(${q.id})" class="accent-blue-600 w-4 h-4 mt-0.5 shrink-0 cursor-pointer">
                <div class="flex items-start gap-2">
                  <span class="font-bold text-xs text-blue-700 bg-blue-50 group-hover:bg-blue-100 border border-blue-200 px-1.5 py-0.5 rounded-md shrink-0">
                    ${alphabet[optIdx] || (optIdx + 1)}
                  </span>
                  <span class="text-xs text-slate-800 font-medium leading-relaxed">${opt.text}</span>
                </div>
              </label>
            `).join('')}
          </div>
        </div>
        `;
      }).join('');
    }

    function calculateAndSaveAssessment() {
      // Kiểm tra xem đã trả lời đầy đủ 10 câu hỏi chưa
      const missingQuestions = [];
      let totalScore = 0;

      for (let i = 1; i <= 10; i++) {
        const radios = document.getElementsByName(`question_${i}`);
        let answered = false;
        for (const r of radios) {
          if (r.checked) {
            totalScore += parseInt(r.value, 10);
            answered = true;
            break;
          }
        }
        if (!answered) {
          missingQuestions.push(i);
        }
      }

      if (missingQuestions.length > 0) {
        missingQuestions.forEach(id => {
          const card = document.getElementById(`question-card-${id}`);
          if (card) {
            card.classList.add('border-rose-400', 'bg-rose-50/40');
          }
        });

        const firstCard = document.getElementById(`question-card-${missingQuestions[0]}`);
        if (firstCard) {
          firstCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        alert(`⚠️ BẠN CHƯA HOÀN THÀNH ĐỦ 10 CÂU HỎI!\n\nBạn còn thiếu câu số: ${missingQuestions.join(', ')}.\n\nVì các đáp án đã được xáo trộn ngẫu nhiên, vui lòng đọc kỹ từng câu và chọn đáp án trước khi nộp bài!`);
        return;
      }

      // Total score from 10 questions ranges from 100 to 1000
      const calculatedBFS = Math.min(1000, Math.max(100, totalScore));
      APP_STATE.bfsScore = calculatedBFS;
      
      if (!APP_STATE.isOnboardingActive) {
        const name = document.getElementById('assess-input-name').value || APP_STATE.userName;
        const school = document.getElementById('assess-input-school').value || APP_STATE.userSchool;
        APP_STATE.userName = name;
        APP_STATE.userSchool = school;
      }

      // Mark onboarding as complete and persist
      try {
        localStorage.setItem('bf_onboarded_completed', 'true');
      } catch (e) {}

      saveAppStateToLocal();
      syncCurrentUserToDatabase();
      syncProfileDOM();
      updateStatsUI();
      renderLeaderboard();

      const resBox = document.getElementById('assessment-result-box');
      resBox.classList.remove('hidden');
      document.getElementById('result-bfs-number').innerText = `${calculatedBFS} / 1000`;
      
      const levelData = getBFSLevelDetails(calculatedBFS);

      const badgeEl = document.getElementById('result-bfs-level-badge');
      if (badgeEl) {
        badgeEl.className = `inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold shadow-xs ${levelData.badgeClass}`;
        badgeEl.innerHTML = `<span>${levelData.dot}</span> <span>${levelData.title}</span>`;
      }

      const headlineEl = document.getElementById('result-bfs-headline');
      if (headlineEl) headlineEl.innerText = levelData.headline;

      const descEl = document.getElementById('result-bfs-desc');
      if (descEl) descEl.innerText = levelData.description;

      const recsEl = document.getElementById('result-bfs-recommendations');
      if (recsEl) {
        recsEl.innerHTML = levelData.recommendations.map(r => `<li>${r}</li>`).join('');
      }

      const quoteEl = document.getElementById('result-bfs-quote');
      if (quoteEl) quoteEl.innerText = levelData.quote;

      document.getElementById('assess-submit-btn').classList.add('hidden');

      // Scroll smoothly down to result
      const contentEl = document.getElementById('assessment-content');
      if (contentEl) {
        contentEl.scrollTo({ top: contentEl.scrollHeight, behavior: 'smooth' });
      }
    }

    function finishOnboardingAndEnterApp() {
      closeAssessmentModal();
      switchTab('leaderboard');
      alert(`🎉 Chúc mừng ${APP_STATE.userName}! Hồ sơ của bạn đã sẵn sàng với 1000đ Xếp Hạng + ${APP_STATE.bfsScore}đ BFS (Tổng ${1000 + APP_STATE.bfsScore}đ). Vị trí của bạn đã hiển thị trên Bảng Xếp Hạng!`);
    }

    // ================= REFLECTION MODAL =================
    function openReflectionModal() {
      // Chỉ cho phép mở modal khi có một phiên học vừa hoàn thành thực tế và chưa đúc kết
      if (!APP_STATE.pendingReflectionSessionId) {
        return;
      }
      const noteInput = document.getElementById('reflection-note-input');
      if (noteInput) noteInput.value = '';
      selectEmotion('Tập trung cao 🚀');
      const modal = document.getElementById('reflection-modal');
      if (modal) modal.classList.remove('hidden');
    }

    function closeReflectionModal() {
      // Khi bấm bỏ qua hoặc đóng, hủy quyền nhận điểm của phiên này để chống spam
      APP_STATE.pendingReflectionSessionId = null;
      const modal = document.getElementById('reflection-modal');
      if (modal) modal.classList.add('hidden');
    }

    function selectEmotion(em) {
      APP_STATE.selectedEmotion = em;
      document.querySelectorAll('.emotion-btn').forEach(btn => {
        if (btn.innerText.includes(em.slice(0, 3))) {
          btn.className = 'emotion-btn flex-1 py-2 rounded-xl bg-blue-600 text-white border border-blue-600 text-xs font-black shadow-sm';
        } else {
          btn.className = 'emotion-btn flex-1 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:border-blue-500 bg-slate-50';
        }
      });
    }

    function saveSessionReflection() {
      // Chống hack/spam: Bắt buộc phải có đúng phiên học vừa hoàn thành
      if (!APP_STATE.pendingReflectionSessionId) {
        alert('⚠️ Bạn chỉ có thể đánh giá đúc kết ngay khi vừa hoàn thành 1 phiên học thực tế!');
        closeReflectionModal();
        return;
      }

      const targetSession = Array.isArray(APP_STATE.history)
        ? APP_STATE.history.find(s => s.id === APP_STATE.pendingReflectionSessionId)
        : null;

      if (!targetSession) {
        alert('⚠️ Không tìm thấy phiên học hợp lệ để lưu đúc kết.');
        closeReflectionModal();
        return;
      }

      if (targetSession.hasReflected) {
        alert('⚠️ Phiên học này đã nhận điểm thưởng đúc kết trước đó. Mỗi phiên chỉ được nhận thưởng 1 lần duy nhất!');
        closeReflectionModal();
        return;
      }

      const noteInput = document.getElementById('reflection-note-input');
      const note = (noteInput && noteInput.value.trim()) || "Đã hoàn thành phiên tập trung cao độ và củng cố synap thần kinh.";
      const emotion = APP_STATE.selectedEmotion || "Tập trung cao 🚀";

      // Khóa phiên học và hủy token pending ngay lập tức
      targetSession.note = note;
      targetSession.emotion = emotion;
      targetSession.hasReflected = true;
      APP_STATE.pendingReflectionSessionId = null;

      // Thưởng duy nhất +25 BFS củng cố trí nhớ vào hồ sơ
      APP_STATE.bfsScore = (APP_STATE.bfsScore || 0) + 25;

      saveAppStateToLocal();
      syncCurrentUserToDatabase();
      updateStatsUI();
      renderLeaderboard();
      renderHistory();
      closeReflectionModal();

      if (noteInput) noteInput.value = '';

      alert('🌟 ĐÃ LƯU ĐÚC KẾT THÀNH CÔNG!\n\n+25 điểm BFS củng cố hồi hải mã đã được cộng vào hồ sơ của bạn!');
    }

    // ================= ACCOUNT & PROFILE MANAGEMENT =================
    function saveAppStateToLocal() {
      try {
        localStorage.setItem('bf_user_profile', JSON.stringify({
          userEmail: APP_STATE.userEmail,
          userName: APP_STATE.userName,
          userSchool: APP_STATE.userSchool,
          userAvatar: APP_STATE.userAvatar,
          userPassword: APP_STATE.userPassword || '',
          rankPoints: APP_STATE.rankPoints,
          bfsScore: APP_STATE.bfsScore,
          purchasedGymPlays: Math.max(0, Number(APP_STATE.purchasedGymPlays) || 0),
          totalHours: APP_STATE.totalHours,
          streakDays: APP_STATE.streakDays,
          sessionsCompletedCount: APP_STATE.sessionsCompletedCount || (Array.isArray(APP_STATE.history) ? APP_STATE.history.length : 0),
          gymCompletedCount: APP_STATE.gymCompletedCount,
          history: APP_STATE.history
        }));

        if (APP_STATE.dailyTracker) {
          localStorage.setItem('bf_daily_tracker', JSON.stringify(APP_STATE.dailyTracker));
        }

        if (APP_STATE.dailyGymTracker) {
          localStorage.setItem('bf_daily_gym_tracker', JSON.stringify(APP_STATE.dailyGymTracker));
        }
        // Tự động đồng bộ vào database danh sách người dùng để BXH luôn đầy đủ
        syncCurrentUserToDatabase();
      } catch (e) {}
    }

    function loadAppStateFromLocal() {
      try {
        const saved = localStorage.getItem('bf_user_profile');
        if (saved) {
          const data = JSON.parse(saved);
          if (data.userEmail) APP_STATE.userEmail = data.userEmail;
          if (data.userName) APP_STATE.userName = data.userName;
          if (data.userSchool) APP_STATE.userSchool = data.userSchool;
          if (data.userAvatar !== undefined) APP_STATE.userAvatar = data.userAvatar;
          if (data.userPassword !== undefined) APP_STATE.userPassword = data.userPassword;
          if (data.rankPoints !== undefined) APP_STATE.rankPoints = Number(data.rankPoints) || 1000;
          if (data.bfsScore !== undefined) APP_STATE.bfsScore = Number(data.bfsScore) || 0;
          if (data.purchasedGymPlays !== undefined) APP_STATE.purchasedGymPlays = Math.max(0, Number(data.purchasedGymPlays) || 0);
          if (data.totalHours !== undefined) APP_STATE.totalHours = Number(data.totalHours) || 0;
          if (data.streakDays !== undefined) APP_STATE.streakDays = Number(data.streakDays) || 1;
          if (data.sessionsCompletedCount !== undefined) APP_STATE.sessionsCompletedCount = Number(data.sessionsCompletedCount) || 0;
          if (data.gymCompletedCount !== undefined) APP_STATE.gymCompletedCount = Number(data.gymCompletedCount) || 0;
          if (data.history && Array.isArray(data.history)) APP_STATE.history = data.history;
        }

        const savedTracker = localStorage.getItem('bf_daily_tracker');
        if (savedTracker) {
          APP_STATE.dailyTracker = JSON.parse(savedTracker);
        }

        const savedGymTracker = localStorage.getItem('bf_daily_gym_tracker');
        if (savedGymTracker) {
          APP_STATE.dailyGymTracker = JSON.parse(savedGymTracker);
        }
      } catch (e) {}
    }

    function syncProfileDOM() {
      const hasAccount = Boolean(APP_STATE.userEmail && APP_STATE.userName);
      const initial = hasAccount ? APP_STATE.userName.charAt(0).toUpperCase() : '👤';
      
      // Update Header Avatar & Name
      const headerInitialEl = document.getElementById('header-avatar-initial');
      const headerImgEl = document.getElementById('header-avatar-img');
      const headerNameEl = document.getElementById('header-account-name');

      if (headerNameEl) {
        headerNameEl.innerText = hasAccount ? APP_STATE.userName : 'Tài khoản';
      }

      if (headerInitialEl && headerImgEl) {
        if (APP_STATE.userAvatar) {
          headerImgEl.src = APP_STATE.userAvatar;
          headerImgEl.classList.remove('hidden');
          headerInitialEl.classList.add('hidden');
        } else {
          headerInitialEl.innerText = initial;
          headerInitialEl.classList.remove('hidden');
          headerImgEl.classList.add('hidden');
        }
      }

      // Update Profile Tab Info
      const profileNameEl = document.getElementById('user-display-name');
      if (profileNameEl) profileNameEl.innerText = hasAccount ? APP_STATE.userName : 'Chưa đăng ký';

      const profileSchoolEl = document.getElementById('user-display-school');
      if (profileSchoolEl) profileSchoolEl.innerText = APP_STATE.userSchool || (hasAccount ? 'Người học tập trung' : 'Tạo tài khoản để đồng bộ điểm và đua Top');

      const profileEmailEl = document.getElementById('user-display-email');
      const authBadgeEl = document.getElementById('user-auth-badge');
      if (profileEmailEl) {
        profileEmailEl.innerText = hasAccount ? APP_STATE.userEmail : 'Chưa liên kết Gmail';
      }
      if (authBadgeEl) {
        if (hasAccount) {
          authBadgeEl.className = 'text-[10px] bg-emerald-100 text-emerald-700 border border-emerald-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 max-w-[190px] truncate';
        } else {
          authBadgeEl.className = 'text-[10px] bg-slate-100 text-slate-700 hover:bg-blue-50 hover:text-blue-700 border border-slate-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 max-w-[190px] truncate cursor-pointer transition-all';
        }
      }

      const profileInitialEl = document.getElementById('user-avatar-initial');
      const profileImgEl = document.getElementById('user-avatar-img');
      if (profileInitialEl && profileImgEl) {
        if (APP_STATE.userAvatar) {
          profileImgEl.src = APP_STATE.userAvatar;
          profileImgEl.classList.remove('hidden');
          profileInitialEl.classList.add('hidden');
        } else {
          profileInitialEl.innerText = initial;
          profileInitialEl.classList.remove('hidden');
          profileImgEl.classList.add('hidden');
        }
      }
    }

    // Modal Triggers
    function openRegisterModal(isOnboarding = false) {
      APP_STATE.isOnboardingActive = isOnboarding;

      // Đóng tất cả các modal khác để modal tạo tài khoản luôn hiển thị trên cùng và không bị che khuất
      const authModal = document.getElementById('account-auth-modal');
      if (authModal) authModal.classList.add('hidden');
      const switchModal = document.getElementById('switch-account-modal');
      if (switchModal) switchModal.classList.add('hidden');
      const editModal = document.getElementById('edit-profile-modal');
      if (editModal) editModal.classList.add('hidden');
      const assessmentModal = document.getElementById('assessment-modal');
      if (assessmentModal) assessmentModal.classList.add('hidden');
      const reflectionModal = document.getElementById('reflection-modal');
      if (reflectionModal) reflectionModal.classList.add('hidden');

      const modal = document.getElementById('register-modal');
      const closeBtn = document.getElementById('register-modal-close-btn');
      const cancelBtn = document.getElementById('reg-cancel-btn');
      const titleEl = document.getElementById('register-modal-title');
      const subtitleEl = document.getElementById('register-modal-subtitle');

      const isForced = !APP_STATE.userEmail || !APP_STATE.userName || !APP_STATE.isAuthenticated;

      if (closeBtn) {
        if (isForced && (!APP_STATE.userEmail || !APP_STATE.userName)) {
          closeBtn.classList.add('hidden');
        } else {
          closeBtn.classList.remove('hidden');
        }
      }
      if (cancelBtn) {
        if (isForced && (!APP_STATE.userEmail || !APP_STATE.userName)) {
          cancelBtn.classList.add('hidden');
        } else {
          cancelBtn.classList.remove('hidden');
          cancelBtn.innerText = "Huỷ";
        }
      }

      if (isOnboarding || (!APP_STATE.userEmail || !APP_STATE.userName)) {
        if (titleEl) titleEl.innerText = "CHÀO MỪNG ĐẾN VỚI BRAIN FOCUS";
        if (subtitleEl) subtitleEl.innerText = "Bước 1/2: Đăng ký & Đặt mật khẩu bảo vệ tài khoản";
      } else {
        if (titleEl) titleEl.innerText = "TẠO TÀI KHOẢN HỌC VIÊN";
        if (subtitleEl) subtitleEl.innerText = "Nhận ngay 1000 điểm xếp hạng gốc";
      }

      // Reset các trường nhập liệu khi mở modal
      const regEmailInput = document.getElementById('reg-input-email');
      const regNameInput = document.getElementById('reg-input-name');
      const regSchoolInput = document.getElementById('reg-input-school');
      const regPasswordInput = document.getElementById('reg-input-password');
      const errorMsgBox = document.getElementById('reg-error-msg');
      if (errorMsgBox) errorMsgBox.classList.add('hidden');

      if (isOnboarding || (!APP_STATE.userEmail || !APP_STATE.userName)) {
        if (regEmailInput) {
          regEmailInput.value = APP_STATE.userEmail || '';
          handleRegEmailInput(regEmailInput.value);
        }
        if (regNameInput) regNameInput.value = APP_STATE.userName || '';
        if (regSchoolInput) regSchoolInput.value = APP_STATE.userSchool || '';
        if (regPasswordInput) regPasswordInput.value = APP_STATE.userPassword || '';
      } else {
        // Mở từ nút tạo tài khoản mới: dọn sạch trường để nhập tài khoản mới
        if (regEmailInput) {
          regEmailInput.value = '';
          handleRegEmailInput('');
        }
        if (regNameInput) regNameInput.value = '';
        if (regSchoolInput) regSchoolInput.value = '';
        if (regPasswordInput) regPasswordInput.value = '';
        tempUploadedAvatarBase64 = null;
        const imgEl = document.getElementById('reg-avatar-img');
        const initEl = document.getElementById('reg-avatar-initial');
        if (imgEl && initEl) {
          imgEl.src = '';
          imgEl.classList.add('hidden');
          initEl.innerText = '👤';
          initEl.classList.remove('hidden');
        }
      }

      modal.classList.remove('hidden');
      modal.style.display = 'flex';
      setTimeout(() => {
        if (regEmailInput) regEmailInput.focus();
      }, 150);
    }

    function closeRegisterModal() {
      const modal = document.getElementById('register-modal');
      if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
      }
      try {
        localStorage.setItem('bf_onboarded_completed', 'true');
      } catch (_) {}

      // Nếu chưa được xác thực mật khẩu
      if (!APP_STATE.isAuthenticated) {
        if (!APP_STATE.userEmail || !APP_STATE.userName) {
          openRegisterModal(true);
        } else {
          loadUsersDatabase();
          const targetUser = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === (APP_STATE.userEmail || '').toLowerCase().trim()) || {
            email: APP_STATE.userEmail,
            name: APP_STATE.userName,
            avatar: APP_STATE.userAvatar,
            password: APP_STATE.userPassword
          };
          openAccountAuthModal(targetUser, true);
        }
      }
    }

    function openEditProfileModal() {
      document.getElementById('edit-input-name').value = APP_STATE.userName || '';
      document.getElementById('edit-input-school').value = APP_STATE.userSchool || '';
      const editEmailInput = document.getElementById('edit-input-email');
      if (editEmailInput) {
        editEmailInput.value = APP_STATE.userEmail || '';
        handleEditEmailInput(editEmailInput.value);
      }
      
      const prevImg = document.getElementById('edit-avatar-img');
      const prevInit = document.getElementById('edit-avatar-initial');
      if (APP_STATE.userAvatar) {
        prevImg.src = APP_STATE.userAvatar;
        prevImg.classList.remove('hidden');
        prevInit.classList.add('hidden');
      } else {
        prevInit.innerText = (APP_STATE.userName || 'T').charAt(0).toUpperCase();
        prevInit.classList.remove('hidden');
        prevImg.classList.add('hidden');
      }

      document.getElementById('edit-profile-modal').classList.remove('hidden');
    }

    function closeEditProfileModal() {
      document.getElementById('edit-profile-modal').classList.add('hidden');
    }

    function openAvatarCustomizer() {
      openEditProfileModal();
    }

    // Handle Image file upload via FileReader (tempUploadedAvatarBase64 hoisted at top of script)
    // tempUploadedAvatarBase64 is declared globally

    function handleAvatarFileUpload(event, type) {
      const file = event.target.files[0];
      if (!file) return;

      if (!file.type.startsWith('image/')) {
        alert('Vui lòng chọn tệp hình ảnh hợp lệ (PNG, JPG, JPEG, WEBP).');
        return;
      }

      const reader = new FileReader();
      reader.onload = function(e) {
        const base64Data = e.target.result;
        tempUploadedAvatarBase64 = base64Data;

        if (type === 'reg') {
          const imgEl = document.getElementById('reg-avatar-img');
          const initEl = document.getElementById('reg-avatar-initial');
          if (imgEl && initEl) {
            imgEl.src = base64Data;
            imgEl.classList.remove('hidden');
            initEl.classList.add('hidden');
          }
        } else if (type === 'edit') {
          const imgEl = document.getElementById('edit-avatar-img');
          const initEl = document.getElementById('edit-avatar-initial');
          if (imgEl && initEl) {
            imgEl.src = base64Data;
            imgEl.classList.remove('hidden');
            initEl.classList.add('hidden');
          }
        }
      };
      reader.readAsDataURL(file);
    }

    function removeCustomAvatar() {
      tempUploadedAvatarBase64 = "";
      const imgEl = document.getElementById('edit-avatar-img');
      const initEl = document.getElementById('edit-avatar-initial');
      if (imgEl && initEl) {
        imgEl.src = "";
        imgEl.classList.add('hidden');
        initEl.innerText = (document.getElementById('edit-input-name').value || 'T').charAt(0).toUpperCase();
        initEl.classList.remove('hidden');
      }
    }

    // ================= XÁC THỰC ĐỊNH DẠNG GMAIL =================
    function validateGmailAddress(rawEmail) {
      let email = String(rawEmail || '').trim().toLowerCase();
      if (!email) {
        return { valid: false, message: 'Vui lòng nhập địa chỉ Gmail của bạn.' };
      }

      // 1. Tuyệt đối không chứa khoảng trắng
      if (/\s/.test(email)) {
        return { valid: false, message: 'Địa chỉ Gmail không được chứa dấu cách (khoảng trống).' };
      }

      // Tự động gợi ý/yêu cầu @gmail.com
      if (!email.includes('@')) {
        return {
          valid: false,
          message: 'Vui lòng điền đầy đủ đuôi "@gmail.com" (Ví dụ: ' + email + '@gmail.com).'
        };
      }

      const parts = email.split('@');
      if (parts.length !== 2) {
        return { valid: false, message: 'Địa chỉ email không hợp lệ (chỉ được có đúng 1 ký tự @).' };
      }

      const username = parts[0];
      const domain = parts[1];

      if (domain !== 'gmail.com') {
        return {
          valid: false,
          message: `Ứng dụng yêu cầu tài khoản Gmail có đuôi "@gmail.com" (hiện tại là "@${domain}").`
        };
      }

      // Độ dài username theo Google (ít nhất 3 ký tự, tối đa 30)
      if (username.length < 3) {
        return {
          valid: false,
          message: `Tên Gmail quá ngắn (${username.length} ký tự). Tối thiểu từ 3 ký tự trở lên.`
        };
      }
      if (username.length > 30) {
        return {
          valid: false,
          message: `Tên Gmail quá dài (${username.length} ký tự). Tối đa 30 ký tự.`
        };
      }

      if (username.startsWith('.') || username.endsWith('.')) {
        return { valid: false, message: 'Tên Gmail không được bắt đầu hoặc kết thúc bằng dấu chấm (.).' };
      }
      if (username.includes('..')) {
        return { valid: false, message: 'Tên Gmail không được chứa 2 dấu chấm liên tiếp (..).' };
      }

      // Ký tự hợp lệ cho username Gmail: a-z, 0-9, dấu chấm
      const validCharsRegex = /^[a-z0-9.]+$/;
      if (!validCharsRegex.test(username)) {
        return {
          valid: false,
          message: 'Tên Gmail chỉ chứa chữ cái không dấu (a-z), chữ số (0-9) và dấu chấm (.).'
        };
      }

      return { valid: true, email: email, username: username };
    }

    // Phản hồi thời gian thực khi người dùng gõ email tại Modal Đăng Ký
    function handleRegEmailInput(val) {
      const trimmed = String(val || '').trim().toLowerCase();
      const feedbackEl = document.getElementById('reg-email-feedback');
      const inputEl = document.getElementById('reg-input-email');
      const quickBtn = document.getElementById('reg-email-quick-suffix-btn');

      if (!inputEl) return;

      // Hiển thị nút bấm nhanh "+ @gmail.com" nếu người dùng gõ tên mà chưa có @
      if (trimmed.length > 0 && !trimmed.includes('@')) {
        if (quickBtn) quickBtn.classList.remove('hidden');
      } else {
        if (quickBtn) quickBtn.classList.add('hidden');
      }

      if (!trimmed) {
        inputEl.className = 'w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors';
        if (feedbackEl) {
          feedbackEl.className = 'text-[11px] mt-1.5 transition-all text-slate-500 flex items-start gap-1 leading-tight';
          feedbackEl.innerHTML = '<span>💡</span> <span>Định dạng chuẩn: <strong>tentaikhoan@gmail.com</strong> (chỉ chữ thường, số, dấu chấm; từ 6 - 30 ký tự trước @)</span>';
        }
        return;
      }

      const res = validateGmailAddress(trimmed);
      if (res.valid) {
        inputEl.className = 'w-full text-xs bg-emerald-50/50 border-2 border-emerald-500 rounded-xl px-3.5 py-2.5 text-slate-900 focus:ring-2 focus:ring-emerald-400 focus:outline-none transition-colors';
        if (feedbackEl) {
          feedbackEl.className = 'text-[11px] mt-1.5 transition-all text-emerald-600 font-bold flex items-center gap-1 leading-tight';
          feedbackEl.innerHTML = `<span>✅</span> <span>Địa chỉ Gmail hợp lệ (${res.username}@gmail.com)</span>`;
        }
      } else {
        inputEl.className = 'w-full text-xs bg-rose-50/50 border-2 border-rose-400 rounded-xl px-3.5 py-2.5 text-slate-900 focus:ring-2 focus:ring-rose-400 focus:outline-none transition-colors';
        if (feedbackEl) {
          feedbackEl.className = 'text-[11px] mt-1.5 transition-all text-rose-600 font-bold flex items-start gap-1 leading-snug';
          feedbackEl.innerHTML = `<span>⚠️</span> <span>${res.message}</span>`;
        }
      }
    }

    // Tự động gắn đuôi @gmail.com khi nhấn nút gợi ý
    function appendRegGmailSuffix() {
      const inputEl = document.getElementById('reg-input-email');
      if (!inputEl) return;
      let val = inputEl.value.trim();
      if (!val.includes('@')) {
        val = val.replace(/[^a-zA-Z0-9.]/g, '').toLowerCase() + '@gmail.com';
        inputEl.value = val;
        handleRegEmailInput(val);
        inputEl.focus();
      }
    }

    // Phản hồi thời gian thực khi chỉnh sửa email tại Modal Chỉnh Sửa Hồ Sơ
    function handleEditEmailInput(val) {
      const trimmed = String(val || '').trim().toLowerCase();
      const feedbackEl = document.getElementById('edit-email-feedback');
      const inputEl = document.getElementById('edit-input-email');
      if (!inputEl) return;

      if (!trimmed) {
        inputEl.className = 'w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors';
        if (feedbackEl) {
          feedbackEl.className = 'text-[11px] mt-1.5 transition-all text-slate-500 flex items-start gap-1 leading-tight';
          feedbackEl.innerHTML = '<span>💡</span> <span>Bắt buộc tài khoản Google có đuôi @gmail.com</span>';
        }
        return;
      }

      const res = validateGmailAddress(trimmed);
      if (res.valid) {
        inputEl.className = 'w-full text-xs bg-emerald-50/50 border-2 border-emerald-500 rounded-xl px-3.5 py-2.5 text-slate-900 focus:ring-2 focus:ring-emerald-400 focus:outline-none transition-colors';
        if (feedbackEl) {
          feedbackEl.className = 'text-[11px] mt-1.5 transition-all text-emerald-600 font-bold flex items-center gap-1 leading-tight';
          feedbackEl.innerHTML = `<span>✅</span> <span>Gmail hợp lệ (${res.username}@gmail.com)</span>`;
        }
      } else {
        inputEl.className = 'w-full text-xs bg-rose-50/50 border-2 border-rose-400 rounded-xl px-3.5 py-2.5 text-slate-900 focus:ring-2 focus:ring-rose-400 focus:outline-none transition-colors';
        if (feedbackEl) {
          feedbackEl.className = 'text-[11px] mt-1.5 transition-all text-rose-600 font-bold flex items-start gap-1 leading-snug';
          feedbackEl.innerHTML = `<span>⚠️</span> <span>${res.message}</span>`;
        }
      }
    }

    // Submission Handlers
    function showRegisterError(msg) {
      const errorBox = document.getElementById('reg-error-msg');
      const errorText = document.getElementById('reg-error-text');
      if (errorBox && errorText) {
        errorText.innerText = msg;
        errorBox.classList.remove('hidden');
        errorBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } else {
        alert(msg);
      }
    }

    function handleRegisterSubmit(e) {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }

      const errorBox = document.getElementById('reg-error-msg');
      if (errorBox) errorBox.classList.add('hidden');

      const emailInput = document.getElementById('reg-input-email');
      const rawEmail = (emailInput ? emailInput.value : '').trim();
      const nameInput = document.getElementById('reg-input-name');
      const name = (nameInput ? nameInput.value : '').trim();
      const school = (document.getElementById('reg-input-school')?.value || '').trim() || 'Người học tập trung';
      const passwordInput = document.getElementById('reg-input-password');
      const password = passwordInput ? passwordInput.value.trim() : '';
      
      // 1. Kiểm tra chuẩn định dạng Gmail
      const gmailCheck = validateGmailAddress(rawEmail);
      if (!gmailCheck.valid) {
        showRegisterError(gmailCheck.message);
        if (emailInput) {
          emailInput.focus();
          emailInput.select();
        }
        handleRegEmailInput(rawEmail);
        return false;
      }
      const email = gmailCheck.email;

      if (!name || name.length < 2) {
        showRegisterError('Vui lòng điền họ và tên của bạn (tối thiểu 2 ký tự).');
        if (nameInput) nameInput.focus();
        return false;
      }

      if (!password || password.length < 4) {
        showRegisterError('Vui lòng nhập mật khẩu tối thiểu 4 ký tự để bảo vệ tài khoản.');
        if (passwordInput) passwordInput.focus();
        return false;
      }

      try {
        // 2. Lưu lại tài khoản hiện tại vào DB trước khi chuyển sang tài khoản mới
        syncCurrentUserToDatabase();
        loadUsersDatabase();

        // 3. Kiểm tra xem email này đã từng được tạo trên thiết bị chưa
        const existingUser = REGISTERED_USERS_DB.find(u => u.email.toLowerCase().trim() === email.toLowerCase().trim());
        
        if (existingUser) {
          // Nếu tài khoản cũ đã có mật khẩu và mật khẩu nhập vào không khớp
          if (existingUser.password && String(existingUser.password).trim() !== password) {
            showRegisterError('Email Gmail này đã đăng ký nhưng mật khẩu không khớp. Vui lòng nhập đúng mật khẩu đã tạo!');
            if (passwordInput) {
              passwordInput.focus();
              passwordInput.select();
            }
            return false;
          }

          // Khôi phục tài khoản cũ với đầy đủ số điểm và tiến độ đã lưu
          APP_STATE.userEmail = existingUser.email;
          APP_STATE.userName = name || existingUser.name;
          APP_STATE.userSchool = school || existingUser.school;
          APP_STATE.userPassword = password || existingUser.password || '';
          APP_STATE.rankPoints = Number(existingUser.rankPoints) || 1000;
          APP_STATE.bfsScore = Number(existingUser.bfs) || 0;
          APP_STATE.sessionsCompletedCount = existingUser.sessionsCount || 0;
          APP_STATE.totalHours = existingUser.totalHours || 0;
          APP_STATE.streakDays = existingUser.streakDays || 1;
          APP_STATE.history = Array.isArray(existingUser.history) ? existingUser.history : [];
          if (tempUploadedAvatarBase64 !== null) {
            APP_STATE.userAvatar = tempUploadedAvatarBase64;
          } else if (existingUser.avatar) {
            APP_STATE.userAvatar = existingUser.avatar;
          }
        } else {
          // Tài khoản học viên mới: khởi tạo 1000 điểm Xếp Hạng gốc
          APP_STATE.userEmail = email;
          APP_STATE.userName = name;
          APP_STATE.userSchool = school;
          APP_STATE.userPassword = password;
          APP_STATE.rankPoints = 1000;
          APP_STATE.bfsScore = 0;
          APP_STATE.sessionsCompletedCount = 0;
          APP_STATE.totalHours = 0;
          APP_STATE.streakDays = 1;
          APP_STATE.history = [];
          if (tempUploadedAvatarBase64 !== null) {
            APP_STATE.userAvatar = tempUploadedAvatarBase64;
          } else {
            APP_STATE.userAvatar = '';
          }
        }

        // 4. Đánh dấu đã xác thực mật khẩu thành công & lưu vào DB
        APP_STATE.isAuthenticated = true;
        APP_STATE.isAuthModalStartupLock = false;
        saveAppStateToLocal();
        syncCurrentUserToDatabase();
        syncProfileDOM();
        updateStatsUI();
        renderLeaderboard();
        renderHistory();
        closeRegisterModal();
        
        // Nếu chưa có điểm BFS (tài khoản mới tạo), tự động mở bài test 10 câu BFS để tính điểm
        if (!APP_STATE.bfsScore) {
          setTimeout(() => {
            openAssessmentModal(false, true);
          }, 250);
        } else {
          alert(`🎉 Đã đăng nhập tài khoản Gmail: ${APP_STATE.userEmail}!\nTổng điểm xếp hạng hiện tại: ${(APP_STATE.rankPoints || 1000) + (APP_STATE.bfsScore || 0) + getSessionPointsTotal()}đ.`);
        }
      } catch (err) {
        console.error('Lỗi khi đăng ký tài khoản:', err);
        showRegisterError('Có lỗi xảy ra khi lưu tài khoản. Vui lòng thử lại!');
        return false;
      }
      return false;
    }

    async function handleEditProfileSubmit(e) {
      e.preventDefault();
      const nameInput = document.getElementById('edit-input-name');
      const name = (nameInput ? nameInput.value : '').trim();
      const school = (document.getElementById('edit-input-school')?.value || '').trim();
      const emailInput = document.getElementById('edit-input-email');
      const email = (emailInput ? emailInput.value : '').trim();
      const newPasswordInput = document.getElementById('edit-input-password');
      const newPassword = newPasswordInput ? newPasswordInput.value.trim() : '';
      const originalEmail = String(APP_STATE.userEmail || '').trim().toLowerCase();
      const previousPassword = String(APP_STATE.userPassword || '');

      if (!name) { alert('Vui lòng nhập họ và tên!'); nameInput?.focus(); return; }
      let normalizedEmail = originalEmail;
      if (email) {
        const gmailCheck = validateGmailAddress(email);
        if (!gmailCheck.valid) { alert('Cập nhật thất bại:\n' + gmailCheck.message); emailInput?.focus(); emailInput?.select(); handleEditEmailInput(email); return; }
        normalizedEmail = gmailCheck.email.toLowerCase();
      }
      if (newPassword && newPassword.length < 4) { alert('Mật khẩu mới phải có ít nhất 4 ký tự.'); return; }

      const serverAvailable = typeof bfCheckBackendHealth === 'function' ? await bfCheckBackendHealth() : false;
      if (serverAvailable && originalEmail) {
        if (!previousPassword) { alert('Không thể cập nhật dữ liệu máy chủ vì phiên local không có mật khẩu hiện tại. Hãy đăng nhập lại.'); return; }
        if (normalizedEmail && normalizedEmail !== originalEmail) {
          const r = await bfChangeUserEmail(originalEmail, normalizedEmail, previousPassword);
          if (!r?.success) { alert('Đổi email thất bại: ' + (r?.message || 'Không xác định')); return; }
        }
        if (newPassword) {
          const r = await bfChangeUserPassword(normalizedEmail || originalEmail, previousPassword, newPassword);
          if (!r?.success) { alert('Đổi mật khẩu thất bại: ' + (r?.message || 'Không xác định')); return; }
        }
      }

      APP_STATE.userEmail = normalizedEmail || originalEmail;
      APP_STATE.userName = name;
      if (school) APP_STATE.userSchool = school;
      if (newPassword) APP_STATE.userPassword = newPassword;
      if (tempUploadedAvatarBase64 !== null) APP_STATE.userAvatar = tempUploadedAvatarBase64;
      saveAppStateToLocal();
      if (typeof syncCurrentUserToDatabase === 'function') await syncCurrentUserToDatabase();
      syncProfileDOM(); updateStatsUI(); renderLeaderboard(); closeEditProfileModal();
      alert('✅ Đã cập nhật thành công thông tin hồ sơ!');
    }

    function handleGoogleLogin() {
      openRegisterModal();
    }

    // Chức năng xoá sạch toàn bộ tài khoản thử nghiệm & đặt lại ứng dụng như mới
    function resetAccountAndData() {
      if (confirm('Xác nhận xoá toàn bộ tài khoản thử nghiệm và dữ liệu đã lưu để tạo mới từ đầu?')) {
        try {
          localStorage.removeItem('bf_registered_users');
          localStorage.removeItem('bf_user_profile');
          localStorage.removeItem('bf_onboarded_completed');
          localStorage.removeItem('bf_active_session');
          localStorage.removeItem('bf_active_session_backup');
          localStorage.removeItem('bf_daily_tracker');
          localStorage.removeItem('bf_daily_gym_tracker');
          localStorage.removeItem('bf_cooldown_until');
          localStorage.removeItem('bf_cooldown_total_seconds');
          localStorage.removeItem('bf_restored_user_test_sessions');
        } catch (e) {}
        REGISTERED_USERS_DB = [];
        APP_STATE.userEmail = "";
        APP_STATE.userName = "";
        APP_STATE.userSchool = "";
        APP_STATE.userAvatar = "";
        APP_STATE.rankPoints = 1000;
        APP_STATE.bfsScore = 0;
        APP_STATE.totalHours = 0;
        APP_STATE.streakDays = 1;
        APP_STATE.sessionsCompletedCount = 0;
        APP_STATE.gymCompletedCount = 0;
        APP_STATE.history = [];
        saveAppStateToLocal();
        saveUsersDatabase();
        syncProfileDOM();
        updateStatsUI();
        renderLeaderboard();
        renderHistory();
        openRegisterModal(true);
        alert('✨ Đã xoá sạch toàn bộ tài khoản thử nghiệm! Vui lòng tạo tài khoản mới.');
      }
    }

    // Helper for personal statistics timeframe filtering
    window.adminpagentnFilterStatsTimeframe = function(days) {
      const btns = ['7', '30', '90', 'all'];
      btns.forEach(b => {
        const el = document.getElementById(`adminpagentn-tf-${b}`);
        if (el) {
          el.className = (b == days || (days >= 365 && b === 'all'))
            ? 'px-3 py-1 rounded-lg bg-white text-blue-900 shadow-xs'
            : 'px-3 py-1 rounded-lg text-slate-600 hover:text-slate-900';
        }
      });

      // Recalculate metrics from APP_STATE.history
      const history = (window.APP_STATE && Array.isArray(window.APP_STATE.history)) ? window.APP_STATE.history : [];
      const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
      const filtered = history.filter(h => (h.timestamp || h.id) >= cutoff);

      let totalIntegrity = 0;
      let integrityCount = 0;
      let deepCount = 0;

      filtered.forEach(h => {
        if (h.isDeepFocus) deepCount++;
        if (h.focusIntegrity !== undefined) {
          totalIntegrity += Number(h.focusIntegrity);
          integrityCount++;
        }
      });

      const avgIntegrityEl = document.getElementById('stat-avg-integrity');
      const deepCountEl = document.getElementById('stat-deep-focus-count');
      if (avgIntegrityEl) {
        avgIntegrityEl.innerText = integrityCount > 0 ? `${Math.round(totalIntegrity / integrityCount)}/100` : '98/100';
      }
      if (deepCountEl) {
        deepCountEl.innerText = `${deepCount} phiên`;
      }
    };
