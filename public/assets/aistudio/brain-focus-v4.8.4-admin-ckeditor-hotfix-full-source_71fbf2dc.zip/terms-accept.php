<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/includes/terms.php';
$user=bfCurrentUser($pdo);
if(!$user){header('Location:/login.php?next='.urlencode('/terms-accept.php'));exit;}
$terms=bfCurrentTerms($pdo);if(!$terms){header('Location:/');exit;}
if(bfTermsAccepted($pdo,(int)$user['id'],(int)$terms['id'])){header('Location:/');exit;}
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    bfCheckUserCsrf();
    $scrolled=(string)($_POST['terms_scrolled']??'0');$accepted=isset($_POST['accepted']);
    if($scrolled!=='1'||!$accepted)$err='Bạn cần đọc đến cuối điều khoản và xác nhận đồng ý.';
    else{
        $reward=!empty($_SESSION['bf_new_user_terms_no_reward'])?0:max(0,(int)$terms['reward_xp']);
        $pdo->beginTransaction();
        try{
            $st=$pdo->prepare("INSERT INTO bf_terms_acceptances(user_id,terms_id,accepted_ip,user_agent,reward_xp) VALUES(?,?,?,?,?)");
            $st->execute([$user['id'],$terms['id'],bfRequestIp(),substr(bfUserAgent(),0,500),$reward]);
            if($reward>0){
                $pdo->prepare("UPDATE bf_users SET rank_points=rank_points+? WHERE id=?")->execute([$reward,$user['id']]);
                $pdo->prepare("INSERT INTO bf_point_transactions(user_id,points,point_type,reason_code,reason_text,ref_type,ref_id) VALUES(?,?,'RANK','TERMS_ACCEPT','Xác nhận điều khoản Brain Focus','TERMS',?)")->execute([$user['id'],$reward,(string)$terms['id']]);
            }
            $pdo->prepare("UPDATE bf_notifications SET is_read=1,read_at=NOW() WHERE user_email=? AND type='TERMS' AND link_url='/terms-accept.php'")->execute([$user['email']]);
            $pdo->commit();unset($_SESSION['bf_new_user_terms_no_reward']);
            header('Location:/?terms=accepted');exit;
        }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$err='Không thể lưu xác nhận. Có thể điều khoản đã được xác nhận ở phiên khác.';}
    }
}
?>
<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Xác nhận điều khoản · Brain Focus</title><script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><style>body{font-family:Inter,sans-serif}</style></head><body class="bg-slate-950 min-h-screen p-4 flex items-center justify-center"><div class="w-full max-w-3xl bg-white rounded-3xl overflow-hidden shadow-2xl"><div class="p-5 sm:p-6 bg-slate-900 text-white"><div class="text-xs text-amber-300 font-semibold">CẬP NHẬT ĐIỀU KHOẢN · +<?=number_format((int)$terms['reward_xp'])?> XP khi xác nhận</div><h1 class="font-black text-xl sm:text-2xl mt-1"><?=htmlspecialchars($terms['title'])?></h1><p class="text-xs text-slate-300 mt-1">Phiên bản <?=htmlspecialchars($terms['version'])?> · Bạn phải cuộn xuống cuối trước khi có thể xác nhận.</p></div><?php if($err):?><div class="mx-5 mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700"><?=htmlspecialchars($err)?></div><?php endif;?><div id="terms-scroll" class="m-5 sm:m-6 h-[55vh] overflow-y-auto border border-slate-200 rounded-2xl p-4 sm:p-5 bg-slate-50"><?=$terms['content_html']?></div><form method="post" class="px-5 sm:px-6 pb-6"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(bfUserCsrf())?>"><input type="hidden" id="terms-scrolled" name="terms_scrolled" value="0"><label id="accept-wrap" class="flex items-start gap-3 p-4 rounded-2xl border border-slate-200 bg-slate-50 opacity-50 cursor-not-allowed"><input id="accept-box" type="checkbox" name="accepted" disabled class="mt-1"><span class="text-sm"><b>Tôi xác nhận đã đọc hết và đồng ý với Điều khoản sử dụng & Chính sách bảo vệ dữ liệu Brain Focus.</b><span id="scroll-hint" class="block text-xs text-slate-500 mt-1">Cuộn xuống cuối nội dung để mở khóa xác nhận.</span></span></label><button id="accept-btn" disabled class="mt-3 w-full rounded-xl py-3 bg-slate-900 text-white font-bold disabled:opacity-40">Đồng ý & tiếp tục sử dụng Brain Focus</button></form></div><script>const sc=document.getElementById('terms-scroll'),cb=document.getElementById('accept-box'),hid=document.getElementById('terms-scrolled'),wrap=document.getElementById('accept-wrap'),btn=document.getElementById('accept-btn'),hint=document.getElementById('scroll-hint');function unlock(){if(sc.scrollTop+sc.clientHeight>=sc.scrollHeight-8){cb.disabled=false;hid.value='1';wrap.classList.remove('opacity-50','cursor-not-allowed');hint.textContent='Bạn đã đọc đến cuối. Hãy tích xác nhận để tiếp tục.'}}sc.addEventListener('scroll',unlock);unlock();cb.addEventListener('change',()=>btn.disabled=!cb.checked);</script></body></html>
